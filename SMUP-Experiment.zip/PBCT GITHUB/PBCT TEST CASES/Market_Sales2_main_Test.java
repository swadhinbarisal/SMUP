
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class Market_Sales2_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public Market_Sales2_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(-1086252198);
        input[i++] = new Integer(-241834331);
        input[i++] = new Integer(736932474);
        input[i++] = new Integer(507327656);
        input[i++] = new Integer(472070540);
        input[i++] = new Integer(-442483622);
        input[i++] = new Integer(1835339530);
        i=0;
        cute.Cute.input = this;
        Market_Sales2.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(736932474);
        input[i++] = new Integer(507327656);
        input[i++] = new Integer(472070540);
        input[i++] = new Integer(-442483622);
        input[i++] = new Integer(1835339530);
        i=0;
        cute.Cute.input = this;
        Market_Sales2.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(736932474);
        input[i++] = new Integer(507327656);
        input[i++] = new Integer(472070540);
        input[i++] = new Integer(-442483622);
        input[i++] = new Integer(1835339530);
        i=0;
        cute.Cute.input = this;
        Market_Sales2.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(400);
        input[i++] = new Integer(736932474);
        input[i++] = new Integer(507327656);
        input[i++] = new Integer(472070540);
        input[i++] = new Integer(-442483622);
        input[i++] = new Integer(1835339530);
        i=0;
        cute.Cute.input = this;
        Market_Sales2.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(400);
        input[i++] = new Integer(400);
        input[i++] = new Integer(736932474);
        input[i++] = new Integer(507327656);
        input[i++] = new Integer(472070540);
        input[i++] = new Integer(-442483622);
        input[i++] = new Integer(1835339530);
        i=0;
        cute.Cute.input = this;
        Market_Sales2.main(null);
    }

    public void test66(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(400);
        input[i++] = new Integer(736932474);
        input[i++] = new Integer(507327656);
        input[i++] = new Integer(472070540);
        input[i++] = new Integer(1);
        input[i++] = new Integer(1835339530);
        i=0;
        cute.Cute.input = this;
        Market_Sales2.main(null);
    }

    public void test67(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(400);
        input[i++] = new Integer(736932474);
        input[i++] = new Integer(507327656);
        input[i++] = new Integer(472070540);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        Market_Sales2.main(null);
    }

    public void test69(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(736932474);
        input[i++] = new Integer(507327656);
        input[i++] = new Integer(472070540);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        Market_Sales2.main(null);
    }

    public void test72(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(400);
        input[i++] = new Integer(400);
        input[i++] = new Integer(736932474);
        input[i++] = new Integer(507327656);
        input[i++] = new Integer(472070540);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        Market_Sales2.main(null);
    }

}
