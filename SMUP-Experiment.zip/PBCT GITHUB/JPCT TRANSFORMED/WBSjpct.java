package jpct;

import cute.Cute;

/**
 *  .
 * User: ksen
 * Date: Oct 25, 2005
 * Time: 7:38:52 PM
 * To change this template use File | Settings | File Templates.
 */



public class WBSjpct {

	//Internal state
	private int PRE;
	private int PRE1;
	private int PRE2;

	//Outputs
	private int Nor_Pressure;
	private int Alt_Pressure;
	private int Sys_Mode;

	public WBSjpct() {
		PRE = Cute.input.Integer();
		PRE1 =Cute.input.Integer();
		PRE2 = Cute.input.Integer();
		Nor_Pressure = Cute.input.Integer();
		Alt_Pressure = Cute.input.Integer();
		Sys_Mode = Cute.input.Integer();
	}

	public void update(int PedalPos, boolean AutoBrake,
			boolean Skid) {
		int AS_MeterValve_Switch;
		int AccumulatorValve_Switch;
		int AntiSkidCommand_Normal_Switch;
		boolean Is_Normal_Relational_Operator;
		int PedalCommand_Switch1;
		int Switch;
		boolean _Operator6;
		int Unit_Delay;
		int witch2;
		int witch3;
		int Unit_Delay1;
		int Green_Pump_IsolationValve_Switch;
		int SelectorValve_Switch;
		int SelectorValve_Switch1;
		int Unit_Delay2;

	   Unit_Delay2 = PRE2;
	   Unit_Delay1 = PRE1;
	   Unit_Delay = PRE;

	   Is_Normal_Relational_Operator = (Unit_Delay == 0);

	   if ((PedalPos == 0)) {
		      PedalCommand_Switch1 =  Cute.input.Integer(); // node 6
		   } else {
			   if ((PedalPos == 1)) {
			      PedalCommand_Switch1 = Cute.input.Integer();
			   }  else {
				   if ((PedalPos == 2)) {
				      PedalCommand_Switch1 =  Cute.input.Integer();
				   } else {
					   if ((PedalPos == 3)) {
					      PedalCommand_Switch1 =  Cute.input.Integer();
					   } else {
						   if ((PedalPos == 4)) {
						      PedalCommand_Switch1 =  Cute.input.Integer();
						   }  else {
						      PedalCommand_Switch1 =  Cute.input.Integer();
						   }
					   }
				   }
			   }
		   }

Switch = 1;
	   _Operator6 = true;

	   if (_Operator6) {
	      if (Skid)
	         witch3 = 0;
	      else
	         witch3 = 4;
	   }
	   else {
	      witch3 = 4;
	    }

	   if (_Operator6) {
	      Green_Pump_IsolationValve_Switch = 0;
	   }  else {
	      Green_Pump_IsolationValve_Switch = 5;
	    }

	   if ((Green_Pump_IsolationValve_Switch >= 1)) {
	      SelectorValve_Switch1 = 0;
	   }
	   else {
	      SelectorValve_Switch1 = 5;
	   }

	   if ((!_Operator6)) {
	      AccumulatorValve_Switch = 0;
	   }  else {
		   if ((SelectorValve_Switch1 >= 1)) {
		      AccumulatorValve_Switch = SelectorValve_Switch1;
		   }
		   else {
		      AccumulatorValve_Switch = 5;
		   }
	   }

	   if ((witch3 == 0)) {
	      AS_MeterValve_Switch = 0;
	   }  else {
		   if ((witch3 == 1))  {
		      AS_MeterValve_Switch = (AccumulatorValve_Switch / 4);
		   }  else {
			   if ((witch3 == 2))  {
			      AS_MeterValve_Switch = (AccumulatorValve_Switch / 2);
			   }  else {
				   if ((witch3 == 3)) {
				      AS_MeterValve_Switch = ((AccumulatorValve_Switch / 4) * 3);
				   }  else {
					   if ((witch3 == 4)) {
					      AS_MeterValve_Switch = AccumulatorValve_Switch;
					   }  else {
					      AS_MeterValve_Switch = 0;
					   }
				   }
			   }
		   }
	   }

	   if (Skid) {
	      AntiSkidCommand_Normal_Switch = 0;
	   }  else {
	      AntiSkidCommand_Normal_Switch = (Switch+PedalCommand_Switch1);
	   }

	   if (_Operator6) {
	      Sys_Mode = 1;
	   }  else {
	      Sys_Mode = 0;
	   }

	   if (_Operator6) {
	      witch2 = 0;
	   }  else {
//******************Transformed code started****************************
if(AntiSkidCommand_Normal_Switch>=0){
if(AntiSkidCommand_Normal_Switch<1){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		   if (((AntiSkidCommand_Normal_Switch >= 0) &&(AntiSkidCommand_Normal_Switch < 1))) {
		      witch2 = 0;
		   } else {
//******************Transformed code started****************************
if(AntiSkidCommand_Normal_Switch>=1){
if(AntiSkidCommand_Normal_Switch<2){}
 else{}
 }
 else {}
//******************Transformed code end****************************
			   if (((AntiSkidCommand_Normal_Switch >= 1) &&(AntiSkidCommand_Normal_Switch < 2)))  {
			      witch2 = 1;
			   }  else {
//******************Transformed code started****************************
if(AntiSkidCommand_Normal_Switch>=2){
if(AntiSkidCommand_Normal_Switch<3){}
 else{}
 }
 else {}
//******************Transformed code end****************************
				   if (((AntiSkidCommand_Normal_Switch >= 2) &&(AntiSkidCommand_Normal_Switch < 3))) {
				      witch2 = 2;
				   } else {
//******************Transformed code started****************************
if(AntiSkidCommand_Normal_Switch>=3){
if(AntiSkidCommand_Normal_Switch<4){}
 else{}
 }
 else {}
//******************Transformed code end****************************
					   if (((AntiSkidCommand_Normal_Switch >= 3) &&(AntiSkidCommand_Normal_Switch < 4)))  {
					      witch2 = 3;
					   } else {
					      witch2 = 4;
					   }
				   }
			   }
		   }
	   }

	   if ((Green_Pump_IsolationValve_Switch >= 1))  {
	      SelectorValve_Switch = Green_Pump_IsolationValve_Switch;
	   }  else {
	      SelectorValve_Switch = 0;
	   }

	   if ((witch2 == 0)) {
	      Nor_Pressure = 0;
	   }  else {
		   if ((witch2 == 1)) {
		      Nor_Pressure = (SelectorValve_Switch / 4);
		   }  else {
			   if ((witch2 == 2)) {
			      Nor_Pressure = (SelectorValve_Switch / 2);
			   }  else {
				   if ((witch2 == 3)) {
				      Nor_Pressure = ((SelectorValve_Switch / 4) * 3);
				   } else {
					   if ((witch2 == 4)) {
					      Nor_Pressure = SelectorValve_Switch;
					   } else {
					      Nor_Pressure = 0;
					   }
				   }
			   }
		   }
	   }

	   if ((PedalCommand_Switch1 == 0)) {
	      Alt_Pressure = 0;   // node 89
	   }  else {
		   if ((PedalCommand_Switch1 == 1)) {
		      Alt_Pressure = (AS_MeterValve_Switch / 4);
		   }  else {
			   if ((PedalCommand_Switch1 == 2)) {
			      Alt_Pressure = (AS_MeterValve_Switch / 2);
			   } else {
				   if ((PedalCommand_Switch1 == 3)) {
				      Alt_Pressure = ((AS_MeterValve_Switch / 4) * 3);
				   } else {
					   if ((PedalCommand_Switch1 == 4)) {
					      Alt_Pressure = AS_MeterValve_Switch;
					   } else {
					      Alt_Pressure = 0;
					   }
				   }
			   }
		   }
	   }

	   PRE2 = Nor_Pressure;

	   PRE1 = witch2;

	   PRE = Sys_Mode;

	}

	public static void main(String[] args) {
		WBSjpct wBS_orig = new WBSjpct();

	
		int PedalPos = 0;
		boolean AutoBrake = true;
		boolean Skid = true;

		wBS_orig.update(PedalPos, AutoBrake, Skid);


        //new code
		PedalPos = 0;
		AutoBrake = true;
		Skid = true;

		wBS_orig.update(PedalPos, AutoBrake, Skid);

		//PedalPos = Debug.getSymbolicInteger(0, 4, "PedalPos_3");
		//AutoBrake = Debug.getSymbolicBoolean("AutoBrake_3");
		//Skid = Debug.getSymbolicBoolean("Skid_3");

		//new code
		PedalPos = 0;
		AutoBrake = true;
		Skid = true;

		wBS_orig.update(PedalPos, AutoBrake, Skid);

		

		//new code
		PedalPos = 0;
		AutoBrake = true;
		Skid = true;

		wBS_orig.update(PedalPos, AutoBrake, Skid);

		
	}
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
