
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class Bank_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public Bank_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[12];
        input[i++] = new Integer(1358268290);
        input[i++] = new Integer(1814083626);
        input[i++] = new Integer(-1006200624);
        input[i++] = new Integer(-389904369);
        input[i++] = new Integer(-1118739371);
        input[i++] = new Integer(-1635975790);
        input[i++] = new Integer(905951383);
        input[i++] = new Integer(-2099112854);
        input[i++] = new Integer(1342634846);
        input[i++] = new Integer(1969022307);
        input[i++] = new Integer(-494688367);
        input[i++] = new Integer(1832370662);
        i=0;
        cute.Cute.input = this;
        Bank.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[12];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1814083626);
        input[i++] = new Integer(-1006200624);
        input[i++] = new Integer(-389904369);
        input[i++] = new Integer(-1118739371);
        input[i++] = new Integer(-1635975790);
        input[i++] = new Integer(905951383);
        input[i++] = new Integer(-2099112854);
        input[i++] = new Integer(1342634846);
        input[i++] = new Integer(1969022307);
        input[i++] = new Integer(-494688367);
        input[i++] = new Integer(1832370662);
        i=0;
        cute.Cute.input = this;
        Bank.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[16];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1006200624);
        input[i++] = new Integer(-389904369);
        input[i++] = new Integer(-1118739371);
        input[i++] = new Integer(-1635975790);
        input[i++] = new Integer(905951383);
        input[i++] = new Integer(-2099112854);
        input[i++] = new Integer(1342634846);
        input[i++] = new Integer(1969022307);
        input[i++] = new Integer(-494688367);
        input[i++] = new Integer(1832370662);
        input[i++] = new Integer(-2091405672);
        input[i++] = new Integer(1540142179);
        input[i++] = new Integer(1188361787);
        input[i++] = new Integer(-410499109);
        i=0;
        cute.Cute.input = this;
        Bank.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[16];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(441);
        input[i++] = new Integer(-389904369);
        input[i++] = new Integer(-1118739371);
        input[i++] = new Integer(-1635975790);
        input[i++] = new Integer(905951383);
        input[i++] = new Integer(-2099112854);
        input[i++] = new Integer(1342634846);
        input[i++] = new Integer(1969022307);
        input[i++] = new Integer(-494688367);
        input[i++] = new Integer(1832370662);
        input[i++] = new Integer(-2091405672);
        input[i++] = new Integer(1540142179);
        input[i++] = new Integer(1188361787);
        input[i++] = new Integer(-410499109);
        i=0;
        cute.Cute.input = this;
        Bank.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[16];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(441);
        input[i++] = new Integer(701);
        input[i++] = new Integer(-1118739371);
        input[i++] = new Integer(-1635975790);
        input[i++] = new Integer(905951383);
        input[i++] = new Integer(-2099112854);
        input[i++] = new Integer(1342634846);
        input[i++] = new Integer(1969022307);
        input[i++] = new Integer(-494688367);
        input[i++] = new Integer(1832370662);
        input[i++] = new Integer(-2091405672);
        input[i++] = new Integer(1540142179);
        input[i++] = new Integer(1188361787);
        input[i++] = new Integer(-410499109);
        i=0;
        cute.Cute.input = this;
        Bank.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[16];
        input[i++] = new Integer(10);
        input[i++] = new Integer(0);
        input[i++] = new Integer(441);
        input[i++] = new Integer(701);
        input[i++] = new Integer(-1118739371);
        input[i++] = new Integer(-1635975790);
        input[i++] = new Integer(905951383);
        input[i++] = new Integer(-2099112854);
        input[i++] = new Integer(1342634846);
        input[i++] = new Integer(1969022307);
        input[i++] = new Integer(-494688367);
        input[i++] = new Integer(1832370662);
        input[i++] = new Integer(-2091405672);
        input[i++] = new Integer(1540142179);
        input[i++] = new Integer(1188361787);
        input[i++] = new Integer(-410499109);
        i=0;
        cute.Cute.input = this;
        Bank.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[12];
        input[i++] = new Integer(10);
        input[i++] = new Integer(46);
        input[i++] = new Integer(441);
        input[i++] = new Integer(701);
        input[i++] = new Integer(-1118739371);
        input[i++] = new Integer(-1635975790);
        input[i++] = new Integer(905951383);
        input[i++] = new Integer(-2099112854);
        input[i++] = new Integer(1342634846);
        input[i++] = new Integer(1969022307);
        input[i++] = new Integer(-494688367);
        input[i++] = new Integer(1832370662);
        i=0;
        cute.Cute.input = this;
        Bank.main(null);
    }

    public void test9(){
        i=0;
        input = new Object[8];
        input[i++] = new Integer(10);
        input[i++] = new Integer(46);
        input[i++] = new Integer(0);
        input[i++] = new Integer(701);
        input[i++] = new Integer(-1118739371);
        input[i++] = new Integer(-1635975790);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        Bank.main(null);
    }

    public void test11(){
        i=0;
        input = new Object[12];
        input[i++] = new Integer(80);
        input[i++] = new Integer(46);
        input[i++] = new Integer(0);
        input[i++] = new Integer(701);
        input[i++] = new Integer(-1118739371);
        input[i++] = new Integer(-1635975790);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1342634846);
        input[i++] = new Integer(1969022307);
        input[i++] = new Integer(-494688367);
        input[i++] = new Integer(1832370662);
        i=0;
        cute.Cute.input = this;
        Bank.main(null);
    }

    public void test18(){
        i=0;
        input = new Object[12];
        input[i++] = new Integer(0);
        input[i++] = new Integer(46);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1118739371);
        input[i++] = new Integer(-1635975790);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(1342634846);
        input[i++] = new Integer(1969022307);
        input[i++] = new Integer(-494688367);
        input[i++] = new Integer(1832370662);
        i=0;
        cute.Cute.input = this;
        Bank.main(null);
    }

    public void test63(){
        i=0;
        input = new Object[16];
        input[i++] = new Integer(0);
        input[i++] = new Integer(46);
        input[i++] = new Integer(441);
        input[i++] = new Integer(701);
        input[i++] = new Integer(-1118739371);
        input[i++] = new Integer(-1635975790);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(1342634846);
        input[i++] = new Integer(1969022307);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(-2091405672);
        input[i++] = new Integer(1540142179);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        Bank.main(null);
    }

}
