//package A1;

import cute.Cute;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

public class Problem1_RERS2014 {
	public Random random = new Random();
	static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

	private int[] inputs = {5 ,1 ,2 ,3 ,4 };

	public static int a164 = Cute.input.Integer();
	public static int a131 = Cute.input.Integer();
	public static int a100 = Cute.input.Integer();
	public static int a11 = Cute.input.Integer();
	public static int a110 = Cute.input.Integer();
	public static int a138 = Cute.input.Integer();
	public static int a93 = Cute.input.Integer();
	public static int a32 = Cute.input.Integer();
	public static int a8 = Cute.input.Integer();
	public static int a13 = Cute.input.Integer();
	public static int a70 = Cute.input.Integer();
	public static int a35 = Cute.input.Integer();
	public static int a158 = Cute.input.Integer();
	public static int a51 = Cute.input.Integer();
	public static int a162 = Cute.input.Integer();
	public static int a143 = Cute.input.Integer();
	public static int a48 = Cute.input.Integer();
	public static int a76 = Cute.input.Integer();
	public static int a99 = Cute.input.Integer();
	public static int a147 = Cute.input.Integer();
	public static int a118 = Cute.input.Integer();
	public static int a24 = Cute.input.Integer();
	public static int a153 = Cute.input.Integer();
	public static int a168 = Cute.input.Integer();
	public static int a146 = Cute.input.Integer();
	public static int a183 = Cute.input.Integer();
	public static int a133 = Cute.input.Integer();
	public static int a86 = Cute.input.Integer();
	public static int a60 = Cute.input.Integer();
	public static int a112 = Cute.input.Integer();
	public static int a134 = Cute.input.Integer();
	public static int a188 = Cute.input.Integer();
	public static int a57 = Cute.input.Integer();
	public static int a104 = Cute.input.Integer();
	public static int a129 = Cute.input.Integer();
	public static int a41 = Cute.input.Integer();
	public static int cf = Cute.input.Integer();
	public static int a182 = Cute.input.Integer();
	public static int a130 = Cute.input.Integer();
	public static int a43 = Cute.input.Integer();
	public static int a109 = Cute.input.Integer();
	public static int a200 = Cute.input.Integer();
	public static int a198 = Cute.input.Integer();
	public static int a192 = Cute.input.Integer();
	public static int a59 = Cute.input.Integer();
	public static int a177 = Cute.input.Integer();
	public static int a191 = Cute.input.Integer();

	private void errorCheck() {
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a112==13){
                      if(a162==12){
                       }
                   }
if(!(a112==13)){
       if(!(a86==6)){
                                      }
                   }
if(!(a112==13)){
       if(a86==6){
               if(a162==12){
                                  }
                            }
                      }
if(!(a112==13)){
       if(a86==6){
               if(!(a162==12)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a112==13) || (a86==6) && (a162==12)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_0" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a99==9){
       if(a57==7){
                                      }
                   }
if(!(a99==9)){
                      if(!(a162==9)){
                       }
                   }
if(a99==9){
       if(!(a57==7)){
               if(!(a162==9)){
                                  }
                            }
                      }
if(a99==9){
       if(!(a57==7)){
               if(a162==9){
                                  }
                            }
                      }
//*****************************************************************
	    if((a99==9) && (a57==7) ||(a162==9)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_1" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a146==3){
                      if(a162==12){
                       }
                   }
if(!(a146==3)){
       if(!(a86==10)){
                                      }
                   }
if(!(a146==3)){
       if(a86==10){
               if(a162==12){
                                  }
                            }
                      }
if(!(a146==3)){
       if(a86==10){
               if(!(a162==12)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a146==3) ||(a86==10) && (a162==12)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_2" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a32==6){
       if(a177==7){
                                      }
                   }
if(!(a32==6)){
                      if(!(a162==10)){
                       }
                   }
if(a32==6){
       if(!(a177==7)){
               if(!(a162==10)){
                                  }
                            }
                      }
if(a32==6){
       if(!(a177==7)){
               if(a162==10){
                                  }
                            }
                      }
//*****************************************************************
	    if((a32==6) && (a177==7) ||(a162==10)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_3" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a188==1){
                      if(a162==10){
                       }
                   }
if(!(a188==1)){
       if(!(a177==5)){
                                      }
                   }
if(!(a188==1)){
       if(a177==5){
               if(a162==10){
                                  }
                            }
                      }
if(!(a188==1)){
       if(a177==5){
               if(!(a162==10)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a188==1) ||(a177==5) && (a162==10)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_4" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a11==5){
       if(a32==3){
                                      }
                   }
if(!(a11==5)){
                      if(!(a162==7)){
                       }
                   }
if(a11==5){
       if(!(a32==3)){
               if(!(a162==7)){
                                  }
                            }
                      }
if(a11==5){
       if(!(a32==3)){
               if(a162==7){
                                  }
                            }
                      }
//*****************************************************************
	    if((a11==5) && (a32==3) ||(a162==7)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_5" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a112==9){
       if(a32==6){
                                      }
                   }
if(!(a112==9)){
                      if(!(a162==7)){
                       }
                   }
if(a112==9){
       if(!(a32==6)){
               if(!(a162==7)){
                                  }
                            }
                      }
if(a112==9){
       if(!(a32==6)){
               if(a162==7){
                                  }
                            }
                      }
//*****************************************************************
	    if((a112==9) && (a32==6) ||(a162==7)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_6" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a13==4){
                      if(a162==7){
                       }
                   }
if(!(a13==4)){
       if(!(a32==5)){
                                      }
                   }
if(!(a13==4)){
       if(a32==5){
               if(a162==7){
                                  }
                            }
                      }
if(!(a13==4)){
       if(a32==5){
               if(!(a162==7)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a13==4) ||(a32==5) && (a162==7)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_7" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a153==12){
                      if(a162==13){
                       }
                   }
if(!(a153==12)){
       if(!(a138==7)){
                                      }
                   }
if(!(a153==12)){
       if(a138==7){
               if(a162==13){
                                  }
                            }
                      }
if(!(a153==12)){
       if(a138==7){
               if(!(a162==13)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a153==12) ||(a138==7) && (a162==13)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_8" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a35==8){
       if(a183==3){
                                      }
                   }
if(!(a35==8)){
                      if(!(a162==14)){
                       }
                   }
if(a35==8){
       if(!(a183==3)){
               if(!(a162==14)){
                                  }
                            }
                      }
if(a35==8){
       if(!(a183==3)){
               if(a162==14){
                                  }
                            }
                      }
//*****************************************************************
	    if((a35==8) && (a183==3) ||(a162==14)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_9" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a11==4){
       if(a59==9){
                                      }
                   }
if(!(a11==4)){
                      if(!(a162==8)){
                       }
                   }
if(a11==4){
       if(!(a59==9)){
               if(!(a162==8)){
                                  }
                            }
                      }
if(a11==4){
       if(!(a59==9)){
               if(a162==8){
                                  }
                            }
                      }
//*****************************************************************
	    if((a11==4) && (a59==9) ||(a162==8)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_10" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a146==9){
                      if(a162==12){
                       }
                   }
if(!(a146==9)){
       if(!(a86==10)){
                                      }
                   }
if(!(a146==9)){
       if(a86==10){
               if(a162==12){
                                  }
                            }
                      }
if(!(a146==9)){
       if(a86==10){
               if(!(a162==12)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a146==9) ||(a86==10) && (a162==12)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_11" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a164==11){
       if(a138==5){
                                      }
                   }
if(!(a164==11)){
                      if(!(a162==13)){
                       }
                   }
if(a164==11){
       if(!(a138==5)){
               if(!(a162==13)){
                                  }
                            }
                      }
if(a164==11){
       if(!(a138==5)){
               if(a162==13){
                                  }
                            }
                      }
//*****************************************************************
	    if((a164==11) && (a138==5) ||(a162==13)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_12" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a146==5){
       if(a57==11){
                                      }
                   }
if(!(a146==5)){
                      if(!(a162==9)){
                       }
                   }
if(a146==5){
       if(!(a57==11)){
               if(!(a162==9)){
                                  }
                            }
                      }
if(a146==5){
       if(!(a57==11)){
               if(a162==9){
                                  }
                            }
                      }
//*****************************************************************
	    if((a146==5) && (a57==11) ||(a162==9)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_13" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a188==3){
       if(a177==5){
                                      }
                   }
if(!(a188==3)){
                      if(!(a162==10)){
                       }
                   }
if(a188==3){
       if(!(a177==5)){
               if(!(a162==10)){
                                  }
                            }
                      }
if(a188==3){
       if(!(a177==5)){
               if(a162==10){
                                  }
                            }
                      }
//*****************************************************************
	    if((a188==3) && (a177==5) ||(a162==10)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_14" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a112==7){
       if(a32==6){
                                      }
                   }
if(!(a112==7)){
                      if(!(a162==7)){
                       }
                   }
if(a112==7){
       if(!(a32==6)){
               if(!(a162==7)){
                                  }
                            }
                      }
if(a112==7){
       if(!(a32==6)){
               if(a162==7){
                                  }
                            }
                      }
//*****************************************************************
	    if((a112==7) && (a32==6) ||(a162==7)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_15" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a99==10){
       if(a57==7){
                                      }
                   }
if(!(a99==10)){
                      if(!(a162==9)){
                       }
                   }
if(a99==10){
       if(!(a57==7)){
               if(!(a162==9)){
                                  }
                            }
                      }
if(a99==10){
       if(!(a57==7)){
               if(a162==9){
                                  }
                            }
                      }
//*****************************************************************
	    if((a99==10) && (a57==7) ||(a162==9)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_16" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a133==5){
       if(a177==12){
                                      }
                   }
if(!(a133==5)){
                      if(!(a162==10)){
                       }
                   }
if(a133==5){
       if(!(a177==12)){
               if(!(a162==10)){
                                  }
                            }
                      }
if(a133==5){
       if(!(a177==12)){
               if(a162==10){
                                  }
                            }
                      }
//*****************************************************************
	    if((a133==5) && (a177==12) ||(a162==10)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_17" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a11==3){
       if(a59==9){
                                      }
                   }
if(!(a11==3)){
                      if(!(a162==8)){
                       }
                   }
if(a11==3){
       if(!(a59==9)){
               if(!(a162==8)){
                                  }
                            }
                      }
if(a11==3){
       if(!(a59==9)){
               if(a162==8){
                                  }
                            }
                      }
//*****************************************************************
	    if((a11==3) && (a59==9) ||(a162==8)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_18" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a188==2){
       if(a177==5){
                                      }
                   }
if(!(a188==2)){
                      if(!(a162==10)){
                       }
                   }
if(a188==2){
       if(!(a177==5)){
               if(!(a162==10)){
                                  }
                            }
                      }
if(a188==2){
       if(!(a177==5)){
               if(a162==10){
                                  }
                            }
                      }
//*****************************************************************
	    if((a188==2) && (a177==5) ||(a162==10)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_19" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a112==12){
       if(a183==2){
                                      }
                   }
if(!(a112==12)){
                      if(!(a162==14)){
                       }
                   }
if(a112==12){
       if(!(a183==2)){
               if(!(a162==14)){
                                  }
                            }
                      }
if(a112==12){
       if(!(a183==2)){
               if(a162==14){
                                  }
                            }
                      }
//*****************************************************************
	    if((a112==12) && (a183==2) ||(a162==14)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_20" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a153==9){
       if(a138==7){
                                      }
                   }
if(!(a153==9)){
                      if(!(a162==13)){
                       }
                   }
if(a153==9){
       if(!(a138==7)){
               if(!(a162==13)){
                                  }
                            }
                      }
if(a153==9){
       if(!(a138==7)){
               if(a162==13){
                                  }
                            }
                      }
//*****************************************************************
	    if((a153==9) && (a138==7) ||(a162==13)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_21" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a147==13){
                      if(a162==12){
                       }
                   }
if(!(a147==13)){
       if(!(a86==11)){
                                      }
                   }
if(!(a147==13)){
       if(a86==11){
               if(a162==12){
                                  }
                            }
                      }
if(!(a147==13)){
       if(a86==11){
               if(!(a162==12)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a147==13) ||(a86==11) && (a162==12)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_22" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a48==1){
                      if(a162==8){
                       }
                   }
if(!(a48==1)){
       if(!(a59==2)){
                                      }
                   }
if(!(a48==1)){
       if(a59==2){
               if(a162==8){
                                  }
                            }
                      }
if(!(a48==1)){
       if(a59==2){
               if(!(a162==8)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a48==1) ||(a59==2) && (a162==8)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_23" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a138==4){
                      if(a162==7){
                       }
                   }
if(!(a138==4)){
       if(!(a32==2)){
                                      }
                   }
if(!(a138==4)){
       if(a32==2){
               if(a162==7){
                                  }
                            }
                      }
if(!(a138==4)){
       if(a32==2){
               if(!(a162==7)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a138==4) ||(a32==2) && (a162==7)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_24" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a13==1){
       if(a32==5){
                                      }
                   }
if(!(a13==1)){
                      if(!(a162==7)){
                       }
                   }
if(a13==1){
       if(!(a32==5)){
               if(!(a162==7)){
                                  }
                            }
                      }
if(a13==1){
       if(!(a32==5)){
               if(a162==7){
                                  }
                            }
                      }
//*****************************************************************
	    if((a13==1) && (a32==5) ||(a162==7)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_25" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a129==4){
                      if(a162==12){
                       }
                   }
if(!(a129==4)){
       if(!( a86==4)){
                                      }
                   }
if(!(a129==4)){
       if( a86==4){
               if(a162==12){
                                  }
                            }
                      }
if(!(a129==4)){
       if( a86==4){
               if(!(a162==12)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a129==4) || ( a86==4) && (a162==12)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_26" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a158==7){
       if(a76==5){
                                      }
                   }
if(!(a158==7)){
                      if(!(a162==11)){
                       }
                   }
if(a158==7){
       if(!(a76==5)){
               if(!(a162==11)){
                                  }
                            }
                      }
if(a158==7){
       if(!(a76==5)){
               if(a162==11){
                                  }
                            }
                      }
//*****************************************************************
	    if((a158==7) && (a76==5) ||(a162==11)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_27" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a35==7){
                      if(a162==11){
                       }
                   }
if(!(a35==7)){
       if(!(a76==0)){
                                      }
                   }
if(!(a35==7)){
       if(a76==0){
               if(a162==11){
                                  }
                            }
                      }
if(!(a35==7)){
       if(a76==0){
               if(!(a162==11)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a35==7) ||(a76==0) && (a162==11)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_28" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a158==2){
       if(a183==1){
                                      }
                   }
if(!(a158==2)){
                      if(!(a162==14)){
                       }
                   }
if(a158==2){
       if(!(a183==1)){
               if(!(a162==14)){
                                  }
                            }
                      }
if(a158==2){
       if(!(a183==1)){
               if(a162==14){
                                  }
                            }
                      }
//*****************************************************************
	    if((a158==2) && (a183==1) ||(a162==14)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_29" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a182==5){
       if(a177==6){
                                      }
                   }
if(!(a182==5)){
                      if(!(a162==10)){
                       }
                   }
if(a182==5){
       if(!(a177==6)){
               if(!(a162==10)){
                                  }
                            }
                      }
if(a182==5){
       if(!(a177==6)){
               if(a162==10){
                                  }
                            }
                      }
//*****************************************************************
	    if((a182==5) && (a177==6) ||(a162==10)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_30" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a51==5){
                      if(a162==11){
                       }
                   }
if(!(a51==5)){
       if(!(a76==6)){
                                      }
                   }
if(!(a51==5)){
       if(a76==6){
               if(a162==11){
                                  }
                            }
                      }
if(!(a51==5)){
       if(a76==6){
               if(!(a162==11)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a51==5) ||(a76==6) && (a162==11)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_31" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a100==10){
       if(a32==7){
                                      }
                   }
if(!(a100==10)){
                      if(!(a162==7)){
                       }
                   }
if(a100==10){
       if(!(a32==7)){
               if(!(a162==7)){
                                  }
                            }
                      }
if(a100==10){
       if(!(a32==7)){
               if(a162==7){
                                  }
                            }
                      }
//*****************************************************************
	    if((a100==10) && (a32==7) ||(a162==7)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_32" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a43==1){
                      if(a162==13){
                       }
                   }
if(!(a43==1)){
       if(!(a138==8)){
                                      }
                   }
if(!(a43==1)){
       if(a138==8){
               if(a162==13){
                                  }
                            }
                      }
if(!(a43==1)){
       if(a138==8){
               if(!(a162==13)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a43==1) ||(a138==8) && (a162==13)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_33" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a35==8){
       if(a76==0){
                                      }
                   }
if(!(a35==8)){
                      if(!(a162==11)){
                       }
                   }
if(a35==8){
       if(!(a76==0)){
               if(!(a162==11)){
                                  }
                            }
                      }
if(a35==8){
       if(!(a76==0)){
               if(a162==11){
                                  }
                            }
                      }
//*****************************************************************
	    if((a35==8) && (a76==0) ||(a162==11)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_34" );
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a131==9){
       if(a86==8){
                                      }
                   }
if(!(a131==9)){
                      if(!(a162==12)){
                       }
                   }
if(a131==9){
       if(!(a86==8)){
               if(!(a162==12)){
                                  }
                            }
                      }
if(a131==9){
       if(!(a86==8)){
               if(a162==12){
                                  }
                            }
                      }
//*****************************************************************
	    if((a131==9) && (a86==8) ||(a162==12)){
	    	cf = (0);
	    	throw new IllegalStateException( "error_35" );
	    }
	    
	   
	}

	private  void calculateOutputm2(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 4){
                       }
                   }
if(!(cf==1)){
       if(input == 4){
                       }
                   }
if(cf==1){
       if(!(input == 4)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 4)){
    	 cf = (0);
    	a133 = (7);
    	a177 = (12);
    	a162 = (10);
    	  System.out.println( 21);  
    } 
}
private  void calculateOutputm1(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(a70==3)){
                       }
                   }
if(cf==1){
       if(!(a70==3)){
                       }
                   }
if(!(cf==1)){
       if(a70==3){
                       }
                   }
//*********************************************************************
    if((cf==1) || (a70==3)){
    	calculateOutputm2(input);
    } 
}
private  void calculateOutputm4(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 2){
                       }
                   }
if(!(cf==1)){
       if(input == 2){
                       }
                   }
if(cf==1){
       if(!(input == 2)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 2)){
    	 cf = (0);
    	  System.out.println( 25);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(input == 3)){
                       }
                   }
if(cf==1){
       if(!(input == 3)){
                       }
                   }
if(!(cf==1)){
       if(input == 3){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(input == 3)){
    	 cf = (0);
    	a198 = (9);
    	a57 = (6);
    	a162 = (9);
    	  System.out.println( 23);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 4)){
       if(!(cf==1)){
                       }
                   }
if(input == 4){
       if(!(cf==1)){
                       }
                   }
if(!(input == 4)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 4) ||(cf==1)){
    	 cf = (0);
    	a100 = (10);
    	  System.out.println( 23);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 5)){
       if(!(cf==1)){
                       }
                   }
if(input == 5){
       if(!(cf==1)){
                       }
                   }
if(!(input == 5)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 5) ||(cf==1)){
    	 cf = (0);
    	a147 = (15);
    	a86 = (11);
    	a162 = (12);
    	  System.out.println( 22);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 1)){
       if(!(cf==1)){
                       }
                   }
if(input == 1){
       if(!(cf==1)){
                       }
                   }
if(!(input == 1)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 1) ||(cf==1)){
    	 cf = (0);
    	a51 = (4);
    	a86 = (5);
    	a162 = (12);
    	  System.out.println( 21);  
    } 
}
private  void calculateOutputm3(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(a100==6)){
       if(!(cf==1)){
                       }
                   }
if(a100==6){
       if(!(cf==1)){
                       }
                   }
if(!(a100==6)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((a100==6) ||(cf==1)){
    	calculateOutputm4(input);
    } 
}
private  void calculateOutputm6(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 4)){
       if(!(cf==1)){
                       }
                   }
if(input == 4){
       if(!(cf==1)){
                       }
                   }
if(!(input == 4)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 4) ||(cf==1)){
    	 cf = (0);
    	a200 = (7);
    	a86 = (9);
    	a162 = (12);
    	  System.out.println( 21);  
    } 
}
private  void calculateOutputm5(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(a48==4)){
                       }
                   }
if(cf==1){
       if(!(a48==4)){
                       }
                   }
if(!(cf==1)){
       if(a48==4){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(a48==4)){
    	calculateOutputm6(input);
    } 
}
private  void calculateOutputm8(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 5){
                       }
                   }
if(!(cf==1)){
       if(input == 5){
                       }
                   }
if(cf==1){
       if(!(input == 5)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 5)){
    	 cf = (0);
    	a129 = (4);
    	a86 = (4);
    	a162 = (12);
    	  System.out.println( 25);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(input == 2)){
                       }
                   }
if(cf==1){
       if(!(input == 2)){
                       }
                   }
if(!(cf==1)){
       if(input == 2){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(input == 2)){
    	 cf = (0);
    	a158 = (9);
    	a76 = (5);
    	a162 = (11);
    	  System.out.println( 25);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input == 4){
       if(cf==1){
                       }
                   }
if(!(input == 4)){
       if(cf==1){
                       }
                   }
if(input == 4){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((input == 4) && (cf==1)){
    	 cf = (0);
    	a133 = (5);
    	a177 = (12);
    	a162 = (10);
    	  System.out.println( 25);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 1)){
       if(!(cf==1)){
                       }
                   }
if(input == 1){
       if(!(cf==1)){
                       }
                   }
if(!(input == 1)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 1) ||(cf==1)){
    	 cf = (0);
    	a104 = (8);
    	a59 = (3);
    	a162 = (8);
    	  System.out.println( 22);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input == 3){
       if(cf==1){
                       }
                   }
if(!(input == 3)){
       if(cf==1){
                       }
                   }
if(input == 3){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((input == 3) && (cf==1)){
    	 cf = (0);
    	a133 = (7);
    	a177 = (12);
    	a162 = (10);
    	  System.out.println( 21);  
    } 
}
private  void calculateOutputm7(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(a198==9)){
       if(!(cf==1)){
                       }
                   }
if(a198==9){
       if(!(cf==1)){
                       }
                   }
if(!(a198==9)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((a198==9) ||(cf==1)){
    	calculateOutputm8(input);
    } 
}
private  void calculateOutputm10(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 2){
                       }
                   }
if(!(cf==1)){
       if(input == 2){
                       }
                   }
if(cf==1){
       if(!(input == 2)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 2)){
    	 cf = (0);
    	a133 = (7);
    	a177 = (12);
    	a162 = (10);
    	  System.out.println( 21);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 4){
                       }
                   }
if(!(cf==1)){
       if(input == 4){
                       }
                   }
if(cf==1){
       if(!(input == 4)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 4)){
    	 cf = (0);
    	a35 = (8);
    	a183 = (3);
    	a162 = (14);
    	  System.out.println( 22);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(input == 5)){
                       }
                   }
if(cf==1){
       if(!(input == 5)){
                       }
                   }
if(!(cf==1)){
       if(input == 5){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(input == 5)){
    	 cf = (0);
    	a112 = (9);
    	a86 = (6);
    	a162 = (12);
    	  System.out.println( 19);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 1){
                       }
                   }
if(!(cf==1)){
       if(input == 1){
                       }
                   }
if(cf==1){
       if(!(input == 1)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 1)){
    	 cf = (0);
    	a130 = (5);
    	a138 = (3);
    	a162 = (13);
    	  System.out.println( 21);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 3){
                       }
                   }
if(!(cf==1)){
       if(input == 3){
                       }
                   }
if(cf==1){
       if(!(input == 3)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 3)){
    	 cf = (0);
    	a112 = (9);
    	a32 = (6);
    	a162 = (7);
    	  System.out.println( 20);  
    } 
}
private  void calculateOutputm11(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(input == 3)){
                       }
                   }
if(cf==1){
       if(!(input == 3)){
                       }
                   }
if(!(cf==1)){
       if(input == 3){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(input == 3)){
    	 cf = (0);
    	a198 = (9);
    	a57 = (6);
    	  System.out.println( 20);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 1)){
       if(!(cf==1)){
                       }
                   }
if(input == 1){
       if(!(cf==1)){
                       }
                   }
if(!(input == 1)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 1) ||(cf==1)){
    	 cf = (0);
    	a138 = (5);
    	a59 = (6);
    	a162 = (8);
    	  System.out.println( 22);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input == 4){
       if(cf==1){
                       }
                   }
if(!(input == 4)){
       if(cf==1){
                       }
                   }
if(input == 4){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((input == 4) && (cf==1)){
    	 cf = (0);
    	a32 = (6);
    	a177 = (7);
    	a162 = (10);
    	  System.out.println( 20);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 2){
                       }
                   }
if(!(cf==1)){
       if(input == 2){
                       }
                   }
if(cf==1){
       if(!(input == 2)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 2)){
    	 cf = (0);
    	a32 = (1);
    	a177 = (7);
    	a162 = (10);
    	  System.out.println( 21);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 5)){
       if(!(cf==1)){
                       }
                   }
if(input == 5){
       if(!(cf==1)){
                       }
                   }
if(!(input == 5)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 5) ||(cf==1)){
    	 cf = (0);
    	a32 = (1);
    	a177 = (7);
    	a162 = (10);
    	  System.out.println( 21);  
    } 
}
private  void calculateOutputm9(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(a146==4)){
       if(!(cf==1)){
                       }
                   }
if(a146==4){
       if(!(cf==1)){
                       }
                   }
if(!(a146==4)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((a146==4) ||(cf==1)){
    	calculateOutputm10(input);
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(a146==6){
       if(cf==1){
                       }
                   }
if(!(a146==6)){
       if(cf==1){
                       }
                   }
if(a146==6){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((a146==6) && (cf==1)){
    	calculateOutputm11(input);
    } 
}
private  void calculateOutputm13(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input == 2){
       if(cf==1){
                       }
                   }
if(!(input == 2)){
       if(cf==1){
                       }
                   }
if(input == 2){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((input == 2) && (cf==1)){
    	 cf = (0);
    	a32 = (2);
    	a177 = (7);
    	  System.out.println( 19);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(input == 3)){
                       }
                   }
if(cf==1){
       if(!(input == 3)){
                       }
                   }
if(!(cf==1)){
       if(input == 3){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(input == 3)){
    	 cf = (0);
    	a182 = (7);
    	  System.out.println( 19);  
    } 
}
private  void calculateOutputm14(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 1){
                       }
                   }
if(!(cf==1)){
       if(input == 1){
                       }
                   }
if(cf==1){
       if(!(input == 1)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 1)){
    	 cf = (0);
    	a138 = (4);
    	a59 = (6);
    	a162 = (8);
    	  System.out.println( 21);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input == 4){
       if(cf==1){
                       }
                   }
if(!(input == 4)){
       if(cf==1){
                       }
                   }
if(input == 4){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((input == 4) && (cf==1)){
    	 cf = (0);
    	a100 = (6);
    	a32 = (7);
    	a162 = (7);
    	  System.out.println( 20);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 5)){
       if(!(cf==1)){
                       }
                   }
if(input == 5){
       if(!(cf==1)){
                       }
                   }
if(!(input == 5)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 5) ||(cf==1)){
    	 cf = (0);
    	a153 = (9);
    	a138 = (7);
    	a162 = (13);
    	  System.out.println( 23);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(input == 2)){
                       }
                   }
if(cf==1){
       if(!(input == 2)){
                       }
                   }
if(!(cf==1)){
       if(input == 2){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(input == 2)){
    	 cf = (0);
    	a133 = (7);
    	a86 = (7);
    	a162 = (12);
    	  System.out.println( 21);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 3){
                       }
                   }
if(!(cf==1)){
       if(input == 3){
                       }
                   }
if(cf==1){
       if(!(input == 3)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 3)){
    	 cf = (0);
    	a112 = (7);
    	a32 = (6);
    	a162 = (7);
    	  System.out.println( 19);  
    } 
}
private  void calculateOutputm12(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(a182==3)){
                       }
                   }
if(cf==1){
       if(!(a182==3)){
                       }
                   }
if(!(cf==1)){
       if(a182==3){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(a182==3)){
    	calculateOutputm13(input);
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(a182==7){
                       }
                   }
if(!(cf==1)){
       if(a182==7){
                       }
                   }
if(cf==1){
       if(!(a182==7)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (a182==7)){
    	calculateOutputm14(input);
    } 
}
private  void calculateOutputm16(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 1){
                       }
                   }
if(!(cf==1)){
       if(input == 1){
                       }
                   }
if(cf==1){
       if(!(input == 1)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 1)){
    	 cf = (0);
    	a182 = (3);
    	a177 = (6);
    	  System.out.println( 20);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input == 3){
       if(cf==1){
                       }
                   }
if(!(input == 3)){
       if(cf==1){
                       }
                   }
if(input == 3){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((input == 3) && (cf==1)){
    	 cf = (0);
    	a200 = (3);
    	a86 = (9);
    	a162 = (12);
    	  System.out.println( 21);  
    } 
}
private  void calculateOutputm17(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 3)){
       if(!(cf==1)){
                       }
                   }
if(input == 3){
       if(!(cf==1)){
                       }
                   }
if(!(input == 3)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 3) ||(cf==1)){
    	 cf = (0);
    	a35 = (7);
    	a76 = (0);
    	a162 = (11);
    	  System.out.println( 20);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(input == 1)){
                       }
                   }
if(cf==1){
       if(!(input == 1)){
                       }
                   }
if(!(cf==1)){
       if(input == 1){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(input == 1)){
    	 cf = (0);
    	a112 = (6);
    	a183 = (2);
    	a162 = (14);
    	  System.out.println( 20);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input == 4){
       if(cf==1){
                       }
                   }
if(!(input == 4)){
       if(cf==1){
                       }
                   }
if(input == 4){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((input == 4) && (cf==1)){
    	 cf = (0);
    	a146 = (6);
    	a57 = (9);
    	a162 = (9);
    	  System.out.println( 19);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input == 5){
       if(cf==1){
                       }
                   }
if(!(input == 5)){
       if(cf==1){
                       }
                   }
if(input == 5){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((input == 5) && (cf==1)){
    	 cf = (0);
    	a118 = (3);
    	a138 = (9);
    	a162 = (13);
    	  System.out.println( 20);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(input == 2)){
                       }
                   }
if(cf==1){
       if(!(input == 2)){
                       }
                   }
if(!(cf==1)){
       if(input == 2){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(input == 2)){
    	 cf = (0);
    	a143 = (14);
    	a76 = (7);
    	a162 = (11);
    	  System.out.println( 25);  
    } 
}
private  void calculateOutputm15(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(a32==1){
       if(cf==1){
                       }
                   }
if(!(a32==1)){
       if(cf==1){
                       }
                   }
if(a32==1){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((a32==1) && (cf==1)){
    	calculateOutputm16(input);
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(a32==2){
                       }
                   }
if(!(cf==1)){
       if(a32==2){
                       }
                   }
if(cf==1){
       if(!(a32==2)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (a32==2)){
    	calculateOutputm17(input);
    } 
}
private  void calculateOutputm19(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 2){
                       }
                   }
if(!(cf==1)){
       if(input == 2){
                       }
                   }
if(cf==1){
       if(!(input == 2)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 2)){
    	 cf = (0);
    	a158 = (9);
    	a76 = (5);
    	a162 = (11);
    	  System.out.println( 25);  
    } 
}
private  void calculateOutputm18(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(a133==7)){
       if(!(cf==1)){
                       }
                   }
if(a133==7){
       if(!(cf==1)){
                       }
                   }
if(!(a133==7)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((a133==7) ||(cf==1)){
    	calculateOutputm19(input);
    } 
}
private  void calculateOutputm21(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input == 2){
       if(cf==1){
                       }
                   }
if(!(input == 2)){
       if(cf==1){
                       }
                   }
if(input == 2){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((input == 2) && (cf==1)){
    	 cf = (0);
    	a198 = (9);
    	a57 = (6);
    	a162 = (9);
    	  System.out.println( 25);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 4){
                       }
                   }
if(!(cf==1)){
       if(input == 4){
                       }
                   }
if(cf==1){
       if(!(input == 4)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 4)){
    	 cf = (0);
    	a146 = (4);
    	a57 = (9);
    	a162 = (9);
    	  System.out.println( 21);  
    } 
}
private  void calculateOutputm20(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(a158==9)){
                       }
                   }
if(cf==1){
       if(!(a158==9)){
                       }
                   }
if(!(cf==1)){
       if(a158==9){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(a158==9)){
    	calculateOutputm21(input);
    } 
}
private  void calculateOutputm23(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 1){
                       }
                   }
if(!(cf==1)){
       if(input == 1){
                       }
                   }
if(cf==1){
       if(!(input == 1)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 1)){
    	 cf = (0);
    	a110 = (10);
    	a183 = (6);
    	a162 = (14);
    	  System.out.println( 22);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 5){
                       }
                   }
if(!(cf==1)){
       if(input == 5){
                       }
                   }
if(cf==1){
       if(!(input == 5)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 5)){
    	 cf = (0);
    	a146 = (5);
    	a86 = (10);
    	  System.out.println( 20);  
    } 
}
private  void calculateOutputm22(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(a112==11)){
                       }
                   }
if(cf==1){
       if(!(a112==11)){
                       }
                   }
if(!(cf==1)){
       if(a112==11){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(a112==11)){
    	calculateOutputm23(input);
    } 
}
private  void calculateOutputm25(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 5){
                       }
                   }
if(!(cf==1)){
       if(input == 5){
                       }
                   }
if(cf==1){
       if(!(input == 5)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 5)){
    	 cf = (0);
    	a110 = (6);
    	a183 = (6);
    	a162 = (14);
    	  System.out.println( 20);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input == 4){
       if(cf==1){
                       }
                   }
if(!(input == 4)){
       if(cf==1){
                       }
                   }
if(input == 4){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((input == 4) && (cf==1)){
    	 cf = (0);
    	a198 = (9);
    	a57 = (6);
    	a162 = (9);
    	  System.out.println( 20);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(input == 1)){
                       }
                   }
if(cf==1){
       if(!(input == 1)){
                       }
                   }
if(!(cf==1)){
       if(input == 1){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(input == 1)){
    	 cf = (0);
    	a200 = (8);
    	a59 = (4);
    	a162 = (8);
    	  System.out.println( 21);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 3)){
       if(!(cf==1)){
                       }
                   }
if(input == 3){
       if(!(cf==1)){
                       }
                   }
if(!(input == 3)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 3) ||(cf==1)){
    	 cf = (0);
    	a198 = (9);
    	a57 = (6);
    	a162 = (9);
    	  System.out.println( 22);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 2)){
       if(!(cf==1)){
                       }
                   }
if(input == 2){
       if(!(cf==1)){
                       }
                   }
if(!(input == 2)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 2) ||(cf==1)){
    	 cf = (0);
    	a188 = (3);
    	a177 = (5);
    	a162 = (10);
    	  System.out.println( 19);  
    } 
}
private  void calculateOutputm24(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(a131==8)){
       if(!(cf==1)){
                       }
                   }
if(a131==8){
       if(!(cf==1)){
                       }
                   }
if(!(a131==8)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((a131==8) ||(cf==1)){
    	calculateOutputm25(input);
    } 
}
private  void calculateOutputm27(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 3)){
       if(!(cf==1)){
                       }
                   }
if(input == 3){
       if(!(cf==1)){
                       }
                   }
if(!(input == 3)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 3) ||(cf==1)){
    	 cf = (0);
    	a110 = (6);
    	a183 = (6);
    	a162 = (14);
    	  System.out.println( 20);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(input == 2)){
                       }
                   }
if(cf==1){
       if(!(input == 2)){
                       }
                   }
if(!(cf==1)){
       if(input == 2){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(input == 2)){
    	 cf = (0);
    	a112 = (11);
    	a86 = (6);
    	  System.out.println( 19);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input == 5){
       if(cf==1){
                       }
                   }
if(!(input == 5)){
       if(cf==1){
                       }
                   }
if(input == 5){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((input == 5) && (cf==1)){
    	 cf = (0);
    	a13 = (2);
    	a183 = (5);
    	a162 = (14);
    	  System.out.println( 21);  
    } 
}
private  void calculateOutputm28(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(input == 1)){
                       }
                   }
if(cf==1){
       if(!(input == 1)){
                       }
                   }
if(!(cf==1)){
       if(input == 1){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(input == 1)){
    	 cf = (0);
    	a146 = (2);
    	a86 = (10);
    	  System.out.println( 25);  
    } 
}
private  void calculateOutputm26(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(a200==3)){
                       }
                   }
if(cf==1){
       if(!(a200==3)){
                       }
                   }
if(!(cf==1)){
       if(a200==3){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(a200==3)){
    	calculateOutputm27(input);
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(a200==7){
       if(cf==1){
                       }
                   }
if(!(a200==7)){
       if(cf==1){
                       }
                   }
if(a200==7){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((a200==7) && (cf==1)){
    	calculateOutputm28(input);
    } 
}private  void calculateOutputm30(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 4){
                       }
                   }
if(!(cf==1)){
       if(input == 4){
                       }
                   }
if(cf==1){
       if(!(input == 4)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 4)){
    	 cf = (0);
    	a32 = (1);
    	a177 = (7);
    	a162 = (10);
    	  System.out.println( 23);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 2)){
       if(!(cf==1)){
                       }
                   }
if(input == 2){
       if(!(cf==1)){
                       }
                   }
if(!(input == 2)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 2) ||(cf==1)){
    	 cf = (0);
    	a70 = (3);
    	a32 = (4);
    	a162 = (7);
    	  System.out.println( 25);  
    } 
}
private  void calculateOutputm31(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input == 1){
       if(cf==1){
                       }
                   }
if(!(input == 1)){
       if(cf==1){
                       }
                   }
if(input == 1){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((input == 1) && (cf==1)){
    	 cf = (0);
    	a147 = (14);
    	a86 = (11);
    	  System.out.println( 25);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 2)){
       if(!(cf==1)){
                       }
                   }
if(input == 2){
       if(!(cf==1)){
                       }
                   }
if(!(input == 2)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 2) ||(cf==1)){
    	 cf = (0);
    	a200 = (3);
    	a86 = (9);
    	  System.out.println( 21);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(input == 5)){
                       }
                   }
if(cf==1){
       if(!(input == 5)){
                       }
                   }
if(!(cf==1)){
       if(input == 5){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(input == 5)){
    	 cf = (0);
    	a112 = (6);
    	a86 = (6);
    	  System.out.println( 20);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 3){
                       }
                   }
if(!(cf==1)){
       if(input == 3){
                       }
                   }
if(cf==1){
       if(!(input == 3)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 3)){
    	 cf = (0);
    	a168 = (7);
    	a183 = (0);
    	a162 = (14);
    	  System.out.println( 21);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 4)){
       if(!(cf==1)){
                       }
                   }
if(input == 4){
       if(!(cf==1)){
                       }
                   }
if(!(input == 4)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 4) ||(cf==1)){
    	 cf = (0);
    	a200 = (3);
    	a86 = (9);
    	  System.out.println( 21);  
    } 
}
private  void calculateOutputm29(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(a146==2){
                       }
                   }
if(!(cf==1)){
       if(a146==2){
                       }
                   }
if(cf==1){
       if(!(a146==2)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (a146==2)){
    	calculateOutputm30(input);
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(a146==5){
       if(cf==1){
                       }
                   }
if(!(a146==5)){
       if(cf==1){
                       }
                   }
if(a146==5){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((a146==5) && (cf==1)){
    	calculateOutputm31(input);
    } 
}
private  void calculateOutputm33(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 1)){
       if(!(cf==1)){
                       }
                   }
if(input == 1){
       if(!(cf==1)){
                       }
                   }
if(!(input == 1)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 1) ||(cf==1)){
    	 cf = (0);
    	a168 = (13);
    	a183 = (0);
    	a162 = (14);
    	  System.out.println( 21);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 4)){
       if(!(cf==1)){
                       }
                   }
if(input == 4){
       if(!(cf==1)){
                       }
                   }
if(!(input == 4)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 4) ||(cf==1)){
    	 cf = (0);
    	a192 = (4);
    	a59 = (7);
    	a162 = (8);
    	  System.out.println( 22);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 3){
                       }
                   }
if(!(cf==1)){
       if(input == 3){
                       }
                   }
if(cf==1){
       if(!(input == 3)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 3)){
    	 cf = (0);
    	a146 = (2);
    	a86 = (10);
    	a162 = (12);
    	  System.out.println( 25);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(input == 5)){
                       }
                   }
if(cf==1){
       if(!(input == 5)){
                       }
                   }
if(!(cf==1)){
       if(input == 5){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(input == 5)){
    	 cf = (0);
    	a188 = (1);
    	a177 = (5);
    	a162 = (10);
    	  System.out.println( 22);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(input == 2)){
                       }
                   }
if(cf==1){
       if(!(input == 2)){
                       }
                   }
if(!(cf==1)){
       if(input == 2){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(input == 2)){
    	 cf = (0);
    	a133 = (3);
    	a177 = (12);
    	a162 = (10);
    	  System.out.println( 21);  
    } 
}
private  void calculateOutputm32(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(a43==3){
                       }
                   }
if(!(cf==1)){
       if(a43==3){
                       }
                   }
if(cf==1){
       if(!(a43==3)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (a43==3)){
    	calculateOutputm33(input);
    } 
}
private  void calculateOutputm35(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 3){
                       }
                   }
if(!(cf==1)){
       if(input == 3){
                       }
                   }
if(cf==1){
       if(!(input == 3)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 3)){
    	 cf = (0);
    	a133 = (2);
    	a177 = (12);
    	a162 = (10);
    	  System.out.println( 21);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input == 1){
       if(cf==1){
                       }
                   }
if(!(input == 1)){
       if(cf==1){
                       }
                   }
if(input == 1){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((input == 1) && (cf==1)){
    	 cf = (0);
    	a48 = (2);
    	a59 = (2);
    	a162 = (8);
    	  System.out.println( 20);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 2)){
       if(!(cf==1)){
                       }
                   }
if(input == 2){
       if(!(cf==1)){
                       }
                   }
if(!(input == 2)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 2) ||(cf==1)){
    	 cf = (0);
    	a24 = (1);
    	a177 = (8);
    	a162 = (10);
    	  System.out.println( 21);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 5)){
       if(!(cf==1)){
                       }
                   }
if(input == 5){
       if(!(cf==1)){
                       }
                   }
if(!(input == 5)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 5) ||(cf==1)){
    	 cf = (0);
    	a43 = (3);
    	a138 = (8);
    	a162 = (13);
    	  System.out.println( 22);  
    } 
}
private  void calculateOutputm34(int input) {
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(a13==2)){
                       }
                   }
if(cf==1){
       if(!(a13==2)){
                       }
                   }
if(!(cf==1)){
       if(a13==2){
                       }
                   }
//*********************************************************************
    if((cf==1) ||(a13==2)){
    	calculateOutputm35(input);
    } 
}
private  void calculateOutputm37(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 5){
                       }
                   }
if(!(cf==1)){
       if(input == 5){
                       }
                   }
if(cf==1){
       if(!(input == 5)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 5)){
    	 cf = (0);
    	a131 = (8);
    	a86 = (8);
    	a162 = (12);
    	  System.out.println( 19);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 1)){
       if(!(cf==1)){
                       }
                   }
if(input == 1){
       if(!(cf==1)){
                       }
                   }
if(!(input == 1)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 1) ||(cf==1)){
    	 cf = (0);
    	a138 = (4);
    	a32 = (2);
    	a162 = (7);
    	  System.out.println( 20);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 4){
                       }
                   }
if(!(cf==1)){
       if(input == 4){
                       }
                   }
if(cf==1){
       if(!(input == 4)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 4)){
    	 cf = (0);
    	a104 = (5);
    	a59 = (3);
    	a162 = (8);
    	  System.out.println( 21);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 3)){
       if(!(cf==1)){
                       }
                   }
if(input == 3){
       if(!(cf==1)){
                       }
                   }
if(!(input == 3)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 3) || (cf==1)){
    	 cf = (0);
    	a146 = (9);
    	a86 = (10);
    	a162 = (12);
    	  System.out.println( 23);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 2)){
       if(!(cf==1)){
                       }
                   }
if(input == 2){
       if(!(cf==1)){
                       }
                   }
if(!(input == 2)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 2) ||(cf==1)){
    	 cf = (0);
    	a168 = (11);
    	a183 = (0);
    	  System.out.println( 20);  
    } 
}
private  void calculateOutputm38(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 4){
                       }
                   }
if(!(cf==1)){
       if(input == 4){
                       }
                   }
if(cf==1){
       if(!(input == 4)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 4)){
    	 cf = (0);

    	  System.out.println( 22);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 5)){
       if(!(cf==1)){
                       }
                   }
if(input == 5){
       if(!(cf==1)){
                       }
                   }
if(!(input == 5)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 5) ||(cf==1)){
    	 cf = (0);
    	a112 = (11);
    	a86 = (6);
    	a162 = (12);
    	  System.out.println( 19);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 3)){
       if(!(cf==1)){
                       }
                   }
if(input == 3){
       if(!(cf==1)){
                       }
                   }
if(!(input == 3)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 3) ||(cf==1)){
    	 cf = (0);
    	a158 = (4);
    	a76 = (5);
    	a162 = (11);
    	  System.out.println( 19);  
    } 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(input == 2)){
       if(!(cf==1)){
                       }
                   }
if(input == 2){
       if(!(cf==1)){
                       }
                   }
if(!(input == 2)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    if((input == 2) ||(cf==1)){
    	 cf = (0);
    	a200 = (6);
    	a177 = (10);
    	a162 = (10);
    	  System.out.println( 22);  
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(input == 1){
                       }
                   }
if(!(cf==1)){
       if(input == 1){
                       }
                   }
if(cf==1){
       if(!(input == 1)){
                       }
                   }
//*********************************************************************
    if((cf==1) && (input == 1)){
    	 cf = (0);
    	a112 = (12);
    	a183 = (2);
    	  System.out.println( 22);  
    } 
}
private  void calculateOutputm36(int input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(a110==6){
       if(cf==1){
                       }
                   }
if(!(a110==6)){
       if(cf==1){
                       }
                   }
if(a110==6){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((a110==6) && (cf==1)){
    	calculateOutputm37(input);
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(a110==10){
       if(cf==1){
                       }
                   }
if(!(a110==10)){
       if(cf==1){
                       }
                   }
if(a110==10){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    if((a110==10) && (cf==1)){
    	calculateOutputm38(input);
    } 
}
public  void calculateOutput(int input) {
 	cf = (1);
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(a32==4)){
       if(!(cf==1)){
                       }
                   }
if(a32==4){
       if(!(cf==1)){
                       }
                   }
if(!(a32==4)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    	if((a32==4) ||(cf==1)){
    		calculateOutputm1(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(a32==7){
                       }
                   }
if(!(cf==1)){
       if(a32==7){
                       }
                   }
if(cf==1){
       if(!(a32==7)){
                       }
                   }
//*********************************************************************
    	if((cf==1) && (a32==7)){
    		calculateOutputm3(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(a59==2){
                       }
                   }
if(!(cf==1)){
       if(a59==2){
                       }
                   }
if(cf==1){
       if(!(a59==2)){
                       }
                   }
//*********************************************************************
    	if((cf==1) && (a59==2)){
    		calculateOutputm5(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(a57==6)){
                       }
                   }
if(cf==1){
       if(!(a57==6)){
                       }
                   }
if(!(cf==1)){
       if(a57==6){
                       }
                   }
//*********************************************************************
    	if((cf==1) ||(a57==6)){
    		calculateOutputm7(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(a57==9){
       if(cf==1){
                       }
                   }
if(!(a57==9)){
       if(cf==1){
                       }
                   }
if(a57==9){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    	if((a57==9) && (cf==1)){
    		calculateOutputm9(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(a177==6){
                       }
                   }
if(!(cf==1)){
       if(a177==6){
                       }
                   }
if(cf==1){
       if(!(a177==6)){
                       }
                   }
//*********************************************************************
    	if((cf==1) && (a177==6)){
    		calculateOutputm12(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(a177==7){
       if(cf==1){
                       }
                   }
if(!(a177==7)){
       if(cf==1){
                       }
                   }
if(a177==7){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    	if((a177==7) && (cf==1)){
    		calculateOutputm15(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(a177==12)){
                       }
                   }
if(cf==1){
       if(!(a177==12)){
                       }
                   }
if(!(cf==1)){
       if(a177==12){
                       }
                   }
//*********************************************************************
    	if((cf==1) ||(a177==12)){
    		calculateOutputm18(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(a76==5){
                       }
                   }
if(!(cf==1)){
       if(a76==5){
                       }
                   }
if(cf==1){
       if(!(a76==5)){
                       }
                   }
//*********************************************************************
    	if((cf==1) && (a76==5)){
    		calculateOutputm20(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(a86==6){
       if(cf==1){
                       }
                   }
if(!(a86==6)){
       if(cf==1){
                       }
                   }
if(a86==6){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    	if((a86==6) && (cf==1)){
    		calculateOutputm22(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(a86==8){
       if(cf==1){
                       }
                   }
if(!(a86==8)){
       if(cf==1){
                       }
                   }
if(a86==8){
       if(!(cf==1)){
                       }
                   }
//*********************************************************************
    	if((a86==8) && (cf==1)){
    		calculateOutputm24(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(a86==9){
                       }
                   }
if(!(cf==1)){
       if(a86==9){
                       }
                   }
if(cf==1){
       if(!(a86==9)){
                       }
                   }
//*********************************************************************
    	if((cf==1) && (a86==9)){
    		calculateOutputm26(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==1){
       if(a86==10){
                       }
                   }
if(!(cf==1)){
       if(a86==10){
                       }
                   }
if(cf==1){
       if(!(a86==10)){
                       }
                   }
//*********************************************************************
    	if((cf==1) && (a86==10)){
    		calculateOutputm29(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(a138==8)){
                       }
                   }
if(cf==1){
       if(!(a138==8)){
                       }
                   }
if(!(cf==1)){
       if(a138==8){
                       }
                   }
//*********************************************************************
    	if((cf==1) ||(a138==8)){
    		calculateOutputm32(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(a183==5)){
       if(!(cf==1)){
                       }
                   }
if(a183==5){
       if(!(cf==1)){
                       }
                   }
if(!(a183==5)){
       if(cf==1){
                       }
                   }
//*********************************************************************
    	if((a183==5) ||(cf==1)){
    		calculateOutputm34(input);
    	} 
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(cf==1)){
       if(!(a183==6)){
                       }
                   }
if(cf==1){
       if(!(a183==6)){
                       }
                   }
if(!(cf==1)){
       if(a183==6){
                       }
                   }
//*********************************************************************
    	if((cf==1) ||(a183==6)){
    		calculateOutputm36(input);
    	} 
  
  errorCheck();
    if((cf==1))
    	throw new IllegalArgumentException("Current state has no transition for this input!");
}

public static void main() throws Exception 
	{
	     // init system and input reader
            Problem1_RERS2014 eca = new Problem1_RERS2014();
        int a=0;
	int x;
        int y;
         
        x = Cute.input.Integer();
        y = Cute.input.Integer();
		int input = Cute.input.Integer();
		
			// main i/o-loop
            while(a<10) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
//*********************************************************************
//Transformation for predictes containing only AND operator
if(x>199){
       if(x>y){
                       }
                   }
if(!(x>199)){
       if(x>y){
                       }
                   }
if(x>199){
       if(!(x>y)){
                       }
                   }
//*********************************************************************
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                	 eca.calculateOutput(input);
					 
				}
				
//*********************************************************************
//Transformation for predictes containing only AND operator
if(x>299){
       if(x<y){
                       }
                   }
if(!(x>299)){
       if(x<y){
                       }
                   }
if(x>299){
       if(!(x<y)){
                       }
                   }
//*********************************************************************
				if (x>299 && x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutput(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
	}
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
