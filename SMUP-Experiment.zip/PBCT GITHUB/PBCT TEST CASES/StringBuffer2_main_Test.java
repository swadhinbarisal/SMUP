
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class StringBuffer2_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public StringBuffer2_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[1];
        input[i++] = new Integer(562163687);
        i=0;
        cute.Cute.input = this;
        StringBuffer2.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[2];
        input[i++] = new Integer(0);
        input[i++] = new Integer(252056074);
        i=0;
        cute.Cute.input = this;
        StringBuffer2.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(1);
        input[i++] = new Integer(252056074);
        input[i++] = new Integer(415574356);
        i=0;
        cute.Cute.input = this;
        StringBuffer2.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(1);
        input[i++] = new Integer(415574356);
        input[i++] = new Integer(0);
        input[i++] = new Character(?);
        i=0;
        cute.Cute.input = this;
        StringBuffer2.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(1);
        input[i++] = new Integer(415574356);
        input[i++] = new Integer(1);
        input[i++] = new Integer(195497985);
        i=0;
        cute.Cute.input = this;
        StringBuffer2.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(1);
        input[i++] = new Integer(1);
        input[i++] = new Integer(1);
        input[i++] = new Integer(195497985);
        i=0;
        cute.Cute.input = this;
        StringBuffer2.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[6];
        input[i++] = new Integer(1);
        input[i++] = new Integer(1);
        input[i++] = new Integer(2);
        input[i++] = new Character(?);
        input[i++] = new Integer(-1663752148);
        input[i++] = new Integer(-1969870267);
        i=0;
        cute.Cute.input = this;
        StringBuffer2.main(null);
    }

    public void test14(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(3);
        input[i++] = new Integer(3);
        input[i++] = new Integer(2);
        input[i++] = new Character(676434111);
        input[i++] = new Character(?);
        input[i++] = new Integer(464607748);
        i=0;
        cute.Cute.input = this;
        StringBuffer2.main(null);
    }

}
