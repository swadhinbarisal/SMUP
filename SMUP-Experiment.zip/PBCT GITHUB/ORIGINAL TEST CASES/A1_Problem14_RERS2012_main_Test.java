
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class A1_Problem14_RERS2012_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public A1_Problem14_RERS2012_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(-1812244556);
        input[i++] = new Integer(-548906891);
        input[i++] = new Integer(2100110070);
        input[i++] = new Integer(-1575695156);
        input[i++] = new Integer(-1993586153);
        input[i++] = new Integer(-1885082668);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(-1812244556);
        input[i++] = new Integer(-548906891);
        input[i++] = new Integer(2100110070);
        input[i++] = new Integer(-1575695156);
        input[i++] = new Integer(200);
        input[i++] = new Integer(-1885082668);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(-1812244556);
        input[i++] = new Integer(-548906891);
        input[i++] = new Integer(2100110070);
        input[i++] = new Integer(-1575695156);
        input[i++] = new Integer(200);
        input[i++] = new Integer(200);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(-1812244556);
        input[i++] = new Integer(-548906891);
        input[i++] = new Integer(2100110070);
        input[i++] = new Integer(-1575695156);
        input[i++] = new Integer(300);
        input[i++] = new Integer(300);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(-1812244556);
        input[i++] = new Integer(-548906891);
        input[i++] = new Integer(2100110070);
        input[i++] = new Integer(-1575695156);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(-548906891);
        input[i++] = new Integer(2100110070);
        input[i++] = new Integer(-1575695156);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(6);
        input[i++] = new Integer(2100110070);
        input[i++] = new Integer(-1575695156);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test8(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(6);
        input[i++] = new Integer(10);
        input[i++] = new Integer(-1575695156);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test9(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(6);
        input[i++] = new Integer(10);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test10(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(6);
        input[i++] = new Integer(10);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test19(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(6);
        input[i++] = new Integer(10);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test20(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(6);
        input[i++] = new Integer(10);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test21(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(7);
        input[i++] = new Integer(10);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test22(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(8);
        input[i++] = new Integer(10);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test23(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(8);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test24(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test25(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test27(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test28(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(8);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test29(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(8);
        input[i++] = new Integer(10);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test30(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(8);
        input[i++] = new Integer(10);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test39(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(8);
        input[i++] = new Integer(10);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test41(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(6);
        input[i++] = new Integer(10);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test52(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(6);
        input[i++] = new Integer(10);
        input[i++] = new Integer(2);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test55(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(6);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test56(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test62(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test63(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(6);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test64(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(6);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test65(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(6);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test76(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(12);
        input[i++] = new Integer(6);
        input[i++] = new Integer(11);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test77(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(12);
        input[i++] = new Integer(6);
        input[i++] = new Integer(11);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test78(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(12);
        input[i++] = new Integer(6);
        input[i++] = new Integer(8);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test85(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(6);
        input[i++] = new Integer(8);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test86(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(7);
        input[i++] = new Integer(8);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test87(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(7);
        input[i++] = new Integer(8);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test88(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(8);
        input[i++] = new Integer(8);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test89(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(8);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test90(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test95(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(7);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test96(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(7);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test104(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(10);
        input[i++] = new Integer(7);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test105(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(10);
        input[i++] = new Integer(7);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test108(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(7);
        input[i++] = new Integer(6);
        input[i++] = new Integer(2);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test112(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(6);
        input[i++] = new Integer(8);
        input[i++] = new Integer(2);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test113(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(6);
        input[i++] = new Integer(8);
        input[i++] = new Integer(2);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test117(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(6);
        input[i++] = new Integer(8);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test134(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test161(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(8);
        input[i++] = new Integer(10);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test167(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(7);
        input[i++] = new Integer(7);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test174(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(7);
        input[i++] = new Integer(7);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test175(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(6);
        input[i++] = new Integer(7);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test190(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(6);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test197(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(7);
        input[i++] = new Integer(7);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test199(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(8);
        input[i++] = new Integer(7);
        input[i++] = new Integer(2);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test204(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(8);
        input[i++] = new Integer(7);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test207(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(12);
        input[i++] = new Integer(9);
        input[i++] = new Integer(10);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test209(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(12);
        input[i++] = new Integer(7);
        input[i++] = new Integer(10);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test212(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(7);
        input[i++] = new Integer(10);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test213(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(7);
        input[i++] = new Integer(6);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test215(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(8);
        input[i++] = new Integer(6);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test243(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(8);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test259(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(6);
        input[i++] = new Integer(11);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test260(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(6);
        input[i++] = new Integer(8);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test267(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(7);
        input[i++] = new Integer(8);
        input[i++] = new Integer(2);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test270(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(8);
        input[i++] = new Integer(8);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test271(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(8);
        input[i++] = new Integer(7);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test291(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(8);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test297(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(8);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test337(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(8);
        input[i++] = new Integer(11);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test348(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(12);
        input[i++] = new Integer(7);
        input[i++] = new Integer(7);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test350(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(12);
        input[i++] = new Integer(9);
        input[i++] = new Integer(10);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test421(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(81);
        input[i++] = new Integer(8);
        input[i++] = new Integer(7);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test430(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(81);
        input[i++] = new Integer(6);
        input[i++] = new Integer(10);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test477(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(81);
        input[i++] = new Integer(8);
        input[i++] = new Integer(10);
        input[i++] = new Integer(1);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test481(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(81);
        input[i++] = new Integer(7);
        input[i++] = new Integer(7);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test482(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(81);
        input[i++] = new Integer(7);
        input[i++] = new Integer(8);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test501(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(7);
        input[i++] = new Integer(6);
        input[i++] = new Integer(2);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test519(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(81);
        input[i++] = new Integer(7);
        input[i++] = new Integer(8);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test526(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(7);
        input[i++] = new Integer(8);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test560(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(81);
        input[i++] = new Integer(6);
        input[i++] = new Integer(11);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test564(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(9);
        input[i++] = new Integer(11);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test591(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(44);
        input[i++] = new Integer(5);
        input[i++] = new Integer(8);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test598(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(5);
        input[i++] = new Integer(8);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test601(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(6);
        input[i++] = new Integer(6);
        input[i++] = new Integer(2);
        input[i++] = new Integer(300);
        input[i++] = new Integer(301);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test612(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(8);
        input[i++] = new Integer(6);
        input[i++] = new Integer(2);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test679(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(9);
        input[i++] = new Integer(6);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test897(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(12);
        input[i++] = new Integer(8);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(true);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test983(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(81);
        input[i++] = new Integer(6);
        input[i++] = new Integer(8);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

    public void test984(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(81);
        input[i++] = new Integer(6);
        input[i++] = new Integer(6);
        input[i++] = new Integer(1);
        input[i++] = new Integer(200);
        input[i++] = new Integer(0);
        input[i++] = new Boolean(false);
        i=0;
        cute.Cute.input = this;
        A1.Problem14_RERS2012.main(null);
    }

}
