package jxnct;

import cute.Cute;

public class Problem4_RERS2019jxnct {
	
	private String[] inputs = {"D","J","B","E","H","G","L","C","M","K","I","O","F","A","N"};

	public int a37715639 = Cute.input.Integer();
	public int a1903106971 = Cute.input.Integer();
	public int a1159686220 = Cute.input.Integer();
	public int a846246165 = Cute.input.Integer();
	public int a1287306075 = Cute.input.Integer();
	public int a439146033 = Cute.input.Integer();
	public int a2035270918 = Cute.input.Integer();
	public int a96697915 = Cute.input.Integer();
	public int a817053393 = Cute.input.Integer();
	public int a1137531920 =Cute.input.Integer();
	public int a1096058849 = Cute.input.Integer();
	public int a1175284955 = Cute.input.Integer();
	public int a965000114 = Cute.input.Integer();
	public int a1809130631 = Cute.input.Integer();
	public int a1432372429 = Cute.input.Integer();
	public int a1031575710 = Cute.input.Integer();
	public int a310547442 = Cute.input.Integer();
	public int a606789331 = Cute.input.Integer();
	public int a336589140 = Cute.input.Integer();
	public int a642273090 = Cute.input.Integer();
	public int a2059641681 = Cute.input.Integer();
	public int a101599338 = Cute.input.Integer();
	public int a1996793042 = Cute.input.Integer();
	public int a1797294897 = Cute.input.Integer();
	public boolean cf = Cute.input.Boolean();
	public boolean input = Cute.input.Boolean();
	public int a2138011404 = Cute.input.Integer();
	public int a694319863 = Cute.input.Integer();
	public int a445665251 = Cute.input.Integer();
	public int a1949910810 = Cute.input.Integer();
	public int a980176568 = Cute.input.Integer();
	public int a2119175241 = Cute.input.Integer();
	public int a319680784 = Cute.input.Integer();
	public int a1314524615 = Cute.input.Integer();
	public int a1668287217 = Cute.input.Integer();
	public int a2049033870 = Cute.input.Integer();
	public int a1268955651 = Cute.input.Integer();
	public int a1926573135 = Cute.input.Integer();
	public int a1809737646 = Cute.input.Integer();
	public int a82644459 = Cute.input.Integer();
	public int a1830171812 = Cute.input.Integer();
	public int a1919024723 = Cute.input.Integer();
	public int a169968510 = Cute.input.Integer();
	public int a240160131 = Cute.input.Integer();
	public int a210582800 = Cute.input.Integer();
	public int a1863335615 = Cute.input.Integer();
	public int a1997755444 = Cute.input.Integer();
	public int a1706450595 = Cute.input.Integer();
	public int a1322942843 = Cute.input.Integer();
	public int a446192584 = Cute.input.Integer();
	public int a10006008 = Cute.input.Integer();
	public int a315270875 = Cute.input.Integer();
	public int a1332297805 = Cute.input.Integer();
	public int a136048686 = Cute.input.Integer();
	public int a460768686 =Cute.input.Integer();
	public int a1801650070 = Cute.input.Integer();
	public int a415417543 = Cute.input.Integer();
	public int a1772678946 = Cute.input.Integer();
	public int a367523735 = Cute.input.Integer();
	public int a742257091 = Cute.input.Integer();
	public int a506686070 = Cute.input.Integer();
	public int a2121455691 = Cute.input.Integer();
	public int a193239507 = Cute.input.Integer();
	public int a1614547010 = Cute.input.Integer();
	public int a1839837863 = Cute.input.Integer();
	public int a1857955441 = Cute.input.Integer();
	public int a135483884 = Cute.input.Integer();
	public int a1049854501 = Cute.input.Integer();
	public int a1160822650 = Cute.input.Integer();
	public int a1138657697 = Cute.input.Integer();
	public int a1299628692 = Cute.input.Integer();
	public int a249165573 = Cute.input.Integer();
	public int a1118899526 = Cute.input.Integer();
	public int a371658569 = Cute.input.Integer();
	public int a1147972397 = Cute.input.Integer();
	public int a799584195 = Cute.input.Integer();
	public int a2069556765 = Cute.input.Integer();
	public int a639300781 = Cute.input.Integer();
	public int a1894566393 = Cute.input.Integer();
	public int a134078375 = Cute.input.Integer();
	public int a198886191 =Cute.input.Integer();
	public int a516554631 = Cute.input.Integer();
	public int a826297789 = Cute.input.Integer();
	public int a432276736 = Cute.input.Integer();
	public int a2028167822 = Cute.input.Integer();
	public int a667587542 = Cute.input.Integer();
	public int a1445407416 = Cute.input.Integer();
	public int a1541223916 = Cute.input.Integer();
	public int a968224050 = Cute.input.Integer();
	public int a1961665287 = Cute.input.Integer();
	public int a367928470 = Cute.input.Integer();
	public int a1424251579 = Cute.input.Integer();
	public int a331348541 = Cute.input.Integer();
	public int a905781092 = Cute.input.Integer();
	public int a1247881348 = Cute.input.Integer();
	public int a1449404688 = Cute.input.Integer();
	public int a58725572 = Cute.input.Integer();
	public int a985710449 = Cute.input.Integer();
	public int a356828654 = Cute.input.Integer();
	public int a1231632361 = Cute.input.Integer();
	public int a455482258 = Cute.input.Integer();
	public int a362178176 = Cute.input.Integer();
	public int a1252084870 = Cute.input.Integer();
	public int a1909701604 = Cute.input.Integer();
	public int a1731288604 = Cute.input.Integer();

private  void calculateOutputm38(boolean input) {
//************************Modified code Start***********************************
 if((input==false)&&(a968224050==0)&&(cf==false)&&(a1147972397==0)&&(a1706450595==0)){
if(a1614547010==0){}
else if(!(a1614547010==0)){}
}
else{}
 if(!(a968224050==0)||!(cf==false)||!(a1147972397==0)||!(a1706450595==0)||(a1614547010==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a1147972397==0)||!(a1706450595==0)||(a1614547010==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(input==false)||!(a968224050==0)||!(a1147972397==0)||!(a1706450595==0)||(a1614547010==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a968224050==0)||!(cf==false)||!(a1706450595==0)||(a1614547010==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(input==false)||!(a968224050==0)||!(cf==false)||!(a1147972397==0)||(a1614547010==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
    if((a1614547010 ==0) || (input==false) && (a968224050==0) && (cf==false) && (a1147972397 ==0) && (a1706450595==0)){
    	cf = false;
    	a1801650070 = 6;
    	a1706450595 =0;
    	a1247881348 = 11;
    	a1252084870 = 7; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if((cf==false)&&(a1614547010==0)&&(a968224050==0)||(input==false)&&(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1706450595==0)||(cf==false)&&(a1614547010==0)&&(a968224050==0)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a1614547010==0)&&(a968224050==0)||(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1614547010==0)||!(a968224050==0)||(input==false)&&(a1706450595==0)||(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a968224050==0)||(input==false)&&(a1706450595==0)||(a1147972397==0)){
if(a1614547010==0){}
else if(!(a1614547010==0)){}
}
else{}
 if(!(cf==false)||!(a1614547010==0)||(input==false)&&(a1706450595==0)||(a1147972397==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) || (input==false) && (a1706450595==0) || (cf==false) && (a1614547010 ==0) && (a968224050==0)){
    	cf = false;
    	a1332297805 =0;
    	a1147972397 = 10;
    	a1801650070 = 12; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm39(boolean input) {
//************************Modified code Start***********************************
 if(!(a968224050==0)||(a1614547010==0)&&(input==false)&&(a1147972397==0)||(cf==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||(a1614547010==0)&&(input==false)&&(a1147972397==0)||(cf==false)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if((a1614547010==0)&&(input==false)&&(a1147972397==0)||(a1706450595==0)&&(a968224050==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a1147972397==0)||(cf==false)||(a1706450595==0)&&(a968224050==0)){
if(a1614547010==0){}
else if(!(a1614547010==0)){}
}
else{}
 if(!(a1614547010==0)||!(a1147972397==0)||(cf==false)||(a1706450595==0)&&(a968224050==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1614547010==0)||!(input==false)||(cf==false)||(a1706450595==0)&&(a968224050==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
    if((a1706450595==0) && (a968224050==0) || (cf==false) || (a1614547010 ==0) && (input==false) && (a1147972397 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a606789331 =0;
    	a455482258 =0;
    	a1247881348 = 12; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a1614547010==0)||(a1706450595==0)&&(a1147972397==0)||(a968224050==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a1706450595==0)&&(a1147972397==0)||(a968224050==0)&&(cf==false)){
if(a1614547010==0){}
else if(!(a1614547010==0)){}
}
else{}
 if(!(cf==false)||(a1706450595==0)&&(a1147972397==0)||(input==false)&&(a1614547010==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(a968224050==0)||(a1706450595==0)&&(a1147972397==0)||(input==false)&&(a1614547010==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1147972397==0)||(a968224050==0)&&(cf==false)||(input==false)&&(a1614547010==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||(a968224050==0)&&(cf==false)||(input==false)&&(a1614547010==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
	if((input==false) && (a1614547010 ==0) || (a968224050==0) && (cf==false) || (a1706450595==0) && (a1147972397 ==0)){
    	cf = false;
    	a817053393 = 13;
    	a1997755444 = 10;
    	a1706450595 =0;
    	a1830171812 = 4; 
    	System.out.println("P");
    } 
}
private  void calculateOutputm40(boolean input) {
//************************Modified code Start***********************************
 if(!(a1147972397==0)||(cf==false)&&(input==false)&&(a1706450595==0)||(a968224050==0)){
if(a1137531920==0){}
else if(!(a1137531920==0)){}
}
else{}
 if(!(a1137531920==0)||(cf==false)&&(input==false)&&(a1706450595==0)||(a968224050==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((cf==false)&&(input==false)&&(a1706450595==0)||(a1137531920==0)&&(a1147972397==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(input==false)||!(a1706450595==0)||(a968224050==0)||(a1137531920==0)&&(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a1706450595==0)||(a968224050==0)||(a1137531920==0)&&(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||!(input==false)||(a968224050==0)||(a1137531920==0)&&(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
    if((a1137531920==0) && (a1147972397 ==0) || (a968224050==0) || (cf==false) && (input==false) && (a1706450595==0)){
    	cf = false;
    	a1706450595 =0;
    	a817053393 = 15;
    	a1031575710 = 14;
    	a210582800 = 5; 
    	System.out.println("Q");
    } 
//************************Modified code Start***********************************
 if((input==false)||(cf==false)&&(a1137531920==0)&&(a1147972397==0)||(a968224050==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((input==false)||(cf==false)&&(a1137531920==0)&&(a1147972397==0)||(a1706450595==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(a1137531920==0)||!(a1147972397==0)||(input==false)||(a968224050==0)||(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a1147972397==0)||(input==false)||(a968224050==0)||(a1706450595==0)){
if(a1137531920==0){}
else if(!(a1137531920==0)){}
}
else{}
 if(!(cf==false)||!(a1137531920==0)||(input==false)||(a968224050==0)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((cf==false)&&(a1137531920==0)&&(a1147972397==0)||(a968224050==0)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
	if((a1706450595==0) || (a968224050==0) || (cf==false) && (a1137531920==0) && (a1147972397 ==0) || (input==false)){
    	cf = false;
    	a367928470 =0;
    	a1706450595 =0;
    	a1096058849 = 14;
    	a1926573135 = 11; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if((a1137531920==0)||(a1147972397==0)&&(a1706450595==0)||(cf==false)&&(input==false)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(input==false)||(a1137531920==0)||(a1147972397==0)&&(a1706450595==0)||(a968224050==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a1137531920==0)||(a1147972397==0)&&(a1706450595==0)||(a968224050==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1706450595==0)||(a1137531920==0)||(cf==false)&&(input==false)||(a968224050==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a1137531920==0)||(cf==false)&&(input==false)||(a968224050==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((a1147972397==0)&&(a1706450595==0)||(cf==false)&&(input==false)||(a968224050==0)){
if(a1137531920==0){}
else if(!(a1137531920==0)){}
}
else{}
//************************Modified code end***********************************
	if((a968224050==0) || (cf==false) && (input==false) || (a1147972397 ==0) && (a1706450595==0) || (a1137531920==0)){
    	cf = false;
    	a968224050 =0;
    	a965000114 =0; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm41(boolean input) {
//************************Modified code Start***********************************
 if(!(a1706450595==0)||(a1147972397==0)&&(a968224050==0)||(cf==false)&&(input==false)){
if(a1137531920==0){}
else if(!(a1137531920==0)){}
}
else{}
 if(!(a1137531920==0)||(a1147972397==0)&&(a968224050==0)||(cf==false)&&(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(input==false)||(a1147972397==0)&&(a968224050==0)||(a1137531920==0)&&(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a1147972397==0)&&(a968224050==0)||(a1137531920==0)&&(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a968224050==0)||(cf==false)&&(input==false)||(a1137531920==0)&&(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(cf==false)&&(input==false)||(a1137531920==0)&&(a1706450595==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
//************************Modified code end***********************************
    if((a1137531920==0) && (a1706450595==0) || (cf==false) && (input==false) || (a1147972397 ==0) && (a968224050==0)){
    	cf = false;
    	a1449404688 =0;
    	a1299628692 =0;
    	a1706450595 =0;
    	a1247881348 = 10; 
    	System.out.println("Y");
    } 
//************************Modified code Start***********************************
 if((input==false)||(a968224050==0)&&(a1706450595==0)||(a1137531920==0)&&(cf==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(cf==false)||(input==false)||(a968224050==0)&&(a1706450595==0)||(a1147972397==0)){
if(a1137531920==0){}
else if(!(a1137531920==0)){}
}
else{}
 if(!(a1137531920==0)||(input==false)||(a968224050==0)&&(a1706450595==0)||(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1706450595==0)||(input==false)||(a1137531920==0)&&(cf==false)||(a1147972397==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(a968224050==0)||(input==false)||(a1137531920==0)&&(cf==false)||(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((a968224050==0)&&(a1706450595==0)||(a1137531920==0)&&(cf==false)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) || (a1137531920==0) && (cf==false) || (a968224050==0) && (a1706450595==0) || (input==false)){
    	cf = false;
    	a1175284955 =0;
    	a1706450595 =0;
    	a817053393 = 10;
    	a37715639 = 5; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm42(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)&&(a968224050==0)&&(a1706450595==0)||(a1147972397==0)&&(input==false)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a968224050==0)&&(a1706450595==0)||(a965000114==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(cf==false)&&(a968224050==0)&&(a1706450595==0)||(a965000114==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a968224050==0)||!(a1706450595==0)||(a1147972397==0)&&(input==false)||(a965000114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a1706450595==0)||(a1147972397==0)&&(input==false)||(a965000114==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(cf==false)||!(a968224050==0)||(a1147972397==0)&&(input==false)||(a965000114==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
    if((a965000114==0) || (a1147972397 ==0) && (input==false) || (cf==false) && (a968224050==0) && (a1706450595==0)){
    	cf = false;
    	a2035270918 =0;
    	a1147972397 = 9;
    	a356828654 = 7; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if((cf==false)&&(input==false)&&(a1147972397==0)||(a968224050==0)&&(a1706450595==0)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
 if(!(a1706450595==0)||(cf==false)&&(input==false)&&(a1147972397==0)||(a965000114==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(a968224050==0)||(cf==false)&&(input==false)&&(a1147972397==0)||(a965000114==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(input==false)||!(a1147972397==0)||(a968224050==0)&&(a1706450595==0)||(a965000114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a1147972397==0)||(a968224050==0)&&(a1706450595==0)||(a965000114==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||!(input==false)||(a968224050==0)&&(a1706450595==0)||(a965000114==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
	if((a965000114==0) || (a968224050==0) && (a1706450595==0) || (cf==false) && (input==false) && (a1147972397 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a817053393 = 11;
    	a198886191 =0;
    	a2059641681 = 16; 
    	System.out.println("Y");
    } 
//************************Modified code Start***********************************
 if((cf==false)&&(a965000114==0)&&(a1147972397==0)||(a968224050==0)&&(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a965000114==0)&&(a1147972397==0)||(a1706450595==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(a968224050==0)||(cf==false)&&(a965000114==0)&&(a1147972397==0)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a965000114==0)||!(a1147972397==0)||(a968224050==0)&&(input==false)||(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a1147972397==0)||(a968224050==0)&&(input==false)||(a1706450595==0)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
 if(!(cf==false)||!(a965000114==0)||(a968224050==0)&&(input==false)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1706450595==0) || (a968224050==0) && (input==false) || (cf==false) && (a965000114==0) && (a1147972397 ==0)){
    	cf = false;
    	a1247881348 = 5;
    	a1706450595 =0;
    	a516554631 =0;
    	a1961665287 = 7; 
    	System.out.println("Y");
    } 
//************************Modified code Start***********************************
 if((a1706450595==0)||(a968224050==0)&&(cf==false)||(a1147972397==0)&&(a965000114==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a965000114==0)||(a1706450595==0)||(a968224050==0)&&(cf==false)||(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a1706450595==0)||(a968224050==0)&&(cf==false)||(input==false)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
 if(!(cf==false)||(a1706450595==0)||(a1147972397==0)&&(a965000114==0)||(input==false)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(a968224050==0)||(a1706450595==0)||(a1147972397==0)&&(a965000114==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a968224050==0)&&(cf==false)||(a1147972397==0)&&(a965000114==0)||(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
	if((input==false) || (a1147972397 ==0) && (a965000114==0) || (a968224050==0) && (cf==false) || (a1706450595==0)){
    	cf = false;
    	a980176568 =0;
    	a1706450595 =0;
    	a455482258 =0;
    	a1096058849 = 9; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if((a1706450595==0)||(a1147972397==0)&&(cf==false)||(input==false)&&(a965000114==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(a965000114==0)||(a1706450595==0)||(a1147972397==0)&&(cf==false)||(a968224050==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a1706450595==0)||(a1147972397==0)&&(cf==false)||(a968224050==0)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
 if(!(cf==false)||(a1706450595==0)||(input==false)&&(a965000114==0)||(a968224050==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a1706450595==0)||(input==false)&&(a965000114==0)||(a968224050==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a1147972397==0)&&(cf==false)||(input==false)&&(a965000114==0)||(a968224050==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
	if((a968224050==0) || (input==false) && (a965000114==0) || (a1147972397 ==0) && (cf==false) || (a1706450595==0)){
    	cf = false;
    	a985710449 =0;
    	a1147972397 = 9;
    	a356828654 = 5; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if(!(a965000114==0)||(a1147972397==0)&&(a968224050==0)||(input==false)&&(cf==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||(a1147972397==0)&&(a968224050==0)||(input==false)&&(cf==false)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
 if(!(cf==false)||(a1147972397==0)&&(a968224050==0)||(a1706450595==0)&&(a965000114==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a1147972397==0)&&(a968224050==0)||(a1706450595==0)&&(a965000114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a968224050==0)||(input==false)&&(cf==false)||(a1706450595==0)&&(a965000114==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(input==false)&&(cf==false)||(a1706450595==0)&&(a965000114==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1706450595==0) && (a965000114==0) || (input==false) && (cf==false) || (a1147972397 ==0) && (a968224050==0)){
    	cf = false;
    	a1706450595 =0;
    	a1424251579 =0;
    	a1137531920 =0;
    	a415417543 = 6; 
    	System.out.println("Q");
    } 
	
	
//************************Modified code Start***********************************
 if((a1147972397==0)||(cf==false)&&(a1706450595==0)||(input==false)&&(a968224050==0)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
 if(!(a968224050==0)||(a1147972397==0)||(cf==false)&&(a1706450595==0)||(a965000114==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a1147972397==0)||(cf==false)&&(a1706450595==0)||(a965000114==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(a1706450595==0)||(a1147972397==0)||(input==false)&&(a968224050==0)||(a965000114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a1147972397==0)||(input==false)&&(a968224050==0)||(a965000114==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((cf==false)&&(a1706450595==0)||(input==false)&&(a968224050==0)||(a965000114==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
	if((a965000114==0) || (input==false) && (a968224050==0) || (cf==false) && (a1706450595==0) || (a1147972397 ==0)){
    	cf = false;
    	a1996793042 = 6;
    	a1424251579 =0;
    	a1706450595 =0;
    	a1541223916 = 7; 
    	System.out.println("Z");
    } 
	
//************************Modified code Start***********************************
 if((cf==false)&&(input==false)&&(a1706450595==0)||(a1147972397==0)&&(a965000114==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(a965000114==0)||(cf==false)&&(input==false)&&(a1706450595==0)||(a968224050==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(cf==false)&&(input==false)&&(a1706450595==0)||(a968224050==0)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
 if(!(input==false)||!(a1706450595==0)||(a1147972397==0)&&(a965000114==0)||(a968224050==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a1706450595==0)||(a1147972397==0)&&(a965000114==0)||(a968224050==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||!(input==false)||(a1147972397==0)&&(a965000114==0)||(a968224050==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
	if((a968224050==0) || (a1147972397 ==0) && (a965000114==0) || (cf==false) && (input==false) && (a1706450595==0)){
    	cf = false;
    	a1706450595 =0;
    	a1997755444 = 4;
    	a817053393 = 13;
    	a319680784 = 9; 
    	System.out.println("Q");
    } 
//************************Modified code Start***********************************
 if((a968224050==0)||(cf==false)&&(input==false)&&(a1706450595==0)&&(a965000114==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(input==false)||!(a1706450595==0)||!(a965000114==0)||(a968224050==0)||(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a1706450595==0)||!(a965000114==0)||(a968224050==0)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||!(input==false)||!(a965000114==0)||(a968224050==0)||(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(cf==false)||!(input==false)||!(a1706450595==0)||(a968224050==0)||(a1147972397==0)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
 if((cf==false)&&(input==false)&&(a1706450595==0)&&(a965000114==0)||(a1147972397==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) || (cf==false) && (input==false) && (a1706450595==0) && (a965000114==0) || (a968224050==0)){
    	cf = false;
    	a1706450595 =0;
    	a2049033870 =0;
    	a980176568 =0;
    	a1096058849 = 9; 
    	System.out.println("U");
    } 
	
//************************Modified code Start***********************************
 if(!(a968224050==0)||(a1706450595==0)||(cf==false)&&(a965000114==0)||(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a1706450595==0)||(cf==false)&&(a965000114==0)||(input==false)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if((a1706450595==0)||(cf==false)&&(a965000114==0)||(a1147972397==0)&&(a968224050==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a965000114==0)||(a1706450595==0)||(input==false)||(a1147972397==0)&&(a968224050==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a1706450595==0)||(input==false)||(a1147972397==0)&&(a968224050==0)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
 if((cf==false)&&(a965000114==0)||(input==false)||(a1147972397==0)&&(a968224050==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) && (a968224050==0) || (input==false) || (cf==false) && (a965000114==0) || (a1706450595==0)){
    	cf = false;
    	a817053393 = 15;
    	a1706450595 =0;
    	a968224050 =0;
    	a1031575710 = 11; 
    	System.out.println("U");
    } 
	
}
private  void calculateOutputm43(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)&&(a965000114==0)&&(a1147972397==0)||(a968224050==0)||(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((cf==false)&&(a965000114==0)&&(a1147972397==0)||(a968224050==0)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((cf==false)&&(a965000114==0)&&(a1147972397==0)||(input==false)||(a1706450595==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(a965000114==0)||!(a1147972397==0)||(a968224050==0)||(input==false)||(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a1147972397==0)||(a968224050==0)||(input==false)||(a1706450595==0)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
 if(!(cf==false)||!(a965000114==0)||(a968224050==0)||(input==false)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
    if((a1706450595==0) || (input==false) || (a968224050==0) || (cf==false) && (a965000114==0) && (a1147972397 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a1949910810 =0;
    	a1797294897 =0;
    	a1096058849 = 13; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a968224050==0)||(input==false)&&(a1706450595==0)&&(a1147972397==0)||(cf==false)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
 if(!(a965000114==0)||(input==false)&&(a1706450595==0)&&(a1147972397==0)||(cf==false)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if((input==false)&&(a1706450595==0)&&(a1147972397==0)||(a965000114==0)&&(a968224050==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1706450595==0)||!(a1147972397==0)||(cf==false)||(a965000114==0)&&(a968224050==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a1147972397==0)||(cf==false)||(a965000114==0)&&(a968224050==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(input==false)||!(a1706450595==0)||(cf==false)||(a965000114==0)&&(a968224050==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
	if((a965000114==0) && (a968224050==0) || (cf==false) || (input==false) && (a1706450595==0) && (a1147972397 ==0)){
    	cf = false;
    	a58725572 = 5;
    	a1147972397 = 7;
    	a362178176 = 11; 
    	System.out.println("P");
    } 
//************************Modified code Start***********************************
 if((cf==false)&&(a1147972397==0)&&(input==false)&&(a1706450595==0)||(a965000114==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if((cf==false)&&(a1147972397==0)&&(input==false)&&(a1706450595==0)||(a968224050==0)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
 if(!(a1147972397==0)||!(input==false)||!(a1706450595==0)||(a965000114==0)||(a968224050==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(input==false)||!(a1706450595==0)||(a965000114==0)||(a968224050==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(cf==false)||!(a1147972397==0)||!(a1706450595==0)||(a965000114==0)||(a968224050==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||!(a1147972397==0)||!(input==false)||(a965000114==0)||(a968224050==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
	if((a968224050==0) || (a965000114==0) || (cf==false) && (a1147972397 ==0) && (input==false) && (a1706450595==0)){
    	cf = false;
    	a1706450595 =0;
    	a1247881348 = 10;
    	a1299628692 =0;
    	a336589140 = 10; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm44(boolean input) {
//************************Modified code Start***********************************
 if((a1706450595==0)||(a968224050==0)&&(input==false)&&(cf==false)&&(a1147972397==0)){
if(a460768686==00){}
else if(!(a460768686==00)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a1147972397==0)||(a1706450595==0)||(a460768686==00)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(a968224050==0)||!(cf==false)||!(a1147972397==0)||(a1706450595==0)||(a460768686==00)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a968224050==0)||!(input==false)||!(a1147972397==0)||(a1706450595==0)||(a460768686==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a968224050==0)||!(input==false)||!(cf==false)||(a1706450595==0)||(a460768686==00)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((a968224050==0)&&(input==false)&&(cf==false)&&(a1147972397==0)||(a460768686==00)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
    if((a460768686 ==00) || (a968224050==0) && (input==false) && (cf==false) && (a1147972397 ==0) || (a1706450595==0)){
    	cf = false;
    	a1147972397 = 9;
    	a985710449 =0;
    	a356828654 = 5; 
    	System.out.println("Q");
    } 
//************************Modified code Start***********************************
 if((a460768686==0)||(input==false)||(a968224050==0)&&(cf==false)&&(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(cf==false)||!(a1706450595==0)||(a460768686==0)||(input==false)||(a1147972397==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if(!(a968224050==0)||!(a1706450595==0)||(a460768686==0)||(input==false)||(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a968224050==0)||!(cf==false)||(a460768686==0)||(input==false)||(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((a460768686==0)||(a968224050==0)&&(cf==false)&&(a1706450595==0)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((input==false)||(a968224050==0)&&(cf==false)&&(a1706450595==0)||(a1147972397==0)){
if(a460768686==0){}
else if(!(a460768686==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) || (a968224050==0) && (cf==false) && (a1706450595==0) || (input==false) || (a460768686 ==0)){
    	cf = false;
    	a1147972397 = 5;
    	a1926573135 = 9;
    	a2119175241 = 12; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm45(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)&&(a460768686==0)&&(input==false)&&(a1706450595==0)||(a1147972397==0)){
if(a968224050==0){}
else if(!(a968224050==0)){}
}
else{}
 if((cf==false)&&(a460768686==0)&&(input==false)&&(a1706450595==0)||(a968224050==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a460768686==0)||!(input==false)||!(a1706450595==0)||(a1147972397==0)||(a968224050==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(input==false)||!(a1706450595==0)||(a1147972397==0)||(a968224050==0)){
if(a460768686==0){}
else if(!(a460768686==0)){}
}
else{}
 if(!(cf==false)||!(a460768686==0)||!(a1706450595==0)||(a1147972397==0)||(a968224050==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||!(a460768686==0)||!(input==false)||(a1147972397==0)||(a968224050==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
    if((a968224050==0) || (a1147972397 ==0) || (cf==false) && (a460768686 ==0) && (input==false) && (a1706450595==0)){
    	cf = false;
    	a1175284955 =0;
    	a371658569 =0;
    	a1147972397 = 4; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm46(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)&&(a371658569==0)&&(a1706450595==0)||(input==false)&&(a1147972397==0)){
if(a1175284955==0){}
else if(!(a1175284955==0)){}
}
else{}
 if(!(a1147972397==0)||(cf==false)&&(a371658569==0)&&(a1706450595==0)||(a1175284955==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a371658569==0)&&(a1706450595==0)||(a1175284955==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a371658569==0)||!(a1706450595==0)||(input==false)&&(a1147972397==0)||(a1175284955==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a1706450595==0)||(input==false)&&(a1147972397==0)||(a1175284955==0)){
if(a371658569==0){}
else if(!(a371658569==0)){}
}
else{}
 if(!(cf==false)||!(a371658569==0)||(input==false)&&(a1147972397==0)||(a1175284955==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
    if((a1175284955==0) || (input==false) && (a1147972397 ==0) || (cf==false) && (a371658569==0) && (a1706450595==0)){
    	cf = false;
    	 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if(!(a1175284955==0)||!(cf==false)||!(a1147972397==0)||!(a1706450595==0)||!(input==false)){
if(a371658569==0){}
else if(!(a371658569==0)){}
}
else{}
 if(!(a371658569==0)||!(cf==false)||!(a1147972397==0)||!(a1706450595==0)||!(input==false)){
if(a1175284955==0){}
else if(!(a1175284955==0)){}
}
else{}
 if(!(a371658569==0)||!(a1175284955==0)||!(a1147972397==0)||!(a1706450595==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a371658569==0)||!(a1175284955==0)||!(cf==false)||!(a1706450595==0)||!(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a371658569==0)||!(a1175284955==0)||!(cf==false)||!(a1147972397==0)||!(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a371658569==0)||!(a1175284955==0)||!(cf==false)||!(a1147972397==0)||!(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
	if((a371658569==0) && (a1175284955==0) && (cf==false) && (a1147972397 ==0) && (a1706450595==0) && (input==false)){
    	cf = false;
    	a642273090 = 8;
    	a1147972397 = 6;
    	a1961665287 = 9; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if((a1175284955==0)||(input==false)&&(cf==false)&&(a371658569==0)&&(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(cf==false)||!(a371658569==0)||!(a1706450595==0)||(a1175284955==0)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a371658569==0)||!(a1706450595==0)||(a1175284955==0)||(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a1706450595==0)||(a1175284955==0)||(a1147972397==0)){
if(a371658569==0){}
else if(!(a371658569==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a371658569==0)||(a1175284955==0)||(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((input==false)&&(cf==false)&&(a371658569==0)&&(a1706450595==0)||(a1147972397==0)){
if(a1175284955==0){}
else if(!(a1175284955==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) || (input==false) && (cf==false) && (a371658569==0) && (a1706450595==0) || (a1175284955==0)){
    	cf = false;
    	a1299628692 =0;
    	a1706450595 =0;
    	a817053393 = 14;
    	a1322942843 = 7; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm47(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)&&(a371658569==0)&&(a1706450595==0)||(a1147972397==0)&&(a1175284955==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1175284955==0)||(cf==false)&&(a371658569==0)&&(a1706450595==0)||(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(cf==false)&&(a371658569==0)&&(a1706450595==0)||(input==false)){
if(a1175284955==0){}
else if(!(a1175284955==0)){}
}
else{}
 if(!(a371658569==0)||!(a1706450595==0)||(a1147972397==0)&&(a1175284955==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a1706450595==0)||(a1147972397==0)&&(a1175284955==0)||(input==false)){
if(a371658569==0){}
else if(!(a371658569==0)){}
}
else{}
 if(!(cf==false)||!(a371658569==0)||(a1147972397==0)&&(a1175284955==0)||(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (a1147972397 ==0) && (a1175284955==0) || (cf==false) && (a371658569==0) && (a1706450595==0)){
    	cf = false;
    	a367928470 =0;
    	a1096058849 = 14;
    	a1706450595 =0;
    	a1926573135 = 11; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(a371658569==0)||(a1706450595==0)&&(a1175284955==0)&&(a1147972397==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a1706450595==0)&&(a1175284955==0)&&(a1147972397==0)||(cf==false)){
if(a371658569==0){}
else if(!(a371658569==0)){}
}
else{}
 if((a1706450595==0)&&(a1175284955==0)&&(a1147972397==0)||(input==false)&&(a371658569==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1175284955==0)||!(a1147972397==0)||(cf==false)||(input==false)&&(a371658569==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||!(a1147972397==0)||(cf==false)||(input==false)&&(a371658569==0)){
if(a1175284955==0){}
else if(!(a1175284955==0)){}
}
else{}
 if(!(a1706450595==0)||!(a1175284955==0)||(cf==false)||(input==false)&&(a371658569==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
	if((input==false) && (a371658569==0) || (cf==false) || (a1706450595==0) && (a1175284955==0) && (a1147972397 ==0)){
    	cf = false;
    	a817053393 = 15;
    	a1706450595 =0;
    	a1031575710 = 14;
    	a210582800 = 5; 
    	System.out.println("Q");
    } 
//************************Modified code Start***********************************
 if(!(input==false)||(cf==false)&&(a371658569==0)||(a1175284955==0)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(cf==false)&&(a371658569==0)||(a1175284955==0)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((cf==false)&&(a371658569==0)||(a1175284955==0)||(a1147972397==0)&&(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((cf==false)&&(a371658569==0)||(a1706450595==0)||(a1147972397==0)&&(input==false)){
if(a1175284955==0){}
else if(!(a1175284955==0)){}
}
else{}
 if(!(a371658569==0)||(a1175284955==0)||(a1706450595==0)||(a1147972397==0)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a1175284955==0)||(a1706450595==0)||(a1147972397==0)&&(input==false)){
if(a371658569==0){}
else if(!(a371658569==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) && (input==false) || (a1706450595==0) || (a1175284955==0) || (cf==false) && (a371658569==0)){
    	cf = false;
    	a1231632361 =0;
    	a1706450595 =0;
    	a1247881348 = 9;
    	a362178176 = 13; 
    	System.out.println("P");
    } 
//************************Modified code Start***********************************
 if((a1175284955==0)&&(input==false)&&(a371658569==0)||(cf==false)||(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((a1175284955==0)&&(input==false)&&(a371658569==0)||(cf==false)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((a1175284955==0)&&(input==false)&&(a371658569==0)||(a1147972397==0)||(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a371658569==0)||(cf==false)||(a1147972397==0)||(a1706450595==0)){
if(a1175284955==0){}
else if(!(a1175284955==0)){}
}
else{}
 if(!(a1175284955==0)||!(a371658569==0)||(cf==false)||(a1147972397==0)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1175284955==0)||!(input==false)||(cf==false)||(a1147972397==0)||(a1706450595==0)){
if(a371658569==0){}
else if(!(a371658569==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1706450595==0) || (a1147972397 ==0) || (cf==false) || (a1175284955==0) && (input==false) && (a371658569==0)){
    	cf = false;
    	a1096058849 = 11;
    	a1706450595 =0;
    	a1268955651 =0;
    	a319680784 = 5; 
    	System.out.println("Q");
    } 
}
private  void calculateOutputm48(boolean input) {
//************************Modified code Start***********************************
 if((a371658569==0)&&(cf==false)&&(a1706450595==0)||(input==false)&&(a1894566393==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1894566393==0)||(a371658569==0)&&(cf==false)&&(a1706450595==0)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a371658569==0)&&(cf==false)&&(a1706450595==0)||(a1147972397==0)){
if(a1894566393==0){}
else if(!(a1894566393==0)){}
}
else{}
 if(!(cf==false)||!(a1706450595==0)||(input==false)&&(a1894566393==0)||(a1147972397==0)){
if(a371658569==0){}
else if(!(a371658569==0)){}
}
else{}
 if(!(a371658569==0)||!(a1706450595==0)||(input==false)&&(a1894566393==0)||(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a371658569==0)||!(cf==false)||(input==false)&&(a1894566393==0)||(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
    if((a1147972397 ==0) || (input==false) && (a1894566393 ==0) || (a371658569==0) && (cf==false) && (a1706450595==0)){
    	cf = false;
    	a1322942843 = 2;
    	a817053393 = 14;
    	a1706450595 =0;
    	a2069556765 = 7; 
    	System.out.println("R");
    } 
//************************Modified code Start***********************************
 if(!(input==false)||(a1706450595==0)||(cf==false)&&(a1894566393==0)||(a1147972397==0)){
if(a371658569==0){}
else if(!(a371658569==0)){}
}
else{}
 if(!(a371658569==0)||(a1706450595==0)||(cf==false)&&(a1894566393==0)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a1706450595==0)||(cf==false)&&(a1894566393==0)||(a371658569==0)&&(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1894566393==0)||(a1706450595==0)||(a1147972397==0)||(a371658569==0)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a1706450595==0)||(a1147972397==0)||(a371658569==0)&&(input==false)){
if(a1894566393==0){}
else if(!(a1894566393==0)){}
}
else{}
 if((cf==false)&&(a1894566393==0)||(a1147972397==0)||(a371658569==0)&&(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
	if((a371658569==0) && (input==false) || (a1147972397 ==0) || (cf==false) && (a1894566393 ==0) || (a1706450595==0)){
    	cf = false;
    	a1096058849 = 7;
    	a1706450595 =0;
    	a1863335615 = 14;
    	a1614547010 = 11; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if((a1147972397==0)||(input==false)&&(cf==false)&&(a1706450595==0)&&(a371658569==0)){
if(a1894566393==0){}
else if(!(a1894566393==0)){}
}
else{}
 if(!(cf==false)||!(a1706450595==0)||!(a371658569==0)||(a1147972397==0)||(a1894566393==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a1706450595==0)||!(a371658569==0)||(a1147972397==0)||(a1894566393==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a371658569==0)||(a1147972397==0)||(a1894566393==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a1706450595==0)||(a1147972397==0)||(a1894566393==0)){
if(a371658569==0){}
else if(!(a371658569==0)){}
}
else{}
 if((input==false)&&(cf==false)&&(a1706450595==0)&&(a371658569==0)||(a1894566393==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1894566393 ==0) || (input==false) && (cf==false) && (a1706450595==0) && (a371658569==0) || (a1147972397 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a1096058849 = 11;
    	a1268955651 =0;
    	a240160131 = 13; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm49(boolean input) {
//************************Modified code Start***********************************
 if((a1147972397==0)||(cf==false)&&(a315270875==0)&&(a371658569==0)&&(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a315270875==0)||!(a371658569==0)||!(input==false)||(a1147972397==0)||(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a371658569==0)||!(input==false)||(a1147972397==0)||(a1706450595==0)){
if(a315270875==0){}
else if(!(a315270875==0)){}
}
else{}
 if(!(cf==false)||!(a315270875==0)||!(input==false)||(a1147972397==0)||(a1706450595==0)){
if(a371658569==0){}
else if(!(a371658569==0)){}
}
else{}
 if(!(cf==false)||!(a315270875==0)||!(a371658569==0)||(a1147972397==0)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((cf==false)&&(a315270875==0)&&(a371658569==0)&&(input==false)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
    if((a1706450595==0) || (cf==false) && (a315270875==0) && (a371658569==0) && (input==false) || (a1147972397 ==0)){
    	cf = false;
    	a817053393 = 10;
    	a1809737646 =0;
    	a1706450595 =0;
    	a37715639 = 7; 
    	System.out.println("Y");
    } 
//************************Modified code Start***********************************
 if((a371658569==0)||(cf==false)&&(a1706450595==0)||(a1147972397==0)&&(input==false)){
if(a315270875==0){}
else if(!(a315270875==0)){}
}
else{}
 if(!(input==false)||(a371658569==0)||(cf==false)&&(a1706450595==0)||(a315270875==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a371658569==0)||(cf==false)&&(a1706450595==0)||(a315270875==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1706450595==0)||(a371658569==0)||(a1147972397==0)&&(input==false)||(a315270875==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a371658569==0)||(a1147972397==0)&&(input==false)||(a315270875==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((cf==false)&&(a1706450595==0)||(a1147972397==0)&&(input==false)||(a315270875==0)){
if(a371658569==0){}
else if(!(a371658569==0)){}
}
else{}
//************************Modified code end***********************************
	if((a315270875==0) || (a1147972397 ==0) && (input==false) || (cf==false) && (a1706450595==0) || (a371658569==0)){
    	cf = false;
    	a1268955651 =0;
    	a1096058849 = 11;
    	a1706450595 =0;
    	a240160131 = 13; 
    	
    } 
}
private  void calculateOutputm51(boolean input) {
//************************Modified code Start***********************************
 if((a371658569==0)||(input==false)&&(cf==false)&&(a1706450595==0)&&(a1147972397==0)){
if(a1096058849==01){}
else if(!(a1096058849==01)){}
}
else{}
 if(!(cf==false)||!(a1706450595==0)||!(a1147972397==0)||(a371658569==0)||(a1096058849==01)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a1706450595==0)||!(a1147972397==0)||(a371658569==0)||(a1096058849==01)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a1147972397==0)||(a371658569==0)||(a1096058849==01)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a1706450595==0)||(a371658569==0)||(a1096058849==01)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((input==false)&&(cf==false)&&(a1706450595==0)&&(a1147972397==0)||(a1096058849==01)){
if(a371658569==0){}
else if(!(a371658569==0)){}
}
else{}
//************************Modified code end***********************************
    if((a1096058849 ==01) || (input==false) && (cf==false) && (a1706450595==0) && (a1147972397 ==0) || (a371658569==0)){
    	cf = false;
    	a1096058849 = 14;
    	a367928470 =0;
    	a1706450595 =0;
    	a1926573135 = 11; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm52(boolean input) {
//************************Modified code Start***********************************
 if((input==false)&&(a1147972397==0)||(cf==false)||(a1926573135==0)&&(a1706450595==0)){
if(a336589140==0){}
else if(!(a336589140==0)){}
}
else{}
 if(!(a1706450595==0)||(input==false)&&(a1147972397==0)||(cf==false)||(a336589140==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(a1926573135==0)||(input==false)&&(a1147972397==0)||(cf==false)||(a336589140==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((input==false)&&(a1147972397==0)||(a1926573135==0)&&(a1706450595==0)||(a336589140==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1147972397==0)||(cf==false)||(a1926573135==0)&&(a1706450595==0)||(a336589140==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)||(a1926573135==0)&&(a1706450595==0)||(a336589140==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
    if((a336589140 ==0) || (a1926573135 ==0) && (a1706450595==0) || (cf==false) || (input==false) && (a1147972397 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a1299628692 =0;
    	a817053393 = 14;
    	a1322942843 = 7; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if((a1706450595==0)||(cf==false)&&(a336589140==0)||(a1926573135==0)&&(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1147972397==0)||(a1706450595==0)||(cf==false)&&(a336589140==0)||(input==false)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(a1926573135==0)||(a1706450595==0)||(cf==false)&&(a336589140==0)||(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a336589140==0)||(a1706450595==0)||(a1926573135==0)&&(a1147972397==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a1706450595==0)||(a1926573135==0)&&(a1147972397==0)||(input==false)){
if(a336589140==0){}
else if(!(a336589140==0)){}
}
else{}
 if((cf==false)&&(a336589140==0)||(a1926573135==0)&&(a1147972397==0)||(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
	if((input==false) || (a1926573135 ==0) && (a1147972397 ==0) || (cf==false) && (a336589140 ==0) || (a1706450595==0)){
    	cf = false;
    	a1175284955 =0;
    	a371658569 =0;
    	a1147972397 = 4; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm53(boolean input) {
//************************Modified code Start***********************************
 if(!(a1147972397==0)||(a1926573135==0)&&(a2119175241==0)&&(input==false)||(cf==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||(a1926573135==0)&&(a2119175241==0)&&(input==false)||(cf==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((a1926573135==0)&&(a2119175241==0)&&(input==false)||(a1706450595==0)&&(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a2119175241==0)||!(input==false)||(cf==false)||(a1706450595==0)&&(a1147972397==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(a1926573135==0)||!(input==false)||(cf==false)||(a1706450595==0)&&(a1147972397==0)){
if(a2119175241==0){}
else if(!(a2119175241==0)){}
}
else{}
 if(!(a1926573135==0)||!(a2119175241==0)||(cf==false)||(a1706450595==0)&&(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a1706450595==0) && (a1147972397 ==0) || (cf==false) || (a1926573135 ==0) && (a2119175241 ==0) && (input==false)){
    	cf = false;
    	a1706450595 =0;
    	a37715639 = 10;
    	a817053393 = 10;
    	a310547442 = 13; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if((a1926573135==0)&&(cf==false)&&(input==false)||(a2119175241==0)&&(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1706450595==0)||(a1926573135==0)&&(cf==false)&&(input==false)||(a1147972397==0)){
if(a2119175241==0){}
else if(!(a2119175241==0)){}
}
else{}
 if(!(a2119175241==0)||(a1926573135==0)&&(cf==false)&&(input==false)||(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(cf==false)||!(input==false)||(a2119175241==0)&&(a1706450595==0)||(a1147972397==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(a1926573135==0)||!(input==false)||(a2119175241==0)&&(a1706450595==0)||(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1926573135==0)||!(cf==false)||(a2119175241==0)&&(a1706450595==0)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) || (a2119175241 ==0) && (a1706450595==0) || (a1926573135 ==0) && (cf==false) && (input==false)){
    	cf = false;
    	a1147972397 = 3;
    	a968224050 =0;
    	a460768686 = 10; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm54(boolean input) {
//************************Modified code Start***********************************
 if((a1706450595==0)&&(cf==false)&&(input==false)||(a1147972397==0)&&(a799584195==0)){
if(a1926573135==00){}
else if(!(a1926573135==00)){}
}
else{}
 if(!(a799584195==0)||(a1706450595==0)&&(cf==false)&&(input==false)||(a1926573135==00)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a1706450595==0)&&(cf==false)&&(input==false)||(a1926573135==00)){
if(a799584195==0){}
else if(!(a799584195==0)){}
}
else{}
 if(!(cf==false)||!(input==false)||(a1147972397==0)&&(a799584195==0)||(a1926573135==00)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||!(input==false)||(a1147972397==0)&&(a799584195==0)||(a1926573135==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1706450595==0)||!(cf==false)||(a1147972397==0)&&(a799584195==0)||(a1926573135==00)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a1926573135 ==00) || (a1147972397 ==0) && (a799584195==0) || (a1706450595==0) && (cf==false) && (input==false)){
    	cf = false;
    	a1247881348 = 10;
    	a1706450595 =0;
    	a1299628692 =0;
    	a336589140 = 10; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm55(boolean input) {
//************************Modified code Start***********************************
 if((input==false)||(a2069556765==0)&&(a1926573135==0)&&(a1706450595==0)&&(cf==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1926573135==0)||!(a1706450595==0)||!(cf==false)||(input==false)||(a1147972397==0)){
if(a2069556765==0){}
else if(!(a2069556765==0)){}
}
else{}
 if(!(a2069556765==0)||!(a1706450595==0)||!(cf==false)||(input==false)||(a1147972397==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(a2069556765==0)||!(a1926573135==0)||!(cf==false)||(input==false)||(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a2069556765==0)||!(a1926573135==0)||!(a1706450595==0)||(input==false)||(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a2069556765==0)&&(a1926573135==0)&&(a1706450595==0)&&(cf==false)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a1147972397 ==0) || (a2069556765 ==0) && (a1926573135 ==0) && (a1706450595==0) && (cf==false) || (input==false)){
    	cf = false;
    	a446192584 =0;
    	a1706450595 =0;
    	a1096058849 = 7;
    	a1863335615 = 9; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if((a1926573135==0)&&(cf==false)&&(a1147972397==0)&&(a1706450595==0)||(a2069556765==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a1926573135==0)&&(cf==false)&&(a1147972397==0)&&(a1706450595==0)||(input==false)){
if(a2069556765==0){}
else if(!(a2069556765==0)){}
}
else{}
 if(!(cf==false)||!(a1147972397==0)||!(a1706450595==0)||(a2069556765==0)||(input==false)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(a1926573135==0)||!(a1147972397==0)||!(a1706450595==0)||(a2069556765==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1926573135==0)||!(cf==false)||!(a1706450595==0)||(a2069556765==0)||(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1926573135==0)||!(cf==false)||!(a1147972397==0)||(a2069556765==0)||(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
	if((input==false) || (a2069556765 ==0) || (a1926573135 ==0) && (cf==false) && (a1147972397 ==0) && (a1706450595==0)){
    	cf = false;
    	a1137531920 =0;
    	a1424251579 =0;
    	a1706450595 =0;
    	a415417543 = 8; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm56(boolean input) {
//************************Modified code Start***********************************
 if((a2069556765==0)&&(a1926573135==0)&&(input==false)||(a1706450595==0)||(cf==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((a2069556765==0)&&(a1926573135==0)&&(input==false)||(a1706450595==0)||(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a2069556765==0)&&(a1926573135==0)&&(input==false)||(cf==false)||(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1926573135==0)||!(input==false)||(a1706450595==0)||(cf==false)||(a1147972397==0)){
if(a2069556765==0){}
else if(!(a2069556765==0)){}
}
else{}
 if(!(a2069556765==0)||!(input==false)||(a1706450595==0)||(cf==false)||(a1147972397==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(a2069556765==0)||!(a1926573135==0)||(a1706450595==0)||(cf==false)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a1147972397 ==0) || (cf==false) || (a1706450595==0) || (a2069556765 ==0) && (a1926573135 ==0) && (input==false)){
    	cf = false;
    	a1147972397 = 4;
    	a371658569 =0;
    	a1894566393 = 7; 
    	System.out.println("W");
//************************Modified code Start***********************************
 if(!(input==false)||(cf==false)&&(a1147972397==0)&&(a1926573135==0)||(a2069556765==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||(cf==false)&&(a1147972397==0)&&(a1926573135==0)||(a2069556765==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((cf==false)&&(a1147972397==0)&&(a1926573135==0)||(a1706450595==0)&&(input==false)){
if(a2069556765==0){}
else if(!(a2069556765==0)){}
}
else{}
 if(!(a1147972397==0)||!(a1926573135==0)||(a2069556765==0)||(a1706450595==0)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a1926573135==0)||(a2069556765==0)||(a1706450595==0)&&(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(cf==false)||!(a1147972397==0)||(a2069556765==0)||(a1706450595==0)&&(input==false)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
//************************Modified code end***********************************
    } if((a1706450595==0) && (input==false) || (a2069556765 ==0) || (cf==false) && (a1147972397 ==0) && (a1926573135 ==0)){
    	cf = false;
    	a817053393 = 11;
    	a1706450595 =0;
    	a198886191 =0;
    	a2059641681 = 12; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(a1706450595==0)||(a1147972397==0)&&(cf==false)&&(input==false)||(a2069556765==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(a1926573135==0)||(a1147972397==0)&&(cf==false)&&(input==false)||(a2069556765==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((a1147972397==0)&&(cf==false)&&(input==false)||(a1926573135==0)&&(a1706450595==0)){
if(a2069556765==0){}
else if(!(a2069556765==0)){}
}
else{}
 if(!(cf==false)||!(input==false)||(a2069556765==0)||(a1926573135==0)&&(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||!(input==false)||(a2069556765==0)||(a1926573135==0)&&(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1147972397==0)||!(cf==false)||(a2069556765==0)||(a1926573135==0)&&(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
	if((a1926573135 ==0) && (a1706450595==0) || (a2069556765 ==0) || (a1147972397 ==0) && (cf==false) && (input==false)){
    	cf = false;
    	a817053393 = 12;
    	a1706450595 =0;
    	a356828654 = 7;
    	a1118899526 = 2; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm57(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||(input==false)||(a1147972397==0)&&(a2069556765==0)||(a1706450595==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(a1926573135==0)||(input==false)||(a1147972397==0)&&(a2069556765==0)||(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((input==false)||(a1147972397==0)&&(a2069556765==0)||(a1926573135==0)&&(cf==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a2069556765==0)||(input==false)||(a1706450595==0)||(a1926573135==0)&&(cf==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(input==false)||(a1706450595==0)||(a1926573135==0)&&(cf==false)){
if(a2069556765==0){}
else if(!(a2069556765==0)){}
}
else{}
 if((a1147972397==0)&&(a2069556765==0)||(a1706450595==0)||(a1926573135==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a1926573135 ==0) && (cf==false) || (a1706450595==0) || (a1147972397 ==0) && (a2069556765 ==0) || (input==false)){
    	cf = false;
    	a799584195 =0;
    	a1926573135 = 10; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if((cf==false)&&(a1706450595==0)&&(a2069556765==0)||(input==false)&&(a1926573135==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1926573135==0)||(cf==false)&&(a1706450595==0)&&(a2069556765==0)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a1706450595==0)&&(a2069556765==0)||(a1147972397==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(a1706450595==0)||!(a2069556765==0)||(input==false)&&(a1926573135==0)||(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a2069556765==0)||(input==false)&&(a1926573135==0)||(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(cf==false)||!(a1706450595==0)||(input==false)&&(a1926573135==0)||(a1147972397==0)){
if(a2069556765==0){}
else if(!(a2069556765==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) || (input==false) && (a1926573135==0) || (cf==false) && (a1706450595==0) && (a2069556765 ==0)){
    	cf = false;
    	a985710449 =0;
    	a817053393 = 12;
    	a1706450595 =0;
    	a356828654 = 8; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if((cf==false)&&(a2069556765==0)&&(a1147972397==0)&&(input==false)||(a1706450595==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if((cf==false)&&(a2069556765==0)&&(a1147972397==0)&&(input==false)||(a1926573135==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a2069556765==0)||!(a1147972397==0)||!(input==false)||(a1706450595==0)||(a1926573135==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a1147972397==0)||!(input==false)||(a1706450595==0)||(a1926573135==0)){
if(a2069556765==0){}
else if(!(a2069556765==0)){}
}
else{}
 if(!(cf==false)||!(a2069556765==0)||!(input==false)||(a1706450595==0)||(a1926573135==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(cf==false)||!(a2069556765==0)||!(a1147972397==0)||(a1706450595==0)||(a1926573135==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
	if((a1926573135 ==0) || (a1706450595==0) || (cf==false) && (a2069556765 ==0) && (a1147972397 ==0) && (input==false)){
    	cf = false;
    	a371658569 =0;
    	a1247881348 = 8;
    	a1706450595 =0;
    	a58725572 = 12; 
    	System.out.println("R");
    } 
//************************Modified code Start***********************************
 if(!(input==false)||(a1926573135==0)&&(a1706450595==0)&&(a2069556765==0)||(cf==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a1926573135==0)&&(a1706450595==0)&&(a2069556765==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a1926573135==0)&&(a1706450595==0)&&(a2069556765==0)||(a1147972397==0)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1706450595==0)||!(a2069556765==0)||(cf==false)||(a1147972397==0)&&(input==false)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(a1926573135==0)||!(a2069556765==0)||(cf==false)||(a1147972397==0)&&(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1926573135==0)||!(a1706450595==0)||(cf==false)||(a1147972397==0)&&(input==false)){
if(a2069556765==0){}
else if(!(a2069556765==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) && (input==false) || (cf==false) || (a1926573135 ==0) && (a1706450595==0) && (a2069556765 ==0)){
    	cf = false;
    	a1797294897 =0;
    	a1706450595 =0;
    	a1247881348 = 7;
    	a2138011404 = 3; 
    	System.out.println("P");
    } 
}
private  void calculateOutputm58(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)&&(a134078375==00)&&(input==false)||(a1706450595==0)&&(a1147972397==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(a1147972397==0)||(cf==false)&&(a134078375==00)&&(input==false)||(a1926573135==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||(cf==false)&&(a134078375==00)&&(input==false)||(a1926573135==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a134078375==00)||!(input==false)||(a1706450595==0)&&(a1147972397==0)||(a1926573135==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(input==false)||(a1706450595==0)&&(a1147972397==0)||(a1926573135==0)){
if(a134078375==00){}
else if(!(a134078375==00)){}
}
else{}
 if(!(cf==false)||!(a134078375==00)||(a1706450595==0)&&(a1147972397==0)||(a1926573135==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a1926573135 ==0) || (a1706450595==0) && (a1147972397 ==0) || (cf==false) && (a134078375 ==00) && (input==false)){
    	cf = false;
    	a1706450595 =0;
    	a1096058849 = 7;
    	a446192584 =0;
    	a1863335615 = 9; 
    	System.out.println("Y");
    } 
//************************Modified code Start***********************************
 if((a1706450595==0)&&(input==false)&&(cf==false)||(a1147972397==0)&&(a134078375==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(a134078375==0)||(a1706450595==0)&&(input==false)&&(cf==false)||(a1926573135==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a1706450595==0)&&(input==false)&&(cf==false)||(a1926573135==0)){
if(a134078375==0){}
else if(!(a134078375==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||(a1147972397==0)&&(a134078375==0)||(a1926573135==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||!(cf==false)||(a1147972397==0)&&(a134078375==0)||(a1926573135==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1706450595==0)||!(input==false)||(a1147972397==0)&&(a134078375==0)||(a1926573135==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
	if((a1926573135 ==0) || (a1147972397 ==0) && (a134078375 ==0) || (a1706450595==0) && (input==false) && (cf==false)){
    	cf = false;
    	a455482258 =0;
    	a1706450595 =0;
    	a1138657697 =0;
    	a1096058849 = 10; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if((a1147972397==0)&&(a1706450595==0)&&(input==false)||(cf==false)&&(a1926573135==0)){
if(a134078375==00){}
else if(!(a134078375==00)){}
}
else{}
 if(!(a1926573135==0)||(a1147972397==0)&&(a1706450595==0)&&(input==false)||(a134078375==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a1147972397==0)&&(a1706450595==0)&&(input==false)||(a134078375==00)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(a1706450595==0)||!(input==false)||(cf==false)&&(a1926573135==0)||(a134078375==00)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||!(input==false)||(cf==false)&&(a1926573135==0)||(a134078375==00)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1147972397==0)||!(a1706450595==0)||(cf==false)&&(a1926573135==0)||(a134078375==00)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
	if((a134078375 ==00) || (cf==false) && (a1926573135 ==0) || (a1147972397 ==0) && (a1706450595==0) && (input==false)){
    	cf = false;
    	a642273090 = 6;
    	a1147972397 = 6;
    	a2119175241 = 10; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||!(a1147972397==0)||!(input==false)||!(a134078375==00)||!(a1926573135==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||!(a1147972397==0)||!(input==false)||!(a134078375==00)||!(a1926573135==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1706450595==0)||!(cf==false)||!(input==false)||!(a134078375==00)||!(a1926573135==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1706450595==0)||!(cf==false)||!(a1147972397==0)||!(a134078375==00)||!(a1926573135==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1706450595==0)||!(cf==false)||!(a1147972397==0)||!(input==false)||!(a1926573135==0)){
if(a134078375==00){}
else if(!(a134078375==00)){}
}
else{}
 if(!(a1706450595==0)||!(cf==false)||!(a1147972397==0)||!(input==false)||!(a134078375==00)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1706450595==0) && (cf==false) && (a1147972397 ==0) && (input==false) && (a134078375 ==00) && (a1926573135 ==0)){
    	cf = false;
    	a817053393 = 17;
    	a1160822650 = 6;
    	a1706450595 =0;
    	a356828654 = 8; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm59(boolean input) {
//************************Modified code Start***********************************
 if((a1706450595==0)&&(cf==false)&&(input==false)&&(a1147972397==0)||(a1926573135==0)){
if(a134078375==0){}
else if(!(a134078375==0)){}
}
else{}
 if((a1706450595==0)&&(cf==false)&&(input==false)&&(a1147972397==0)||(a134078375==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(cf==false)||!(input==false)||!(a1147972397==0)||(a1926573135==0)||(a134078375==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||!(input==false)||!(a1147972397==0)||(a1926573135==0)||(a134078375==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1706450595==0)||!(cf==false)||!(a1147972397==0)||(a1926573135==0)||(a134078375==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1706450595==0)||!(cf==false)||!(input==false)||(a1926573135==0)||(a134078375==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
    if((a134078375 ==0) || (a1926573135 ==0) || (a1706450595==0) && (cf==false) && (input==false) && (a1147972397 ==0)){
    	cf = false;
    	a1424251579 =0;
    	a1614547010 = 8;
    	a1706450595 =0;
    	a1909701604 = 5; 
    	System.out.println("P");
    } 
//************************Modified code Start***********************************
 if((a1706450595==0)&&(input==false)&&(a1147972397==0)||(a1926573135==0)||(a134078375==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a1706450595==0)&&(input==false)&&(a1147972397==0)||(a1926573135==0)||(cf==false)){
if(a134078375==0){}
else if(!(a134078375==0)){}
}
else{}
 if((a1706450595==0)&&(input==false)&&(a1147972397==0)||(a134078375==0)||(cf==false)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(input==false)||!(a1147972397==0)||(a1926573135==0)||(a134078375==0)||(cf==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||!(a1147972397==0)||(a1926573135==0)||(a134078375==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1706450595==0)||!(input==false)||(a1926573135==0)||(a134078375==0)||(cf==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
	if((cf==false) || (a134078375 ==0) || (a1926573135 ==0) || (a1706450595==0) && (input==false) && (a1147972397 ==0)){
    	cf = false;
    	a356828654 = 4;
    	a1706450595 =0;
    	a817053393 = 12;
    	a331348541 = 9; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if((a134078375==0)||(cf==false)&&(a1147972397==0)&&(a1926573135==0)||(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((a134078375==0)||(cf==false)&&(a1147972397==0)&&(a1926573135==0)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1147972397==0)||!(a1926573135==0)||(a134078375==0)||(input==false)||(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a1926573135==0)||(a134078375==0)||(input==false)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(cf==false)||!(a1147972397==0)||(a134078375==0)||(input==false)||(a1706450595==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if((cf==false)&&(a1147972397==0)&&(a1926573135==0)||(input==false)||(a1706450595==0)){
if(a134078375==0){}
else if(!(a134078375==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1706450595==0) || (input==false) || (cf==false) && (a1147972397 ==0) && (a1926573135 ==0) || (a134078375 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a817053393 = 10;
    	a37715639 = 3;
    	a1252084870 = 6; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if(!(a1706450595==0)||(a134078375==0)||(a1147972397==0)&&(cf==false)||(a1926573135==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a134078375==0)||(a1147972397==0)&&(cf==false)||(a1926573135==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((a134078375==0)||(a1147972397==0)&&(cf==false)||(input==false)&&(a1706450595==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if(!(cf==false)||(a134078375==0)||(a1926573135==0)||(input==false)&&(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a134078375==0)||(a1926573135==0)||(input==false)&&(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a1147972397==0)&&(cf==false)||(a1926573135==0)||(input==false)&&(a1706450595==0)){
if(a134078375==0){}
else if(!(a134078375==0)){}
}
else{}
//************************Modified code end***********************************
	if((input==false) && (a1706450595==0) || (a1926573135 ==0) || (a1147972397 ==0) && (cf==false) || (a134078375 ==0)){
    	cf = false;
    	a1299628692 =0;
    	a1247881348 = 10;
    	a1706450595 =0;
    	a336589140 = 12; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm60(boolean input) {
//************************Modified code Start***********************************
 if((a134078375==0)&&(a1147972397==0)&&(a1926573135==0)||(cf==false)&&(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1706450595==0)||(a134078375==0)&&(a1147972397==0)&&(a1926573135==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a134078375==0)&&(a1147972397==0)&&(a1926573135==0)||(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1147972397==0)||!(a1926573135==0)||(cf==false)&&(a1706450595==0)||(input==false)){
if(a134078375==0){}
else if(!(a134078375==0)){}
}
else{}
 if(!(a134078375==0)||!(a1926573135==0)||(cf==false)&&(a1706450595==0)||(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a134078375==0)||!(a1147972397==0)||(cf==false)&&(a1706450595==0)||(input==false)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (cf==false) && (a1706450595==0) || (a134078375 ==0) && (a1147972397 ==0) && (a1926573135 ==0)){
    	cf = false;
    	 
    	System.out.println("Q");
    } 
}
private  void calculateOutputm61(boolean input) {
//************************Modified code Start***********************************
 if((a1147972397==0)||(cf==false)&&(a1926573135==0)||(input==false)&&(a1706450595==0)){
if(a134078375==0){}
else if(!(a134078375==0)){}
}
else{}
 if(!(a1706450595==0)||(a1147972397==0)||(cf==false)&&(a1926573135==0)||(a134078375==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a1147972397==0)||(cf==false)&&(a1926573135==0)||(a134078375==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1926573135==0)||(a1147972397==0)||(input==false)&&(a1706450595==0)||(a134078375==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a1147972397==0)||(input==false)&&(a1706450595==0)||(a134078375==0)){
if(a1926573135==0){}
else if(!(a1926573135==0)){}
}
else{}
 if((cf==false)&&(a1926573135==0)||(input==false)&&(a1706450595==0)||(a134078375==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
    if((a134078375 ==0) || (input==false) && (a1706450595==0) || (cf==false) && (a1926573135 ==0) || (a1147972397 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a1096058849 = 7;
    	a1863335615 = 13;
    	a742257091 = 8; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm62(boolean input) {
//************************Modified code Start***********************************
 if(!(a642273090==0)||(a2119175241==0)||(cf==false)&&(a1706450595==0)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a2119175241==0)||(cf==false)&&(a1706450595==0)||(a1147972397==0)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
 if((a2119175241==0)||(cf==false)&&(a1706450595==0)||(input==false)&&(a642273090==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1706450595==0)||(a2119175241==0)||(a1147972397==0)||(input==false)&&(a642273090==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a2119175241==0)||(a1147972397==0)||(input==false)&&(a642273090==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((cf==false)&&(a1706450595==0)||(a1147972397==0)||(input==false)&&(a642273090==0)){
if(a2119175241==0){}
else if(!(a2119175241==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a642273090 ==0) || (a1147972397 ==0) || (cf==false) && (a1706450595==0) || (a2119175241 ==0)){
    	cf = false;
    	a817053393 = 12;
    	a1706450595 =0;
    	a356828654 = 4;
    	a331348541 = 8; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if(!(a1147972397==0)||(a642273090==0)||(input==false)||(cf==false)&&(a1706450595==0)){
if(a2119175241==00){}
else if(!(a2119175241==00)){}
}
else{}
 if(!(a2119175241==00)||(a642273090==0)||(input==false)||(cf==false)&&(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1706450595==0)||(a642273090==0)||(input==false)||(a2119175241==00)&&(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a642273090==0)||(input==false)||(a2119175241==00)&&(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((a642273090==0)||(cf==false)&&(a1706450595==0)||(a2119175241==00)&&(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((input==false)||(cf==false)&&(a1706450595==0)||(a2119175241==00)&&(a1147972397==0)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
//************************Modified code end***********************************
	if((a2119175241 ==00) && (a1147972397 ==0) || (cf==false) && (a1706450595==0) || (input==false) || (a642273090 ==0)){
    	cf = false;
    	a1996793042 = 11;
    	a1424251579 =0;
    	a1706450595 =0;
    	a1159686220 = 10; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if(!(input==false)||(a1706450595==0)||(cf==false)&&(a1147972397==0)||(a2119175241==00)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
 if(!(a642273090==0)||(a1706450595==0)||(cf==false)&&(a1147972397==0)||(a2119175241==00)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a1706450595==0)||(cf==false)&&(a1147972397==0)||(a642273090==0)&&(input==false)){
if(a2119175241==00){}
else if(!(a2119175241==00)){}
}
else{}
 if(!(a1147972397==0)||(a1706450595==0)||(a2119175241==00)||(a642273090==0)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a1706450595==0)||(a2119175241==00)||(a642273090==0)&&(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((cf==false)&&(a1147972397==0)||(a2119175241==00)||(a642273090==0)&&(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
	if((a642273090 ==0) && (input==false) || (a2119175241 ==00) || (cf==false) && (a1147972397 ==0) || (a1706450595==0)){
    	cf = false;
    	a1231632361 =0;
    	a1706450595 =0;
    	a446192584 =0;
    	a1247881348 = 9; 
    	System.out.println("Q");
    } 
//************************Modified code Start***********************************
 if(!(a642273090==0)||(a1147972397==0)||(input==false)&&(cf==false)||(a1706450595==0)){
if(a2119175241==00){}
else if(!(a2119175241==00)){}
}
else{}
 if(!(a2119175241==00)||(a1147972397==0)||(input==false)&&(cf==false)||(a1706450595==0)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
 if((a1147972397==0)||(input==false)&&(cf==false)||(a2119175241==00)&&(a642273090==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(cf==false)||(a1147972397==0)||(a1706450595==0)||(a2119175241==00)&&(a642273090==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a1147972397==0)||(a1706450595==0)||(a2119175241==00)&&(a642273090==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((input==false)&&(cf==false)||(a1706450595==0)||(a2119175241==00)&&(a642273090==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
	if((a2119175241 ==00) && (a642273090 ==0) || (a1706450595==0) || (input==false) && (cf==false) || (a1147972397 ==0)){
    	cf = false;
    	a817053393 = 13;
    	a1706450595 =0;
    	a1997755444 = 10;
    	a1830171812 = 4; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm63(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||(a1706450595==0)||(a1432372429==00)||(a1147972397==0)&&(input==false)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
 if(!(a642273090==0)||(a1706450595==0)||(a1432372429==00)||(a1147972397==0)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||(a1706450595==0)||(a1432372429==00)||(a642273090==0)&&(cf==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a1706450595==0)||(a1432372429==00)||(a642273090==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a1706450595==0)||(a1147972397==0)&&(input==false)||(a642273090==0)&&(cf==false)){
if(a1432372429==00){}
else if(!(a1432372429==00)){}
}
else{}
 if((a1432372429==00)||(a1147972397==0)&&(input==false)||(a642273090==0)&&(cf==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
    if((a642273090 ==0) && (cf==false) || (a1147972397 ==0) && (input==false) || (a1432372429 ==00) || (a1706450595==0)){
    	cf = false;
    	a1706450595 =0;
    	a817053393 = 13;
    	a1997755444 = 11;
    	a1287306075 = 5; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm66(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)&&(a1961665287==0)&&(a642273090==0)||(input==false)&&(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1147972397==0)||(cf==false)&&(a1961665287==0)&&(a642273090==0)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a1961665287==0)&&(a642273090==0)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1961665287==0)||!(a642273090==0)||(input==false)&&(a1147972397==0)||(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a642273090==0)||(input==false)&&(a1147972397==0)||(a1706450595==0)){
if(a1961665287==0){}
else if(!(a1961665287==0)){}
}
else{}
 if(!(cf==false)||!(a1961665287==0)||(input==false)&&(a1147972397==0)||(a1706450595==0)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
//************************Modified code end***********************************
    if((a1706450595==0) || (input==false) && (a1147972397 ==0) || (cf==false) && (a1961665287 ==0) && (a642273090 ==0)){
    	cf = false;
    	a371658569 =0;
    	a1175284955 =0;
    	a1147972397 = 4; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if((a1706450595==0)&&(a1147972397==0)&&(input==false)||(a1961665287==0)&&(cf==false)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
 if(!(cf==false)||(a1706450595==0)&&(a1147972397==0)&&(input==false)||(a642273090==0)){
if(a1961665287==0){}
else if(!(a1961665287==0)){}
}
else{}
 if(!(a1961665287==0)||(a1706450595==0)&&(a1147972397==0)&&(input==false)||(a642273090==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1147972397==0)||!(input==false)||(a1961665287==0)&&(cf==false)||(a642273090==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||!(input==false)||(a1961665287==0)&&(cf==false)||(a642273090==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1706450595==0)||!(a1147972397==0)||(a1961665287==0)&&(cf==false)||(a642273090==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
	if((a642273090 ==0) || (a1961665287 ==0) && (cf==false) || (a1706450595==0) && (a1147972397 ==0) && (input==false)){
    	cf = false;
    	a1147972397 = 7;
    	a58725572 = 8;
    	a2138011404 = 1; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if((a1961665287==0)&&(input==false)&&(a642273090==0)||(cf==false)&&(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1706450595==0)||(a1961665287==0)&&(input==false)&&(a642273090==0)||(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a1961665287==0)&&(input==false)&&(a642273090==0)||(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(input==false)||!(a642273090==0)||(cf==false)&&(a1706450595==0)||(a1147972397==0)){
if(a1961665287==0){}
else if(!(a1961665287==0)){}
}
else{}
 if(!(a1961665287==0)||!(a642273090==0)||(cf==false)&&(a1706450595==0)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1961665287==0)||!(input==false)||(cf==false)&&(a1706450595==0)||(a1147972397==0)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) || (cf==false) && (a1706450595==0) || (a1961665287 ==0) && (input==false) && (a642273090 ==0)){
    	cf = false;
    	a1147972397 = 3;
    	a968224050 =0;
    	a460768686 = 10; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm67(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||(a642273090==0)||(input==false)&&(a1706450595==0)||(a1961665287==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a642273090==0)||(input==false)&&(a1706450595==0)||(a1961665287==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a642273090==0)||(input==false)&&(a1706450595==0)||(a1147972397==0)&&(cf==false)){
if(a1961665287==0){}
else if(!(a1961665287==0)){}
}
else{}
 if(!(a1706450595==0)||(a642273090==0)||(a1961665287==0)||(a1147972397==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a642273090==0)||(a1961665287==0)||(a1147972397==0)&&(cf==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((input==false)&&(a1706450595==0)||(a1961665287==0)||(a1147972397==0)&&(cf==false)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
//************************Modified code end***********************************
    if((a1147972397 ==0) && (cf==false) || (a1961665287 ==0) || (input==false) && (a1706450595==0) || (a642273090 ==0)){
    	cf = false;
    	a1160822650 = 3;
    	a817053393 = 17;
    	a1706450595 =0;
    	a82644459 = 4; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||(a642273090==0)||(a1706450595==0)&&(input==false)||(a1961665287==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a642273090==0)||(a1706450595==0)&&(input==false)||(a1961665287==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a642273090==0)||(a1706450595==0)&&(input==false)||(a1147972397==0)&&(cf==false)){
if(a1961665287==0){}
else if(!(a1961665287==0)){}
}
else{}
 if(!(input==false)||(a642273090==0)||(a1961665287==0)||(a1147972397==0)&&(cf==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||(a642273090==0)||(a1961665287==0)||(a1147972397==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a1706450595==0)&&(input==false)||(a1961665287==0)||(a1147972397==0)&&(cf==false)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) && (cf==false) || (a1961665287 ==0) || (a1706450595==0) && (input==false) || (a642273090 ==0)){
    	cf = false;
    	a1160822650 = 3;
    	a817053393 = 17;
    	a1706450595 =0;
    	a82644459 = 4; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm68(boolean input) {
//************************Modified code Start***********************************
 if((a1706450595==0)||(input==false)&&(a1445407416==0)&&(a1147972397==0)||(cf==false)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
 if((a1706450595==0)||(input==false)&&(a1445407416==0)&&(a1147972397==0)||(a642273090==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1445407416==0)||!(a1147972397==0)||(a1706450595==0)||(cf==false)||(a642273090==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a1147972397==0)||(a1706450595==0)||(cf==false)||(a642273090==0)){
if(a1445407416==0){}
else if(!(a1445407416==0)){}
}
else{}
 if(!(input==false)||!(a1445407416==0)||(a1706450595==0)||(cf==false)||(a642273090==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((input==false)&&(a1445407416==0)&&(a1147972397==0)||(cf==false)||(a642273090==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
    if((a642273090 ==0) || (cf==false) || (input==false) && (a1445407416 ==0) && (a1147972397 ==0) || (a1706450595==0)){
    	cf = false;
    	a1706450595 =0;
    	a817053393 = 10;
    	a37715639 = 3;
    	a1252084870 = 9; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if((a642273090==0)||(cf==false)&&(a1445407416==0)||(input==false)&&(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1706450595==0)||(a642273090==0)||(cf==false)&&(a1445407416==0)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a642273090==0)||(cf==false)&&(a1445407416==0)||(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1445407416==0)||(a642273090==0)||(input==false)&&(a1706450595==0)||(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a642273090==0)||(input==false)&&(a1706450595==0)||(a1147972397==0)){
if(a1445407416==0){}
else if(!(a1445407416==0)){}
}
else{}
 if((cf==false)&&(a1445407416==0)||(input==false)&&(a1706450595==0)||(a1147972397==0)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) || (input==false) && (a1706450595==0) || (cf==false) && (a1445407416 ==0) || (a642273090 ==0)){
    	cf = false;
    	a817053393 = 11;
    	a198886191 =0;
    	a1706450595 =0;
    	a1252084870 = 5; 
    	System.out.println("Q");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||!(a642273090==0)||!(input==false)||!(a1445407416==0)||!(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||!(a642273090==0)||!(input==false)||!(a1445407416==0)||!(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1706450595==0)||!(cf==false)||!(input==false)||!(a1445407416==0)||!(a1147972397==0)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
 if(!(a1706450595==0)||!(cf==false)||!(a642273090==0)||!(a1445407416==0)||!(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1706450595==0)||!(cf==false)||!(a642273090==0)||!(input==false)||!(a1147972397==0)){
if(a1445407416==0){}
else if(!(a1445407416==0)){}
}
else{}
 if(!(a1706450595==0)||!(cf==false)||!(a642273090==0)||!(input==false)||!(a1445407416==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1706450595==0) && (cf==false) && (a642273090 ==0) && (input==false) && (a1445407416 ==0) && (a1147972397 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a455482258 =0;
    	a606789331 =0;
    	a1247881348 = 12; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm69(boolean input) {
//************************Modified code Start***********************************
 if(!(a249165573==0)||(a642273090==0)||(cf==false)&&(a1147972397==0)||(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||(a642273090==0)||(cf==false)&&(a1147972397==0)||(input==false)){
if(a249165573==0){}
else if(!(a249165573==0)){}
}
else{}
 if((a642273090==0)||(cf==false)&&(a1147972397==0)||(a1706450595==0)&&(a249165573==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1147972397==0)||(a642273090==0)||(input==false)||(a1706450595==0)&&(a249165573==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a642273090==0)||(input==false)||(a1706450595==0)&&(a249165573==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((cf==false)&&(a1147972397==0)||(input==false)||(a1706450595==0)&&(a249165573==0)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
//************************Modified code end***********************************
    if((a1706450595==0) && (a249165573==0) || (input==false) || (cf==false) && (a1147972397 ==0) || (a642273090 ==0)){
    	cf = false;
    	a1147972397 = 7;
    	a432276736 =0;
    	a58725572 = 11; 
    	System.out.println("P");
    } 
//************************Modified code Start***********************************
 if(!(a1147972397==0)||!(a642273090==00)||(input==false)||(a249165573==0)||(cf==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||!(a642273090==00)||(input==false)||(a249165573==0)||(cf==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1706450595==0)||!(a1147972397==0)||(input==false)||(a249165573==0)||(cf==false)){
if(a642273090==00){}
else if(!(a642273090==00)){}
}
else{}
 if((input==false)||(a249165573==0)||(a1706450595==0)&&(a1147972397==0)&&(a642273090==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((input==false)||(cf==false)||(a1706450595==0)&&(a1147972397==0)&&(a642273090==00)){
if(a249165573==0){}
else if(!(a249165573==0)){}
}
else{}
 if((a249165573==0)||(cf==false)||(a1706450595==0)&&(a1147972397==0)&&(a642273090==00)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
	if((a1706450595==0) && (a1147972397 ==0) && (a642273090 ==00) || (cf==false) || (a249165573==0) || (input==false)){
    	cf = false;
    	a799584195 =0;
    	a1147972397 = 5;
    	a1926573135 = 10; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if((cf==false)&&(a1147972397==0)||(a1706450595==0)||(a642273090==00)&&(a249165573==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a249165573==0)||(cf==false)&&(a1147972397==0)||(a1706450595==0)||(input==false)){
if(a642273090==00){}
else if(!(a642273090==00)){}
}
else{}
 if(!(a642273090==00)||(cf==false)&&(a1147972397==0)||(a1706450595==0)||(input==false)){
if(a249165573==0){}
else if(!(a249165573==0)){}
}
else{}
 if((cf==false)&&(a1147972397==0)||(a642273090==00)&&(a249165573==0)||(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1147972397==0)||(a1706450595==0)||(a642273090==00)&&(a249165573==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a1706450595==0)||(a642273090==00)&&(a249165573==0)||(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
	if((input==false) || (a642273090 ==00) && (a249165573==0) || (a1706450595==0) || (cf==false) && (a1147972397 ==0)){
    	cf = false;
    	 
    	System.out.println("Q");
    } 
//************************Modified code Start***********************************
 if((cf==false)&&(a1706450595==0)&&(a249165573==0)&&(input==false)||(a642273090==00)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((cf==false)&&(a1706450595==0)&&(a249165573==0)&&(input==false)||(a1147972397==0)){
if(a642273090==00){}
else if(!(a642273090==00)){}
}
else{}
 if(!(a1706450595==0)||!(a249165573==0)||!(input==false)||(a642273090==00)||(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a249165573==0)||!(input==false)||(a642273090==00)||(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(cf==false)||!(a1706450595==0)||!(input==false)||(a642273090==00)||(a1147972397==0)){
if(a249165573==0){}
else if(!(a249165573==0)){}
}
else{}
 if(!(cf==false)||!(a1706450595==0)||!(a249165573==0)||(a642273090==00)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) || (a642273090 ==00) || (cf==false) && (a1706450595==0) && (a249165573==0) && (input==false)){
    	cf = false;
    	a968224050 =0;
    	a1147972397 = 3;
    	a460768686 = 10; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm71(boolean input) {
//************************Modified code Start***********************************
 if(!(input==false)||(a1706450595==0)||(cf==false)&&(a1147972397==0)||(a1909701604==0)){
if(a642273090==01){}
else if(!(a642273090==01)){}
}
else{}
 if(!(a642273090==01)||(a1706450595==0)||(cf==false)&&(a1147972397==0)||(a1909701604==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a1706450595==0)||(cf==false)&&(a1147972397==0)||(a642273090==01)&&(input==false)){
if(a1909701604==0){}
else if(!(a1909701604==0)){}
}
else{}
 if(!(a1147972397==0)||(a1706450595==0)||(a1909701604==0)||(a642273090==01)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a1706450595==0)||(a1909701604==0)||(a642273090==01)&&(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((cf==false)&&(a1147972397==0)||(a1909701604==0)||(a642273090==01)&&(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
    if((a642273090 ==01) && (input==false) || (a1909701604 ==0) || (cf==false) && (a1147972397 ==0) || (a1706450595==0)){
    	cf = false;
    	a58725572 = 8;
    	a1147972397 = 7;
    	a2138011404 = 1; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||(input==false)||(a642273090==01)||(a1909701604==0)&&(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||(input==false)||(a642273090==01)||(a1909701604==0)&&(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1147972397==0)||(input==false)||(a642273090==01)||(a1706450595==0)&&(cf==false)){
if(a1909701604==0){}
else if(!(a1909701604==0)){}
}
else{}
 if(!(a1909701604==0)||(input==false)||(a642273090==01)||(a1706450595==0)&&(cf==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((input==false)||(a1909701604==0)&&(a1147972397==0)||(a1706450595==0)&&(cf==false)){
if(a642273090==01){}
else if(!(a642273090==01)){}
}
else{}
 if((a642273090==01)||(a1909701604==0)&&(a1147972397==0)||(a1706450595==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
	if((a1706450595==0) && (cf==false) || (a1909701604 ==0) && (a1147972397 ==0) || (a642273090 ==01) || (input==false)){
    	cf = false;
    	a1137531920 =0;
    	a968224050 =0;
    	a1147972397 = 3; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if(!(input==false)||(cf==false)&&(a1909701604==0)||(a642273090==01)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(cf==false)&&(a1909701604==0)||(a642273090==01)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((cf==false)&&(a1909701604==0)||(a642273090==01)||(a1147972397==0)&&(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((cf==false)&&(a1909701604==0)||(a1706450595==0)||(a1147972397==0)&&(input==false)){
if(a642273090==01){}
else if(!(a642273090==01)){}
}
else{}
 if(!(a1909701604==0)||(a642273090==01)||(a1706450595==0)||(a1147972397==0)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a642273090==01)||(a1706450595==0)||(a1147972397==0)&&(input==false)){
if(a1909701604==0){}
else if(!(a1909701604==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1147972397 ==0) && (input==false) || (a1706450595==0) || (a642273090 ==01) || (cf==false) && (a1909701604 ==0)){
    	cf = false;
    	a1839837863 =0;
    	a135483884 =0;
    	a1147972397 = 8; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm72(boolean input) {
//************************Modified code Start***********************************
 if((a1147972397==0)||(a642273090==0)&&(a1137531920==0)&&(cf==false)||(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((a1147972397==0)||(a642273090==0)&&(a1137531920==0)&&(cf==false)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1137531920==0)||!(cf==false)||(a1147972397==0)||(input==false)||(a1706450595==0)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
 if(!(a642273090==0)||!(cf==false)||(a1147972397==0)||(input==false)||(a1706450595==0)){
if(a1137531920==0){}
else if(!(a1137531920==0)){}
}
else{}
 if(!(a642273090==0)||!(a1137531920==0)||(a1147972397==0)||(input==false)||(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a642273090==0)&&(a1137531920==0)&&(cf==false)||(input==false)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
    if((a1706450595==0) || (input==false) || (a642273090 ==0) && (a1137531920==0) && (cf==false) || (a1147972397 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a1247881348 = 11;
    	a1801650070 = 6;
    	a1252084870 = 7; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if((a1147972397==0)&&(a1137531920==0)||(a1706450595==0)||(input==false)&&(cf==false)){
if(a642273090==0){}
else if(!(a642273090==0)){}
}
else{}
 if(!(cf==false)||(a1147972397==0)&&(a1137531920==0)||(a1706450595==0)||(a642273090==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a1147972397==0)&&(a1137531920==0)||(a1706450595==0)||(a642273090==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a1147972397==0)&&(a1137531920==0)||(input==false)&&(cf==false)||(a642273090==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1137531920==0)||(a1706450595==0)||(input==false)&&(cf==false)||(a642273090==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a1706450595==0)||(input==false)&&(cf==false)||(a642273090==0)){
if(a1137531920==0){}
else if(!(a1137531920==0)){}
}
else{}
//************************Modified code end***********************************
	if((a642273090 ==0) || (input==false) && (cf==false) || (a1706450595==0) || (a1147972397 ==0) && (a1137531920==0)){
    	cf = false;
    	a1706450595 =0;
    	a1247881348 = 11;
    	a1801650070 = 6;
    	a1252084870 = 7; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm73(boolean input) {
//************************Modified code Start***********************************
 if(!(a362178176==01)||(a1706450595==0)||(a1147972397==0)&&(cf==false)||(a58725572==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a1706450595==0)||(a1147972397==0)&&(cf==false)||(a58725572==0)){
if(a362178176==01){}
else if(!(a362178176==01)){}
}
else{}
 if((a1706450595==0)||(a1147972397==0)&&(cf==false)||(input==false)&&(a362178176==01)){
if(a58725572==0){}
else if(!(a58725572==0)){}
}
else{}
 if(!(cf==false)||(a1706450595==0)||(a58725572==0)||(input==false)&&(a362178176==01)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a1706450595==0)||(a58725572==0)||(input==false)&&(a362178176==01)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a1147972397==0)&&(cf==false)||(a58725572==0)||(input==false)&&(a362178176==01)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a362178176 ==01) || (a58725572 ==0) || (a1147972397 ==0) && (cf==false) || (a1706450595==0)){
    	cf = false;
    	a1797294897 =0;
    	a1839837863 =0;
    	a1706450595 =0;
    	a1096058849 = 13; 
    	System.out.println("Q");
//************************Modified code Start***********************************
 if(!(a362178176==01)||(a58725572==0)||(cf==false)&&(a1147972397==0)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a58725572==0)||(cf==false)&&(a1147972397==0)||(a1706450595==0)){
if(a362178176==01){}
else if(!(a362178176==01)){}
}
else{}
 if((a58725572==0)||(cf==false)&&(a1147972397==0)||(input==false)&&(a362178176==01)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1147972397==0)||(a58725572==0)||(a1706450595==0)||(input==false)&&(a362178176==01)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a58725572==0)||(a1706450595==0)||(input==false)&&(a362178176==01)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((cf==false)&&(a1147972397==0)||(a1706450595==0)||(input==false)&&(a362178176==01)){
if(a58725572==0){}
else if(!(a58725572==0)){}
}
else{}
//************************Modified code end***********************************
    } if((input==false) && (a362178176 ==01) || (a1706450595==0) || (cf==false) && (a1147972397 ==0) || (a58725572 ==0)){
    	cf = false;
    	a1137531920 =0;
    	a968224050 =0;
    	a1147972397 = 3; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm74(boolean input) {
//************************Modified code Start***********************************
 if((a1706450595==0)||(a1147972397==0)&&(a1231632361==0)&&(input==false)||(cf==false)){
if(a58725572==0){}
else if(!(a58725572==0)){}
}
else{}
 if((a1706450595==0)||(a1147972397==0)&&(a1231632361==0)&&(input==false)||(a58725572==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1231632361==0)||!(input==false)||(a1706450595==0)||(cf==false)||(a58725572==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||!(input==false)||(a1706450595==0)||(cf==false)||(a58725572==0)){
if(a1231632361==0){}
else if(!(a1231632361==0)){}
}
else{}
 if(!(a1147972397==0)||!(a1231632361==0)||(a1706450595==0)||(cf==false)||(a58725572==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a1147972397==0)&&(a1231632361==0)&&(input==false)||(cf==false)||(a58725572==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
    if((a58725572 ==0) || (cf==false) || (a1147972397 ==0) && (a1231632361==0) && (input==false) || (a1706450595==0)){
    	cf = false;
    	a1706450595 =0;
    	a1801650070 = 6;
    	a1247881348 = 11;
    	a1252084870 = 7; 
    	System.out.println("U");
//************************Modified code Start***********************************
 if((a1147972397==0)||(a58725572==0)&&(a1231632361==0)||(cf==false)&&(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(input==false)||(a1147972397==0)||(a58725572==0)&&(a1231632361==0)||(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a1147972397==0)||(a58725572==0)&&(a1231632361==0)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1231632361==0)||(a1147972397==0)||(cf==false)&&(input==false)||(a1706450595==0)){
if(a58725572==0){}
else if(!(a58725572==0)){}
}
else{}
 if(!(a58725572==0)||(a1147972397==0)||(cf==false)&&(input==false)||(a1706450595==0)){
if(a1231632361==0){}
else if(!(a1231632361==0)){}
}
else{}
 if((a58725572==0)&&(a1231632361==0)||(cf==false)&&(input==false)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
    } if((a1706450595==0) || (cf==false) && (input==false) || (a58725572 ==0) && (a1231632361==0) || (a1147972397 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a455482258 =0;
    	a1332297805 =0;
    	a1247881348 = 12; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if((a1147972397==0)||(a1231632361==0)&&(a58725572==0)&&(input==false)||(cf==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((a1147972397==0)||(a1231632361==0)&&(a58725572==0)&&(input==false)||(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a58725572==0)||!(input==false)||(a1147972397==0)||(cf==false)||(a1706450595==0)){
if(a1231632361==0){}
else if(!(a1231632361==0)){}
}
else{}
 if(!(a1231632361==0)||!(input==false)||(a1147972397==0)||(cf==false)||(a1706450595==0)){
if(a58725572==0){}
else if(!(a58725572==0)){}
}
else{}
 if(!(a1231632361==0)||!(a58725572==0)||(a1147972397==0)||(cf==false)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a1231632361==0)&&(a58725572==0)&&(input==false)||(cf==false)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1706450595==0) || (cf==false) || (a1231632361==0) && (a58725572 ==0) && (input==false) || (a1147972397 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a1247881348 = 11;
    	a1801650070 = 6;
    	a1252084870 = 7; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(a1706450595==0)||!(input==false)||!(cf==false)||!(a1147972397==0)||!(a58725572==0)){
if(a1231632361==0){}
else if(!(a1231632361==0)){}
}
else{}
 if(!(a1231632361==0)||!(input==false)||!(cf==false)||!(a1147972397==0)||!(a58725572==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1231632361==0)||!(a1706450595==0)||!(cf==false)||!(a1147972397==0)||!(a58725572==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1231632361==0)||!(a1706450595==0)||!(input==false)||!(a1147972397==0)||!(a58725572==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1231632361==0)||!(a1706450595==0)||!(input==false)||!(cf==false)||!(a58725572==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1231632361==0)||!(a1706450595==0)||!(input==false)||!(cf==false)||!(a1147972397==0)){
if(a58725572==0){}
else if(!(a58725572==0)){}
}
else{}
//************************Modified code end***********************************
	if((a1231632361==0) && (a1706450595==0) && (input==false) && (cf==false) && (a1147972397 ==0) && (a58725572 ==0)){
    	cf = false;
    	a817053393 = 17;
    	a1160822650 = 3;
    	a1706450595 =0;
    	a82644459 = 4; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm75(boolean input) {
//************************Modified code Start***********************************
 if((a2138011404==0)&&(a1147972397==0)||(cf==false)||(a58725572==0)&&(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1706450595==0)||(a2138011404==0)&&(a1147972397==0)||(cf==false)||(input==false)){
if(a58725572==0){}
else if(!(a58725572==0)){}
}
else{}
 if(!(a58725572==0)||(a2138011404==0)&&(a1147972397==0)||(cf==false)||(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((a2138011404==0)&&(a1147972397==0)||(a58725572==0)&&(a1706450595==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1147972397==0)||(cf==false)||(a58725572==0)&&(a1706450595==0)||(input==false)){
if(a2138011404==0){}
else if(!(a2138011404==0)){}
}
else{}
 if(!(a2138011404==0)||(cf==false)||(a58725572==0)&&(a1706450595==0)||(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (a58725572 ==0) && (a1706450595==0) || (cf==false) || (a2138011404 ==0) && (a1147972397 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a817053393 = 10;
    	a1809737646 =0;
    	a37715639 = 7; 
    	System.out.println("Y");
//************************Modified code Start***********************************
 if((input==false)&&(a1147972397==0)&&(a58725572==0)||(cf==false)&&(a2138011404==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a2138011404==0)||(input==false)&&(a1147972397==0)&&(a58725572==0)||(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(input==false)&&(a1147972397==0)&&(a58725572==0)||(a1706450595==0)){
if(a2138011404==0){}
else if(!(a2138011404==0)){}
}
else{}
 if(!(a1147972397==0)||!(a58725572==0)||(cf==false)&&(a2138011404==0)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a58725572==0)||(cf==false)&&(a2138011404==0)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(input==false)||!(a1147972397==0)||(cf==false)&&(a2138011404==0)||(a1706450595==0)){
if(a58725572==0){}
else if(!(a58725572==0)){}
}
else{}
//************************Modified code end***********************************
    } if((a1706450595==0) || (cf==false) && (a2138011404 ==0) || (input==false) && (a1147972397 ==0) && (a58725572 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a135483884 =0;
    	a367928470 =0;
    	a1096058849 = 14; 
    	System.out.println("T");
//************************Modified code Start***********************************
 if((a2138011404==0)||(a1147972397==0)&&(input==false)||(a1706450595==0)&&(cf==false)){
if(a58725572==0){}
else if(!(a58725572==0)){}
}
else{}
 if(!(cf==false)||(a2138011404==0)||(a1147972397==0)&&(input==false)||(a58725572==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||(a2138011404==0)||(a1147972397==0)&&(input==false)||(a58725572==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||(a2138011404==0)||(a1706450595==0)&&(cf==false)||(a58725572==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a2138011404==0)||(a1706450595==0)&&(cf==false)||(a58725572==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a1147972397==0)&&(input==false)||(a1706450595==0)&&(cf==false)||(a58725572==0)){
if(a2138011404==0){}
else if(!(a2138011404==0)){}
}
else{}
//************************Modified code end***********************************
    } if((a58725572 ==0) || (a1706450595==0) && (cf==false) || (a1147972397 ==0) && (input==false) || (a2138011404 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a817053393 = 10;
    	a1809737646 =0;
    	a37715639 = 7; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm76(boolean input) {
//************************Modified code Start***********************************
 if(!(a2138011404==0)||!(cf==false)||!(input==false)||!(a1706450595==0)||!(a1147972397==0)){
if(a58725572==0){}
else if(!(a58725572==0)){}
}
else{}
 if(!(a58725572==0)||!(cf==false)||!(input==false)||!(a1706450595==0)||!(a1147972397==0)){
if(a2138011404==0){}
else if(!(a2138011404==0)){}
}
else{}
 if(!(a58725572==0)||!(a2138011404==0)||!(input==false)||!(a1706450595==0)||!(a1147972397==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a58725572==0)||!(a2138011404==0)||!(cf==false)||!(a1706450595==0)||!(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a58725572==0)||!(a2138011404==0)||!(cf==false)||!(input==false)||!(a1147972397==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a58725572==0)||!(a2138011404==0)||!(cf==false)||!(input==false)||!(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
//************************Modified code end***********************************
    if((a58725572 ==0) && (a2138011404 ==0) && (cf==false) && (input==false) && (a1706450595==0) && (a1147972397 ==0)){
    	cf = false;
    	a1706450595 =0;
    	a1247881348 = 11;
    	a1801650070 = 6;
    	a1252084870 = 7; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm77(boolean input) {
//************************Modified code Start***********************************
 if((a1706450595==0)&&(cf==false)&&(a432276736==0)||(a1147972397==0)&&(input==false)){
if(a58725572==01){}
else if(!(a58725572==01)){}
}
else{}
 if(!(input==false)||(a1706450595==0)&&(cf==false)&&(a432276736==0)||(a58725572==01)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a1147972397==0)||(a1706450595==0)&&(cf==false)&&(a432276736==0)||(a58725572==01)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||!(a432276736==0)||(a1147972397==0)&&(input==false)||(a58725572==01)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1706450595==0)||!(a432276736==0)||(a1147972397==0)&&(input==false)||(a58725572==01)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a1706450595==0)||!(cf==false)||(a1147972397==0)&&(input==false)||(a58725572==01)){
if(a432276736==0){}
else if(!(a432276736==0)){}
}
else{}
//************************Modified code end***********************************
    if((a58725572 ==01) || (a1147972397 ==0) && (input==false) || (a1706450595==0) && (cf==false) && (a432276736==0)){
    	cf = false;
    	a1175284955 =0;
    	a371658569 =0;
    	a1147972397 = 4; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm78(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(a1147972397==0)||!(a1706450595==0)||!(a58725572==01)||!(a432276736==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a1147972397==0)||!(a1706450595==0)||!(a58725572==01)||!(a432276736==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a1706450595==0)||!(a58725572==01)||!(a432276736==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a1147972397==0)||!(a58725572==01)||!(a432276736==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a1147972397==0)||!(a1706450595==0)||!(a432276736==0)){
if(a58725572==01){}
else if(!(a58725572==01)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a1147972397==0)||!(a1706450595==0)||!(a58725572==01)){
if(a432276736==0){}
else if(!(a432276736==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (cf==false) && (a1147972397 ==0) && (a1706450595==0) && (a58725572 ==01) && (a432276736==0)){
    	cf = false;
    	 
    	System.out.println("Y");
//************************Modified code Start***********************************
 if((a58725572==01)&&(a1147972397==0)&&(cf==false)&&(input==false)&&(a432276736==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1147972397==0)||!(cf==false)||!(input==false)||!(a432276736==0)||(a1706450595==0)){
if(a58725572==01){}
else if(!(a58725572==01)){}
}
else{}
 if(!(a58725572==01)||!(cf==false)||!(input==false)||!(a432276736==0)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a58725572==01)||!(a1147972397==0)||!(input==false)||!(a432276736==0)||(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a58725572==01)||!(a1147972397==0)||!(cf==false)||!(a432276736==0)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a58725572==01)||!(a1147972397==0)||!(cf==false)||!(input==false)||(a1706450595==0)){
if(a432276736==0){}
else if(!(a432276736==0)){}
}
else{}
//************************Modified code end***********************************
    } if((a1706450595==0) || (a58725572 ==01) && (a1147972397 ==0) && (cf==false) && (input==false) && (a432276736==0)){
    	cf = false;
    	a1096058849 = 7;
    	a1706450595 =0;
    	a985710449 =0;
    	a1863335615 = 10; 
    	System.out.println("Q");
    } 
}
private  void calculateOutputm79(boolean input) {
//************************Modified code Start***********************************
 if((a58725572==0)&&(a1706450595==0)||(cf==false)&&(a439146033==0)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a58725572==0)&&(a1706450595==0)||(cf==false)&&(a439146033==0)||(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a439146033==0)||(a58725572==0)&&(a1706450595==0)||(a1147972397==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a58725572==0)&&(a1706450595==0)||(a1147972397==0)||(input==false)){
if(a439146033==0){}
else if(!(a439146033==0)){}
}
else{}
 if(!(a1706450595==0)||(cf==false)&&(a439146033==0)||(a1147972397==0)||(input==false)){
if(a58725572==0){}
else if(!(a58725572==0)){}
}
else{}
 if(!(a58725572==0)||(cf==false)&&(a439146033==0)||(a1147972397==0)||(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (a1147972397 ==0) || (cf==false) && (a439146033==0) || (a58725572 ==0) && (a1706450595==0)){
    	cf = false;
    	a367928470 =0;
    	a1706450595 =0;
    	a1096058849 = 14;
    	a1926573135 = 11; 
    	System.out.println("U");
//************************Modified code Start***********************************
 if((a439146033==0)||(cf==false)&&(a1147972397==0)||(a58725572==0)&&(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a1706450595==0)||(a439146033==0)||(cf==false)&&(a1147972397==0)||(input==false)){
if(a58725572==0){}
else if(!(a58725572==0)){}
}
else{}
 if(!(a58725572==0)||(a439146033==0)||(cf==false)&&(a1147972397==0)||(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(a1147972397==0)||(a439146033==0)||(a58725572==0)&&(a1706450595==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a439146033==0)||(a58725572==0)&&(a1706450595==0)||(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if((cf==false)&&(a1147972397==0)||(a58725572==0)&&(a1706450595==0)||(input==false)){
if(a439146033==0){}
else if(!(a439146033==0)){}
}
else{}
//************************Modified code end***********************************
    } if((input==false) || (a58725572 ==0) && (a1706450595==0) || (cf==false) && (a1147972397 ==0) || (a439146033==0)){
    	cf = false;
    	a1247881348 = 10;
    	a1299628692 =0;
    	a1706450595 =0;
    	a336589140 = 10; 
    	System.out.println("Z");
//************************Modified code Start***********************************
 if((cf==false)&&(a58725572==0)&&(a1706450595==0)&&(a439146033==0)||(a1147972397==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((cf==false)&&(a58725572==0)&&(a1706450595==0)&&(a439146033==0)||(input==false)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a58725572==0)||!(a1706450595==0)||!(a439146033==0)||(a1147972397==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a1706450595==0)||!(a439146033==0)||(a1147972397==0)||(input==false)){
if(a58725572==0){}
else if(!(a58725572==0)){}
}
else{}
 if(!(cf==false)||!(a58725572==0)||!(a439146033==0)||(a1147972397==0)||(input==false)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if(!(cf==false)||!(a58725572==0)||!(a1706450595==0)||(a1147972397==0)||(input==false)){
if(a439146033==0){}
else if(!(a439146033==0)){}
}
else{}
//************************Modified code end***********************************
    } if((input==false) || (a1147972397 ==0) || (cf==false) && (a58725572 ==0) && (a1706450595==0) && (a439146033==0)){
    	cf = false;
    	a817053393 = 17;
    	a1160822650 = 10;
    	a1706450595 =0;
    	a1252084870 = 10; 
    	System.out.println("W");
//************************Modified code Start***********************************
 if((a58725572==0)&&(a1147972397==0)&&(input==false)&&(cf==false)||(a439146033==0)){
if(a1706450595==0){}
else if(!(a1706450595==0)){}
}
else{}
 if((a58725572==0)&&(a1147972397==0)&&(input==false)&&(cf==false)||(a1706450595==0)){
if(a439146033==0){}
else if(!(a439146033==0)){}
}
else{}
 if(!(a1147972397==0)||!(input==false)||!(cf==false)||(a439146033==0)||(a1706450595==0)){
if(a58725572==0){}
else if(!(a58725572==0)){}
}
else{}
 if(!(a58725572==0)||!(input==false)||!(cf==false)||(a439146033==0)||(a1706450595==0)){
if(a1147972397==0){}
else if(!(a1147972397==0)){}
}
else{}
 if(!(a58725572==0)||!(a1147972397==0)||!(cf==false)||(a439146033==0)||(a1706450595==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a58725572==0)||!(a1147972397==0)||!(input==false)||(a439146033==0)||(a1706450595==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    } if((a1706450595==0) || (a439146033==0) || (a58725572 ==0) && (a1147972397 ==0) && (input==false) && (cf==false)){
    	cf = false;
    	a968224050 =0;
    	a965000114 =0;
    	a1147972397 = 3; 
    	System.out.println("W");
    } 
}



public  void calculateOutput(boolean input) {
 	cf = true;
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a1614547010==0){}
else if(!(a1614547010==0)){}
}
else{}
 if(!(a1614547010==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a1614547010 ==0) && (cf==false)) {
    		calculateOutputm38(input);
    	} 
//************************Modified code Start***********************************
 if(!(a1614547010==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a1614547010==0){}
else if(!(a1614547010==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a1614547010 ==0)){
    		calculateOutputm39(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a1137531920==0){}
else if(!(a1137531920==0)){}
}
else{}
 if(!(a1137531920==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
		if((a1137531920==0) && (cf==false)) {
    		calculateOutputm40(input);
    	} 
//************************Modified code Start***********************************
 if(!(a1137531920==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a1137531920==0){}
else if(!(a1137531920==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a1137531920==0)){
    		calculateOutputm41(input);
    	} 
//************************Modified code Start***********************************
 if(!(a965000114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a965000114==0)){
    		calculateOutputm42(input);
    	} 
//************************Modified code Start***********************************
 if((cf==false)){
if(a965000114==0){}
else if(!(a965000114==0)){}
}
else{}
 if((a965000114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a965000114==0) || (cf==false)) {
    		calculateOutputm43(input);
    	} 
//************************Modified code Start***********************************
 if((cf==false)){
if(a460768686==00){}
else if(!(a460768686==00)){}
}
else{}
 if((a460768686==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a460768686 ==00) || (cf==false)) {
    		calculateOutputm44(input);
    	} 
//************************Modified code Start***********************************
 if((cf==false)){
if(a460768686==0){}
else if(!(a460768686==0)){}
}
else{}
 if((a460768686==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a460768686 ==0) || (cf==false)) {
    		calculateOutputm45(input);
    	} 
//************************Modified code Start***********************************
 if((a1175284955==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a1175284955==0){}
else if(!(a1175284955==0)){}
}
else{}
//************************Modified code end***********************************
			if((cf==false) || (a1175284955==0)){
    		calculateOutputm46(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a1175284955==0){}
else if(!(a1175284955==0)){}
}
else{}
 if(!(a1175284955==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a1175284955==0) && (cf==false)) {
    		calculateOutputm47(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a1894566393==0){}
else if(!(a1894566393==0)){}
}
else{}
 if(!(a1894566393==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a1894566393 ==0) && (cf==false)) {
    		calculateOutputm48(input);
    	} 
//************************Modified code Start***********************************
 if((cf==false)){
if(a315270875==0){}
else if(!(a315270875==0)){}
}
else{}
 if((a315270875==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a315270875==0) || (cf==false)) {
    		calculateOutputm49(input);
    	} 
//************************Modified code Start***********************************
 if(!(a1096058849==01)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a1096058849==01){}
else if(!(a1096058849==01)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a1096058849 ==01)){
    		calculateOutputm51(input);
    	}
//************************Modified code Start***********************************
 if((a336589140==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a336589140==0){}
else if(!(a336589140==0)){}
}
else{}
//************************Modified code end***********************************
		if((cf==false) || (a336589140 ==0)){
    		calculateOutputm52(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a2119175241==0){}
else if(!(a2119175241==0)){}
}
else{}
 if(!(a2119175241==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a2119175241 ==0) && (cf==false)) {
    		calculateOutputm53(input);
    	} 
//************************Modified code Start***********************************
 if((cf==false)){
if(a799584195==0){}
else if(!(a799584195==0)){}
}
else{}
 if((a799584195==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a799584195==0) || (cf==false)) {
    		calculateOutputm54(input);
    	} 
//************************Modified code Start***********************************
 if((cf==false)){
if(a2069556765==0){}
else if(!(a2069556765==0)){}
}
else{}
 if((a2069556765==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a2069556765 ==0) || (cf==false)) {
    		calculateOutputm55(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a2069556765==0){}
else if(!(a2069556765==0)){}
}
else{}
 if(!(a2069556765==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a2069556765 ==0) && (cf==false)) {
    		calculateOutputm56(input);
    	} 
//************************Modified code Start***********************************
 if((a2069556765==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a2069556765==0){}
else if(!(a2069556765==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) || (a2069556765 ==0)){
    		calculateOutputm57(input);
    	} 
//************************Modified code Start***********************************
 if((cf==false)){
if(a134078375==00){}
else if(!(a134078375==00)){}
}
else{}
 if((a134078375==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a134078375 ==00) || (cf==false)) {
    		calculateOutputm58(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a134078375==0){}
else if(!(a134078375==0)){}
}
else{}
 if(!(a134078375==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a134078375 ==0) && (cf==false)) {
    		calculateOutputm59(input);
    	} 
//************************Modified code Start***********************************
 if((cf==false)){
if(a134078375==0){}
else if(!(a134078375==0)){}
}
else{}
 if((a134078375==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a134078375 ==0) || (cf==false)) {
    		calculateOutputm60(input);
    	} 
//************************Modified code Start***********************************
 if(!(a134078375==06)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a134078375==06){}
else if(!(a134078375==06)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a134078375 ==06)){
    		calculateOutputm61(input);
    	} 
//************************Modified code Start***********************************
 if((a2119175241==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a2119175241==00){}
else if(!(a2119175241==00)){}
}
else{}
//************************Modified code end***********************************
		if((cf==false) || (a2119175241 ==00)){
    		calculateOutputm62(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a1432372429==00){}
else if(!(a1432372429==00)){}
}
else{}
 if(!(a1432372429==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a1432372429 ==00) && (cf==false)) {
    		calculateOutputm63(input);
    	} 
//************************Modified code Start***********************************
 if((cf==false)){
if(a1961665287==0){}
else if(!(a1961665287==0)){}
}
else{}
 if((a1961665287==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
		if((a1961665287 ==0) || (cf==false)) {
    		calculateOutputm66(input);
    	} 
//************************Modified code Start***********************************
 if((a1961665287==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a1961665287==0){}
else if(!(a1961665287==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) || (a1961665287 ==0)){
    		calculateOutputm67(input);
    	} 
//************************Modified code Start***********************************
 if(!(a1445407416==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a1445407416==0){}
else if(!(a1445407416==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a1445407416 ==0)){
    		calculateOutputm68(input);
    	} 
//************************Modified code Start***********************************
 if((cf==false)){
if(a249165573==0){}
else if(!(a249165573==0)){}
}
else{}
 if((a249165573==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a249165573==0) || (cf==false)) {
    		calculateOutputm69(input);
    	} 
//************************Modified code Start***********************************
 if((a1909701604==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a1909701604==0){}
else if(!(a1909701604==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) || (a1909701604 ==0)){
    		calculateOutputm71(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a1137531920==0){}
else if(!(a1137531920==0)){}
}
else{}
 if(!(a1137531920==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a1137531920==0) && (cf==false)) {
    		calculateOutputm72(input);
    	} 		
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a362178176==01){}
else if(!(a362178176==01)){}
}
else{}
 if(!(a362178176==01)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
		if((a362178176 ==01) && (cf==false)) {
    		calculateOutputm73(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a1231632361==0){}
else if(!(a1231632361==0)){}
}
else{}
 if(!(a1231632361==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a1231632361==0) && (cf==false)) {
    		calculateOutputm74(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a2138011404==0){}
else if(!(a2138011404==0)){}
}
else{}
 if(!(a2138011404==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a2138011404 ==0) && (cf==false)) {
    		calculateOutputm75(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a2138011404==0){}
else if(!(a2138011404==0)){}
}
else{}
 if(!(a2138011404==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a2138011404 ==0) && (cf==false)) {
    		calculateOutputm76(input);
    	} 
//************************Modified code Start***********************************
 if((a432276736==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a432276736==0){}
else if(!(a432276736==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) || (a432276736==0)){
    		calculateOutputm77(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a432276736==0){}
else if(!(a432276736==0)){}
}
else{}
 if(!(a432276736==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a432276736==0) && (cf==false)) {
    		calculateOutputm78(input);
    	} 
//************************Modified code Start***********************************
 if((a439146033==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a439146033==0){}
else if(!(a439146033==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) || (a439146033==0)){
    		calculateOutputm79(input);
    	} 
   
		
    	
    	
    if(cf==false)
    	throw new IllegalArgumentException("Current state has no transition for this input ");
}


public static void main() throws Exception{
	// init system and input reader
	Problem4_RERS2019jxnct eca = new Problem4_RERS2019jxnct();

        int a=0;
		int x;
        int y;
         
        x = Cute.input.Integer();
        y = Cute.input.Integer();
		boolean input = Cute.input.Boolean();
			// main i/o-loop
            while(a<10) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
//************************Modified code Start***********************************
 if(!(x>y)){
if(x>199){}
else if(!(x>199)){}
}
else{}
 if(!(x>199)){
if(x>y){}
else if(!(x>y)){}
}
else{}
//************************Modified code end***********************************
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                	 eca.calculateOutput(input);
					 
				}
				
//************************Modified code Start***********************************
 if((x<y)){
if(x>299){}
else if(!(x>299)){}
}
else{}
 if((x>299)){
if(x<y){}
else if(!(x<y)){}
}
else{}
//************************Modified code end***********************************
				if (x>299 || x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutput(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
}
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
