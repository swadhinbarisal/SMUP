package jpct;

import cute.Cute;

public class Problem12_RER2016jpct {

	public int a127 = Cute.input.Integer();
	public int a103 =Cute.input.Integer();
	public int a181 = Cute.input.Integer();
	public int a14 = Cute.input.Integer();
	public int a187 = Cute.input.Integer();
	public int a83 = Cute.input.Integer();
	public int a20 = Cute.input.Integer();
	public int a84 = Cute.input.Integer();
	public int a170 = Cute.input.Integer();
	public int a120 = Cute.input.Integer();
	public int a133 = Cute.input.Integer();
	public int a36 = Cute.input.Integer();
	public int a28 = Cute.input.Integer();
	public int a118 = Cute.input.Integer();
	public int a92 = Cute.input.Integer();
	public int a8 = Cute.input.Integer();
	public int a115 = Cute.input.Integer();
	public int a35 = Cute.input.Integer();
	public int a74 = Cute.input.Integer();
	public int a81 = Cute.input.Integer();
	public int a178 = Cute.input.Integer();
	public int a190 = Cute.input.Integer();
	public int a60 = Cute.input.Integer();
	public int a105 = Cute.input.Integer();
	public int a50 = Cute.input.Integer();
	public int a85 = Cute.input.Integer();
	public int a97 = Cute.input.Integer();
	public int a154 = Cute.input.Integer();
	public int a76 = Cute.input.Integer();
	public int a102 = Cute.input.Integer();
	public int a162 = Cute.input.Integer();
	public int a58 = Cute.input.Integer();
	public int a135 = Cute.input.Integer();
	public int a6 = Cute.input.Integer();
	public int a108 = Cute.input.Integer();
	public int a59 = Cute.input.Integer();
	public int a174 = Cute.input.Integer();
	public boolean cf = Cute.input.Boolean();
	public int a168 = Cute.input.Integer();
	public int a194 = Cute.input.Integer();
	public int a185 = Cute.input.Integer();
	public int a146 = Cute.input.Integer();
	public int a82 = Cute.input.Integer();
	public int a0 = Cute.input.Integer();
	public int a17 = Cute.input.Integer();
	public int a25 = Cute.input.Integer();
	public int a173 = Cute.input.Integer();
	public int a150 = Cute.input.Integer();
	public int a15 = Cute.input.Integer();
	public int a44 = Cute.input.Integer();
	public int a189 = Cute.input.Integer();
	public int a129 = Cute.input.Integer();
	public int a114 = Cute.input.Integer();
	public int a101 = Cute.input.Integer();
	public int a86 = Cute.input.Integer();
	public int a111 = Cute.input.Integer();
	public int a87 = Cute.input.Integer();
	public int a45 = Cute.input.Integer();
	public int a141 = Cute.input.Integer();
	public int a90 = Cute.input.Integer();
	public int a196 = Cute.input.Integer();
	public int a156 = Cute.input.Integer();
	public int a38 = Cute.input.Integer();
	public int a197 = Cute.input.Integer();
	public int a11 = Cute.input.Integer();
	public int a65 = Cute.input.Integer();
	public int a75 = Cute.input.Integer();
	public int a157 = Cute.input.Integer();
	public int a180 = Cute.input.Integer();
	public int a169 = Cute.input.Integer();
	public int a100 = Cute.input.Integer();
	public int a16 = Cute.input.Integer();
	public int a136 = Cute.input.Integer();
	
	private void errorCheck() {
//******************Transformed code started****************************
if(152<a115){
 }
 else {}
if(a35<=114){
if(397>=a36){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((152 < a115) || (a35 <=  114) && (397 >= a36)){
	    	cf = false;
	    	System.out.println("0");
	    }
//******************Transformed code started****************************
if(112<a36){
 }
 else {}
if(270<a118){
if(157<a58){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((270 < a118) && (157 < a58)|| (112 < a36)){
	    	cf = false;
	    	System.out.println("1");
	    }
//******************Transformed code started****************************
if(182>=a36){
 }
 else {}
if(a92==1){
if(354<a58){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a92 == 1) && (354 < a58) || (182 >= a36)){
	    	cf = false;
	    	System.out.println("2");
	    }
//******************Transformed code started****************************
if(a178==7){
 }
 else {}
if(a174==15){
if(a36<=112){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a178 == 7) || (a174 == 15) && (a36 <=  112)){
	    	cf = false;
	    	System.out.println("3");
	    }
//******************Transformed code started****************************
if(a194==14){
 }
 else {}
if(243<a35){
if(397>=a36){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a194 == 14) || (243 < a35) && (397 >= a36)){
	    	cf = false;
	    	System.out.println("4");
	    }
//******************Transformed code started****************************
if(62<a84){
if(a187==5){}
 else{}
if(397<a36){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((62 < a84) && (a187 == 5) && (397 < a36)){
	    	cf = false;
	    	System.out.println("5");
	    }
	    
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a178==12){
if(a174==15){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a178 == 12) && (a174 == 15) ||( a36 <=  112)){
	    	cf = false;
	    	System.out.println("7");
	    }
//******************Transformed code started****************************
if(397<a36){
 }
 else {}
if(a146==15){
if(a187==6){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a146 == 15) && (a187 == 6) || (397 < a36)){
	    	cf = false;
	    	System.out.println("8");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a178==6){
if(a174==15){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a178 == 6) && (a174 == 15) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("9");
	    }
	  
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a108==9){
if(a174==10){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a108 == 9) && (a174 == 10) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("11");
	    }
//******************Transformed code started****************************
if(397<a36){
 }
 else {}
if(a59==5){
if(a187==7){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a59 == 5) && (a187 == 7)  || ( 397 < a36)){
	    	cf = false;
	    	System.out.println("12");
	    }
//******************Transformed code started****************************
if(397<a36){
 }
 else {}
if(a146==13){
if(a187==6){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a146 == 13) && (a187 == 6) || (397 < a36)){
	    	cf = false;
	    	System.out.println("13");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a135==13){
if(a174==13){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a135 == 13) && (a174 == 13) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("14");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a108==8){
if(a174==10){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a108 == 8) && (a174 == 10) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("15");
	    }
//******************Transformed code started****************************
if(397<a36){
 }
 else {}
if(a146==12){
if(a187==6){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a146 == 12) && (a187 == 6) || ( 397 < a36)){
	    	cf = false;
	    	System.out.println("16");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a108==7){
if(a174==10){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a108 == 7) && (a174 == 10) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("18");
	    }
//******************Transformed code started****************************
if(397<a36){
 }
 else {}
if(a76==10){
if(a187==10){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a76 == 10) && (a187 == 10) ||( 397 < a36)){
	    	cf = false;
	    	System.out.println("19");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a181<=41){
if(a174==12){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a181 <=  41) && (a174 == 12) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("24");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a170==14){
if(a174==16){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a170 == 14) && (a174 == 16) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("25");
	    }
//******************Transformed code started****************************
if(397<a36){
 }
 else {}
if(a146==16){
if(a187==6){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a146 == 16) && (a187 == 6) || (397 < a36)){
	    	cf = false;
	    	System.out.println("26");
	    }
//******************Transformed code started****************************
if(397<a36){
 }
 else {}
if(a76==8){
if(a187==10){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a76 == 8) && (a187 == 10) || (397 < a36)){
	    	cf = false;
	    	System.out.println("28");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a135==9){
if(a174==13){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a135 == 9) && (a174 == 13) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("29");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a178==8){
if(a174==15){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a178 == 8) && (a174 == 15) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("32");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a135==15){
if(a174==13){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a135 == 15) && (a174 == 13) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("33");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a108==8){
if(a174==9){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a108 == 8) && (a174 == 9) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("34");
	    }
//******************Transformed code started****************************
if(397<a36){
 }
 else {}
if(a84<=132){
if(a187==5){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a84 <=  132) && (a187 == 5) ||(397 < a36)){
	    	cf = false;
	    	System.out.println("36");
	    }
//******************Transformed code started****************************
if(397<a36){
 }
 else {}
if(a14==14){
if(a187==8){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a14 == 14) && (a187 == 8) || (397 < a36)){
	    	cf = false;
	    	System.out.println("40");
	    }
//******************Transformed code started****************************
if(397<a36){
 }
 else {}
if(a76==12){
if(a187==10){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a76 == 12) && (a187 == 10) || (397 < a36)){
	    	cf = false;
	    	System.out.println("42");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a154==16){
if(a174==14){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a154 == 16) && (a174 == 14) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("43");
	    }
//******************Transformed code started****************************
if(397<a36){
 }
 else {}
if(a14==11){
if(a187==8){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a14 == 11) && (a187 == 8) || ( 397 < a36)){
	    	cf = false;
	    	System.out.println("44");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(310<a181){
if(a174==12){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((310 < a181) && (a174 == 12) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("45");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a108==6){
if(a174==9){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a108 == 6) && (a174 == 9) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("48");
	    }
//******************Transformed code started****************************
if(397<a36){
 }
 else {}
if(a168==6){
if(a187==9){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a168 == 6) && (a187 == 9) ||(397 < a36)){
	    	cf = false;
	    	System.out.println("50");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a170==7){
if(a174==16){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a170 == 7) && (a174 == 16) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("51");
	    }
//******************Transformed code started****************************
if(a36<=112){
 }
 else {}
if(a108==7){
if(a174==9){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a108 == 7) && (a174 == 9) || (a36 <=  112)){
	    	cf = false;
	    	System.out.println("52");
	    }
	}
	
	private  void calculateOutputm36(boolean input) {
//******************Transformed code started****************************
if(a28==3){
if(a82==4){}
 else{}
 }
 else {}
if(a105==10){
if(a85<=182){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a105 == 10)&& (a85 <=  182) || (a28 == 3) && (a82 == 4)){
    	a150 -= (a150 - 20) < a150 ? 2 : 0;
    	a114 += (a114 + 20) > a114 ? 1 : 0;
    	a180 += (a180 + 20) > a180 ? 2 : 0;
    	a16 -= (a16 - 20) < a16 ? 2 : 0;
    	cf = false;
    	a170 = a105;
    	a174 = (a105 - -6); 
    	System.out.println("S");
    } 
//******************Transformed code started****************************
if(input==true){
if(cf==true){}
 else{}
if(a20<=123){}
 else{}
if(a6<=31){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==true) && (cf==true) && (a20 <=  123) && (a6 <=  31)){
    	cf = false;
    	a181 = ((((((a20 * a85) % 14999) + -10255) - 4557) % 44) - -266);
    	a174 = (a102 - -9); 
    	System.out.println("U");
    } 
}
	private  void calculateOutputm2(boolean input) {
//******************Transformed code started****************************
if(324>=a20){
 }
 else {}
if(a105==11){
 }
 else {}
if(a28==4){
if(123<a20){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((a105 == 11)||(a28 == 4) && (123 < a20) || (324 >= a20)){
    	a196 -= (a196 - 20) < a196 ? 4 : 0;
    	cf = false;
    	a187 = (a28 - -5);
    	a168 = (a187 - 6); 
    	System.out.println("Y");
		}
//******************Transformed code started****************************
if(123<a20){
 }
 else {}
if(319>=a190){
 }
 else {}
if(a74==7){
if(182<a190){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((a74 == 7) && (182 < a190) || (319 >= a190) || (123 < a20) ){
    	cf = false;
    	a187 = (a102 - -5);
    	a168 = (a60 - 8); 
    	System.out.println("Z");
		} 
//******************Transformed code started****************************
if(124>=a162){
 }
 else {}
if(47<a162){
 }
 else {}
if(a28==4){
if(a74==7){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((a28 == 4) && (a74 == 7) || (47 < a162) || (124 >= a162)){
    	a25 += (a25 + 20) > a25 ? 2 : 0;
    	a86 += (a86 + 20) > a86 ? 2 : 0;
    	a45 += (a45 + 20) > a45 ? 4 : 0;
    	cf = false;
    	a187 = (a59 - -5);
    	a14 = ((a185 / a102) + 8); 
    	System.out.println("U");
		} 
	}
	private  void calculateOutputm42(boolean input) {
//******************Transformed code started****************************
if(a74==6){
if(a60==10){}
 else{}
if(a120<=179){}
 else{}
if(a105==10){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a74 == 6) && (a60 == 10) && (a120 <=  179) && (a105 == 10)){
    	a0 += (a0 + 20) > a0 ? 1 : 0;
    	a44 += (a44 + 20) > a44 ? 2 : 0;
    	a38 += (a38 + 20) > a38 ? 1 : 0;
    	a65 -= (a65 - 20) < a65 ? 4 : 0;
    	cf = false;
    	a108 = ((a74 - a74) + 12);
    	a174 = (a28 + 7); 
    	System.out.println("S");
    } 
}
	private  void calculateOutputm43(boolean input) {
//******************Transformed code started****************************
if(cf==true){
if(input==true){}
 else{}
if(a28==3){}
 else{}
if(a185==4){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==true) && (input==true) && (a28 == 3) && (a185 == 4)){
    	a90 -= (a90 - 20) < a90 ? 2 : 0;
    	cf = false;
    	a36 = ((((((a36 * a162) % 14999) % 14801) - -15198) + 1) * 1);
    	a83 = (((((((a83 * a162) % 14999) % 50) + 156) - -1) / 5) + 107);
    	a82 = (a174 - 7);
    	a50 = (a28 - -4);
    	a14 = (a174 + -5);
    	a162 = (((((((a83 * a83) % 14999) % 85) + 14) * 9) / 10) - 13);
    	a81 = (((((((a81 * a85) % 14999) % 72) - 41) + -1) - -15718) - 15719);
    	a85 = ((((((a85 * a83) % 14999) + 9600) * 1) % 76) + 258);
    	a97 = ((a174 * a60) + -115);
    	a102 = ((a82 - a185) + 3);
    	a28 = (a174 - 8);
    	a6 = (((((((a6 * a181) % 14999) % 23) - 6) - 2) + -8788) + 8788);
    	a8 = (((((((a8 * a120) % 14999) % 39) + 153) * 5) % 39) - -135);
    	a187 = (a74 + 2);
    	a20 = ((((((a36 * a83) % 14999) / 5) % 100) + 167) + 30);
    	a120 = ((((((a36 * a190) % 14999) * 2) % 93) + 273) + 1);
    	a185 = (a50 - 2);
    	a74 = (a105 - 3);
    	a190 = (((((((a190 * a20) % 14999) * 2) % 68) - -250) + 13663) - 13661);
    	a60 = (a105 - -1);
    	a105 = (a82 - -6); 
    	System.out.println("S");
    } 
//******************Transformed code started****************************
if(a20<=123){
if(a50==6){}
 else{}
if(a97==4){}
 else{}
if(input==true){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a20 <=  123) && (a50 == 6) && (a97 == 4) && (input==true)){
    	a157 += (a157 + 20) > a157 ? 2 : 0;
    	a16 += (a16 + 20) > a16 ? 2 : 0;
    	a136 += (a136 + 20) > a136 ? 2 : 0;
    	cf = false;
    	a190 = (((((((a190 * a181) % 14999) % 68) - -251) / 5) * 5) + 3);
    	a187 = (a102 + 3);
    	a120 = ((((((a190 * a190) % 14999) / 5) % 93) - -193) + 19);
    	a105 = ((a97 + a97) + 3);
    	a50 = (a102 - -4);
    	a8 = ((((((a8 * a81) % 14999) + -11894) + -902) % 39) - -154);
    	a85 = ((((((a85 * a120) % 14999) / 5) % 76) + 259) + -1);
    	a146 = ((a28 - a82) - -12);
    	a82 = ((a74 * a50) - 37);
    	a81 = ((((((((a85 * a190) % 14999) % 72) - 106) + 9) * 5) % 72) - -7);
    	a36 = ((((((a36 * a162) % 14999) + 12330) % 14801) + 15198) - -1);
    	a20 = ((((((a190 * a190) % 14999) % 100) - -193) - 11820) - -11787);
    	a162 = ((((((a190 * a120) % 14999) / 5) % 85) - 36) + -5);
    	a83 = ((((((((a83 * a20) % 14999) * 2) % 50) - -156) * 5) % 50) - -136);
    	a28 = (a74 - 2);
    	a60 = (a97 - -7);
    	a97 = (a174 - a50);
    	a6 = ((((((a6 * a181) % 14999) - 7608) + 3183) % 23) - 7);
    	a185 = a74;
    	a102 = (a105 - 7);
    	a74 = (a60 - 3); 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(a50==6){
if(a20<=123){}
 else{}
if(cf==true){}
 else{}
if(input==true){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a50 == 6) && (a20 <=  123) && (cf==true) && (input==true)){
    	a129 += (a129 + 20) > a129 ? 1 : 0;
    	cf = false;
    	a103 = (((((a190 * a6) % 14999) / 5) - 7037) + -15103);
    	a174 = (a102 - -8); 
    	System.out.println("T");
    } 
//******************Transformed code started****************************
if(a20<=123){
if(a74==6){}
 else{}
if(a81<=116){}
 else{}
if(a28==3){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a20 <=  123) && (a74 == 6) && (a81 <=  116) && (a28 == 3)){
    	a101 += (a101 + 20) > a101 ? 2 : 0;
    	cf = false;
    	a190 = ((((((a85 * a120) % 14999) % 68) - -250) * 5) / 5);
    	a8 = (((((((a8 * a120) % 14999) % 39) + 153) + 8929) - -11828) + -20755);
    	a97 = (a74 + -1);
    	a6 = ((((((a6 * a85) % 14999) + 128) % 23) - 7) + -1);
    	a50 = (a28 + 4);
    	a76 = (a174 + -1);
    	a162 = ((((((a162 * a181) % 14999) % 85) - -39) / 5) - -97);
    	a60 = (a82 - -7);
    	a102 = ((a97 / a50) - -4);
    	a187 = a105;
    	a36 = ((((((a36 * a20) % 14999) % 14801) + 15198) - -1) + 0);
    	a105 = a60;
    	a20 = (((((((a83 * a181) % 14999) * 2) % 100) + 223) - 27988) + 27989);
    	a83 = (((((((a83 * a190) % 14999) + 13060) % 50) + 156) + -7147) - -7147);
    	a120 = (((((((a120 * a81) % 14999) + 455) % 93) + 273) + -15551) + 15550); 
    	System.out.println("T");
    } 
//******************Transformed code started****************************
if(a81<=116){
if(a8<=114){}
 else{}
if(a60==10){}
 else{}
if(a185==4){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a81 <=  116) && (a8 <=  114) && (a60 == 10) && (a185 == 4)){
    	cf = false;
    	a174 = ((a28 - a102) + 14);
    	a154 = (a60 - -4);
    	a60 = ((a50 - a74) - -11); 
    	System.out.println("Y");
    } 
}
	private  void calculateOutputm4(boolean input) {
//******************Transformed code started****************************
if(a50==7){
if(a185==5){}
 else{}
 }
 else {}
if(a82==5){
if(a74==7){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((a82 == 5) && (a74 == 7) || (a50 == 7) && (a185 == 5)){
    	a173 += (a173 + 20) > a173 ? 4 : 0;
    	cf = false;
    	a187 = (a28 - -7);
    	a35 = ((((((a83 * a190) % 14999) + -25587) + -3596) % 41) + 231); 
    	System.out.println("S");
		} 
//******************Transformed code started****************************
if(a82==5){
 }
 else {}
if(105<a83){
 }
 else {}
if(206>=a83){
if(a50==7){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((105 < a83) || (206 >= a83) && (a50 == 7) || (a82 == 5)){
    	a38 -= (a38 - 20) < a38 ? 3 : 0;
    	cf = false;
    	a187 = (a102 + 6);
    	a76 = (a28 + 3); 
    	System.out.println("W");
		} 
//******************Transformed code started****************************
if(a82==5){
 }
 else {}
if(a28==4){
 }
 else {}
if(47<a162){
if(124>=a162){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((a28 == 4) || (47 < a162) && (124 >= a162) || (a82 == 5) ){
    	cf = false;
    	a170 = (a60 + 2);
    	a36 = (((((a36 * a81) % 14999) - 10598) + -4394) + -2);
    	a174 = ((a168 + a187) - -4); 
    	System.out.println("Z");
		} 
	}
	private  void calculateOutputm54(boolean input) {
//******************Transformed code started****************************
if(a185==4){
if(a20<=123){}
 else{}
if(a83<=105){}
 else{}
if(a162<=47){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a185 == 4) && (a20 <=  123 )&& (a83 <=  105) && (a162 <=  47)){
    	a129 -= (a129 - 20) < a129 ? 4 : 0;
    	cf = false;
    	a103 = ((((((((a83 * a6) % 14999) % 60) + 79) * 5) * 5) % 60) + 70);
    	a174 = (a74 - -5); 
    	System.out.println("Z");
    } 
//******************Transformed code started****************************
if(a28==3){
if(a185==4){}
 else{}
if(a85<=182){}
 else{}
if(a20<=123){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a28 == 3) && (a185 == 4) && (a85 <=  182) && (a20 <=  123)){
    	a173 += (a173 + 20) > a173 ? 4 : 0;
    	cf = false;
    	a181 = (((((((a85 * a85) % 14999) % 44) + 264) - -1) + -8921) + 8922);
    	a20 = (((((((a20 * a81) % 14999) / 5) * 5) + 2003) % 100) + 224);
    	a74 = (a174 - 7);
    	a162 = (((((a162 * a6) % 14999) / 5) / 5) / 5);
    	a36 = ((((((a36 * a8) % 14999) + -4319) % 34) + 148) - -1);
    	a105 = (a74 + 4);
    	a28 = (a74 + -3);
    	a120 = (((((((a120 * a36) % 14999) * 2) % 93) - -272) - 12192) + 12192);
    	a97 = (a28 + 1);
    	a8 = ((((((((a8 * a181) % 14999) % 39) + 153) - 0) * 5) % 39) + 131);
    	a58 = ((((((a190 * a190) % 14999) - 14946) + 25507) - -1513) + -27020);
    	a190 = ((((((a181 * a20) % 14999) - -11257) * 1) % 68) - -226);
    	a83 = ((((((a83 * a36) % 14999) - -1199) % 50) - -156) + -1); 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(a50==6){
if(a83<=105){}
 else{}
if(cf==true){}
 else{}
if(input==true){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a50 == 6) && (a83 <=  105) && (cf==true) && (input==true)){
    	a173 += (a173 + 20) > a173 ? 3 : 0;
    	cf = false;
    	a85 = (((((((a85 * a20) % 14999) - 8651) % 76) + 258) - -1779) + -1777);
    	a118 = ((((((((a81 * a36) % 14999) % 36) - -233) - 1) * 5) % 36) - -211);
    	a20 = ((((((a20 * a118) % 14999) * 2) % 100) - -223) + 2);
    	a74 = (a60 + -4);
    	a58 = (((((((a162 * a8) % 14999) % 98) - -256) * 5) % 98) - -233);
    	a102 = (a74 - 3);
    	a120 = (((((((a120 * a58) % 14999) + -8095) - -8120) / 5) % 93) + 274);
    	a185 = ((a174 / a105) - -4);
    	a105 = a60;
    	a162 = ((((((a85 * a190) % 14999) % 85) - -39) + 14564) + -14563);
    	a81 = ((((((((a6 * a85) % 14999) % 72) + -43) - 1) * 5) % 72) - 42);
    	a82 = ((a154 - a185) - 4);
    	a28 = ((a60 + a102) - 11);
    	a6 = (((((((a6 * a85) % 14999) % 23) + -7) - -1) + -7442) - -7440);
    	a50 = (a102 + 3);
    	a36 = ((((((((a36 * a8) % 14999) + 11310) % 34) + 146) * 5) % 34) + 115);
    	a8 = (((((((a8 * a83) % 14999) - 921) - 9601) * 1) % 39) - -153);
    	a83 = (((((((a83 * a190) % 14999) - 4693) % 50) + 156) / 5) + 97);
    	a97 = ((a50 / a28) + 4);
    	a190 = ((((((((a190 * a85) % 14999) % 68) - -251) + 1) * 5) % 68) + 239); 
    	System.out.println("T");
    } 
//******************Transformed code started****************************
if(a83<=105){
if(a185==4){}
 else{}
if(a74==6){}
 else{}
if(a28==3){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a83 <=  105) && (a185 == 4) && (a74 == 6) && (a28 == 3)){
    	cf = false;
    	a97 = (a105 - 5);
    	a6 = ((((((a85 * a85) % 14999) % 23) + -6) - 11674) - -11672);
    	a81 = ((((((a85 * a85) % 14999) % 72) - 43) - 1) - 0);
    	a50 = (a74 + 1);
    	a185 = a97;
    	a20 = ((((((a6 * a6) - -19202) % 100) - -125) / 5) + 177);
    	a28 = (a174 + -10);
    	a120 = ((((((((a120 * a81) % 14999) - -3421) % 93) - -274) * 5) % 93) - -264);
    	a187 = (a74 + 2);
    	a14 = (a102 + 4);
    	a105 = ((a28 * a74) + -13);
    	a8 = (((((((a8 * a162) % 14999) * 2) / 5) + -3515) % 39) - -153);
    	a82 = (a74 - 1);
    	a162 = ((((((a85 * a85) % 14999) + 7639) + 3865) % 85) - -38);
    	a83 = ((((((a83 * a20) % 14999) % 50) - -156) + -3534) - -3533);
    	a102 = (a60 + -7);
    	a36 = (((((((a36 * a190) % 14999) % 14801) - -15198) + 0) - 5474) - -5476);
    	a190 = ((((((a85 * a85) % 14999) + -2645) % 68) - -251) - -1);
    	a85 = ((((((a85 * a20) % 14999) % 76) + 258) - 0) + 0);
    	a74 = ((a60 / a60) + 6); 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(a97==4){
if(cf==true){}
 else{}
if(input==true){}
 else{}
if(a85<=182){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a97 == 4) && (cf==true) && (input==true) && (a85 <=  182)){
    	a150 -= (a150 - 20) < a150 ? 2 : 0;
    	cf = false;
    	a174 = ((a74 + a105) + -6);
    	a108 = (a185 - -7); 
    	System.out.println("T");
    } 
}
	private  void calculateOutputm55(boolean input) {
//******************Transformed code started****************************
if(a60==10){
if(a74==6){}
 else{}
if(a8<=114){}
 else{}
if(a20<=123){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a60 == 10) && (a74 == 6) && (a8 <=  114) && ( a20 <=  123)){
    	a87 += (a87 + 20) > a87 ? 3 : 0;
    	cf = false;
    	a174 = (a74 + 4);
    	a108 = (a185 - -8); 
    	System.out.println("S");
    } 
//******************Transformed code started****************************
if(a97==4){
if(a102==3){}
 else{}
if(cf==true){}
 else{}
if(input==true){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a97 == 4) && (a102 == 3) && (cf==true) && (input==true)){
    	a114 -= (a114 - 20) < a114 ? 3 : 0;
    	cf = false;
    	a74 = (a97 + 3);
    	a28 = ((a60 - a74) + 1);
    	a83 = ((((55 - -101) + 11006) - 26073) - -15034);
    	a105 = (a74 - -4);
    	a8 = ((((((a83 * a83) % 14999) - -4535) * 1) % 39) - -148);
    	a82 = (a97 + 1);
    	a36 = (((((((a36 * a20) % 14999) % 14801) + 15198) - 8818) / 5) + 4258);
    	a185 = ((a28 + a82) - 4);
    	a120 = (((((((a120 * a81) % 14999) + -9452) - 3935) + -1578) % 93) + 272);
    	a190 = ((((((a8 * a83) % 14999) + 6503) + -32846) % 68) + 255);
    	a187 = (a154 + -7);
    	a14 = ((a187 - a102) - -4);
    	a60 = (a97 + 7);
    	a81 = (((64 + 14297) + -29164) + 14790);
    	a20 = ((((((a8 * a6) % 14999) / 5) - 21493) % 100) - -297);
    	a6 = (((((30 * -5) / 10) - -4896) - -4695) + -9601);
    	a85 = (((((((a85 * a162) % 14999) % 76) - -258) + 4803) / 5) + -780);
    	a50 = (a97 + 3);
    	a162 = (((((((a190 * a190) % 14999) % 85) + 4) * 10) / 9) - -8);
    	a102 = ((a105 - a97) + -3);
    	a97 = (a105 + -6); 
    	System.out.println("Z");
    } 
}
	private  void calculateOutputm6(boolean input) {
//******************Transformed code started****************************
if(193>=a8){
 }
 else {}
if(a28==4){
 }
 else {}
if(a82==5){
if(114<a8){}
 else{}
 }
 else {}
//******************Transformed code end****************************
			if((a28 == 4) || (a82 == 5) && (114 < a8) ||(193 >= a8) ){
    	a150 += (a150 + 20) > a150 ? 3 : 0;
    	cf = false;
    	a187 = ((a102 - a102) + 7);
    	a59 = (a74 - 4); 
    	System.out.println("W");
		} 
	
//******************Transformed code started****************************
if(116<a81){
 }
 else {}
if(a105==11){
 }
 else {}
if(105<a83){
if(206>=a83){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((105 < a83) && (206 >= a83) ||(a105 == 11) ||(116 < a81)){
    	a101 += (a101 + 20) > a101 ? 3 : 0;
    	cf = false;
    	a58 = (((((((a81 * a36) % 14999) % 14822) - -15176) / 5) + -16744) - -18083);
    	a92 = a185;
    	a36 = ((((((a36 * a120) % 14999) / 5) - -19664) % 34) + 124); 
    	System.out.println("S");
		} 
	}
	private  void calculateOutputm66(boolean input) {
//******************Transformed code started****************************
if(a60==10){
if(a85<=182){}
 else{}
if(a74==6){}
 else{}
if(a105==10){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a60 == 10) && (a85 <=  182) && (a74 == 6) && (a105 == 10)){
    	a100 += (a100 + 20) > a100 ? 2 : 0;
    	cf = false;
    	a181 = ((((((a20 * a8) % 14999) % 89) + 130) - -2) - 2);
    	a174 = ((a185 / a50) - -12);
    	a97 = (a74 - 2);
    	a162 = (((((a162 * a6) % 14999) + -20076) / 5) * 5);
    	a6 = ((((((a6 * a20) % 14999) - -5405) % 14984) - 15014) - 1);
    	a8 = (((((a8 * a120) % 14999) + -2353) - 12572) + -76);
    	a20 = ((((((a20 * a181) % 14999) * 2) - 0) % 15061) - 14937); 
    	System.out.println("U");
    } 
}
	private  void calculateOutputm8(boolean input) {
//******************Transformed code started****************************
if(a105==11){
 }
 else {}
if(a74==7){
 }
 else {}
if(114<a8){
if(193>=a8){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((114 < a8) && (193 >= a8) || (a74 == 7) || (a105 == 11)){
    	a141 += (a141 + 20) > a141 ? 3 : 0;
    	cf = false;
    	a14 = (a28 + 5);
    	a187 = ((a14 / a102) + 6); 
    	System.out.println("T");
		} 
//******************Transformed code started****************************
if(a105==11){
 }
 else {}
if(a60==11){
 }
 else {}
if(31<a6){
if(16>=a6){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((a60 == 11) ||(a105 == 11) ||(31 < a6) && (16 >= a6) ){
    	a141 += (a141 + 20) > a141 ? 2 : 0;
    	cf = false;
    	a14 = (a60 - 4);
    	a187 = (a60 + -3); 
    	System.out.println("T");
		} 
	}
	private  void calculateOutputm80(boolean input) {
//******************Transformed code started****************************
if(input==true){
 }
 else {}
if(cf==true){
if(a50==6){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==true) || (cf==true) && (a50 == 6)){
    	a196 += (a196 + 20) > a196 ? 1 : 0;
    	cf = false;
    	a187 = (a185 - -4);
    	a168 = ((a187 / a50) - -2);
    	a36 = (((((a36 * a81) - 4345) / 5) / 5) + 5195); 
    	System.out.println("Z");
    } 
//******************Transformed code started****************************
if(a50==6){
 }
 else {}
if(a60==10){
 }
 else {}
if(a74==6){
if(a105==10){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a60 == 10) || (a74 == 6) && (a105 == 10) || (a50 == 6)){
    	cf = false;
    	a36 = (((((a36 * a20) % 14999) - -14755) * 1) * 1);
    	a187 = (a102 - -5);
    	a168 = (a187 + -3); 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(a8<=114){
 }
 else {}
if(a108==12){
 }
 else {}
if(a28==3){
if(a6<=31){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a108 == 12) || (a28 == 3) && (a6 <=  31) || (a8 <=  114)){
    	a0 -= (a0 - 20) < a0 ? 4 : 0;
    	cf = false;
    	a168 = ((a185 * a60) + -52);
    	a36 = (((((((a36 * a118) % 14999) / 5) - -4330) - 7783) * -9) / 10);
    	a187 = ((a105 / a74) + 8); 
    	System.out.println("Z");
    } 
//******************Transformed code started****************************
if(a105==10){
if(input==true){}
 else{}
if(cf==true){}
 else{}
if(a102==3){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a105 == 10) && (input==true) && (cf==true) && (a102 == 3)){
    	a38 -= (a38 - 20) < a38 ? 4 : 0;
    	cf = false;
    	a190 = ((((((a120 * a83) % 14999) - 22811) * 10) / 9) * 1);
    	a74 = (a105 + -5);
    	a85 = (((((a85 * a190) % 14999) + -14822) + -180) - 0);
    	a6 = ((((a6 * a118) - 17819) / 5) / 5);
    	a36 = ((((((a36 * a8) % 14999) - 15328) + -9719) * 10) / 9);
    	a28 = (a105 + -8);
    	a102 = (a82 - 2);
    	a97 = (a185 + -1);
    	a185 = (a105 + -7);
    	a50 = ((a105 * a105) + -115);
    	a174 = (a105 + 5);
    	a60 = (a105 - 1);
    	a81 = (((((a81 * a8) + -6239) * 1) - -27686) - 27653);
    	a8 = (((((a190 * a58) % 14999) - 14919) + -20) + -37);
    	a83 = (((((a83 * a162) % 15052) - 14946) - 1) + -1);
    	a162 = ((((((a162 * a20) % 14999) % 14976) + -15022) - 3) - 0);
    	a170 = (a174 - 8); 
    	System.out.println("S");
    } 
//******************Transformed code started****************************
if(a20<=123){
if(a120<=179){}
 else{}
 }
 else {}
if(a28==3){
if(a20<=123){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a28 == 3) && (a20 <=  123) || (a120 <=  179) && (a20 <=  123)){
    	a150 += (a150 + 20) > a150 ? 4 : 0;
    	cf = false;
    	a187 = (a60 - 1);
    	a36 = (((((a36 * a162) / 5) + -14110) * 10) / -9);
    	a76 = (a74 - -3); 
    	System.out.println("U");
    } 
}

	private  void calculateOutput(boolean input) {
//******************Transformed code started****************************
if(a60==10){
 }
 else {}
if(a174==10){
 }
 else {}
if(a82==4){
if(a6<=31){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((a82 == 4) && (a6 <=  31) || (a174 == 10) || (a60 == 10)) {
    		calculateOutputm2(input);
    	} 
//******************Transformed code started****************************
if(a50==6){
if(a174==12){}
 else{}
 }
 else {}
if(a185==4){
if(a50==6){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a185 == 4) && (a50 == 6) || (a174 == 12) && (a50 == 6)) {
    		calculateOutputm4(input);
    	} 
//******************Transformed code started****************************
if(a174==14){
 }
 else {}
if(a162<=47){
 }
 else {}
if(a105==10){
if(a97==4){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a162 <=  47) ||(a174 == 14) || (a105 == 10) && (a97 == 4)) {
    		calculateOutputm6(input);
    	} 
//******************Transformed code started****************************
if(a174==16){
 }
 else {}
if(a102==3){
 }
 else {}
if(a8<=114){
if(a85<=182){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a102 == 3) ||(a174 == 16) || (a8 <=  114) && (a85 <=  182)) {
    		calculateOutputm8(input);
    	} 
//******************Transformed code started****************************
if(a102==3){
if(a74==6){}
 else{}
if(a185==4){}
 else{}
if(cf==true){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((a102 == 3) && (a74 == 6) && (a185 == 4) && (cf==true)){
			calculateOutputm36(input);
		}
//******************Transformed code started****************************
if(a50==6){
if(a28==3){}
 else{}
if(41<a181){}
 else{}
if(220>=a181){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((a50 == 6) && (a28 == 3) && (41 < a181) && (220 >= a181)){
			calculateOutputm42(input);
		} 
//******************Transformed code started****************************
if(cf==true){
if(220<a181){}
 else{}
if(310>=a181){}
 else{}
if(a190<=182){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((cf==true) && (220 < a181) && (310 >= a181) && (a190 <=  182)){
			calculateOutputm43(input);
		} 
//******************Transformed code started****************************
if(a83<=105){
if(a85<=182){}
 else{}
if(a20<=123){}
 else{}
if(a8<=114){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((a83 <=  105) && (a85 <=  182) && (a20 <=  123) && (a8 <=  114)){
			calculateOutputm54(input);
		} 
//******************Transformed code started****************************
if(a74==6){
if(a190<=182){}
 else{}
if(a120<=179){}
 else{}
if(a102==3){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((a74 == 6) && (a190 <=  182) && (a120 <=  179) && (a102 == 3)){
			calculateOutputm55(input);
		} 
//******************Transformed code started****************************
if(a81<=116){
if(a82==4){}
 else{}
if(a170==10){}
 else{}
if(cf==true){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((a81 <=  116) && (a82 == 4) && (a170 == 10) && (cf==true)){
			calculateOutputm66(input);
		} 
//******************Transformed code started****************************
if(a97==4){
if(a20<=123){}
 else{}
 }
 else {}
if(cf==true){
if(a85<=182){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		if((cf==true) && (a85 <=  182) || (a97 == 4) && (a20 <=  123)){
			calculateOutputm80(input);
		} 
}	
	public static void main() throws Exception 
	{
	     // init system and input reader
            Problem12_RER2016jpct eca = new Problem12_RER2016jpct();
        int a=0;
	int x;
        int y;
         
        x = Cute.input.Integer();
        y = Cute.input.Integer();
		boolean input = Cute.input.Boolean();
		
			// main i/o-loop
            while(a<10) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
//******************Transformed code started****************************
if(x>199){
if(x>y){}
 else{}
 }
 else {}
//******************Transformed code end****************************
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                	 eca.calculateOutput(input);
					 
				}
				
//******************Transformed code started****************************
if(x>299){
if(x<y){}
 else{}
 }
 else {}
//******************Transformed code end****************************
				if (x>299 && x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutput(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
	}
	
	
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
