
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class insertion_sort_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public insertion_sort_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-2024122232);
        input[i++] = new Integer(400146408);
        input[i++] = new Integer(-2121429193);
        input[i++] = new Integer(548922285);
        i=0;
        cute.Cute.input = this;
        insertion_sort.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(400146408);
        input[i++] = new Integer(-2121429193);
        input[i++] = new Integer(548922285);
        i=0;
        cute.Cute.input = this;
        insertion_sort.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(400146408);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        insertion_sort.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(400146408);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1);
        i=0;
        cute.Cute.input = this;
        insertion_sort.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(0);
        input[i++] = new Integer(400146408);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1);
        i=0;
        cute.Cute.input = this;
        insertion_sort.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(1);
        input[i++] = new Integer(400146408);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1);
        i=0;
        cute.Cute.input = this;
        insertion_sort.main(null);
    }

    public void test8(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(100);
        input[i++] = new Integer(400146408);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1);
        i=0;
        cute.Cute.input = this;
        insertion_sort.main(null);
    }

    public void test13(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(200);
        input[i++] = new Integer(400146408);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        insertion_sort.main(null);
    }

    public void test14(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(240);
        input[i++] = new Integer(400146408);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        insertion_sort.main(null);
    }

}
