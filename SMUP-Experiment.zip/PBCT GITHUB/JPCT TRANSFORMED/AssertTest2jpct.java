package jpct;
import cute.Cute;

/**
 * Author: Koushik Sen <ksen@cs.uiuc.edu>
 */
public class AssertTest2jpct extends Thread{

    synchronized public void run() {
        try {
            System.out.println("Nothing");
            this.wait();
        } catch (InterruptedException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public static void main(String[] args) {
		int l,m,n,o,p,q,r;
		l=Cute.input.Integer();
		m=Cute.input.Integer();
		n=Cute.input.Integer();
		o=Cute.input.Integer();
		p=Cute.input.Integer();
		q=Cute.input.Integer();
		r=Cute.input.Integer();
//******************Transformed code started****************************
if(m>=150){
 }
 else {}
if(l<=200){
 }
 else {}
//******************Transformed code end****************************
		if((l<=200)||(m>=150))
                {
                    System.out.println("This a new trial");
                }
                else
                    {
//******************Transformed code started****************************
if(l>=150){
 }
 else {}
if(n!=90){
 }
 else {}
//******************Transformed code end****************************
                        if((n!=90)||(l>=150))
                            {
                                System.out.println("This a new trial");
                            }

                    System.out.println("This a not new trial");
                     }


//******************Transformed code started****************************
if(q==2000){
 }
 else {}
if(o!=9){
if(p>=0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
                if((o!=9)&&(p>=0)||(q==2000))
                {
                    System.out.println("This a new ...............trial");
                }
//******************Transformed code started****************************
if(o>=1501){
 }
 else {}
if(r!=89){
 }
 else {}
if(q==2000){
if(m>=299){}
 else{}
if(p<=100){}
 else{}
 }
 else {}
//******************Transformed code end****************************
                if((r!=89)||(o>=1501)||(q==2000)&&(m>=299)&&(p<=100))
                {
                    System.out.println("This a new ...............trial");
                }
//******************Transformed code started****************************
if(m==2000){
 }
 else {}
if(n!=9){
if(l>=1500){}
 else{}
 }
 else {}
//******************Transformed code end****************************
                if((n!=9)&&(l>=1500)||(m==2000))
                {
                    System.out.println("This a new ...............trial");
                }
//******************Transformed code started****************************
if(o!=900){
if(l>=1500){}
 else{}
if(p==2000){}
 else{}
 }
 else {}
//******************Transformed code end****************************
                if((o!=900)&&(l>=1500)&&(p==2000))
                {
                    System.out.println("This a new ...............trial");
                }
//******************Transformed code started****************************
if(q!=900){
if(p>=1500){}
 else{}
if(m==2000){}
 else{}
 }
 else {}
//******************Transformed code end****************************
                if((q!=900)&&(p>=1500)&&(m==2000))
                {
                    System.out.println("This a new ...............trial");
                }


        AssertTest2jpct at = new AssertTest2jpct();
        at.start();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
