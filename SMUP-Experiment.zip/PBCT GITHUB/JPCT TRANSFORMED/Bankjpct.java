package jpct;
import cute.Cute;
import java.util.Scanner;

class bankInternal {
 
    void deposit(float bal)
    {
        float amount;
        System.out.println("Enter Amount to be Deposited:");
        amount = Cute.input.Integer();
        bal = bal+amount;
        System.out.println("Deposited! Account Balance is "+bal);
    }
    void withdraw(float bal)
    {
        float amount;
        System.out.println("Enter Amount to be Withdrawn:");
        amount = Cute.input.Integer();
        if(amount<bal)
        {
            bal = bal-amount;
            System.out.println("Amount Withdrawn!! Available Balance: "+bal);
        }
        else
        {
            System.out.println("Insufficient funds!!");
        }
    }
}
 
public class Bankjpct {
    public static void main(String[] args)
    {
        bankInternal myObj = new bankInternal();
              
		
		int x = Cute.input.Integer();
        int y = Cute.input.Integer();
        int m = Cute.input.Integer();
        int n = Cute.input.Integer();
//******************Transformed code started****************************
if(x>79){
if(y<=200){}
 else{}
 }
 else {}
//******************Transformed code end****************************
        if((x>79)&&(y<=200))
		{
			 myObj.deposit(Cute.input.Integer());
        myObj.withdraw(Cute.input.Integer());
		}
//******************Transformed code started****************************
if(y<=200){
 }
 else {}
if(x>79){
 }
 else {}
//******************Transformed code end****************************
        if((x>79)||(y<=200))
		{
             myObj.deposit(Cute.input.Integer());
        myObj.withdraw(Cute.input.Integer());
		}
//******************Transformed code started****************************
if(y!=46){
 }
 else {}
if(x<10){
 }
 else {}
if(m>440){
if(n<=700){}
 else{}
 }
 else {}
//******************Transformed code end****************************
        if((m>440)&&(n<=700)||(x<10)||(y!=46))
		{
            myObj.deposit(Cute.input.Integer());
        myObj.withdraw(Cute.input.Integer());
		}
//******************Transformed code started****************************
if(m>440){
 }
 else {}
if(n<=700){
if(x<10){}
 else{}
if(y!=46){}
 else{}
 }
 else {}
//******************Transformed code end****************************
         if((m>440)||(n<=700)&&(x<10)&&(y!=46))
		 {
             myObj.deposit(Cute.input.Integer());
        myObj.withdraw(Cute.input.Integer());
		}
		
		
    }
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
