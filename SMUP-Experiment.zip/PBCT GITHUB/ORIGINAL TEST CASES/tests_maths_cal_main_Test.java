
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class tests_maths_cal_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public tests_maths_cal_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-1023055379);
        input[i++] = new Integer(853572729);
        input[i++] = new Integer(1939675725);
        input[i++] = new Integer(1309500699);
        i=0;
        cute.Cute.input = this;
        tests.maths_cal.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(853572729);
        input[i++] = new Integer(1939675725);
        input[i++] = new Integer(1309500699);
        i=0;
        cute.Cute.input = this;
        tests.maths_cal.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(0);
        input[i++] = new Integer(853572729);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        tests.maths_cal.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(1);
        input[i++] = new Integer(853572729);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        tests.maths_cal.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(100);
        input[i++] = new Integer(853572729);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        tests.maths_cal.main(null);
    }

    public void test8(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(100);
        input[i++] = new Integer(853572729);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        tests.maths_cal.main(null);
    }

    public void test9(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(100);
        input[i++] = new Integer(853572729);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        tests.maths_cal.main(null);
    }

    public void test10(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(0);
        input[i++] = new Integer(853572729);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        tests.maths_cal.main(null);
    }

    public void test27(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(200);
        input[i++] = new Integer(853572729);
        input[i++] = new Integer(11);
        input[i++] = new Integer(-1);
        i=0;
        cute.Cute.input = this;
        tests.maths_cal.main(null);
    }

    public void test28(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(240);
        input[i++] = new Integer(853572729);
        input[i++] = new Integer(11);
        input[i++] = new Integer(-1);
        i=0;
        cute.Cute.input = this;
        tests.maths_cal.main(null);
    }

}
