/**
 * TODO description
 */
//package tests;
import cute.Cute;
import java.util.Scanner;


abstract class Sal$$Basic {
	double gs,bs,sda,shra,sinc;
	void input() {
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter Basic Salary: ");
	bs=Cute.input.Integer();
	sc.close();
	}
	void comp() {
	//System.out.println("From Basic Layer Comp");
	sda=0;
	shra=0;
	sinc=0;
	}
	void output() {
	//System.out.println("From Basic Layer Output");
	System.out.println("Basic Salary is: "+bs);
	}	
}

/**
 * TODO description
 */
abstract class Sal$$DA extends  Sal$$Basic  {
	void comp(){
		//System.out.println("From DA Layer Comp");
		super.comp();
			//System.out.println("From DA Layer Comp Again");
		if(bs>=20000)
		sda=0.25*bs;
 else
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(bs==25000){
                      if(bs<20000){
                       }
                   }
if(!(bs==25000)){
       if(!(bs>=10000)){
                                      }
                   }
if(!(bs==25000)){
       if(bs>=10000){
               if(bs<20000){
                                  }
                            }
                      }
if(!(bs==25000)){
       if(bs>=10000){
               if(!(bs<20000)){
                                  }
                            }
                      }
//*****************************************************************
		 if((bs==25000)||(bs>=10000) && (bs<20000)  )
		sda=0.2*bs;
		else
		sda=0.1*bs;
		}

		void output(){
			//System.out.println("From DA Layer output");
		super.output();
		//System.out.println("From DA Layer output Again");
		System.out.println("DA is: "+sda);
		}
}

/**
 * TODO description
 */
abstract class Sal$$HRA extends  Sal$$DA  {
	void comp(){
		//System.out.println("From HRA Layer Comp");
	super.comp();
		//System.out.println("From HRA Layer Comp Again");
	if(bs>=20000)
	shra=0.2*bs;
 else
//*********************************************************************
//Transformation for predictes containing only AND operator
if(bs>=10000){
       if(bs<20000){
                       }
                   }
if(!(bs>=10000)){
       if(bs<20000){
                       }
                   }
if(bs>=10000){
       if(!(bs<20000)){
                       }
                   }
//*********************************************************************
	 if(bs>=10000 && bs<20000)
	shra=0.15*bs;
	else
	shra=0.05*bs;
	}

	void output(){
		//System.out.println("From HRA Layer output");
	super.output();
	//System.out.println("From HRA Layer output Again");
	System.out.println("HRA is: "+shra);
	}
}

/**
 * TODO description
 */
abstract class Sal$$Inc extends  Sal$$HRA  {
	void comp(){
		//System.out.println("From Inc Layer Comp");
		super.comp();
			//System.out.println("From Inc Layer Comp Again");
		if(bs>=20000)
		sinc=0.08*bs;
 else
//*********************************************************************
//Transformation for predictes containing only AND operator
if(bs>=10000){
       if(bs<20000){
                       }
                   }
if(!(bs>=10000)){
       if(bs<20000){
                       }
                   }
if(bs>=10000){
       if(!(bs<20000)){
                       }
                   }
//*********************************************************************
		 if(bs>=10000 && bs<20000)
		sinc=0.05*bs;
		else
		sinc=0.02*bs;
		}

		void output(){
			//System.out.println("From Inc Layer output");
		super.output();
		//System.out.println("From Inc Layer output Again");
		System.out.println("Increment is: "+sinc);
		}
}

/**
 * TODO description
 */
public class Sal extends  Sal$$Inc  {
	void comp(){
		//System.out.println("From Gross Layer Comp");
	super.comp();
		//System.out.println("From Gross Layer Comp Again");
	gs=bs+sda+shra+sinc;
	}
	void output() {
		//System.out.println("From Gross Layer output");
	super.output();
	//System.out.println("From Gross Layer output Again");
	System.out.println("Gross Salary is: "+gs);
	}
	public static void main(String[] args) {
		Sal s=new Sal();
		//System.out.println("From Gross Layer Main");
		s.input();
		s.comp();
		s.output();
		}
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
