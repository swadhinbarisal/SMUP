//package tests;

import cute.Cute;

//Written by Francois Rivest, 1997
//E-Mail: frives@po-box.mcgill.ca


//==============================================================================
//  ConditionalDemo1 class
//
//==============================================================================

public class  ConditionalDemo1 {

    public static void main(String[] args){
        int value1;
        int value2;
        int value3;
        value1= Cute.input.Integer();
   value2= Cute.input.Integer();
   value3= Cute.input.Integer();
//*********************************************************************
//Transformation for predictes containing only AND operator
if(value1 == 1){
       if(value2 == 2){
                       }
                   }
if(!(value1 == 1)){
       if(value2 == 2){
                       }
                   }
if(value1 == 1){
       if(!(value2 == 2)){
                       }
                   }
//*********************************************************************
        if((value1 == 1)&&(value2 == 2))
            System.out.println("value1 is 1 AND value2 is 2");
			
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(value1 == 1)){
       if(!(value2 == 1)){
                       }
                   }
if(value1 == 1){
       if(!(value2 == 1)){
                       }
                   }
if(!(value1 == 1)){
       if(value2 == 1){
                       }
                   }
//*********************************************************************
        if((value1 == 1)||(value2 == 1))
            System.out.println("value1 is 1 OR value2 is 1");
			
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(value1==1){
       if(value2==2){
                                      }
                   }
if(!(value1==1)){
                      if(!(value3==4)){
                       }
                   }
if(value1==1){
       if(!(value2==2)){
               if(!(value3==4)){
                                  }
                            }
                      }
if(value1==1){
       if(!(value2==2)){
               if(value3==4){
                                  }
                            }
                      }
//*****************************************************************
            if((value1==1)&&(value2==2)||(value3==4))
	     System.out.println("value1 is 1 AND value2 is 2");
		 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(value1==1){
                                  }
if(!(value1==1)){
       if(!(value2==2)){
                                      }
                   }
if(!(value1==1)){
       if(value2==2){
               if(value3==4){
                                  }
                            }
                      }
if(!(value1==1)){
       if(value2==2){
               if(!(value3==4)){
                                  }
                            }
                      }
//*****************************************************************
	      if((value1==1)||((value2==2)&&(value3==4)))
            System.out.println("value1 is 1 OR value2 is 1");
			
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(value1==1){
       if(value2==2){
                                      }
                   }
if(!(value1==1)){
                      if(!(value3==4)){
                       }
                   }
if(value1==1){
       if(!(value2==2)){
               if(!(value3==4)){
                                  }
                            }
                      }
if(value1==1){
       if(!(value2==2)){
               if(value3==4){
                                  }
                            }
                      }
//*****************************************************************
             if((value1==1)&&(value2==2)||(value3==4))
	    	     System.out.println("value1 is 1 AND value2 is 2");
				 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(value1==1){
                      if(value3==4){
                       }
                   }
if(!(value1==1)){
       if(!(value2==2)){
                                      }
                   }
if(!(value1==1)){
       if(value2==2){
               if(value3==4){
                                  }
                            }
                      }
if(!(value1==1)){
       if(value2==2){
               if(!(value3==4)){
                                  }
                            }
                      }
//*****************************************************************
	    	      if((value1==1)||(value2==2)&&(value3==4))
            System.out.println("value1 is 1 OR value2 is 1");
    }
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=500
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
