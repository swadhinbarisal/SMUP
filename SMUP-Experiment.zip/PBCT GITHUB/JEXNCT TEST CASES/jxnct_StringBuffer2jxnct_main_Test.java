
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class jxnct_StringBuffer2jxnct_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public jxnct_StringBuffer2jxnct_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[2];
        input[i++] = new Integer(-1793926632);
        input[i++] = new Integer(-1467016891);
        i=0;
        cute.Cute.input = this;
        jxnct.StringBuffer2jxnct.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[1];
        input[i++] = new Integer(4);
        i=0;
        cute.Cute.input = this;
        jxnct.StringBuffer2jxnct.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1467016891);
        input[i++] = new Integer(1659610143);
        i=0;
        cute.Cute.input = this;
        jxnct.StringBuffer2jxnct.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(2);
        input[i++] = new Integer(-1467016891);
        input[i++] = new Integer(1659610143);
        input[i++] = new Integer(1745024399);
        i=0;
        cute.Cute.input = this;
        jxnct.StringBuffer2jxnct.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(2);
        input[i++] = new Integer(0);
        input[i++] = new Character(?);
        input[i++] = new Integer(1866782223);
        input[i++] = new Integer(-1507094234);
        i=0;
        cute.Cute.input = this;
        jxnct.StringBuffer2jxnct.main(null);
    }

    public void test8(){
        i=0;
        input = new Object[6];
        input[i++] = new Integer(3);
        input[i++] = new Integer(0);
        input[i++] = new Character(?);
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1507094234);
        input[i++] = new Integer(1530334513);
        i=0;
        cute.Cute.input = this;
        jxnct.StringBuffer2jxnct.main(null);
    }

    public void test12(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(1401058883);
        i=0;
        cute.Cute.input = this;
        jxnct.StringBuffer2jxnct.main(null);
    }

    public void test51(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(1);
        input[i++] = new Integer(2);
        input[i++] = new Integer(0);
        input[i++] = new Character(?);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        jxnct.StringBuffer2jxnct.main(null);
    }

    public void test67(){
        i=0;
        input = new Object[8];
        input[i++] = new Integer(2);
        input[i++] = new Integer(2);
        input[i++] = new Integer(2);
        input[i++] = new Integer(-1973683657);
        input[i++] = new Integer(?);
        input[i++] = new Character(?);
        input[i++] = new Integer(-1316951069);
        input[i++] = new Integer(-995575820);
        i=0;
        cute.Cute.input = this;
        jxnct.StringBuffer2jxnct.main(null);
    }

}
