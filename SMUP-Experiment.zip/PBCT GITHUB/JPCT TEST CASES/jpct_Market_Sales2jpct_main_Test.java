
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class jpct_Market_Sales2jpct_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public jpct_Market_Sales2jpct_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(272591029);
        input[i++] = new Integer(-1655240202);
        input[i++] = new Integer(735523989);
        input[i++] = new Integer(-1565796934);
        input[i++] = new Integer(2122467359);
        input[i++] = new Integer(1724988151);
        input[i++] = new Integer(-934480635);
        i=0;
        cute.Cute.input = this;
        jpct.Market_Sales2jpct.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(735523989);
        input[i++] = new Integer(-1565796934);
        input[i++] = new Integer(2122467359);
        input[i++] = new Integer(1724988151);
        input[i++] = new Integer(-934480635);
        i=0;
        cute.Cute.input = this;
        jpct.Market_Sales2jpct.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(400);
        input[i++] = new Integer(735523989);
        input[i++] = new Integer(-1565796934);
        input[i++] = new Integer(2122467359);
        input[i++] = new Integer(1724988151);
        input[i++] = new Integer(-934480635);
        i=0;
        cute.Cute.input = this;
        jpct.Market_Sales2jpct.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(735523989);
        input[i++] = new Integer(-1565796934);
        input[i++] = new Integer(2122467359);
        input[i++] = new Integer(1724988151);
        input[i++] = new Integer(-934480635);
        i=0;
        cute.Cute.input = this;
        jpct.Market_Sales2jpct.main(null);
    }

    public void test18(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(101);
        input[i++] = new Integer(401);
        input[i++] = new Integer(735523989);
        input[i++] = new Integer(-1565796934);
        input[i++] = new Integer(2122467359);
        input[i++] = new Integer(1724988151);
        input[i++] = new Integer(-934480635);
        i=0;
        cute.Cute.input = this;
        jpct.Market_Sales2jpct.main(null);
    }

    public void test27(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(4001);
        input[i++] = new Integer(735523989);
        input[i++] = new Integer(-1565796934);
        input[i++] = new Integer(2122467359);
        input[i++] = new Integer(1724988151);
        input[i++] = new Integer(-934480635);
        i=0;
        cute.Cute.input = this;
        jpct.Market_Sales2jpct.main(null);
    }

    public void test33(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(101);
        input[i++] = new Integer(102);
        input[i++] = new Integer(735523989);
        input[i++] = new Integer(-1565796934);
        input[i++] = new Integer(2122467359);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-934480635);
        i=0;
        cute.Cute.input = this;
        jpct.Market_Sales2jpct.main(null);
    }

    public void test37(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(400);
        input[i++] = new Integer(735523989);
        input[i++] = new Integer(-1565796934);
        input[i++] = new Integer(2122467359);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-934480635);
        i=0;
        cute.Cute.input = this;
        jpct.Market_Sales2jpct.main(null);
    }

    public void test40(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        input[i++] = new Integer(735523989);
        input[i++] = new Integer(-1565796934);
        input[i++] = new Integer(2122467359);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-934480635);
        i=0;
        cute.Cute.input = this;
        jpct.Market_Sales2jpct.main(null);
    }

}
