package A1;

import cute.Cute;

public class Problem5_RER2015 {

	private String[] inputs = {"H","F","J","A","I","D","B","E","C","G"};

	public static int a326 =Cute.input.Integer();
	public static int a71 =Cute.input.Integer();
	public static int a382 =Cute.input.Integer();
	public static int a67 = Cute.input.Integer();
	public static boolean a191  =Cute.input.Boolean();
	public static boolean a198  =Cute.input.Boolean();
	public static int a395 = Cute.input.Integer();
	public static int a51 =Cute.input.Integer();
	public static int a125 =Cute.input.Integer();
	public static int a248 =Cute.input.Integer();
	public static int a99 =Cute.input.Integer();
	public static int a80 =Cute.input.Integer();
	public static int a383 =Cute.input.Integer();
	public static int a250 =Cute.input.Integer();
	public static int a24 =Cute.input.Integer();
	public static int a119 =Cute.input.Integer();
	public static boolean a303  =Cute.input.Boolean();
	public static int a293 =Cute.input.Integer();
	public static int a86 =Cute.input.Integer();
	public static int a175 =Cute.input.Integer();
	public static int a256 =Cute.input.Integer();
	public static int a163 =Cute.input.Integer();
	public static int a159 =Cute.input.Integer();
	public static int a273 =Cute.input.Integer();
	public static boolean cf  =Cute.input.Boolean();
	public static int a14 =Cute.input.Integer();
	public static int a194 =Cute.input.Integer();
	public static int a391 =Cute.input.Integer();
	public static boolean a277  =Cute.input.Boolean();
	public static int a42 =Cute.input.Integer();
	public static int a264 =Cute.input.Integer();
	public static int a38 =Cute.input.Integer();
	public static boolean a121  =Cute.input.Boolean();
	public static boolean a145  =Cute.input.Boolean();
	public static boolean a79  =Cute.input.Boolean();
	public static int a93 =Cute.input.Integer();
	public static int a196 =Cute.input.Integer();
	public static int a309 =Cute.input.Integer();
	public static int a78 =Cute.input.Integer();
	public static int a55 =Cute.input.Integer();
	public static boolean a257  =Cute.input.Boolean();
	public static int a334 =Cute.input.Integer();
	public static int a373 =Cute.input.Integer();
	public static boolean a385  =Cute.input.Boolean();
	public static boolean a12  =Cute.input.Boolean();
	public static int a305 =Cute.input.Integer();
	public static boolean a153  =Cute.input.Boolean();
	public static int a0 =Cute.input.Integer();
	public static int a258 =Cute.input.Integer();
	public static int a19 =Cute.input.Integer();
	public static int a353 =Cute.input.Integer();
	public static int a300 =Cute.input.Integer();
	public static int a104 =Cute.input.Integer();
	public static int a126 =Cute.input.Integer();
	public static int a137 =Cute.input.Integer();
	public static boolean a70  =Cute.input.Boolean();
	public static int a189 =Cute.input.Integer();
	public static boolean a69  =Cute.input.Boolean();
	public static int a65 =Cute.input.Integer();
	public static int a41 =Cute.input.Integer();
	public static int a76 =Cute.input.Integer();
	public static int a401 =Cute.input.Integer();
	public static int a164 =Cute.input.Integer();
	public static int a345 =Cute.input.Integer();
	public static int a106 =Cute.input.Integer();
	public static boolean a9  =Cute.input.Boolean();
	public static int a259 =Cute.input.Integer();
	public static boolean a376  =Cute.input.Boolean();
	public static int a68 =Cute.input.Integer();
	public static boolean a151  =Cute.input.Boolean();
	public static int a357 = Cute.input.Integer();
	public static int a263 = Cute.input.Integer();
	public static int a2 =Cute.input.Integer();
	public static boolean a13  =Cute.input.Boolean();
	public static boolean a5  =Cute.input.Boolean();
	public static int a363 =Cute.input.Integer();
	public static int a282 =Cute.input.Integer();
	public static int a219 =Cute.input.Integer();
	public static int a332 =Cute.input.Integer();
	public static boolean a118  =Cute.input.Boolean();
	public static int a322 =Cute.input.Integer();
	public static boolean a130  =Cute.input.Boolean();
	public static int a47 =Cute.input.Integer();
	public static int a295 =Cute.input.Integer();
	public static int a26 =Cute.input.Integer();
	public static int a392 = Cute.input.Integer();
	public static int a123 =Cute.input.Integer();
	public static int a394 =Cute.input.Integer();
	public static int a355 = Cute.input.Integer();
	public static boolean a387  =Cute.input.Boolean();
	public static int a149 = Cute.input.Integer();
	public static boolean a386  =Cute.input.Boolean();
	public static boolean a316  =Cute.input.Boolean();
	public static int a183 = Cute.input.Integer();
	public static boolean a15  =Cute.input.Boolean();
	public static boolean a140  =Cute.input.Boolean();
	public static int a152 =Cute.input.Integer();
	public static int a108 =Cute.input.Integer();
	public static int a275 = Cute.input.Integer();
	public static int a34 = Cute.input.Integer();
	public static int a324 =Cute.input.Integer();
	public static int a288 =Cute.input.Integer();
	public static int a284 =Cute.input.Integer();
	public static int a20 =Cute.input.Integer();


	private void errorCheck() {
	    if((78 < a395) && (132 >= a395)  && (a41==0) && (a191==false) && (a189==0)){
	    	cf = (false);
	    	throw new IllegalStateException( "error_0" );
	    }
	    if((a386==false) && (a152==0) && (87 < a256) && (85 >= a256) && (a189==0)){
	    	cf = (false);
	    	throw new IllegalStateException( "error_1" );
	    }
	    if((a71==0) && (a363==15) && (a68==0) && (a189==0)){
	    	cf = (false);
	    	throw new IllegalStateException( "error_2" );
	    }
	    if((a326==8) && (a353==0) && (a68==0) && (a189==0)){
	    	cf = (false);
	    	throw new IllegalStateException( "error_3" );
	    }
	    if((a219==4) && (a363==12) && (a68==0) && (a189==0)){
	    	cf = (false);
	    	throw new IllegalStateException( "error_4" );
	    }
	    if((337 < a355)  &&   (95 < a263) && (217 >= a263) && (85 < a256) && (270 >= a256) && (a189==0)){
	    	cf = (false);
	    	throw new IllegalStateException( "error_5" );
	    }
	    if((a137==0) && (a42==0) && (a191==false) && (a189==0)){
	    	cf = (false);
	    	throw new IllegalStateException( "error_6" );
	    }
	    if((a353==0) && (a42==0) && (a68==0) && (a189==0)){
	    	cf = (false);
	    	throw new IllegalStateException( "error_7" );
	    }
	    if((a383==6) && (a293==0) && (a68==0) && (a189==0)){
	    	cf = (false);
	    	throw new IllegalStateException( "error_8" );
	    }
	    if((a78==6) && (a309==0) &&  (a256 <=  87 ) && (a189==0)){
	    	cf = (false);
	    	throw new IllegalStateException( "error_9" );
	    }
	    if((a118==false) && (a293==0) && (a68==0) && (a189==0)){
	    	cf = (false);
	    	throw new IllegalStateException( "error_10" );
	    }
}



private  void calculateOutputm2(boolean input) {
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a164 = (10);
    	a104 = ((((((((  a104) * a67)% 14999) / 5) / 5) / 5) % 44)+ 52);
    	a189 =0;
    	a68 =0;
    	  System.out.println(  "Y"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a194 =0;
    	a189 =0;
    	a34 = ((((((((  a34) * a392)% 14999) * 2) - -3) * 1) % 14982)- 15017);
    	a119 = ((((((((  a119) * a67)% 14999) + 10048) + -5630) * 1) % 14977)- 15021);
    	  System.out.println(  "Q"  );  
    } 
}

private  void calculateOutputm3(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a159 =0;
    	a363 = (10);
    	a68 =0;
    	  System.out.println(  "U"  );  
    } 
}

private  void calculateOutputm4(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a353 =0;
    	a68 =0;
    	a284 = ((((((  a284) * a67)% 14999) / 5) - 25656) - 1131);
    	  System.out.println(  "R"  );  
    } 
    if((input==false) && (cf==false)){
    	 cf = (false);

    	  System.out.println(  "Q"  );  
    } 
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a68 =0;
    	a219 = (6);
    	a363 = (12);
    	  System.out.println(  "W"  );  
    } 
}

private  void calculateOutputm5(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);

    	  System.out.println(  "Q"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a189 =0;
    	a288 =0;
    	a391 =0;
    	a68 =0;
    	  System.out.println(  "Q"  );  
    } 
}

private  void calculateOutputm6(boolean input) {
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a219 = (2);
    	a68 =0;
    	a363 = (12);
    	  System.out.println(  "T"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a108 = (9);
    	a67 = ((((((  a67) * a24) + -15796) * 10)/ -9) * 1);
    	  System.out.println(  "Y"  );  
    } 
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a0 = (7);
    	a189 =0;
    	a263 = (((((((  a263) * a67)% 14999) % 74)- -291) + 13948) + -13946);
    	a256 = ((((((((  a256) * a67)% 14999) - 14690) + 17279) / 5) % 92)+ 178);
    	  System.out.println(  "S"  );  
    } 
}


private  void calculateOutputm7(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a295 = (8);
    	a264 = (((((((  a264) * a67)% 14999) - -11752) % 14978)- 15021) * 1);
    	a119 = (((((((  a119) * a67)% 14999) % 25)+ 53) - -28160) - 28159);
    	a189 =0;
    	  System.out.println(  "U"  );  
    } 
}

private  void calculateOutputm8(boolean input) {
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a258 =0;
    	a189 =0;
    	a250 = (11);
    	a119 = (((((((  a119) * a67)% 14999) % 14960)- -15039) - 0) * 1);
    	  System.out.println(  "Y"  );  
    } 
}

private  void calculateOutputm9(boolean input) {
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a71 =0;
    	a68 =0;
    	a189 =0;
    	a104 = (((((((  a104) * a67)% 14999) % 14917)- -15081) - 0) - 0);
    	  System.out.println(  "V"  );  
    } 
}

private  void calculateOutputm10(boolean input) {
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a189 =0;
    	a42 =0;
    	a163 =0;
    	a191 = (false);
    	  System.out.println(  "O"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a42 =0;
    	a163 =0;
    	a191 = (false);
    	a189 =0;
    	  System.out.println(  "O"  );  
    } 
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a189 =0;
    	a288 =0;
    	a68 =0;
    	a391 =0;
    	  System.out.println(  "Q"  );  
    } 
}


private  void calculateOutputm1(boolean input) {
    if((cf==false) &&  (a67 <=  75 )){
    	if((cf==false) &&   (9 < a392) && (74 >= a392)){
    		calculateOutputm2(input);
    	} 
    	if((cf==false) &&   (74 < a392) && (273 >= a392)){
    		calculateOutputm3(input);
    	} 
    } 
    if((cf==false) && (75 < a67) && (145 >= a67)){
    	if((a9==false) && (cf==false)){
    		calculateOutputm4(input);
    	} 
    } 
    if((cf==false) && (145 < a67) && (364 >= a67)){
    	if((cf==false) &&  (a24 <=  169 )){
    		calculateOutputm5(input);
    	} 
    	if((cf==false) &&  (24 < a24) && (42 >= a24)){
    		calculateOutputm6(input);
    	} 
    } 
    if(( 364 < a67)  && (cf==false)){
    	if((cf==false) && (a108==3)){
    		calculateOutputm7(input);
    	} 
    	if((a108==5) && (cf==false)){
    		calculateOutputm8(input);
    	} 
    	if((cf==false) && (a108==6)){
    		calculateOutputm9(input);
    	} 
    	if((a108==9) && (cf==false)){
    		calculateOutputm10(input);
    	} 
    } 
}


private  void calculateOutputm12(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a119 = (((((  a119) % 14977)+ -15021) - 2) * 1);
    	a68 =0;
    	a363 = (16);
    	  System.out.println(  "Y"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a353 =0;
    	a288 =0;
    	  System.out.println(  "O"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a68 =0;
    	a189 =0;
    	a71 =0;
    	a104 = (((((  a104) % 14917)- -15081) - 0) - -1);
    	  System.out.println(  "W"  );  
    } 
}

private  void calculateOutputm13(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a189 =0;
    	a391 =0;
    	a68 =0;
    	a137 =0;
    	  System.out.println(  "Y"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a391 =0;
    	a189 =0;
    	a137 =0;
    	a68 =0;
    	  System.out.println(  "Y"  );  
    } 
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a189 =0;
    	a198 = (true);
    	a264 = (((((  a264) % 78)- -35) + 2) / 5);
    	a119 = (((((  a119) % 25)+ 53) * 1) - 1);
    	  System.out.println(  "S"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a68 =0;
    	a149 = (((((  a149) / 5) * 5) % 15098)+ -14900);
    	a363 = (13);
    	  System.out.println(  "S"  );  
    } 
}

private  void calculateOutputm14(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a309 =0;
    	a189 =0;
    	a78 = (2);
    	a256 = ((((  a256) / 5) / 5) - 25571);
    	  System.out.println(  "X"  );  
    } 
}

private  void calculateOutputm15(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a123 = (6);
    	a20 = ((((((  a20) % 35)- 163) * 1) + 6073) + -6072);
    	a68 =0;
    	  System.out.println(  "Z"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a258 =0;
    	a309 =0;
    	a119 = ((((((  a119) / 5) - 9074) - 5570) * -1)/ 10);
    	a189 =0;
    	  System.out.println(  "Y"  );  
    } 
}

private  void calculateOutputm16(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a123 = (5);
    	a20 = (((((  a20) * 1) + 0) % 35)- 162);
    	a68 =0;
    	  System.out.println(  "S"  );  
    } 
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a68 =0;
    	a387 = (true);
    	a363 = (9);
    	  System.out.println(  "Y"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a55 = (7);
    	a264 = ((((((  a264) * 1) - 0) - 0) % 78)+ 36);
    	a189 =0;
    	a119 = (((((  a119) - 0) * 1) % 35)- 9);
    	  System.out.println(  "S"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a68 =0;
    	a219 = (2);
    	a363 = (12);
    	  System.out.println(  "W"  );  
    } 
}

private  void calculateOutputm17(boolean input) {
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a189 =0;
    	a273 = (3);
    	a264 = ((((  a264) / 5) - 19806) * 1);
    	a119 = (((((  a119) - 0) + 0) % 35)+ -9);
    	  System.out.println(  "W"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a189 =0;
    	a300 = ((((((  a300) % 14807)- -15192) - 0) - 15845) + 15846);
    	a71 =0;
    	a256 = (((((  a256) - 0) * 1) % 14864)- -15134);
    	  System.out.println(  "V"  );  
    } 
}

private  void calculateOutputm18(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a68 =0;
    	a137 =0;
    	a391 =0;
    	a189 =0;
    	  System.out.println(  "S"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);

    	  System.out.println(  "Y"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a258 =0;
    	a189 =0;
    	a382 =0;
    	a119 = ((((((  a119) % 14960)+ 15039) + -20095) * 1) + 20096);
    	  System.out.println(  "Q"  );  
    } 
}

private  void calculateOutputm19(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a189 =0;
    	a2 = (10);
    	a264 = ((((((  a264) / 5) / 5) * 5) % 85)+ 200);
    	a119 = ((((((  a119) % 25)+ 54) + -2) / 5) - -38);
    	  System.out.println(  "Y"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a152 =0;
    	a189 =0;
    	a76 = (10);
    	a256 = ((((((  a256) / 5) + -6116) - -20919) % 85)- -1);
    	  System.out.println(  "O"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a106 = (3);
    	a309 =0;
    	a189 =0;
    	a256 = (((((  a256) % 14956)- 15042) - 0) + -2);
    	  System.out.println(  "V"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a189 =0;
    	a258 =0;
    	a151 = (false);
    	a119 = (((((  a119) + 0) % 14960)+ 15039) * 1);
    	  System.out.println(  "W"  );  
    } 
}

private  void calculateOutputm20(boolean input) {
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a189 =0;
    	a55 = (6);
    	a264 = ((((((((  a264) * a284)% 14999) / 5) / 5) / 5) % 78)- -36);
    	a119 = ((((((((  a119) * a284)% 14999) % 35)- 8) / 5) + 9197) - 9225);
    	  System.out.println(  "S"  );  
    } 
}

private  void calculateOutputm21(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a68 =0;
    	a137 =0;
    	a189 =0;
    	a391 =0;
    	  System.out.println(  "S"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a152 =0;
    	a189 =0;
    	a76 = (7);
    	a256 = ((((((((  a256) * a284)% 14999) - -10554) - 4131) + -10372) % 85)- -1);
    	  System.out.println(  "Y"  );  
    } 
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a189 =0;
    	a288 =0;
    	a391 =0;
    	a68 =0;
    	  System.out.println(  "Q"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a76 = (7);
    	a152 =0;
    	a256 = (((((((  a256) * a284)% 14999) / 5) % 85)- -1) + -1);
    	a189 =0;
    	  System.out.println(  "Y"  );  
    } 
}

private  void calculateOutputm22(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a258 =0;
    	a309 =0;
    	a119 = (((((  a119) % 14960)+ 15039) + 0) - -1);
    	a189 =0;
    	  System.out.println(  "X"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a401 = (((((  a401) + 0) % 33)+ 423) + 0);
    	a41 =0;
    	a191 = (true);
    	a189 =0;
    	  System.out.println(  "S"  );  
    } 
}

private  void calculateOutputm23(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a383 = (2);
    	a293 =0;
    	a68 =0;
    	a189 =0;
    	  System.out.println(  "T"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a189 =0;
    	a194 =0;
    	a51 =0;
    	a119 = (((((  a119) - 0) % 14977)+ -15021) - 3);
    	  System.out.println(  "V"  );  
    } 
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a68 =0;
    	a293 =0;
    	a189 =0;
    	a259 = (5);
    	  System.out.println(  "O"  );  
    } 
}

private  void calculateOutputm24(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a326 = (13);
    	a353 =0;
    	  System.out.println(  "O"  );  
    } 
    if((cf==false) && (input==false)){
    	 cf = (false);
    	a189 =0;
    	a68 =0;
    	a137 =0;
    	a391 =0;
    	  System.out.println(  "S"  );  
    } 
}

private  void calculateOutputm25(boolean input) {
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a68 =0;
    	a189 =0;
    	a345 =0;
    	a69 = (false);
    	  System.out.println(  "O"  );  
    } 
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a189 =0;
    	a295 = (6);
    	a264 = (((((  a264) % 14978)- 15021) * 1) * 1);
    	a119 = (((((  a119) - 0) % 25)+ 52) * 1);
    	  System.out.println(  "V"  );  
    } 
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a71 =0;
    	a373 = (7);
    	a189 =0;
    	a256 = (((((  a256) % 14864)+ 15134) + 1) + 1);
    	  System.out.println(  "W"  );  
    } 
    if((input==false) && (cf==false)){
    	 cf = (false);
    	a309 =0;
    	a189 =0;
    	a258 =0;
    	a119 = (((((  a119) % 14960)+ 15039) * 1) + 0);
    	  System.out.println(  "U"  );  
    } 
}

private  void calculateOutputm11(boolean input) {
    if((cf==false) && (a353==0)){
    	if((a326==10) && (cf==false)){
    		calculateOutputm12(input);
    	} 
    	if((cf==false) && (a326==11)){
    		calculateOutputm13(input);
    	} 
    	if((cf==false) && (a326==13)){
    		calculateOutputm14(input);
    	} 
    	if((a326==14) && (cf==false)){
    		calculateOutputm15(input);
    	} 
    } 
    if((a353==0) && (cf==false)){
    	if((cf==false) && (a305==0)){
    		calculateOutputm16(input);
    	} 
    	if((a305==0) && (cf==false)){
    		calculateOutputm17(input);
    	} 
    	if((cf==false) && (a305==0)){
    		calculateOutputm18(input);
    	} 
    	if((cf==false) && (a305==0)){
    		calculateOutputm19(input);
    	} 
    } 
    if((a353==0) && (cf==false)){
    	if(( a284 <= 158)  && (cf==false)){
    		calculateOutputm20(input);
    	} 
    	if((cf==false) &&  (158 < a284) && (50 >= a284)){
    		calculateOutputm21(input);
    	} 
    } 
    if((a353==0) && (cf==false)){
    	if((a288==0) && (cf==false)){
    		calculateOutputm22(input);
    	} 
    	if((cf==false) && (a288==0)){
    		calculateOutputm23(input);
    	} 
    	if((a288==0) && (cf==false)){
    		calculateOutputm24(input);
    	} 
    } 
    if((a353==0) && (cf==false)){
    	if((cf==false) && (a376==true)){
    		calculateOutputm25(input);
    	} 
    } 
}

public  void calculateOutput(boolean input) {
 	cf = (true);
    if((cf==false) && (a189==0)){
    	if((a68==0) && (cf==false)){
    		calculateOutputm1(input);
    	} 
    	if((a68==0) && (cf==false)){
    		calculateOutputm11(input);
    	}    	 
    } 
  
    errorCheck();
    if(cf==false)
    	throw new IllegalArgumentException("Current state has no transition for this input!");
}

public static void main() throws Exception 
	{
	     // init system and input reader
            Problem5_RER2015 eca = new Problem5_RER2015();
        int a=0;
	int x;
        int y;
         
        x = Cute.input.Integer();
        y = Cute.input.Integer();
		boolean input = Cute.input.Boolean();
			// main i/o-loop
            while(a<10) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                 eca.calculateOutput(input);
					 
				}
				
				if (x>299 && x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutput(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
	}
	
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
