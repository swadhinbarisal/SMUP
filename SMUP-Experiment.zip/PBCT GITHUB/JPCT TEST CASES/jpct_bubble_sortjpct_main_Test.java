
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class jpct_bubble_sortjpct_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public jpct_bubble_sortjpct_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-1198491718);
        input[i++] = new Integer(1685249848);
        input[i++] = new Integer(-761551501);
        input[i++] = new Integer(1185011979);
        i=0;
        cute.Cute.input = this;
        jpct.bubble_sortjpct.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(1685249848);
        input[i++] = new Integer(-761551501);
        input[i++] = new Integer(1185011979);
        i=0;
        cute.Cute.input = this;
        jpct.bubble_sortjpct.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(1685249848);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        jpct.bubble_sortjpct.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(1685249848);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1);
        i=0;
        cute.Cute.input = this;
        jpct.bubble_sortjpct.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1685249848);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jpct.bubble_sortjpct.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(1);
        input[i++] = new Integer(1685249848);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jpct.bubble_sortjpct.main(null);
    }

    public void test8(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(100);
        input[i++] = new Integer(1685249848);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jpct.bubble_sortjpct.main(null);
    }

    public void test43(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(200);
        input[i++] = new Integer(1685249848);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jpct.bubble_sortjpct.main(null);
    }

    public void test44(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(240);
        input[i++] = new Integer(1685249848);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jpct.bubble_sortjpct.main(null);
    }

}
