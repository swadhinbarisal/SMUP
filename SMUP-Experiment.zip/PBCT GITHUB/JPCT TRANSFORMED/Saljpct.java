/**
 * TODO description
 */
package jpct;
import cute.Cute;
import java.util.Scanner;


abstract class Saljpct$$Basic {
	double gs,bs,sda,shra,sinc;
	void input() {
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter Basic Saljpctary: ");
	bs=Cute.input.Integer();
	sc.close();
	}
	void comp() {
	//System.out.println("From Basic Layer Comp");
	sda=0;
	shra=0;
	sinc=0;
	}
	void output() {
	//System.out.println("From Basic Layer Output");
	System.out.println("Basic Saljpctary is: "+bs);
	}	
}

/**
 * TODO description
 */
abstract class Saljpct$$DA extends  Saljpct$$Basic  {
	void comp(){
		//System.out.println("From DA Layer Comp");
		super.comp();
			//System.out.println("From DA Layer Comp Again");
		if(bs>=20000)
		sda=0.25*bs;
//******************Transformed code started****************************
 else
if(bs==25000){
 }
 else {}
if(bs>=10000){
if(bs<20000){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		 if((bs==25000)||(bs>=10000) && (bs<20000)  )
		sda=0.2*bs;
		else
		sda=0.1*bs;
		}

		void output(){
			//System.out.println("From DA Layer output");
		super.output();
		//System.out.println("From DA Layer output Again");
		System.out.println("DA is: "+sda);
		}
}

/**
 * TODO description
 */
abstract class Saljpct$$HRA extends  Saljpct$$DA  {
	void comp(){
		//System.out.println("From HRA Layer Comp");
	super.comp();
		//System.out.println("From HRA Layer Comp Again");
	if(bs>=20000)
	shra=0.2*bs;
//******************Transformed code started****************************
 else
if(bs>=10000){
if(bs<20000){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	 if(bs>=10000 && bs<20000)
	shra=0.15*bs;
	else
	shra=0.05*bs;
	}

	void output(){
		//System.out.println("From HRA Layer output");
	super.output();
	//System.out.println("From HRA Layer output Again");
	System.out.println("HRA is: "+shra);
	}
}

/**
 * TODO description
 */
abstract class Saljpct$$Inc extends  Saljpct$$HRA  {
	void comp(){
		//System.out.println("From Inc Layer Comp");
		super.comp();
			//System.out.println("From Inc Layer Comp Again");
		if(bs>=20000)
		sinc=0.08*bs;
//******************Transformed code started****************************
 else
if(bs>=10000){
if(bs<20000){}
 else{}
 }
 else {}
//******************Transformed code end****************************
		 if(bs>=10000 && bs<20000)
		sinc=0.05*bs;
		else
		sinc=0.02*bs;
		}

		void output(){
			//System.out.println("From Inc Layer output");
		super.output();
		//System.out.println("From Inc Layer output Again");
		System.out.println("Increment is: "+sinc);
		}
}

/**
 * TODO description
 */
public class Saljpct extends  Saljpct$$Inc  {
	void comp(){
		//System.out.println("From Gross Layer Comp");
	super.comp();
		//System.out.println("From Gross Layer Comp Again");
	gs=bs+sda+shra+sinc;
	}
	void output() {
		//System.out.println("From Gross Layer output");
	super.output();
	//System.out.println("From Gross Layer output Again");
	System.out.println("Gross Saljpctary is: "+gs);
	}
	public static void main(String[] args) {
		Saljpct s=new Saljpct();
		//System.out.println("From Gross Layer Main");
		s.input();
		s.comp();
		s.output();
		}
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
