
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class jpct_StringBuffer2jpct_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public jpct_StringBuffer2jpct_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[2];
        input[i++] = new Integer(-486729276);
        input[i++] = new Integer(-967158877);
        i=0;
        cute.Cute.input = this;
        jpct.StringBuffer2jpct.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[1];
        input[i++] = new Integer(4);
        i=0;
        cute.Cute.input = this;
        jpct.StringBuffer2jpct.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(1);
        input[i++] = new Integer(-967158877);
        input[i++] = new Integer(-979592617);
        i=0;
        cute.Cute.input = this;
        jpct.StringBuffer2jpct.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(1);
        input[i++] = new Integer(4);
        input[i++] = new Integer(4);
        i=0;
        cute.Cute.input = this;
        jpct.StringBuffer2jpct.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(1);
        input[i++] = new Integer(4);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jpct.StringBuffer2jpct.main(null);
    }

    public void test11(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jpct.StringBuffer2jpct.main(null);
    }

    public void test12(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        input[i++] = new Character(�);
        i=0;
        cute.Cute.input = this;
        jpct.StringBuffer2jpct.main(null);
    }

    public void test36(){
        i=0;
        input = new Object[8];
        input[i++] = new Integer(3);
        input[i++] = new Integer(2);
        input[i++] = new Integer(0);
        input[i++] = new Character(?);
        input[i++] = new Character(?);
        input[i++] = new Integer(131412134);
        input[i++] = new Integer(1089287027);
        input[i++] = new Integer(-2024819171);
        i=0;
        cute.Cute.input = this;
        jpct.StringBuffer2jpct.main(null);
    }

    public void test37(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(3);
        input[i++] = new Integer(2);
        input[i++] = new Character(?);
        input[i++] = new Integer(167340656);
        input[i++] = new Integer(-373706639);
        input[i++] = new Integer(-956417208);
        input[i++] = new Integer(187255047);
        i=0;
        cute.Cute.input = this;
        jpct.StringBuffer2jpct.main(null);
    }

}
