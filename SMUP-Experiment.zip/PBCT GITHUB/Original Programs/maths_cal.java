package tests;

import cute.Cute;

/**
 *  .
 * User: ksen
 * Date: Oct 25, 2005
 * Time: 7:38:52 PM
 * To change this template use File | Settings | File Templates.
 */

class MyException extends RuntimeException {

}

public class maths_cal {

    public static void factorial(int n,int x1,int x2)
   {
        int  c, fact = 1;

        if((x1>x2)&&(x2>4000))
        {
            System.out.println("The system is approaching towards largest numbers");
        }
        if((x1>x2)||(x2>4000))
        {
            System.out.println("The system is approaching towards largest numbers anyway");
        }

      System.out.println("Enter an integer to calculate it's factorial");
      if ( n < 0 )
         System.out.println("Number should be non-negative.");
      else
      {
         for ( c = 1 ; c <= n ; c++ )
         {
             fact = fact*c;
         }

         System.out.println("Factorial of "+n+" is = "+fact);
      }
   }

    public static void reverse(int n,int x1,int x2)
   {
        if((x1>x2)&&(x2>8000))
        {
            System.out.println("The system is approaching towards 8000");
        }
        if((x1>x2)||(x2>8000))
        {
            System.out.println("The system is approaching towards largest numbers anyway");
        }

      int  reverse = 0;
      System.out.println("Enter the number to reverse");
      while( n != 0 )
      {
          reverse = reverse * 10;
          reverse = reverse + n%10;
          n = n/10;
      }

      System.out.println("Reverse of entered number is "+reverse);
   }
    public static void palindrome(int num,int x1,int x2){
		int n = num; //used at last time check
		int reverse=0,remainder;
        if((x1>=x2)&&(x2>14000))
        {
            System.out.println("The system is approaching towards largest numbers---1400");
        }
        if((x1>=x2)||(x2>14000))
        {
            System.out.println("The system is approaching towards largest numbers anyway---------1400");
        }

		while(num > 0){
			remainder = num % 10;
			reverse = reverse * 10 + remainder;
			num = num / 10;
		}
		if(reverse == n)
			System.out.println(n+" is a Palindrome Number");
		else
			System.out.println(n+" is not a Palindrome Number");
	}

    public static int found(int x, int z){

        if((x>199) && (z<50)){
            throw new MyException();
        } else {
            return 2*x+1;
        }
    }

    public static int get(int y){
        int ret = found(y,11) * 23;
        return ret;
    }


    public static void main(String[] args) {
        int x = Cute.input.Integer();
        int y= Cute.input.Integer();
        int y1= Cute.input.Integer();
        int y2= Cute.input.Integer();
        switch(x){
            case -100:
                y=1;
                reverse(y1,x,y);
                reverse(y2,x,y);
                break;
            case 0:
                y = 2;
                palindrome(y1,x,y);
                palindrome(y2,x,y);
                break;
            case 100:
                y = 3;
                factorial(y1,x,y);
                factorial(y2,x,y);
                break;
            default:
                y=4;
        }
        try {
            int z = get(x);
            if(z==69){
                System.out.println("y = " + y);
            }
        } catch(MyException e){
            y = x+10;
            if(y==250)
                System.out.println("OOPS ...");
        }
    }
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=100
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
