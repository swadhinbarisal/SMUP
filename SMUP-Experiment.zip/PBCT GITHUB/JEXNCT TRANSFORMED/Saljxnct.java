/**
 * TODO description
 */
package jxnct;
import cute.Cute;
import java.util.Scanner;


abstract class Saljxnct$$Basic {
	double gs,bs,sda,shra,sinc;
	void input() {
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter Basic Saljxnctary: ");
	bs=Cute.input.Integer();
	sc.close();
	}
	void comp() {
	//System.out.println("From Basic Layer Comp");
	sda=0;
	shra=0;
	sinc=0;
	}
	void output() {
	//System.out.println("From Basic Layer Output");
	System.out.println("Basic Saljxnctary is: "+bs);
	}	
}

/**
 * TODO description
 */
abstract class Saljxnct$$DA extends  Saljxnct$$Basic  {
	void comp(){
		//System.out.println("From DA Layer Comp");
		super.comp();
			//System.out.println("From DA Layer Comp Again");
		if(bs>=20000)
		sda=0.25*bs;
//************************Modified code Start***********************************
 else
 if((bs>=10000)&&(bs<20000)){
if(bs==25000){}
else if(!(bs==25000)){}
}
else{}
 if(!(bs<20000)||(bs==25000)){
if(bs>=10000){}
else if(!(bs>=10000)){}
}
else{}
 if(!(bs>=10000)||(bs==25000)){
if(bs<20000){}
else if(!(bs<20000)){}
}
else{}
//************************Modified code end***********************************
		 if((bs==25000)||(bs>=10000) && (bs<20000)  )
		sda=0.2*bs;
		else
		sda=0.1*bs;
		}

		void output(){
			//System.out.println("From DA Layer output");
		super.output();
		//System.out.println("From DA Layer output Again");
		System.out.println("DA is: "+sda);
		}
}

/**
 * TODO description
 */
abstract class Saljxnct$$HRA extends  Saljxnct$$DA  {
	void comp(){
		//System.out.println("From HRA Layer Comp");
	super.comp();
		//System.out.println("From HRA Layer Comp Again");
	if(bs>=20000)
	shra=0.2*bs;
//************************Modified code Start***********************************
 else
 if(!(bs<20000)){
if(bs>=10000){}
else if(!(bs>=10000)){}
}
else{}
 if(!(bs>=10000)){
if(bs<20000){}
else if(!(bs<20000)){}
}
else{}
//************************Modified code end***********************************
	 if(bs>=10000 && bs<20000)
	shra=0.15*bs;
	else
	shra=0.05*bs;
	}

	void output(){
		//System.out.println("From HRA Layer output");
	super.output();
	//System.out.println("From HRA Layer output Again");
	System.out.println("HRA is: "+shra);
	}
}

/**
 * TODO description
 */
abstract class Saljxnct$$Inc extends  Saljxnct$$HRA  {
	void comp(){
		//System.out.println("From Inc Layer Comp");
		super.comp();
			//System.out.println("From Inc Layer Comp Again");
		if(bs>=20000)
		sinc=0.08*bs;
//************************Modified code Start***********************************
 else
 if(!(bs<20000)){
if(bs>=10000){}
else if(!(bs>=10000)){}
}
else{}
 if(!(bs>=10000)){
if(bs<20000){}
else if(!(bs<20000)){}
}
else{}
//************************Modified code end***********************************
		 if(bs>=10000 && bs<20000)
		sinc=0.05*bs;
		else
		sinc=0.02*bs;
		}

		void output(){
			//System.out.println("From Inc Layer output");
		super.output();
		//System.out.println("From Inc Layer output Again");
		System.out.println("Increment is: "+sinc);
		}
}

/**
 * TODO description
 */
public class Saljxnct extends  Saljxnct$$Inc  {
	void comp(){
		//System.out.println("From Gross Layer Comp");
	super.comp();
		//System.out.println("From Gross Layer Comp Again");
	gs=bs+sda+shra+sinc;
	}
	void output() {
		//System.out.println("From Gross Layer output");
	super.output();
	//System.out.println("From Gross Layer output Again");
	System.out.println("Gross Saljxnctary is: "+gs);
	}
	public static void main(String[] args) {
		Saljxnct s=new Saljxnct();
		//System.out.println("From Gross Layer Main");
		s.input();
		s.comp();
		s.output();
		}
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
