/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jpct;

import cute.Cute;

/**
 *
 * @author ARPITA
 */
public class Orderjpct {
    public static void main(String[] args) {
        int x,y,z;
                 x=Cute.input.Integer();;
                 y=Cute.input.Integer();;
                  z=Cute.input.Integer();;
           System.out.println(x+" "+y+" "+z);
//******************Transformed code started****************************
if(x<y){
if(x<z){}
 else{}
 }
 else {}
//******************Transformed code end****************************
            if (x < y && x < z) {        // x comes first
           if (y < z)
             System.out.println("order is :" + x + " " + y + " " + z );
           else
             System.out.println("order is :" + x + " " + z + " " + y );
           }
//******************Transformed code started****************************
 else
if(x>y){
if(x>z){}
 else{}
 }
 else {}
//******************Transformed code end****************************
      if (x > y && x > z) {   // x comes last
          if (y < z)
            System.out.println( "order is :" +y + " " + z + " " + x );
          else
            System.out.println("order is :" + z + " " + y + " " + x );
    }
    else {                       // x in the middle
         if (y < z)
           System.out.println("order is :" + y + " " + x + " " + z);
         else
           System.out.println("order is :" + z + " " + x + " " + y);
}
    }
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
