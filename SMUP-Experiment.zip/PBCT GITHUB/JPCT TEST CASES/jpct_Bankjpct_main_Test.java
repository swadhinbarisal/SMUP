
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class jpct_Bankjpct_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public jpct_Bankjpct_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[8];
        input[i++] = new Integer(-1512596250);
        input[i++] = new Integer(467664732);
        input[i++] = new Integer(-182095160);
        input[i++] = new Integer(1285729539);
        input[i++] = new Integer(177649024);
        input[i++] = new Integer(1726676241);
        input[i++] = new Integer(-1056637991);
        input[i++] = new Integer(1726725053);
        i=0;
        cute.Cute.input = this;
        jpct.Bankjpct.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[12];
        input[i++] = new Integer(80);
        input[i++] = new Integer(467664732);
        input[i++] = new Integer(-182095160);
        input[i++] = new Integer(1285729539);
        input[i++] = new Integer(177649024);
        input[i++] = new Integer(1726676241);
        input[i++] = new Integer(-1056637991);
        input[i++] = new Integer(1726725053);
        input[i++] = new Integer(-1534142188);
        input[i++] = new Integer(750291546);
        input[i++] = new Integer(1941706860);
        input[i++] = new Integer(690002766);
        i=0;
        cute.Cute.input = this;
        jpct.Bankjpct.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[16];
        input[i++] = new Integer(80);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-182095160);
        input[i++] = new Integer(1285729539);
        input[i++] = new Integer(177649024);
        input[i++] = new Integer(1726676241);
        input[i++] = new Integer(-1056637991);
        input[i++] = new Integer(1726725053);
        input[i++] = new Integer(-1534142188);
        input[i++] = new Integer(750291546);
        input[i++] = new Integer(1941706860);
        input[i++] = new Integer(690002766);
        input[i++] = new Integer(-460692757);
        input[i++] = new Integer(-1826203381);
        input[i++] = new Integer(1817729992);
        input[i++] = new Integer(458582242);
        i=0;
        cute.Cute.input = this;
        jpct.Bankjpct.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[20];
        input[i++] = new Integer(80);
        input[i++] = new Integer(0);
        input[i++] = new Integer(441);
        input[i++] = new Integer(1285729539);
        input[i++] = new Integer(177649024);
        input[i++] = new Integer(1726676241);
        input[i++] = new Integer(-1056637991);
        input[i++] = new Integer(1726725053);
        input[i++] = new Integer(-1534142188);
        input[i++] = new Integer(750291546);
        input[i++] = new Integer(1941706860);
        input[i++] = new Integer(690002766);
        input[i++] = new Integer(-460692757);
        input[i++] = new Integer(-1826203381);
        input[i++] = new Integer(1817729992);
        input[i++] = new Integer(458582242);
        input[i++] = new Integer(-577656423);
        input[i++] = new Integer(1548756735);
        input[i++] = new Integer(-151527681);
        input[i++] = new Integer(-1548229583);
        i=0;
        cute.Cute.input = this;
        jpct.Bankjpct.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[20];
        input[i++] = new Integer(80);
        input[i++] = new Integer(0);
        input[i++] = new Integer(441);
        input[i++] = new Integer(0);
        input[i++] = new Integer(177649024);
        input[i++] = new Integer(1726676241);
        input[i++] = new Integer(-1056637991);
        input[i++] = new Integer(1726725053);
        input[i++] = new Integer(-1534142188);
        input[i++] = new Integer(750291546);
        input[i++] = new Integer(1941706860);
        input[i++] = new Integer(690002766);
        input[i++] = new Integer(-460692757);
        input[i++] = new Integer(-1826203381);
        input[i++] = new Integer(1817729992);
        input[i++] = new Integer(458582242);
        input[i++] = new Integer(-577656423);
        input[i++] = new Integer(1548756735);
        input[i++] = new Integer(-151527681);
        input[i++] = new Integer(-1548229583);
        i=0;
        cute.Cute.input = this;
        jpct.Bankjpct.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[16];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(441);
        input[i++] = new Integer(0);
        input[i++] = new Integer(177649024);
        input[i++] = new Integer(1726676241);
        input[i++] = new Integer(-1056637991);
        input[i++] = new Integer(1726725053);
        input[i++] = new Integer(-1534142188);
        input[i++] = new Integer(750291546);
        input[i++] = new Integer(1941706860);
        input[i++] = new Integer(690002766);
        input[i++] = new Integer(-460692757);
        input[i++] = new Integer(-1826203381);
        input[i++] = new Integer(1817729992);
        input[i++] = new Integer(458582242);
        i=0;
        cute.Cute.input = this;
        jpct.Bankjpct.main(null);
    }

    public void test9(){
        i=0;
        input = new Object[16];
        input[i++] = new Integer(0);
        input[i++] = new Integer(46);
        input[i++] = new Integer(441);
        input[i++] = new Integer(0);
        input[i++] = new Integer(177649024);
        input[i++] = new Integer(1726676241);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1534142188);
        input[i++] = new Integer(750291546);
        input[i++] = new Integer(1941706860);
        input[i++] = new Integer(690002766);
        input[i++] = new Integer(-460692757);
        input[i++] = new Integer(-1826203381);
        input[i++] = new Integer(1817729992);
        input[i++] = new Integer(458582242);
        i=0;
        cute.Cute.input = this;
        jpct.Bankjpct.main(null);
    }

    public void test14(){
        i=0;
        input = new Object[8];
        input[i++] = new Integer(10);
        input[i++] = new Integer(201);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(177649024);
        input[i++] = new Integer(1726676241);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jpct.Bankjpct.main(null);
    }

    public void test44(){
        i=0;
        input = new Object[12];
        input[i++] = new Integer(0);
        input[i++] = new Integer(201);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(177649024);
        input[i++] = new Integer(1726676241);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1534142188);
        input[i++] = new Integer(750291546);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jpct.Bankjpct.main(null);
    }

    public void test48(){
        i=0;
        input = new Object[12];
        input[i++] = new Integer(0);
        input[i++] = new Integer(46);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(177649024);
        input[i++] = new Integer(1726676241);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1534142188);
        input[i++] = new Integer(750291546);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jpct.Bankjpct.main(null);
    }

    public void test49(){
        i=0;
        input = new Object[8];
        input[i++] = new Integer(10);
        input[i++] = new Integer(46);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(177649024);
        input[i++] = new Integer(1726676241);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jpct.Bankjpct.main(null);
    }

}
