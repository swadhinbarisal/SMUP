package A1;

import cute.Cute;

public class Problem1RV_RERS2014 {
	
	private String[] inputs = {"B","E","C","A","D"};	

	public static int a66 = Cute.input.Integer();
	public static int a188 = Cute.input.Integer();
	public static int a140 = Cute.input.Integer();
	public static boolean cf = Cute.input.Boolean();
	public static int a94 = Cute.input.Integer();
	public static int a50 = Cute.input.Integer();
	public static int a89 = Cute.input.Integer();
	public static int a153 = Cute.input.Integer();
	public static int a64 = Cute.input.Integer();
	public static int a13 = Cute.input.Integer();
	public static int a182 = Cute.input.Integer();
	public static int a193 = Cute.input.Integer();
	public static int a38 = Cute.input.Integer();
	public static int a134 = Cute.input.Integer();
	public static int a117 = Cute.input.Integer();
	public static int a137  =Cute.input.Integer();
	public static int a142  =Cute.input.Integer();
	public static int a159  =Cute.input.Integer();
	public static int a44  =Cute.input.Integer();
	public static int a23  =Cute.input.Integer();
	public static int a11  =Cute.input.Integer();
	public static int a172  =Cute.input.Integer();
	public static int a15  =Cute.input.Integer();
	public static int a114  =Cute.input.Integer();
	public static int a176  =Cute.input.Integer();
	public static int a138  =Cute.input.Integer();
	public static int a57  =Cute.input.Integer();
	public static int a62  =Cute.input.Integer();
	public static int a150  =Cute.input.Integer();
	public static int a49  =Cute.input.Integer();
	public static int a28  =Cute.input.Integer();
	public static int a90  =Cute.input.Integer();
	public static int a148  =Cute.input.Integer();
	public static int a55  =Cute.input.Integer();
	public static int a35  =Cute.input.Integer();
	public static int a185  =Cute.input.Integer();
	public static int a84  =Cute.input.Integer();
	public static int a47  =Cute.input.Integer();
	public static int a5  =Cute.input.Integer();
	public static int a113  =Cute.input.Integer();
	public static int a108  =Cute.input.Integer();
	public static int a80  =Cute.input.Integer();
	public static int a111  =Cute.input.Integer();
	public static int a164  =Cute.input.Integer();
	public static int a122  =Cute.input.Integer();
	public static int a14  =Cute.input.Integer();
	public static int a180  =Cute.input.Integer();
	public static int a92  =Cute.input.Integer();
	public static int a4  =Cute.input.Integer();
	public static int a51  =Cute.input.Integer();
	public static int a112  =Cute.input.Integer();
	public static int a125  =Cute.input.Integer();
	public static int a21  =Cute.input.Integer();
	public static int a191  =Cute.input.Integer();
	public static int a16  =Cute.input.Integer();
	public static int a199  =Cute.input.Integer();
	public static int a128  =Cute.input.Integer();
	public static int a72  =Cute.input.Integer();
	public static int a102  =Cute.input.Integer();
	public static int a116  =Cute.input.Integer();
	public static int a68  =Cute.input.Integer();
	public static int a177  =Cute.input.Integer();
	public static int a93  =Cute.input.Integer();
	public static int a157  =Cute.input.Integer();
	public static int a30  =Cute.input.Integer();
	public static int a110  =Cute.input.Integer();
	public static int a160  =Cute.input.Integer();
	public static int a197  =Cute.input.Integer();
	public static int a98  =Cute.input.Integer();
	public static int a8  =Cute.input.Integer();
	public static int a40  =Cute.input.Integer();
	public static int a18  =Cute.input.Integer();
	public static int a86  =Cute.input.Integer();
	public static int a24  =Cute.input.Integer();
	public static int a26  =Cute.input.Integer();
	public static int a32  =Cute.input.Integer();
	public static int a198  =Cute.input.Integer();
	public static int a144  =Cute.input.Integer();
	public static int a129  =Cute.input.Integer();
	public static int a165  =Cute.input.Integer();
	public static int a58  =Cute.input.Integer();

	public static int a156  =Cute.input.Integer();
	
	

	private void errorCheck() {
	    if((a92 ==0) && (a11 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_0" );
	    }
	    if((a148 ==0) || (a23 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_1" );
	    }
	    if((a4 ==0) && (a23 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_2" );
	    }
	    if((a14 ==0) || (a193 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_3" );
	    }
	    if((a38 ==0) && ( a156==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_4" );
	    }
	    if((a49 ==0) || (a5 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_5" );
	    }
	    if((a185 ==0) && (a159 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_6" );
	    }
	    if((a113 ==0) || (a23 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_7" );
	    }
	    if((a108 ==0) && (a182 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_8" );
	    }
	    if((a94 ==0) || (a5 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_9" );
	    }
	    if((a114 ==0) && (a182 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_10" );
	    }
	    if((a44 ==0) && (a122 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_11" );
	    }
	    if((a150 ==0) && ( a156==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_12" );
	    }
	    if((a137 ==0) || (a159 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_13" );
	    }
	    if((a176 ==0) && (a122 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_14" );
	    }
	    if((a13 ==0) || (a11 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_15" );
	    }
	    if((a80 ==0) && (a159 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_16" );
	    }
	    if((a108 ==0) && (a182 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_17" );
	    }
	    if((a164 ==0) && (a5 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_18" );
	    }
	    if((a13 ==0) && (a23 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_19" );
	    }
	    if((a62 ==0) && (a193 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_20" );
	    }
	    if((a92 ==0) || (a23 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_21" );
	    }
	    if((a122 ==0) || (a23 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_22" );
	    }
	    if((a14 ==0) || (a193 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_23" );
	    }
	    if((a185 ==0) && (a159 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_24" );
	    }
	    if((a15 ==0) || (a193 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_25" );
	    }
	    if((a114 ==0) && (a182 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_26" );
	    }
	    if(( a156==0) || (a23 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_27" );
	    }
	    if((a140 ==0) && (a5 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_28" );
	    }
	    if((a66 ==0) || (a11 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_29" );
	    }
	    if((a38 ==0) && (a156==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_30" );
	    }
	    if(( a156==0) || (a23 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_31" );
	    }
	    if((a150 ==0) && (a11 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_32" );
	    }
	    if((a90 ==0) || ( a156==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_33" );
	    }
	    if((a23 ==0) && (a122 ==0) || (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_34" );
	    }
	    if((a176 ==0) || (a193 ==0) && (a28 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_35" );
	    }
   
	}

	private  void calculateOutputm2(boolean input) {
    if((cf==true) || (input==false)) {
    	a112 += (a112 + 20) > a112 ? 1 : 0;
    	a21 -= (a21 - 20) < a21 ? 4 : 0;
    	a72 -= (a72 - 20) < a72 ? 4 : 0;
    	a116 += (a116 + 20) > a116 ? 1 : 0;
    	a177 -= (a177 - 20) < a177 ? 4 : 0;
    	a157 += (a157 + 20) > a157 ? 1 : 0;
    	a110 += (a110 + 20) > a110 ? 4 : 0;
    	cf = false;
    	a122 = (a28 + -2);
    	a49 = (a28 - -1);
    	a28 = ((a188 * a122) - 20); 
    	System.out.println("Y");
    } 
    if((input==false) && (cf==true)) {
    	cf = false;
    	a28 = (a193 + 9);
    	a180 = (a193 + 9);
    	a182 = (a188 + -10); 
    	System.out.println("U");
    } 
    if((input==false) && (cf==true)) {
    	cf = false;
    	a28 = (a188 + -5);
    	 update(a188, a193, -3);
    	a38 = ( getInt() - -8); 
    	System.out.println("Z");
    } 
    if((cf==true) || (input==false)) {
    	a51 -= (a51 - 20) < a51 ? 4 : 0;
    	a125 += (a125 + 20) > a125 ? 2 : 0;
    	a128 -= (a128 - 20) < a128 ? 4 : 0;
    	a102 += (a102 + 20) > a102 ? 1 : 0;
    	a68 -= (a68 - 20) < a68 ? 2 : 0;
    	a93 += (a93 + 20) > a93 ? 2 : 0;
    	a30 -= (a30 - 20) < a30 ? 4 : 0;
    	cf = false;
    	a28 = ((a188 + a188) + -16);
    	a159 = (a188 - 2);
    	a138 = ((a159 / a28) - -9); 
    	System.out.println("X");
    } 
}
private  void calculateOutputm1(boolean input) {
    if((a188 == 1) && (cf==true)) {
    	calculateOutputm2(input);
    } 
}


private  void calculateOutputm4(boolean input) {
    if((cf==true) && (input==false)) {
    	cf = false;
    	a159 = ((a28 + a89) + -6);
    	a80 = (a28 - -4);
    	a28 = ((a159 / a80) + 10); 
    	System.out.println("T");
    } 
    if((cf==true) || (input==false)) {
    	cf = false;
    	a182 = (a89 - -2);
    	a50 = (a28 - 2);
    	a28 = (a50 + 9); 
    	System.out.println("Y");
    } 
    if((cf==true) && (input==false) || (a191 == 0)) {
    	cf = false;
    	 update(a28, 0, 5);
    	a111 = (a193 + 8);
    	a28 = (a89 + 2); 
    	System.out.println("V");
    } 
    if((cf==true) || (input==false) && (a16 <= 22)) {
    	cf = false;
    	a28 = ((a193 * a89) + -9);
    	a23 = (a193 + 6);
    	a92 = ((a193 - a28) + 12); 
    	System.out.println("T");
    } 
    if((cf==true) && (input==false) || (a199 == 0)) {
    	cf = false;
    	a11 = (a89 - -5);
    	a150 = (a89 + 2);
    	a28 = (a193 - -2); 
    	System.out.println("X");
    } 
}
private  void calculateOutputm3(boolean input) {
    if((cf==true) && (a89 == 6)) {
    	calculateOutputm4(input);
    } 
}

private  void calculateOutputm6(boolean input) {
    if((cf==true) && (input==false)) {
    	cf = false;
    	a122 = (a11 + 1);
    	a176 = ((a153 - a11) + -1);
    	a28 = (a176 + 1); 
    	System.out.println("Y");
    } 
    if((input==false) && (cf==true)) {
    	cf = false;
    	a193 = ((a153 / a153) - -2);
    	a89 = ((a193 / a11) - -5);
    	a28 = (a153 + -6); 
    	System.out.println("Y");
    } 
    if((cf==true) || (input==false) && (a125 == 1)) {
    	cf = false;
    	a122 = (a153 + -7);
    	a44 = ((a153 - a28) - -1);
    	a28 = (a153 - 4); 
    	System.out.println("Z");
    } 
    if((cf==true) && (input==false) || (a21 <= 28)) {
    	cf = false;
    	a159 = (a153 - 6);
    	a80 = ((a153 / a159) - -1);
    	a28 = (a11 - -6); 
    	System.out.println("W");
    } 
    if((input==false) && (cf==true)) {
    	cf = false;
    	a11 = (a153 - 5);
    	a92 = ((a28 * a11) - 12); 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm5(boolean input) {
    if((a153 == 10) && (cf==true)) {
    	calculateOutputm6(input);
    } 
}

private  void calculateOutputm8(boolean input) {
    if((cf==true) || (input==false) && (a110 == 0)) {
    	cf = false;
    	a182 = a11;
    	a108 = (a92 + -3);
    	a28 = ((a108 * a182) + -39); 
    	System.out.println("W");
    } 
    if((cf==true) && (input==false)) {
    	cf = false;
    	a11 = (a92 - 9);
    	a153 = (a28 + 5); 
    	System.out.println("W");
    } 
    if((cf==true) && (input==false)) {
    	cf = false;
    	a5 = ((a28 + a28) + -5);
    	a49 = (a92 - 5);
    	a28 = (a5 - -2); 
    	System.out.println("Y");
    } 
    if((cf==true) && (input==false) || (a30 <= 37)) {
    	cf = false;
    	a134 = (a92 + -2);
    	a11 = (a28 - -3); 
    	System.out.println("W");
    } 
}
private  void calculateOutputm7(boolean input) {
    if((cf==true) && (a92 == 1)) {
    	calculateOutputm8(input);
    } 
}

private  void calculateOutputm10(boolean input) {
    if((input==false) && (cf==true)) {
    	cf = false;
    	a188 = ((a49 - a28) - -14);
    	a193 = ((a28 - a122) + -2);
    	a28 = (a188 - 9); 
    	System.out.println("W");
    } 
    if((input==false) || (cf==true) && (a68 <= 41)) {
    	cf = false;
    	a28 = (a122 - -9);
    	a182 = (a28 + -9); 
    	System.out.println("Z");
    } 
    if((cf==true) && (input==false) || (a177 <= 25)) {
    	cf = false;
    	a193 = (a122 - -3);
    	a84 = (a49 + 10);
    	a28 = (a193 + -1); 
    	System.out.println("T");
    } 
    if((cf==true) && (input==false)) {
    	cf = false;
    	a5 = (a28 + -1);
    	a28 = ((a122 + a122) - -3);
    	a49 = (a5 - -3); 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm9(boolean input) {
    if((cf==true) || (a49 == 0)) {
    	calculateOutputm10(input);
    } 
}

private  void calculateOutputm12(boolean input) {
    if((input==false) && (cf==true)) {
    	cf = false;
    	 
    	System.out.println("Z");
    } 
    if((cf==true) || (input==false) && (a93 == 1)) {
    	cf = false;
    	a84 = (a176 - -8);
    	a28 = (a84 - 9);
    	a193 = ((a122 / a176) + 4); 
    	System.out.println("Y");
    } 
    if((input==false) && (cf==true) || (a157 >= 36)) {
    	cf = false;
    	a159 = (a122 + 4);
    	a28 = (a122 + a176);
    	a185 = ((a176 - a28) - -8); 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm11(boolean input) {
    if((cf==true) && (a176 == 0)) {
    	calculateOutputm12(input);
    } 
}



private  void calculateOutputm14(boolean input) {
    if((input==false) || (cf==true)) {
    	cf = false;
    	a188 = (a5 - -8);
    	a193 = (a5 + -3);
    	a28 = (a188 - 9); 
    	System.out.println("Y");
    } 
    if((input==false) && (cf==true) || (a112 >= 33)) {
    	cf = false;
    	a28 = ((a49 - a5) - -8);
    	a182 = (a28 + -4);
    	a114 = (a182 - -6); 
    	System.out.println("U");
    } 
    if((cf==true) || (input==false) && (a51 <= 23)) {
    	cf = false;
    	a80 = (a28 - -3);
    	a159 = (a28 - 3);
    	a28 = a80; 
    	System.out.println("T");
    } 
    if((input==false) || (cf==true)) {
    	cf = false;
    	a11 = (a5 + -1);
    	a28 = (a11 + 1);
    	a153 = (a49 - -2); 
    	System.out.println("W");
    } 
}
private  void calculateOutputm13(boolean input) {
    if((a49 == 8) && (cf==true)) {
    	calculateOutputm14(input);
    } 
}

private  void calculateOutputm16(boolean input) {
    if((cf==true) && (input==false) || (a197 >= 36)) {
    	cf = false;
    	a90 = (a111 - -1);
    	 update(a111, a111, 11);
    	System.out.println("Z");
    } 
    if((input==false) && (cf==true)) {
    	a16 -= (a16 - 20) < a16 ? 2 : 0;
    	a197 += (a197 + 20) > a197 ? 2 : 0;
    	a198 -= (a198 - 20) < a198 ? 2 : 0;
    	cf = false;
    	a28 = ( getInt() + 1);
    	a159 = (a28 + -3);
    	a92 = (a159 - -1); 
    	System.out.println("W");
    } 
    if((input==false) || (cf==true) && (a98 == 0)) {
    	cf = false;
    	a164 = (( getInt() / a28) - -9);
    	a5 = ((a28 - a164) - -12);
    	a28 = (a5 + -3); 
    	System.out.println("X");
    } 
    if((input==false) && (cf==true) || (a160 == 0)) {
    	cf = false;
    	a122 = ((a111 *  getInt()) + -80);
    	a28 = ( getInt() - -2);
    	a182 = (a28 + -9); 
    	System.out.println("Y");
    } 
    if((cf==true) && (input==false)) {
    	cf = false;
    	 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm15(boolean input) {
    if((a111 == 9) || (cf==true)) {
    	calculateOutputm16(input);
    } 
}
private  void calculateOutputm18(boolean input) {
    if((input==false) && (cf==true)) {
    	cf = false;
    	a5 = ( getInt() - 6);
    	a49 = (a5 + 3);
    	a28 = ( getInt() - 4); 
    	System.out.println("U");
    } 
    if((cf==true) || (input==false)) {
    	cf = false;
    	a159 = a90;
    	a28 = ( getInt() - 1);
    	a92 = ((a28 / a159) - -7); 
    	System.out.println("V");
    } 
}
private  void calculateOutputm17(boolean input) {
    if((cf==true) && (a90 == 7)) {
    	calculateOutputm18(input);
    } 
}
private  void calculateOutputm20(boolean input) {
    if((cf==true) || (input==false)) {
    	a199 += (a199 + 20) > a199 ? 4 : 0;
    	a18 -= (a18 - 20) < a18 ? 4 : 0;
    	cf = false;
    	a182 = ((a23 - a4) + 6);
    	a28 = ((a182 + a182) + 3);
    	a180 = (a182 + 7); 
    	System.out.println("V");
    } 
    if((input==false) && (cf==true)) {
    	a40 += (a40 + 20) > a40 ? 2 : 0;
    	a24 -= (a24 - 20) < a24 ? 4 : 0;
    	cf = false;
    	a28 = (a4 + -5);
    	 update(a23, 2, 0);
    	a111 = ((a23 +  getInt()) + -11); 
    	System.out.println("Z");
    } 
    if((input==false) && (cf==true)) {
    	a32 += (a32 + 20) > a32 ? 6 : 0;
    	cf = false;
    	a23 = (a4 - -2);
    	 update(a23*a4, 186, 0);
    	System.out.println("X");
    } 
    if((input==false) || (cf==true)) {
    	cf = false;
    	a5 = (a23 + -4);
    	a140 = ((a23 + a5) + -10);
    	a28 = (a23 - 4); 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm19(boolean input) {
    if((a4 == 13) && (cf==true)) {
    	calculateOutputm20(input);
    } 
}
private  void calculateOutputm22(boolean input) {
    if((input==false) && (cf==true) || (a26 == 1)) {
    	cf = false;
    	a23 = ( getInt() + 4);
    	a122 = (a28 + -1); 
    	System.out.println("Z");
    } 
    if((cf==true) || (input==false) && (a86 == 0)) {
    	cf = false;
    	a134 = (a23 + -6);
    	a11 = ( getInt() - 1);
    	a28 = (a23 - 10); 
    	System.out.println("Y");
    } 
    if((input==false) && (cf==true)) {
    	a160 += (a160 + 20) > a160 ? 4 : 0;
    	a8 += (a8 + 20) > a8 ? 4 : 0;
    	a86 += (a86 + 20) > a86 ? 6 : 0;
    	cf = false;
    	a159 = ( getInt() - 2);
    	a92 = (a28 - 1);
    	a28 = (a23 + -5); 
    	System.out.println("Y");
    } 
    if((input==false) && (cf==true) || (a24 <= 26)) {
    	cf = false;
    	a137 = ( getInt() - 1);
    	a28 = (a137 + 2);
    	a159 = (( getInt() -  getInt()) - -6); 
    	System.out.println("V");
    } 
}
private  void calculateOutputm21(boolean input) {
    if((a156==0) && (cf==true)) {
    	calculateOutputm22(input);
    } 
}

private  void calculateOutputm24(boolean input) {
    if((cf==true) || (input==false) && (a165 <= 24)) {
    	cf = false;
    	a5 = (a80 + 3);
    	a94 = (a159 - -11);
    	a28 = (a94 - 8); 
    	System.out.println("Y");
    } 
    if((cf==true) || (input==false) && (a58 >= 28)) {
    	cf = false;
    	a14 = (a80 - 4);
    	a193 = (a159 - -2);
    	a28 = (a193 - 2); 
    	System.out.println("Y");
    } 
    if((input==false) || (cf==true)) {
    	cf = false;
    	a193 = ((a80 - a159) - 1);
    	a89 = (a80 + -2);
    	a28 = ((a193 + a89) + -5); 
    	System.out.println("T");
    } 
    if((cf==true) && (input==false) || (a129 == 0)) {
    	cf = false;
    	a28 = ((a80 - a159) + 1);
    	a11 = (a28 + 5);
    	a13 = a159; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm23(boolean input) {
    if((cf==true) || (a80 == 8)) {
    	calculateOutputm24(input);
    } 
}
private  void calculateOutputm26(boolean input) {
    if((cf==true) && (input==false)) {
    	a191 += (a191 + 20) > a191 ? 6 : 0;
    	a26 += (a26 + 20) > a26 ? 2 : 0;
    	a144 += (a144 + 20) > a144 ? 2 : 0;
    	a129 += (a129 + 20) > a129 ? 4 : 0;
    	a165 -= (a165 - 20) < a165 ? 4 : 0;
    	cf = false;
    	a4 = (a159 - -6);
    	a23 = (a28 + 1);
    	a28 = (a4 - 4); 
    	System.out.println("Y");
    } 
    if((cf==true) && (input==false)) {
    	cf = false;
    	a89 = (a28 - 4);
    	a193 = (a92 - 5);
    	a28 = ((a159 + a193) - 6); 
    	System.out.println("V");
    } 
}
private  void calculateOutputm25(boolean input) {
    if((cf==true) || (a92 == 8)) {
    	calculateOutputm26(input);
    } 
}

private  void calculateOutputm28(boolean input) {
    if((input==false) || (cf==true) && (a116 >= 24)) {
    	cf = false;
    	 update(a28, -a28, -13);
    	a23 = (a138 + 5);
    	a28 = (a138 - 1); 
    	System.out.println("Y");
    } 
    if((cf==true) && (input==false)) {
    	cf = false;
    	 
    	System.out.println("X");
    } 
    if((input==false) || (cf==true)) {
    	cf = false;
    	a5 = (a138 - 5);
    	a28 = (a159 + -4);
    	a49 = (a5 - -3); 
    	System.out.println("W");
    } 
    if((cf==true) && (input==false) || (a102 >= 24)) {
    	cf = false;
    	a122 = (a28 + -9);
    	a57 = (a159 - 8);
    	a28 = (a122 - -5); 
    	System.out.println("V");
    } 
    if((cf==true) && (input==false)) {
    	cf = false;
    	a188 = ((a28 / a159) + 13);
    	a193 = (a138 + -8);
    	a28 = ((a193 + a138) + -8); 
    	System.out.println("X");
    } 
}
private  void calculateOutputm27(boolean input) {
    if((a138 == 0) || (cf==true)) {
    	calculateOutputm28(input);
    } 
}

private  void calculateOutputm30(boolean input) {
    if((cf==true) && (input==false)) {
    	cf = false;
    	 
    	System.out.println("X");
    } 
    if((input==false) && (cf==true) || (a72 <= 48)) {
    	cf = false;
    	a11 = (a180 + -6);
    	a92 = (a28 - 1);
    	a28 = a11; 
    	System.out.println("Z");
    } 
    if((cf==true) && (input==false)) {
    	cf = false;
    	 
    	System.out.println("Z");
    } 
    if((input==false) || (cf==true) && (a128 <= 37)) {
    	cf = false;
    	a153 = (a180 - 6);
    	a28 = a153;
    	a11 = (a153 - 1); 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm29(boolean input) {
    if((cf==true) && (a180 == 11)) {
    	calculateOutputm30(input);
    } 
}

private  void calculateOutputm32(boolean input) {
    if((cf==true) && (input==false) || (a18 <= 32)) {
    	cf = false;
    	a28 = ((a180 - a182) - -1);
    	 update(a28, -a182, -4);
    	a38 = ((a182 - a182) - -13); 
    	System.out.println("W");
    } 
    if((input==false) || (cf==true) && (a8 == 0)) {
    	cf = false;
    	a159 = (a180 + -5);
    	a137 = ((a182 - a159) - -14);
    	a28 = (a137 - 2); 
    	System.out.println("W");
    } 
    if((input==false) && (cf==true)) {
    	a98 += (a98 + 20) > a98 ? 2 : 0;
    	a58 += (a58 + 20) > a58 ? 1 : 0;
    	cf = false;
    	a28 = (a180 + -1);
    	a92 = (a182 - -4);
    	a159 = (a28 + -3); 
    	System.out.println("Z");
    } 
    if((input==false) || (cf==true) && (a40 == 0)) {
    	cf = false;
    	a182 = (a28 - 3);
    	a50 = (a180 + -10); 
    	System.out.println("W");
    } 
}
private  void calculateOutputm31(boolean input) {
    if((a180 == 11) && (cf==true)) {
    	calculateOutputm32(input);
    } 
}

private  void calculateOutputm34(boolean input) {
    if((input==false) || (cf==true) && (a144 == 0)) {
    	cf = false;
    	a11 = (a50 + 6);
    	a28 = ((a182 - a182) + 5);
    	a134 = ((a11 - a50) + 4); 
    	System.out.println("V");
    } 
    if((input==false) && (cf==true)) {
    	cf = false;
    	 
    	System.out.println("X");
    } 
    if((input==false) || (cf==true)) {
    	cf = false;
    	 
    	System.out.println("T");
    } 
    if((cf==true) || (input==false) && (a32 == 1)) {
    	cf = false;
    	a28 = (a182 - 3);
    	a11 = ((a50 + a28) - -3);
    	a13 = (a11 + -2); 
    	System.out.println("U");
    } 
    if((cf==true) && (input==false) || (a198 <= 40)) {
    	cf = false;
    	a11 = (a182 - -2);
    	a13 = ((a182 / a11) - -5);
    	a28 = (a11 + -5); 
    	System.out.println("U");
    } 
}
private  void calculateOutputm33(boolean input) {
    if((a50 == 0) && (cf==true)) {
    	calculateOutputm34(input);
    } 
}

public  void calculateOutput(boolean input) {

		cf = true;
    
    	if((cf==true) && (a193 == 2)) {
    		calculateOutputm1(input);
    	} 
    	if((a193 == 0) && (cf==true)) {
    		calculateOutputm3(input);
    	} 
    	if((cf==true) && (a11 == 0)) {
    		calculateOutputm5(input);
    	} 
    	if((cf==true) && (a11 == 0)) {
    		calculateOutputm7(input);
    	} 
    	if((a122 == 1) && (cf==true)) {
    		calculateOutputm9(input);
    	} 
    	if((cf==true) && (a122 == 0)) {
    		calculateOutputm11(input);
    	} 
    	if((a5 == 0) || (cf==true)) {
    		calculateOutputm13(input);
    	} 
    	if(( a156==0) && (cf==true)) {
    		calculateOutputm15(input);
    	} 
    	if(( a156==0) || (cf==true)) {
    		calculateOutputm17(input);
    	} 
    	if((a23 == 1) && (cf==true)) {
    		calculateOutputm19(input);
    	} 
    	if((a23 == 1) || (cf==true)) {
    		calculateOutputm21(input);
    	}     
    	if((a159 == 0) && (cf==true)) {
    		calculateOutputm23(input);
    	} 
    	if((cf==true) || (a159 == 7)) {
    		calculateOutputm25(input);
    	} 
    	if((a159 == 1) && (cf==true)) {
    		calculateOutputm27(input);
    	} 
		if((a182 == 0) || (cf==true)) {
    		calculateOutputm29(input);
    	}
		if((cf==true) && (a182 == 0)) {
    		calculateOutputm31(input);
    	} 	
		if((a182 == 8) || (cf==true)) {
    		calculateOutputm33(input);
    	}		
    
    
	  errorCheck();
    if(cf==true)
    	throw new IllegalArgumentException("Current state has no transition for this input!");
} 
	
	public void update(int a, int b , int c) {
		
		a156 = ((a - b) + c);
	}
	
	public int getInt() {
		return a156;
	}

	public static void main() throws Exception 
	{
	     // init system and input reader
            Problem1RV_RERS2014 eca = new Problem1RV_RERS2014();
			
        int value1= Cute.input.Integer();
		int value2= Cute.input.Integer();
		int value3= Cute.input.Integer();
		boolean input = Cute.input.Boolean();
		int a=1;
		
		while(a<10)	 
		{
		
		if((value1 == 1)&&(value2 == 0))
         {   
			System.out.println("value1 is 1 AND value2 is 2");
			eca.calculateOutput(input);
        }
		if((value1 == 1)||(value2 == 1))
        {    
			System.out.println("value1 is 1 OR value2 is 1");
			eca.calculateOutput(input);
        }
		if((value1==1)&&(value2==0)||(value3==0))
	    { 
			System.out.println("value1 is 1 AND value2 is 2");
		 eca.calculateOutput(input);
	    }
		if((value1==1)||((value2==0)&&(value3==0)))
        {    
			System.out.println("value1 is 1 OR value2 is 1");
			eca.calculateOutput(input);
        }
		if((value1==1)&&(value2==0)||(value3==0))
	    {	    
			System.out.println("value1 is 1 AND value2 is 2");
				eca.calculateOutput(input); 
	    }
		if((value1==1)||(value2==0)&&(value3==1))
        {
			System.out.println("value1 is 1 OR value2 is 1");
				eca.calculateOutput(input); 
	    }
			a++;
	}
	}
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=1000
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
