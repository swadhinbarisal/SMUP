package A1;

import cute.Cute;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

public class Problem1_RERS2013 {
	public Random random = new Random();

	private String[] inputs = {"A","B","E","C","F","D"};

	private int a92 = Cute.input.Integer();
	private int a82 = Cute.input.Integer();
	private int a72 = Cute.input.Integer();
	private int a64 = Cute.input.Integer(); 
	private int a148 = Cute.input.Integer(); 
	private int a14 = Cute.input.Integer(); 
	private int a163 = Cute.input.Integer(); 
	private int a188 = Cute.input.Integer(); 
	private int a28 = Cute.input.Integer(); 
	private int a150 = Cute.input.Integer(); 
	private int a124 = Cute.input.Integer(); 
	private int a11 = Cute.input.Integer(); 
	private int a42 = Cute.input.Integer(); 
	private int a86 = Cute.input.Integer(); 
	private int a97 = Cute.input.Integer(); 
	private int a165 = Cute.input.Integer(); 
	private int a140 = Cute.input.Integer(); 
	private int a7 = Cute.input.Integer(); 
	private int a56 = Cute.input.Integer(); 
	private int a23 = Cute.input.Integer(); 
	private int a36 = Cute.input.Integer(); 
	private int a53 = Cute.input.Integer(); 
	private int a65 = Cute.input.Integer(); 
	private int a30 = Cute.input.Integer(); 
	private int a153 = Cute.input.Integer(); 
	private int a95 = Cute.input.Integer(); 
	private int a58 = Cute.input.Integer(); 
	private int a146 = Cute.input.Integer(); 
	private int a147 = Cute.input.Integer(); 
	private int a41 = Cute.input.Integer(); 
	private int a185 = Cute.input.Integer(); 
	private int a189 = Cute.input.Integer(); 
	private int a46 = Cute.input.Integer(); 
	private int a20 = Cute.input.Integer(); 
	private int a15 = Cute.input.Integer(); 
	private int a111 = Cute.input.Integer(); 
	private int a134 = Cute.input.Integer(); 
	private int a145 = Cute.input.Integer(); 
	private int a47 = Cute.input.Integer(); 
	private int a4 = Cute.input.Integer(); 
	private int a113 = Cute.input.Integer(); 
	private int a176 = Cute.input.Integer(); 
	private int a175 = Cute.input.Integer(); 
	private int a106 = Cute.input.Integer(); 
	private int a69 = Cute.input.Integer(); 
	private int a10 = Cute.input.Integer(); 
	private int a117 = Cute.input.Integer(); 
	
	private boolean a67 = Cute.input.Boolean();
	private boolean a112 = Cute.input.Boolean();
	private boolean a180 = Cute.input.Boolean();
	private boolean cf = Cute.input.Boolean();
	private boolean a168 = Cute.input.Boolean();
	private boolean a164 = Cute.input.Boolean();
	private boolean a35 = Cute.input.Boolean();
	private boolean a160 = Cute.input.Boolean();
	private boolean a9 = Cute.input.Boolean();
	private boolean a63 = Cute.input.Boolean();
	private boolean a75 = Cute.input.Boolean();
	private boolean a91 = Cute.input.Boolean();
	private boolean a194 = Cute.input.Boolean();
	private boolean a181 = Cute.input.Boolean();
	private boolean a6 = Cute.input.Boolean();
	private boolean a162 = Cute.input.Boolean();
	private boolean a62 = Cute.input.Boolean();
	private boolean a80 = Cute.input.Boolean();
	private boolean a27 = Cute.input.Boolean();
	private boolean a12 = Cute.input.Boolean();



	private  void calculateOutputa1768(int input) {
	    if((a106==0) && (a67==true) || (cf==false) && (a56==0) && (input==0) || (a69==0)){
	    	cf = (false);
			a67 = (true);
	    	a28 = 5;
	    	a145 = 6;
	    	a11 = 7;
	    	a58 = 8;
	    	a134 = 9;
	    	a150 = 10;
	    	a36 = 1;
	    	a62 = (true);
	    	  System.out.println(  "V"  );
	    } 
	

		if((a9==true) && (a10==1) || (cf==true) || (a11==0) && (a189==0)){
	    	cf = (false);
			a41 = 10;
	    	a140 = 6;
	    	a82 = 10;
	    	a28 = 7;
	    	a7 = 7;
	    	  System.out.println(  "V"  );
	    }	

			if((a9==false) && (a10==6) || (cf==true) || (a11==0) && (a189==0)){
	    	cf = (false);
			a41 = 10;
	    	a140 = 6;
	    	a82 = 10;
	    	a28 = 7;
	    	a9 = true;
	    	a7 = 7;
	    	  System.out.println(  "V"  );
	    } 
	    if((a15==0) && (a153==4) && (a175==1) ||(cf==false) && (a10==6) && (a20==1)|| (a148==0)){
	    	cf = (false);a82 = 6;
	    	a28 = 7;
	    	a10 = 10;
	    	a9 = false;
	    	a113 = 10;
	    	a42 = 6;
	    	 
	    } 
	    if((a175==1) && (a75==true) && (a4==0) && (a188==0) || (cf==false) || (a20==0)){
	    	cf = (false);
			a4 = 12;
	    	a28 = 7;
	    	a82 = 10;
	    	a20 = 9;
	    	a58 = 10;
	    	a185 = 10;
	    	a41 = 10;
	    	a140 = 6;
	    	  System.out.println(  "Y"  );
	    } 
		
		if((a14==5) && (a10==6) && (a175==1) && (a95==0) || (cf==true) || (a145==0) && (a7==0)){
	    	cf = (false);
			a28 = 7;
	    	a124 = 7;
	    	a10 = 6;
	    	a12 = (false);
	    	a10 = 4;
	    	a10 = 10;
	    	a82 = 6;
	    	a42 = 6;
	    	 
	    } 
	    
		if((a188==0) && (a134==2) || (a10==1) && (a12==false) || (a15==0) && (cf==true) && (a58==1)){
	    	cf = (false);
			a189 = 10;
	    	a148 = 6;
	    	a82 = 6;
	    	a12 = (false);
	    	a185 = 10;
	    	a28 = 7;
	    	a42 = 10;
	    	  System.out.println(  "U"  );
	    }
		
	}
	
	private  void calculateOutputa146g(int input) {
	    if((a189==0) || (cf==true) && (a58==1) && (a153==4) && (a11==0) || (a153==4)){
	    	cf = (false);
			a185 = 10;
	    	a4 = 12;
	    	a42 = 6;
	    	a82 = 6;
	    	a113 = 10;
	    	a82 = 10;
	    	 
	    } 
	    if((a148==0) && (cf==true) && (a189==1) && (a14==5) || (a41==3) && (a153==4)){
	    	cf = (false);
			a82 = 8;
	    	a175 = 10;
	    	a92 = 6;
	    	a7 = 6;
	    	a153 = 6;
	    	a189 = 10;
	    	a180 = (true);
	    	a12 = (true);
	    	a95 = 10;
	    	a12 = (false);
	    	  System.out.println(  "Z"  );
	    } 
	    if((a153==4) && (a7==0) && (cf==true) && (a15==0) && (a72==7) || (a113==0)){
	    	cf = (false);
			a82 = 6;
	    	a42 = 6;
	    	a12 = (true);
	    	a72 = 7;
	    	a10 = 6;
	    	a4 = 9;
	    	 
	    } 
	    if((a4==0) && (a15==0) && (a148==0) && (a75==false) || (a10==6) && (cf==true) || (a41==3)){
	    	cf = (false);
			a113 = 10;
	    	a148 = 7;
	    	a189 = 10;
	    	a12 = (false);
	    	  System.out.println(  "W"  );
	    } 
	    if((a72==7) || (a9==false) || (a175==1) || (a124==8) && (a12=true) || (cf=true) || (a58==1)){
	    	cf = (false);
			a9 = true;
	    	a72 = 7;
	    	a75 = (true);
	    	a4 = 12;
	    	a188 = 11;
	    	  System.out.println(  "V"  );
	    } 
	    if((a148==0) && (a175==1) || (a12==false) || (cf==true) && (a117==9) && (a134==2)){
	    	cf = (false);
			a4 = 9;
	    	a41 = 10;
	    	a82 = 6;
	    	a42 = 6;
	    	a148 = 6;
	    	a95 = 10;
	    	 
	    } 
	}	
	
	private  void calculateOutputa146f(int input) {
	    if((a72==7) && (a134==2) && (a4==1) && (a12==false) || (cf==true) && (a10==6) || (a58==1)){
	    	cf = (false);
			a58 = 9;
	    	a189 = 10;
	    	a11 = 7;
	    	a42 = 6;
	    	a58 = 10;
	    	a82 = 6;
	    	a95 = 10;
	    	 
	    } 
	    if((a72==7) && (cf==true) && (a58==1) && (a41==3) || (a58==1) || (a10==6) || (a189==0)){
	    	cf = (false);
			a28 = 10;
	    	a111 = 6;
	    	a58 = 6;
	    	a7 = 7;
	    	a10 = 10;
	    	a14 = 7;
	    	a147 = 10;
	    	a23 = 8;
	    	  System.out.println(  "Z"  );
	    } 
	    if((a36==0) || (a124==8) || (a175==1) || (a4==0) && (cf==true) && (a189==0) || (a82==0)){
	    	cf = (false);
			a42 = 6;
	    	a134 = 6;
	    	a185 = 10;
	    	a124 = 7;
	    	a10 = 6;
	    	a95 = 10;
	    	a82 = 6;
	    	 
	    } 
	    if((a10==6) && (a36==1) || (cf==true)  || (a72==7) && (a124==8) ){
	    	cf = (false);
			a72 = 7;
	    	a58 = 6;
	    	a82 = 6;
	    	a58 = 10;
	    	a42 = 6;
	    	 
	    } 
	    if((a10==6) || (cf==true) && (a58==1) && (a11==0) || (a185==1) && (a82==0) || (a20==0)){
	    	cf = (false);
			a134 = 6;
	    	a35 = (false);
	    	a82 = 6;
	    	a188 = 11;
	    	a42 = 6;
	    	a12 = (false);
	    	 
	    } 
	    if((a175==1) || (a189==0) || (a10==6) || (a4==1) || (a113==0) && (cf==true)) {
	    	cf = (false);
			a82 = 8;
	    	a58 = 10;
	    	a14 = 7;
	    	a4 = 9;
	    	a9 = true;
	    	  System.out.println(  "X"  );
	    } 
	} 	
	
	private  void calculateOutputa42g(int input) {
	    if((a175==1) && (a9==true) && (a10==6) || (a4==0) &&  (a36==0) && (cf==true) && (a113==0)) {
	    	cf = (false);
			a75 = (true);
	    	a42 = 6;
	    	a36 =6;
	    	a153 = 10;
	    	a15 = 6;
	    	a175 = 6;
	    	 
	    } 
	    if  ((a36==0) && (a4==0) &&   (cf=false) && (a175==1)  || (a10==6) || (a41==3)  || (a153==4)) {
	    	cf = (false);
			a4 = 12;
	    	a42 = 6;
	    	a7 = 12;
	    	a12 = (true);
	    	 
	    } 
	    if((a148==0) && (a12==false) || (a72==7) && (a58==1) && (cf=false) || (a15==0)   && (a36==0)) {
	    	cf = (false);
			a75 = (true);
	    	a148 =8 ;
	    	a7 = 14;
	    	a27 = (false);
	    	a134 = 6;
	    	a112 = (false);
	    	a180 = (false);
	    	a12 = (false);
	    	a4 = 12;
	    	  System.out.println(  "W"  );
	    } 
	    if((a15==0) && (a36==0) || (a134==2) || (a11==0) && (a15==0) && (cf=false) || (a185==1)){
	    	cf = (false);
			a20 = 9;
	    	a124 = 7;
	    	a9 = true;
	    	a113 = 10;
	    	a12 = (true);
	    	  System.out.println(  "Z"  );
	    } 
	    if((a11==0) && (a58==1) && (a185==1) || (cf==true) && (a36==0) || (a58==1)) {
	    	cf = (false);
			a134 = 6;
	    	a20 = 9;
	    	a12 = (true);
	    	a9 = false;
	    	  System.out.println(  "Z"  );
	    } 
	    if((a15==0) || (a58==1) && (a175==1)|| (a10==1) && (a4==0) || (cf==false) && (a175==1))   {
	    	cf = (false);
			a58 = 6;
	    	a58 = 9;
	    	a42 = 6;
	    	a10 = 6;
	    	a12 = (true);
	    	a36 =6 ;
	    	 
	    } 
	}	
	
	private  void calculateOutputa150g(int input) {
	    if((cf==true) && (a9==true) || (a12==false) || (a153==4) && (a15==0) || (a41==3) && (a189==0)){
	    	cf = (false);
			a4 = 12;
	    	a92 = 7;
	    	a12 = (false);
	    	a10 = 6;
	    	a12 = (true);
	    	a7 = 6;
	    	a180 = (true);
	    	a95 = 10;
	    	  System.out.println(  "W"  );
	    } 
	    if((a148==0) && (a4==0) || (a20==0) && (cf=false) && (a148==0)){
	    	cf = (false);
			a12 = (false);
	    	a153 = 10;
	    	a148 =8;
	    	a188 = 11;
	    	a42 = 6;
	    	a10 = 6;
	    	a82 = 6;
	    	a28 = 7;
	    	 
	    } 
	    if((cf==true) && (a95==0) || (a4==1) || (a10==6) || (a188==0) || (a12==false)){
	    	cf = (false);
			a58 = 10;
	    	a82 = 6;
	    	a42 = 6;
	    	a12 = (true);
	    	a28 = 7;
	    	a188 = 11;
	    	a41 = 10;
	    	 
	    } 
	    if((a9==true) && (a11==0) || (cf==true) && (a4==0) || (a188==0) && (a15==0)){
	    	cf = (false);
			a36=6;
			a12 = (false);
	    	a42 = 6;
	    	a58 = 9;
	    	a82 = 6;
	    	a72 = 7;
	    	a28 = 7;
	    	a4 = 9;
	    	 
	    } 
	    if((a14==5) || (a36==0) && (a189==0) || (cf==true) || (a113==0) && (a10==6) && (a36==0)) {
	    	cf = (false);
			a82 = 6;
	    	a15 = 6;
	    	a58 = 6;
	    	a153 = 10;
	    	a12 = (true);
	    	a28 = 7;
	    	a42 = 6;
	    	 
	    } 
	    if((cf==true) && (a134==2) && (153==0) &&  (a134==2)  || (a58==1) || (a36==0) || (a58==1)){
	    	cf = (false);
			a28 = 10;
	    	a10 = 10;
	    	a147 = 10;
	    	a111 = 7;
	    	a9=true;
	    	a75 = (true);
	    	a11 = 7;
	    	  System.out.println(  "U"  );
	    } 
	}	
	
	private  void calculateOutputa1710(int input) {
	    if((a4==0) && (cf==true) && (a15==0)  && (a95==0) && (a185==1) && (a58==1)) {
	    	cf = (false);
			a28 = 7;
	    	a189 = 10;
	    	a134 = 6;
	    	a35 = (true);
	    	a82 = 7;
	    	a7 = 9;
	    	a10 = 10;
	    	a14 = 14;
	    	a12 = (true);
	    	 
	    } 
	    if((cf==false) && (a12==false) || (a58==1) || (a189==0) || (a4==0) && (a9==true)){
	    	cf = (false);
			a153 = 10;
	    	a7 = 10;
	    	a117 = 7;
	    	a97 = 10;
	    	a185 = 10;
	    	a75 = (true);
	    	a113 = 10;
	    	a10 = 5;
	    	 
	    } 
	    if((a11==0) && (a10==6) && (a113==0) || (a12==false) && (a4==0) || (cf=false) || (a185==1)){
	    	cf = (false);
			a145 = 10;
	    	a58 = 10;
	    	a28 = 6;
	    	a95 = 10;
	    	a15 = 7;
	    	a14 = 4;
	    	a36=6;
	    	a12 = (true);
	    	a10 = 10;
	    	  System.out.println(  "V"  );
	    } 
	    if((a12==false) && (cf==false) || (a58==1)  &&  (a4==0) || (a189==0) && (a58==1) && (a175==1)){
	    	cf = (false);
			a14 = 14;
	    	a28 = 6;
	    	a58 = 10;
	    	a10 = 6;
	    	a9=true;
	    	a30 = 10;
	    	a58 = 6;
	    	a53 = 7;
	    	a36=6;
	    	a12 = (true);
	    	 
	    } 
	    if((cf==true) &&  (a113==0) || (a95==1) ||   (a58==1) || (a10==6) || (a14==5)){
	    	cf = (false);
			a80 = (false);
	    	a4 = 12;
	    	a7 = 14;
	    	a11 = 7;
	    	a147 = 6;
	    	a91 = (false);
	    	a28 = 10;
	    	a12 = (true);
	    	a188 = 11;
	    	 
	    } 
	    if((a7==0) && (a15==0) && (a12==false) && (a175==1) && (a124==8) || (cf==true) &&  (a58==1)){
	    	cf = (false);
			a10 = 10;
	    	a58 = 6;
	    	a97 = 7;
	    	a194 = (false);
	    	a4 = 12;
	    	a58 = 10;
	    	a4 = 9;
	    	a7 = 10;
	    	 
	    } 
	}
	
	private  void calculateOutputa238(int input) {
	    if((a9==true) && (a20==0) && (cf==true)  || (a4==0) && (a9==true) || (a185==1) && (a188==0)) {
	    	cf = (false);
			a42 = 10;
	    	a28 = 7;
	    	a153 = 10;
	    	a82 = 6;
	    	a134 = 6;
	    	a10 = 10;
	    	a58 = 10;
	    	  System.out.println(  "Z"  );
	    } 
	    if((a189==0) || (a153==4) && (a12==false) || (cf==true) && (a10==1) || (a72==7)){
	    	cf = (false);
			a28 = 7;
	    	a82 = 6;
	    	a113 = 10;
	    	a82 = 7;
	    	a75 = (true);
	    	a42 = 6;
	    	 
	    } 
	    if((a175==1) || (cf=false) || (a15==1) && (a10==6) && (a9==true)  || (a72==7) && (a4==0)){
	    	cf = (false);
			a28 = 7;
	    	a10 = 0;
	    	a175 = 6;
	    	a185 = 10;
	    	a4 = 9;
	    	a7 = 5;
	    	a82 = 6;
	    	a42 = 10;
	    	  System.out.println(  "Z"  );
	    } 
	    if((cf==true) && (a188==0) && (a58==1) && (a11==0) && (a10==1) && (a20==0) && (a185==1)){
	    	cf = (false);
			a7 = 7;
	    	a42 = 6;
	    	a28 = 7;
	    	a75 = (true);
	    	a82 = 6;
	    	a113 = 10;
	    	a58 = 10;
	    	 
	    } 
	    if((a175==1) || (a10==6) || (a11==0)  || (a75==true) &&   (a82==0) ||  (a36==0) || (cf==true)) {
	    	cf = (false);
	    	a7 = 7;
	    	a28 = 6;
	    	a145 = 6;
	    	a36=6;
	    	a95 = 10;
	    	a20 = 9;
	    	a153 = 10;
	    	 
	    } 
	    if((a188==0) || (cf==true) && (a124==1) ||(a4==0) ||(a10==6) && (a175==1)) {
	    	cf = (false);
			a15 = 6;
	    	a124 = 7;
	    	a28 = 7;
	    	a42 = 10;
	    	a82 = 6;
	    	a188 = 11;
	    	a113 = 10;
	    	a10 = 6;
	    	  System.out.println(  "Z"  );
	    } 
	}
	
	private  void calculateOutputa27false(int input) {
	    if((cf ==false) && (input==1) || (a20==0) && (a134==2) || (a65==0) ||  (a11==0)){
	    	cf = (false);
			a124 = (7);
	    	a58 = 1;
	    	a92 = 1;
	    	a86 = 1;
	    	a95 = 1;
	    	a153 = (10);
	    	a7 = 0;
	    	a180 = (true);
	    	  System.out.println(  "Y"  );
	    } 
	    if((a11==0) || (a124==8) || (cf ==false) && (input==0) && (a188==0) && (a86==0)){
	    	cf = (false);
			a82 = 0;
	    	a63 = (false);
	    	a42 = 0;
	    	a28 = 1;
	    	a62 = (true);
	    	a148 = 0;
	    	a67 = (true);
	    	a113 = 1;
	    	 
	    } 
	    if((a72==7) || (a72==7) && (a185==1) && (a11==0) && (a113==0) && (input==0) && (cf==true)){
	    	cf = (false);
			a42 = 1;
	    	a10 = 0;
	    	a82 = 0;
	    	a58 = 1;
	    	a28 = 1;
	    	a62 = (true);
	    	a189 = 1;
	    	a46 = (12);
	    	a11 = 1;
	    	  System.out.println(  "Z"  );
	    } 
	    if((a15==0) || (a56==1) && (a20==0) && (input==0) && (cf==false) || (a56==0)){
	    	cf = (false);
			a82 = 0;
	    	a6 = (true);
	    	a153 = (10);
	    	a20 = (9);
	    	a42 = 0;
	    	a28 = 1;
	    	a62 = (true);
	    	a11 = 1;
	    	a46 = (12);
	    	 
	    } 
	    if((a185==1) || (a65==0) || (a65==0) || (a175==1) &&  (a72==7) || (input==0) && (cf==false)){
	    	cf = (false);
			a64 = (9);
	    	a92 = 1;
	    	a153 = (10);
	    	a160 = (false);
	    	a124 = (7);
	    	a46 = (12);
	    	a7 = 0;
	    	a180 = (true);
	    	  System.out.println(  "V"  );
	    } 
	    if((a46==0) || (cf ==true) && (input==1) || (a69==0) || (a148==0) &&(a86==0) || (a134==2)){
	    	cf = (false);
			a41 = 1;
	    	a28 = 1;
	    	a15 = 0;
	    	a56 = (9);
	    	a82 = 0;
	    	a69 = 0;
	    	a189 = 1;
	    	a42 = 0;
	    	a62 = (true);
	    	 
	    } 
	}
	
	private  void calculateOutputa92e(int input) {
	    if((a188==0) && (a185==1) || (input==0) && (cf==false) && (a189==0)){
	    	cf = (false);
			a189 = 1;
	    	a82 = 0;
	    	a42 = 0;
	    	a10 = 0;
	    	a185 = 1;
	    	a75 = (true);
	    	a28 = 1;
	    	a62 = (true);
	    	a160 = (false);
	    	 
	    } 
	    if((a64==0) &&  (a15==0) && (a175==1) && (input==0) && (cf==false) || (a148==1)){
	    	cf = (false);
			a64 = (9);
	    	a164 = (true);
	    	a42 = 0;
	    	a75 = (true);
	    	a82 = 0;
	    	a160 = (false);
	    	a28 = 1;
	    	a62 = (true);
	    	 
	    } 
	    if((cf ==false) && (input==0) &&  (a58==1) && (a113==0) || (a134==2) || (a11==0)){
	    	cf = (false);
			a111 = 0;
	    	a185 = 1;
	    	a147 = 1;
	    	a10 = 0;
	    	a56 = (9);
	    	a28 = 1;
	    	a23 = (8);
	    	a62 = (true);
	    	a160 = (false);
	    	 
	    } 
	    if((a153==4) || (input==1) && (cf==false)  && (a72==7) || (a148==0) && (a69==0) && (a124==8)){
	    	cf = (false);
			a82 = 0;
	    	a28 = 1;
	    	a42 = 1;
	    	a62 = (true);
	    	a113 = 1;
	    	a63 = (false);
	    	a20 = (9);
	    	  System.out.println(  "Z"  );
	    } 
	    if((a86==0) ||  (a11==1) ||  (cf ==false) && (input==0) || (a69==0)){
	    	cf = (false);
			a162 = (false);
	    	a41 = 1;
	    	a42 = 0;
	    	a63 = (false);
	    	a67 = (true);
	    	a28 = 1;
	    	a82 = 0;
	    	a62 = (true);
	    	 
	    } 
	    if((cf ==false) && (input==0) && (a188==1) || (a69==0) || (a148==0) || (a153==4)){
	    	cf = (false);
			a148 = 0;
	    	a185 = 1;
	    	a42 = 1;
	    	a28 = 1;
	    	a46 = (12);
	    	a6 = (true);
	    	a82 = 0;
	    	a62 = (true);
	    	  System.out.println(  "Z"  );
	    } 
	}

	private  void calculateOutputa111e(int input) {
	    if((cf ==true) && (input==0) && (a64==0) || (a10==1) || (a56==0) && (a153==4) && (a124==8) && (a124==8)){
	    	cf = (false);
			a72 = 1;
	    	a15 = 0;
	    	a160 = (false);
	    	a82 = 0;
	    	a75 = (true);
	    	a134 = 0;
	    	a42 = 0;
	    	a28 = 1;
	    	 
	    } 
	    if((a106==0) && (a106==0) || (a113==0)  && (input==0) && (cf==true) && (a58==1)){
	    	cf = (false);
			a82 = 0;
	    	a124 = (7);
	    	a75 = (true);
	    	a113 = 1;
	    	a65 = 0;
	    	a42 = 1;
	    	a28 = 1;
	    	a46 = (12);
	    	  System.out.println(  "Z"  );
	    } 
	    if((a134==2) || (a175==1) && (cf ==false) && (input==0)){
	    	cf = (false);a82 = 0;
	    	a58 = 1;
	    	a11 = 1;
	    	a42 = 0;
	    	a175 = 0;
	    	a189 = 1;
	    	a95 = 1;
	    	a28 = 1;
	    	 
	    } 
	    if((cf ==false) && (input==1) && (a64==0)){
	    	cf = (false);
			a189 = 1;
	    	a56 = (9);
	    	a27 = (false);
	    	a112 = (false);
	    	a180 = (false);
	    	a62 = (false);
	    	a164 = (true);
	    	a58 = 1;
	    	 
	    } 
	    if((a134==2) || (a41==3) || (a124==8) && (a95==0) && (a189==0) || (cf ==false) && (input==0)){
	    	cf = (false);
			a75 = (true);
	    	a67 = (true);
	    	a42 = 1;
	    	a82 = 0;
	    	a46 = (12);
	    	a28 = 1;
	    	a72 = 1;
	    	  System.out.println(  "Z"  );
	    } 
	    if((a41==3) && (a148==0) && (a15==0) && (input==0) && (cf==true) && (a11==0)  && (a185==1)){
	    	cf = (false);
			a28 = 1;
	    	a42 = 0;
	    	a67 = (true);
	    	a185 = 1;
	    	a82 = 0;
	    	a58 = 1;
	    	a153 = (10);
	    	 
	    } 
	}

	private  void calculateOutputa1657(int input) {
	    if((a175==1) || (a41==3) &&  (a106==0) && (a185==1) && (cf ==false) && (input==0)){
	    	cf = (false);
			a185 = 1;
	    	a75 = (true);
	    	a124 = (7);
	    	a64 = (9);
	    	a86 = 1;
	    	  System.out.println(  "U"  );
	    } 
	    if((a188==0) || (a113==0) || (a175==1) && (cf ==false) && (input==0) || (a69==0) ||  (a58==1)){
	    	cf = (false);
			a41 = 1;
	    	a65 = 0;
	    	a6 = (true);
	    	a113 = 1;
	    	  System.out.println(  "V"  );
	    } 
	    if((input==1) && (cf==false) && (a15==0) && (a72==7) || (a46==0) && (a106==0) && (a153==4)){
	    	cf = (false);
			a111 = 0;
	    	a23 = (12);
	    	a106 = (10);
	    	a124 = (7);
	    	a153 = (10);
	    	a20 = (9);
	    	a147 = 1;
	    	a56 = (9);
	    	a28 = 1;
	    	 
	    } 
	    if((a185==1) && (a11==0) && (a124==8) && (a64==0) || (input==1) && (cf==false)){
	    	cf = (false);
			a15 = 0;
	    	a69 = 0;
	    	a86 = 1;
	    	a47 = 0;
	    	a9 = (false);
	    	a63 = (false);
	    	a112 = (true);
	    	a180 = (false);
	    	a62 = (false);
	    	a160 = (false);
	    	 
	    } 
	    if((a64==0) || (a41==3) && (a64==0) || (a15==0) && (a56==0) && (input==0) && (cf==false)){
	    	cf = (false);
			a46 = (12);
	    	a175 = 0;
	    	a148 = 0;
	    	a185 = 1;
	    	a65 = 0;
	    	  System.out.println(  "Y"  );
	    } 
	    if((a10==6) && (a11==0) && (a189==0) ||  (input==0) && (cf==false)){
	    	cf = (false);
			a64 = (9);
	    	a41 = 1;
	    	a165 = (11);
	    	a185 = 1;
	    	a160 = (false);
	    	a153 = (10);
	    	 
	    } 
	}
	
	public  void calculateOutput(int input) {
	 	cf = (true);	
	if((a65==0) || (a82==0) && (cf==false) && (a11==0) && (a189==0) && (a188==0) || (a189==0) || (a162==false)){
	    		if((a20==0) || (a175==1) && (a15==0) && (a134==2) && (a56==0) || (a58==1) && (a140==0) && (cf==false)){
	    		if((a146==0) && (cf==false) && (a46==1) || (a164==false) || (a11==0)||(a124==8)){
	    					calculateOutputa146f(input);
	    				} 
	    				if((a69==0) || (a20==0) && (a9==false) &&(a134==2) &&(a146==0) && (cf==false) && (a41==3)){
	    					calculateOutputa146g(input);
	    				} 
	    			} 
	    		}
				
	if((a69==0)  ||(cf==false) && (a82==0) && (a153==4) && (a175==1)){
	    			if((a46==0) || (a86==0) || (a175==1) && (a185==1) && (cf==false) && (a42==0) && (a164==false) && (a46==0)){

	    			} 
	    			if((a11==0) || (a11==0) && (a185==1) && (a175==1) || (cf==false) && (a42==0) && (a175==1)){

	    			} 
	    			if((a11==0) || (a164==false) || (a69==0) && (a42==1) && (cf==false) || (a168==false) && (a86==0) || (a15==0)){
	    				calculateOutputa238(input);
	    			} 
	    		} 
	
	  if(cf)
	    	throw new IllegalArgumentException("Current state has no transition for this input");
	}
	public static void main() throws Exception 
	{
			// default output
			//String output = null;

			// init eca-System and input reader
            Problem1_RERS2013 eca = new Problem1_RERS2013();
          //  BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

		int a=0;
	    int x;
        int y;
         
        x = Cute.input.Integer();
        y = Cute.input.Integer();
		int input = Cute.input.Integer();
			// main i/o-loop
            while(a<100) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                	 eca.calculateOutputa1768(input);
					 
				}
				
				if (x>299 && x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutputa1768(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
	}
}


//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
