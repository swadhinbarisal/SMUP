
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class jxnct_Largestjxnct_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public jxnct_Largestjxnct_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(-1767520688);
        input[i++] = new Integer(-74110221);
        input[i++] = new Integer(-1699119810);
        i=0;
        cute.Cute.input = this;
        jxnct.Largestjxnct.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(1);
        input[i++] = new Integer(-74110221);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        jxnct.Largestjxnct.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(0);
        input[i++] = new Integer(-74110221);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        jxnct.Largestjxnct.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(2);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        jxnct.Largestjxnct.main(null);
    }

    public void test13(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(1);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        jxnct.Largestjxnct.main(null);
    }

}
