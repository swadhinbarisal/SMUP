
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class jxnct_AssertTest2jxnct_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public jxnct_AssertTest2jxnct_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1589442992);
        input[i++] = new Integer(-1511666122);
        input[i++] = new Integer(-338540285);
        input[i++] = new Integer(-1796173665);
        input[i++] = new Integer(-1694436403);
        input[i++] = new Integer(1986227807);
        input[i++] = new Integer(-553565197);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1589442992);
        input[i++] = new Integer(150);
        input[i++] = new Integer(-338540285);
        input[i++] = new Integer(-1796173665);
        input[i++] = new Integer(-1694436403);
        input[i++] = new Integer(1986227807);
        input[i++] = new Integer(-553565197);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(150);
        input[i++] = new Integer(-338540285);
        input[i++] = new Integer(-1796173665);
        input[i++] = new Integer(-1694436403);
        input[i++] = new Integer(1986227807);
        input[i++] = new Integer(-553565197);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(150);
        input[i++] = new Integer(-338540285);
        input[i++] = new Integer(-1796173665);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1986227807);
        input[i++] = new Integer(-553565197);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(150);
        input[i++] = new Integer(-338540285);
        input[i++] = new Integer(-1796173665);
        input[i++] = new Integer(0);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(-553565197);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(150);
        input[i++] = new Integer(-338540285);
        input[i++] = new Integer(9);
        input[i++] = new Integer(0);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(-553565197);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(299);
        input[i++] = new Integer(-338540285);
        input[i++] = new Integer(9);
        input[i++] = new Integer(0);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(-553565197);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test8(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(299);
        input[i++] = new Integer(-338540285);
        input[i++] = new Integer(9);
        input[i++] = new Integer(101);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(-553565197);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test9(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(299);
        input[i++] = new Integer(-338540285);
        input[i++] = new Integer(9);
        input[i++] = new Integer(101);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test10(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(299);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(101);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test11(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(101);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test12(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test13(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test14(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test16(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(0);
        input[i++] = new Integer(90);
        input[i++] = new Integer(9);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test18(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(0);
        input[i++] = new Integer(90);
        input[i++] = new Integer(9);
        input[i++] = new Integer(0);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test22(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(0);
        input[i++] = new Integer(90);
        input[i++] = new Integer(900);
        input[i++] = new Integer(101);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test24(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(0);
        input[i++] = new Integer(90);
        input[i++] = new Integer(900);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(900);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test41(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(0);
        input[i++] = new Integer(10);
        input[i++] = new Integer(901);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test51(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(150);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1501);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test52(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(150);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1501);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test64(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(0);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test75(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(299);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test82(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(150);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1501);
        input[i++] = new Integer(0);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test135(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(10);
        input[i++] = new Integer(10);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

    public void test150(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1501);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jxnct.AssertTest2jxnct.main(null);
    }

}
