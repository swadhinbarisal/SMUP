
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class tests_WBS_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public tests_WBS_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[10];
        input[i++] = new Integer(2048415872);
        input[i++] = new Integer(-1981230954);
        input[i++] = new Integer(-607716956);
        input[i++] = new Integer(140334082);
        input[i++] = new Integer(1053354388);
        input[i++] = new Integer(-1438808933);
        input[i++] = new Integer(1065684238);
        input[i++] = new Integer(-1409062117);
        input[i++] = new Integer(805833250);
        input[i++] = new Integer(739808809);
        i=0;
        cute.Cute.input = this;
        tests.WBS.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[10];
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1981230954);
        input[i++] = new Integer(-607716956);
        input[i++] = new Integer(140334082);
        input[i++] = new Integer(1053354388);
        input[i++] = new Integer(-1438808933);
        input[i++] = new Integer(1065684238);
        input[i++] = new Integer(-1409062117);
        input[i++] = new Integer(805833250);
        input[i++] = new Integer(739808809);
        i=0;
        cute.Cute.input = this;
        tests.WBS.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[10];
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1981230954);
        input[i++] = new Integer(-607716956);
        input[i++] = new Integer(140334082);
        input[i++] = new Integer(1053354388);
        input[i++] = new Integer(-1438808933);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1409062117);
        input[i++] = new Integer(805833250);
        input[i++] = new Integer(739808809);
        i=0;
        cute.Cute.input = this;
        tests.WBS.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[10];
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1981230954);
        input[i++] = new Integer(-607716956);
        input[i++] = new Integer(140334082);
        input[i++] = new Integer(1053354388);
        input[i++] = new Integer(-1438808933);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(739808809);
        i=0;
        cute.Cute.input = this;
        tests.WBS.main(null);
    }

    public void test9(){
        i=0;
        input = new Object[10];
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1981230954);
        input[i++] = new Integer(-607716956);
        input[i++] = new Integer(140334082);
        input[i++] = new Integer(1053354388);
        input[i++] = new Integer(-1438808933);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(2);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        tests.WBS.main(null);
    }

    public void test18(){
        i=0;
        input = new Object[10];
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1981230954);
        input[i++] = new Integer(-607716956);
        input[i++] = new Integer(140334082);
        input[i++] = new Integer(1053354388);
        input[i++] = new Integer(-1438808933);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        input[i++] = new Integer(3);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        tests.WBS.main(null);
    }

    public void test19(){
        i=0;
        input = new Object[10];
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1981230954);
        input[i++] = new Integer(-607716956);
        input[i++] = new Integer(140334082);
        input[i++] = new Integer(1053354388);
        input[i++] = new Integer(-1438808933);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        input[i++] = new Integer(4);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        tests.WBS.main(null);
    }

}
