
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class WBS_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public WBS_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[10];
        input[i++] = new Integer(-453292751);
        input[i++] = new Integer(65491795);
        input[i++] = new Integer(630818106);
        input[i++] = new Integer(-819941856);
        input[i++] = new Integer(-1814342693);
        input[i++] = new Integer(-1514640246);
        input[i++] = new Integer(1825961856);
        input[i++] = new Integer(990204527);
        input[i++] = new Integer(1030472030);
        input[i++] = new Integer(-642573111);
        i=0;
        cute.Cute.input = this;
        WBS.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[10];
        input[i++] = new Integer(0);
        input[i++] = new Integer(65491795);
        input[i++] = new Integer(630818106);
        input[i++] = new Integer(-819941856);
        input[i++] = new Integer(-1814342693);
        input[i++] = new Integer(-1514640246);
        input[i++] = new Integer(1825961856);
        input[i++] = new Integer(990204527);
        input[i++] = new Integer(1030472030);
        input[i++] = new Integer(-642573111);
        i=0;
        cute.Cute.input = this;
        WBS.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[10];
        input[i++] = new Integer(0);
        input[i++] = new Integer(65491795);
        input[i++] = new Integer(630818106);
        input[i++] = new Integer(-819941856);
        input[i++] = new Integer(-1814342693);
        input[i++] = new Integer(-1514640246);
        input[i++] = new Integer(0);
        input[i++] = new Integer(990204527);
        input[i++] = new Integer(1030472030);
        input[i++] = new Integer(-642573111);
        i=0;
        cute.Cute.input = this;
        WBS.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[10];
        input[i++] = new Integer(0);
        input[i++] = new Integer(65491795);
        input[i++] = new Integer(630818106);
        input[i++] = new Integer(-819941856);
        input[i++] = new Integer(-1814342693);
        input[i++] = new Integer(-1514640246);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(-642573111);
        i=0;
        cute.Cute.input = this;
        WBS.main(null);
    }

    public void test8(){
        i=0;
        input = new Object[10];
        input[i++] = new Integer(0);
        input[i++] = new Integer(65491795);
        input[i++] = new Integer(630818106);
        input[i++] = new Integer(-819941856);
        input[i++] = new Integer(-1814342693);
        input[i++] = new Integer(-1514640246);
        input[i++] = new Integer(0);
        input[i++] = new Integer(2);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        WBS.main(null);
    }

    public void test39(){
        i=0;
        input = new Object[10];
        input[i++] = new Integer(1);
        input[i++] = new Integer(65491795);
        input[i++] = new Integer(630818106);
        input[i++] = new Integer(-819941856);
        input[i++] = new Integer(-1814342693);
        input[i++] = new Integer(-1514640246);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(3);
        i=0;
        cute.Cute.input = this;
        WBS.main(null);
    }

    public void test43(){
        i=0;
        input = new Object[10];
        input[i++] = new Integer(0);
        input[i++] = new Integer(65491795);
        input[i++] = new Integer(630818106);
        input[i++] = new Integer(-819941856);
        input[i++] = new Integer(-1814342693);
        input[i++] = new Integer(-1514640246);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(1);
        input[i++] = new Integer(4);
        i=0;
        cute.Cute.input = this;
        WBS.main(null);
    }

}
