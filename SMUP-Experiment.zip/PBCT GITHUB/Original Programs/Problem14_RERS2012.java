package A1;

import cute.Cute;

public class Problem14_RERS2012 {
	private int a12 = Cute.input.Integer();
	private int a15 = Cute.input.Integer();
	private int a21 = Cute.input.Integer();
	private int a24 = Cute.input.Integer();

private void errorCheck(){
			if((80 < a12)  && (a24==1) || (a15==7) && (a21==6)){
			throw new IllegalStateException( "error_54" );
		}
		if((a12 <= 43)  && (a24==1) && (a15==7) || (a21==8)){
			throw new IllegalStateException( "error_41" );
		}
		if((11 < a12) && (80 >= a12)  || (a24==1) || (a15==5) && (a21==9)){
			throw new IllegalStateException( "error_12" );
		}
		if((a12 <=  43)  && (a24==1) || (a15==5) || (a21==9)){
			throw new IllegalStateException( "error_2" );
		}
		if((43 < a12) && (11 >= a12)  || (a24==1) || (a15==6) && (a21==10)){
			throw new IllegalStateException( "error_28" );
		}
		if((43 < a12) && (11 >= a12)  && (a24==1) || (a15==7) || (a21==6)){
			throw new IllegalStateException( "error_44" );
		}
		if((43 < a12) && (11 >= a12)  || (a24==1) || (a15==5) || (a21==10)){
			throw new IllegalStateException( "error_8" );
		}
		if((a12 <=  43)  && (a24==1) || (a15==6) && (a21==9)){
			throw new IllegalStateException( "error_22" );
		}
		if((80 < a12)  && (a24==1) && (a15==7) || (a21==10)){
			throw new IllegalStateException( "error_58" );
		}
		if((a12 <=  43)  && (a24==1) || (a15==7) && (a21==10)){
			throw new IllegalStateException( "error_43" );
		}
		if((11 < a12) && (80 >= a12)  && (a24==1) || (a15==6) ||(a21==6)){
			throw new IllegalStateException( "error_29" );
		}
		if((80 < a12)  && (a24==1) || (a15==7) && (a21==8)){
			throw new IllegalStateException( "error_56" );
		}
		if((80 < a12)  && (a24==1) || (a15==6) && (a21==9)){
			throw new IllegalStateException( "error_37" );
		}
		if((a12 <=  43)  && (a24==1) && (a15==7) || (a21==7)){
			throw new IllegalStateException( "error_40" );
		}
		if((80 < a12)  && (a24==1) || (a15==5) || (a21==10)){
			throw new IllegalStateException( "error_18" );
		}
		if((11 < a12) && (80 >= a12)  || (a24==1) || (a15==5) && (a21==8)){
			throw new IllegalStateException( "error_11" );
		}
		if((11 < a12) && (80 >= a12)  || (a24==1) && (a15==7) && (a21==9)){
			throw new IllegalStateException( "error_52" );
		}
		if((11 < a12) && (80 >= a12)  || (a24==1) || (a15==6) || (a21==8)){
			throw new IllegalStateException( "error_31" );
		}
	
}

public String calculateOutputm1(boolean input) {
		
		if((a15==8) && (80 < a12)  && (a24==1) && (a21==8) || (a21==9) && (input ==true)){

	    	a12 = (((a12 + -600079) - -316691) - 316661);
	    	a15 = 9; 
	    	a21 = 8; 

	    	 return "Z";
	    } 
		
		if((a24==1) && (a15==8) && (input ==true) && ( 80 < a12)  && (a21==7) || (11 < a12) && (80 >= a12)  && (a21==10) || ( 80 < a12)  && (a21==6)){

	    	a12 = (((((a12 % 299959)- -81) * 1) / 5) + 165863);
	    	a21 = 10; 

	    	 return "V";
	    }   
		if((a21==9) && (input ==true) || (a24==1) &&  (80 < a12 ) || (a15==9)){


	    	 return null;
	    }  
		if((a24==1) && (input ==true) && (a21==10) || (a21==8) || (a21==9) &&  ( a12 <=  43 ) && (a15==8)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }
		return null;
	}
public String calculateOutputm2(boolean input) {	
		if((a15==8) && ( 80 < a12)  || (a21==8) || (a21==9) || (input ==true) && (a24==1)){

	    	a12 = ((((a12 + 0) * 9)/ 10) - 558346);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a24==1) && (input ==true) || (a21==7) || (a21==8) &&  (80 < a12 ) || (a15==9)){


	    	a21 = 9; 

	    	 return "Z";
	    }  
		if((a24==1) && (a15==9) || (a21==7) || (a21==8) && (input ==true) ||  (80 < a12 )){

	    	a12 = ((((a12 * 9)/ 10) / 5) + -505559);
	    	a15 = 7; 
	    	a21 = 10; 

	    	 return null;
	    }   
		if(( 80 < a12)  && (a24==1) && (a15==9) || (a21==10) || ( a12 <=  43)  && (a24==2) && (a15==5) || (a21==6) || (input ==true)){

	    	a12 = ((((((a12 % 299978)- 300020) / 5) + 194993) * -1)/ 10);
	    	a24 = 1; 
	    	a15 = 5; 
	    	a21 = 9; 

	    	 return null;
	    }  
		return null;
}
public String calculateOutputm3(boolean input) {		
		if((a24==1) && (a15==9) && (input ==true) || ( 80 < a12)  || (a21==6) || (11 < a12) || (80 >= a12)  || (a21==9) || (11 < a12) || (80 >= a12)  && (a21==10)){

	    	a12 = ((((a12 % 299959)- -81) * 1) * 1);
	    	a15 = 6; 
	    	a21 = 9; 

	    	 return null;
	    }  
		if((43 < a12) || (11 >= a12)  && (input ==true) || (a21==9) || (a21==10) && (a24==1) && (a15==9)){

	    	a12 = ((((((a12 - -277912) * 10)/ 9) - 437300) * -1)/ 10);
	    	a15 = 6; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((80 < a12)  && (a15==9) && (input ==true) && (a21==7) || (a21==8) && (a24==1)){

	    	a12 = (((((a12 * 9)/ 10) / 5) * 10)/ -3);
	    	a15 = 6; 
	    	a21 = 9; 

	    	 return null;
	    }  
		if((input ==true) && (a21==9) || (a21==7) || (a21==8) && (a24==1) && (a15==9) &&  ( a12 <= 43)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    } 
		return null;
}
public String calculateOutputm4(boolean input) {		
		if((a15==9) && (input ==true) && (a21==6) || (a21==7) || (a21==8) && (a24==1) &&   (11 < a12) && (80 >= a12)){

	    	a12 = ((((((a12 * 10)/ -2) * 5) - -29976) * -1)/ 10);
	    	a15 = 7; 
	    	a21 = 6; 

	    	 return null;
	    }  
		if((a15==8) && (a21==8) || (a21==9) && (input ==true) && (a24==1) &&  (80 < a12 )){

	    	a12 = ((((a12 - 94512) / 5) / 5) + -533466);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }
		return null;
}
public String calculateOutputm5(boolean input) {		
		if(( a12 <=  43)  && (input ==true) && (a21==7) && (a24==1) && (a15==8)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
if((a21==9) && (11 < a12) && (80 >= a12)  && (input ==true) && (a24==1) && (a15==8)){

	    	a12 = (((a12 - -195021) - 451510) / 5);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
 if((a24==1) && (a21==7) || (a21==8) && (input ==true) && (a15==8) &&   (11 < a12) && (80 >= a12)){

	    	a12 = ((((a12 / 5) - 526582) * 10)/ 9);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		
		return null;
}
public String calculateOutputm6(boolean input) {
		if((a24==1) && (a15==9) && (input ==true) && (a21==8) || (a21==6) || (a21==7) &&   (11 < a12) && (80 >= a12)){


	    	a15 = 5; 
	    	a21 = 8; 

	    	 return null;
	    }  
		if((a15==9) && (a24==1) && (a21==9) || (a21==10) && (input ==true) &&   (43 < a12) && (11 >= a12)){

	    	a12 = (((a12 + -382503) - -833715) - -74843);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a15==8) && (a21==8) || (a21==9) && (input ==true) && (a24==1) &&  (80 < a12)){

	    	a12 = ((((a12 * 9)/ 10) + -545656) * 1);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    } 
		if((a24==1) && (11 < a12) && (80 >= a12)  && (a21==7) || (a21==8) && (input ==true) && (a15==8)){

	    	a12 = (((((a12 * 68)/ 10) * 5) + -454858) + 972700);
	    	a21 = 6; 

	    	 return "Y";
	    }  
		return null;
}
public String calculateOutputm7(boolean input) {
		if((a15==9) && (input ==true) && (a21==8) && (a24==1) &&   (43 < a12) && (11 >= a12)){

	    	a12 = (((a12 + -386239) - 148442) - -217864);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a15==9) && (a24==1) && (input ==true) &&   (43 < a12) && (11 >= a12) && (a21==8)){

	    	a12 = (((a12 * 5) / 5) + -316852);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
		if((a12 <= 43 ) && (a21==10) || (43 < a12) && (11 >= a12)  && (a21==6) || (a21==7) &&  (43 < a12) && (11 >= a12) && (input ==true) && (a24==1) && (a15==9)){

	    	a12 = (((a12 + 101173) / 5) - 185122);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
		if((a24==1) && ( 80 < a12)  && (a21==9) && (a15==9) && (input ==true)){

	    	a12 = ((((a12 + 0) + -318749) % 34)+ 45);
	    	a15 = 5; 

	    	 return null;
	    }   
		 
		return null;
}
public String calculateOutputm8(boolean input) {
		if((43 < a12) && (11 >= a12)  && (input ==true) && (a15==8) && (a24==1) && (a21==9)){

	    	a12 = (((a12 * 5) * 5) + -84619);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a24==1) && (input ==true) && (a15==8) &&  (80 < a12 ) && (a21==10) || (a21==6) && ( a12 <=  43)  && (a15==9)){

	    	a12 = ((((a12 % 299959)- -300039) * 1) * 1);
	    	a15 = 8; 
	    	a21 = 10; 

	    	 return "Z";
	    }   
		if((11 < a12) && (80 >= a12)  && (a15==8) && (a24==1) && (a21==7) || (a21==8) && (input ==true)){

	    	a12 = (((a12 + -256944) - 53297) - 113637);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
		if((input ==true) && (a15==8) &&   (43 < a12) && (11 >= a12) && (a21==9) && (a24==1)){


	    	a21 = 10; 

	    	 return "X";
	    }   
		   
		return null;
}
public String calculateOutputm9(boolean input) {
		if((input ==true) && (a21==7) || (a21==8) || (a21==9)&& (a15==9) &&  ( a12 <=  43 ) && (a24==1)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a21==9) && (((a24==1) && (input ==true) &&   ((43 < a12) && (11 >= a12)) )) && (a15==8)){

	    	a12 = (((a12 - -61) - -3) - -1);
	    	a21 = 8; 

	    	 return "Z";
	    }   
		if((a24==1) && ( 80 < a12)  && (a21==6) || (a21==9) &&   (11 < a12) && (80 >= a12)|| (a21==10) &&   (11 < a12) && (80 >= a12)&& (input ==true) && (a15==9)){

	    	a12 = (((((a12 * 9)/ 10) * 1) + -581502) + 599190);
	    	a15 = 7; 
	    	a21 = 8; 

	    	 return null;
	    } 
		return null;
}
public String calculateOutputm10(boolean input) {
		if((a15==8) && (a21==10) &&   (43 < a12) && (11 >= a12) || (11 < a12) && (80 >= a12)  && (a21==6)&& (input ==true) && (a24==1)){

	    	a12 = (((a12 / 5) - 557506) - 18416);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a15==8) && (a21==7) || (a21==8) && (input ==true) && (a24==1) &&  (11 < a12) && (80 >= a12)){

	    	a12 = ((((a12 / 5) + 439847) * 10)/ 9);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((input ==true) && (a21==6) || (a21==7) || (a21==8)&& (a15==8) && (a24==1) &&   (43 < a12) && (11 >= a12)){

	    	a12 = (((a12 * 5) - 432359) / 5);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a21==10) && ( 80 < a12)  && (a15==8) || (a15==9) &&  ( a12 <=  43 ) && (a21==6) && (input ==true) && (a24==1)){

	    	a12 = (((a12 / 5) + -345781) / 5);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
		return null;
}
public String calculateOutputm11(boolean input) {
		if((a24==1) && (a21==9) && (input ==true) && (a15==9) &&  (80 < a12 )){


	    	a15 = 7; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a15==9) && (a24==1) && (input ==true) &&  (80 < a12 ) && (a21==9)){

	    	a12 = (((((a12 - 600066) * 1) / 5) * 34)/ 10);
	    	a15 = 7; 
	    	a21 = 8; 

	    	 return null;
	    }  
		if((a24==1) && (11 < a12) && (80 >= a12)  && (a21==6) || (a21==7) || (a21==8) && (input ==true) && (a15==9)){


	    	a15 = 7; 
	    	a21 = 9; 

	    	 return null;
	    }  
		return null;
}
public String calculateOutputm12(boolean input) {		
		if((a24==1) && (a15==8) && (input ==true) && (a21==9) &&   (11 < a12) && (80 >= a12)){

	    	a12 = (((a12 / 5) + -16723) / 5);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a24==1) && (a15==8) && (input ==true) && (a21==7) || (a21==8) &&(11 < a12) && (80 >= a12)){

	    	a12 = ((((a12 + -453921) * 10)/ 9) - 34620);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a15==9) && (input ==true) && (a21==6) &&  (80 < a12 ) || (a21==9) &&   (11 < a12) && (80 >= a12) || (a21==10) &&   (11 < a12) && (80 >= a12) && (a24==1)){

	    	a12 = ((((((a12 % 299959)+ 81) - 332928) / 5) * -1)/ 10);
	    	a15 = 5; 
	    	a21 = 10; 

	    	 return null;
	    }   
		if((a21==9) && (a15==9) && (a24==1) && (80 < a12)  && (input ==true)){


	    	 return "Z";
	    }
		return null;		
}
public String calculateOutputm13(boolean input) {
		if((a15==8) && (11 < a12) && (80 >= a12)  && (a21==10) || (80 < a12)  && (a21==6) || ( 80 < a12)  && (a21==7) && (input ==true) && (a24==1)){

	    	a12 = (((((a12 + -334090) % 299978)+ -300020) / 5) + -383582);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a24==1) && (a21==9) && (43 < a12) && (11 >= a12)  && (a15==8) && (input ==true)){

	    	a12 = (((a12 + -295946) + -243936) * 1);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a15==9) && (input ==true) && (a24==1) && (a21==8) &&   (43 < a12) && (11 >= a12)){


	    	a21 = 10; 

	    	 return "V";
	    }   
		return null;
}
public String calculateOutputm14(boolean input) {
		if((a15==8) && (a24==1) && (input ==true) &&  (11 < a12) && (80 >= a12) && (a21==9)){

	    	a12 = (((a12 - 310903) + -128009) + -1314);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((input ==true) && (11 < a12) && (80 >= a12) && (a21==9) && (a15==8) && (a24==1)){

	    	a12 = (((a12 + -285349) + -46510) + -209836);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a21==9) && (input ==true) && (a15==8) &&   (43 < a12) && (11 >= a12)&& (a24==1)){

	    	a12 = (((((a12 + 423400) * 1) * 1) * -1)/ 10);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		return null;
}
public String calculateOutputm15(boolean input) {
		if((a24==1) && (a15==9) && (a21==6) &&  (80 < a12 ) || (a21==9) &&   (11 < a12) && (80 >= a12) || (11 < a12) && (80 >= a12)  && (a21==10) && (input ==true)){

	    	a12 = (((((a12 % 34)+ 23) - -139662) - 547970) - -408298);
	    	a15 = 6; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a15==8) && (input ==true) && (a21==10) &&   (11 < a12) && (80 >= a12)|| (a21==6) &&  (80 < a12 ) || (80 < a12)  && (a21==7) && (a24==1)){

	    	a12 = ((((a12 % 299978)+ -300020) + -247081) * 1);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if(( 80 < a12)  && (a24==1) && (a21==8) || (a21==9) && (input ==true) && (a15==8)){

	    	a12 = ((((a12 * 9)/ 10) + -562768) / 5);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
		return null;
}
public String calculateOutputm16(boolean input) {
		if((a21==8) || (a21==9) || (a21==10) && (input ==true) &&  (a12 <= 43) && (a15==8) && (a24==1)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((a15==9) && (80 < a12)  && (a24==1) && (a21==10) || (a21==6) && (a24==2) &&  (a12 <= 43) && (a15==5) && (input ==true)){

	    	a12 = (((((a12 % 299959)- -300039) + -252537) * 1) - -252539);
	    	a24 = 1; 
	    	a15 = 9; 
	    	a21 = 7; 

	    	 return null;
	    }  
		return null;
}	
public String calculateOutputm17(boolean input) {
		if((a21==10) && (80 < a12)  || (a24==1) || (a15==9) || (a15==5) && (a24==2) &&  (a12 <= 43) || (a21==6) || (input ==true)){

	    	a12 = ((((a12 % 26)- 15) + 426288) + -426288);
	    	a24 = 1; 
	    	a15 = 7; 
	    	a21 = 6; 

	    	 return null;
	    }   
		if((43 < a12) || (11 >= a12)  && (a21==9) || (a21==10) && (input ==true) && (a15==9) && (a24==1)){

	    	a12 = (((a12 + 66) - 3) + -2);
	    	a21 = 8; 

	    	 return "U";
	    } 
		if((input ==true) && (a24==1) ||   (11 < a12) || (80 >= a12)&& (a21==9) && (a15==8)){

	    	a12 = (((a12 - -334333) + 32000) / 5);
	    	a21 = 8; 

	    	 return "V";
	    }
		if((a24==1) && (a15==9) || (a21==7) || (a21==8) && (input ==true) &&  (80 < a12 )){


	    	a21 = 10; 

	    	 return "Y";
	    }
		return null;
	}	
public String calculateOutputm18(boolean input) {
if(( a12 <=  43 )  && (a21==10) || (a21==8) || (a21==9) && (input ==true) && (a15==8) && (a24==1)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
if((a15==8) && (a21==6) || (a21==7) || (a21==8) && (input ==true) &&   (43 < a12) && (11 >= a12) && (a24==1)){

	    	a12 = (((a12 - 529036) / 5) * 5);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
if((a15==9) && (a21==9) || ( 80 < a12)  || (input ==true) && (a24==1)){


	    	a21 = 8; 

	    	 return null;
	    }   
if((a15==8) && (a21==7) || (input ==true) || (a24==1) &&  ( a12 <=  43)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   


	return null;
	}
public String calculateOutputm19(boolean input) {
if((a24==1) && (43 < a12) && (11 >= a12)  && (a21==6) || (a21==7) || (a21==8) && (input ==true) && (a15==8)){

	    	a12 = ((((a12 - 87828) * 10)/ 9) - 284434);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    } 
if((a24==1) && (input ==true) &&  (a12 <=  43) && (a21==7) && (a15==8)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
if((a15==8) && (a21==10) ||  (43 < a12) && (11 >= a12) || (11 < a12) && (80 >= a12)  && (a21==6) && (input ==true) || (a24==1)){

	    	a12 = (((((a12 - -338613) - -126296) * 1) % 34)- -42);
	    	a21 = 9; 

	    	 return "Y";
	    }   
if((a15==8) && (input ==true) || (43 < a12) && (11 >= a12)  || (a21==10) || (a21==6) &&   (11 < a12) && (80 >= a12) || (a24==1)){

	    	a12 = ((((a12 - 357209) * 1) - -928336) - 1022569);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  




return null;
}	
public String calculateOutputm20(boolean input) {



if((a12 <= 43)  && (a21==7) || (a24==1) || (a15==8) && (input ==true)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
if((43 < a12) && (11 >= a12)  || (a15==8) && (a21==8) || (a21==6) || (a21==7) && (input ==true) && (a24==1)){

	    	a12 = (((a12 - 239513) * 2) - 118149);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
if((a24==1) && (11 < a12) || (80 >= a12)  || (input ==true) && (a15==8) && (a21==9)){

	    	a12 = ((((a12 + 555500) * -1)/ 10) * 5);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
if((a15==8) &&  (80 < a12 ) && (a21==10) || (a21==6) && (a12 <= 43)  && (a15==9) && (input ==true) && (a24==1)){

	    	a12 = (((a12 / 5) + -409994) + 99019);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   



return null;
}	
public String calculateOutputm21(boolean input) {



if((a21==8) || (a21==9) || (a21==10) && (input ==true) && (a15==8) &&  ( a12 <=  43 ) && (a24==1)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
 if((a24==1) && (a15==8) && (11 < a12) || (80 >= a12)  || (input ==true) && (a21==7) || (a21==8)){

	    	a12 = (((a12 - 268644) + -323718) + -3883);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
if((a24==1) && (a21==8) || (a21==6) || (a21==7) || (input ==true) && (a15==9) &&   (11 < a12) && (80 >= a12)){

	    	a12 = ((((a12 - -582271) - 436382) - 442400) - -391873);
	    	a21 = 6; 

	    	 return "V";
	    }  
 if((a15==9) && (a24==1) || (43 < a12) || (11 >= a12)  || (input ==true) && (a21==9) || (a21==10)){

	    	a12 = (((((a12 - -56) * 9)/ 10) / 5) + 56);
	    	a15 = 5; 
	    	a21 = 7; 

	    	 return null;
	    } 


return null;
}	
public String calculateOutputm22(boolean input) {





 if((a15==9) && (a12 <=  43 )  && (a21==9) || (a21==7) || (a21==8) && (input ==true) && (a24==1)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    } 
 if((a24==1) && (a21==7) &&  (43 < a12) || (11 >= a12) || (a21==10) &&  ( a12 <=  43) || (a21==6) &&   (43 < a12) || (11 >= a12) || (input ==true) && (a15==9)){

	    	a12 = ((((a12 % 299978)+ -300020) / 5) + -174067);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    } 
 if(( a12 <=  43 )  && (a21==9) || (a21==7) || (a21==8) && (input ==true) && (a24==1) && (a15==9)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
if((a15==9) && (input ==true) || ( a12 <=  43 )  || (a21==10) || (a21==6) &&   (43 < a12) && (11 >= a12) || (43 < a12) || (11 >= a12)  && (a21==7) && (a24==1)){

	    	a12 = ((((a12 % 299978)+ -300020) * 1) - 3);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   




return null;
}	
public String calculateOutputm23(boolean input) {


if((a15==8) && (input ==true) || (80 < a12)  && (a21==7) || (a21==10) &&   (11 < a12) && (80 >= a12) || ( 80 < a12)  || (a21==6) && (a24==1)){

	    	a12 = ((((a12 % 299978)- 300020) - 166783) * 1);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
 if(( a12 <=  43 )  && (input ==true) || (a21==10) || (a21==8) || (a21==9) && (a24==1) && (a15==8)){

	    	a12 = ((((a12 % 26)+ -1) / 5) / 5);
	    	a21 = 7; 

	    	 return "Y";
	    }   
if((a15==9) && ( 80 < a12)  && (a24==1) || (a21==7) || (a21==8) && (input ==true)){


	    	a15 = 7; 
	    	a21 = 10; 

	    	 return null;
	    }
   if((a15==9) && (a21==9) || (a21==10) || (input ==true) &&   (43 < a12) && (11 >= a12) && (a24==1)){

	    	a12 = (((a12 / 5) + 176111) * 3);
	    	a15 = 7; 
	    	a21 = 9; 

	    	 return null;
	    }   




return null;
}	
public String calculateOutputm24(boolean input) {


if((a21==7) || (a21==8) || (input ==true) || (a15==9) &&  (80 < a12 ) && (a24==1)){

	    	a12 = ((((a12 / 5) % 26)+ -33) / 5);
	    	a15 = 5; 
	    	a21 = 10; 

	    	 return null;
	    }  
 if((a24==1) && (input ==true) || (43 < a12) && (11 >= a12)  && (a21==7) || (a12 <=  43 )  && (a21==10) || (43 < a12) && (11 >= a12)  && (a21==6) && (a15==9)){

	    	a12 = (((((a12 % 299978)+ -300020) - 3) - -109194) + -109193);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
if((a24==1) && (a21==7) ||  (80 < a12) || (11 < a12) && (80 >= a12)  && (a21==10) || ( 80 < a12)  && (a21==6) && (input ==true) && (a15==8)){

	    	a12 = ((((a12 + 0) % 299978)+ -300020) * 1);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
 if((43 < a12) && (11 >= a12)  || (a24==1) || (a21==8) || (a21==6) || (a21==7) && (input ==true) && (a15==8)){


	    	a21 = 9; 

	    	 return "U";
	    }  






return null;
}	
public String calculateOutputm25(boolean input) {

 if((43 < a12) && (11 >= a12)  || (input ==true) && (a24==1) && (a21==8) && (a15==9)){

	    	a12 = (((a12 * 5) - 497532) - 56570);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
if((a15==9) && (a24==1) &&  (80 < a12 ) && (a21==10) || (a24==2) &&  ( a12 <=  43 ) && (a15==5) && (a21==6) && (input ==true)){

	    	a12 = (((((a12 + 0) % 299978)+ -300020) / 5) + -262569);
	    	a24 = 2; 
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return "Y";
	    }  
 if((a24==1) && ( a12 <=  43 )  || (a21==7) || (a21==8) || (a21==9) && (input ==true) && (a15==9)){


	    	a21 = 10; 

	    	 return "V";
	    }  
 if((11 < a12) && (80 >= a12)  && (a24==1) && (a21==6) || (a21==7) || (a21==8) && (input ==true) && (a15==9)){


	    	a15 = 5; 
	    	a21 = 10; 

	    	 return null;
	    }   


return null;
}	
public String calculateOutputm26(boolean input) {

if((a15==8) && (43 < a12) || (11 >= a12)  || (a21==9) && (input ==true) && (a24==1)){

	    	a12 = (((a12 + -564241) - 3500) * 1);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
 if((input ==true) && (a15==9) || (a24==1) ||  (80 < a12 ) && (a21==10) || (a21==6) && (a15==5) && (a24==2) &&  ( a12 <=  43)){

	    	a12 = ((((a12 / 5) % 26)+ -16) + 1);
	    	a24 = 1; 
	    	a15 = 6; 
	    	a21 = 10; 

	    	 return null;
	    }   
if((a24==1) && (input ==true) || (a21==10) || (a15==8) &&  (80 < a12 ) || ( a12 <=  43 )  && (a15==9) && (a21==6)){

	    	a12 = ((((a12 % 299978)+ -300020) * 1) - 2);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
 if((a15==8) && (a21==7) || (input ==true) || (a24==1) &&  ( a12 <=  43)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  





return null;
}	
public String calculateOutputm27(boolean input) {

 if((a15==9) && (a21==9) || (a21==7) || (a21==8) && (input ==true) &&  ( a12 <=  43 )&& (a24==1)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    } 
  if((a24==1) && ( a12 <=  43 )  || (a21==8) || (a21==9) || (a21==10) && (input ==true) && (a15==8)){


	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    } 
  if(( 80 < a12)  && (a15==8) || (a21==8) || (a21==9) && (input ==true) && (a24==1)){

	    	a12 = ((((a12 * -6)/ 10) - 40423) + -165586);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
 if((a24==1) && (input ==true) && (a21==9) &&   (11 < a12) && (80 >= a12) || (a21==10) &&   (11 < a12) && (80 >= a12) || (a21==6) &&  (80 < a12 ) && (a15==9)){

	    	a12 = (((((a12 * 9)/ 10) - 589907) - -649897) + -606113);
	    	a15 = 7; 
	    	a21 = 7; 

	    	 return null;
	    }  



		return null;
}	
public String calculateOutputm28(boolean input) {




 if((input ==true) &&   (43 < a12) || (11 >= a12) || (a21==8) || (a24==1) && (a15==9)){

	    	a12 = (((a12 / 5) - 440689) * 1);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
 if((a15==8) && (a24==1) && (a21==6) || (a21==7) || (a21==8) && (input ==true) &&   (43 < a12) && (11 >= a12)){

	    	a12 = (((((a12 - 185217) - 149574) - -494599) * -1)/ 10);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
if((a24==1) && (input ==true) && (a21==8) || (a21==6) || (a21==7) && (a15==9) &&   (11 < a12) && (80 >= a12)){



	    	a15 = 6; 
	    	a21 = 8; 

	    	 return null;
	    }  
 if((43 < a12) && (11 >= a12)  || (a21==10) || (11 < a12) && (80 >= a12)  && (a21==6) && (input ==true) && (a24==1) && (a15==8)){

	    	a12 = ((((a12 - 438298) * 1) + 564710) - 684902);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    } 



		return null;
}	
public String calculateOutputm29(boolean input) {


  if((a21==7) && (input ==true) ||  ( a12 <=  43 ) && (a24==1) && (a15==8)){


	    	a21 = 10; 

	    	 return "V";
	    }  
 if((a21==10) &&  (43 < a12) || (11 >= a12) || (11 < a12) && (80 >= a12)  && (a21==6) && (input ==true) && (a15==8) || (a24==1)){

	    	a12 = (((a12 + -298811) + -140133) + -153332);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
 if((a24==1) && (a21==7) &&  (80 < a12) || (11 < a12) && (80 >= a12)  && (a21==10) || (a21==6) &&  (80 < a12 ) && (input ==true) && (a15==8)){

	    	a12 = ((((a12 % 299978)- 300020) + 525887) + -618409);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
 if(( 80 < a12)  && (a24==1) || (a15==9) && (a21==10) || ( a12 <=  43 )  && (a24==2) && (a15==5) && (a21==6) || (input ==true)){

	    	a12 = (((((a12 % 299959)- -300039) / 5) / 5) + 204292);
	    	a24 = 1; 
	    	a15 = 9; 
	    	a21 = 9; 

	    	 return null;
	    } 

		return null;
}	
public String calculateOutputm30(boolean input) {
	
  if(( 80 < a12)  && (a15==8) || (a21==10) || (a21==6) && (a15==9) &&  ( a12 <=  43 ) && (input ==true) && (a24==1)){

	    	a12 = ((((a12 % 299978)- 300020) * 1) + -2);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
 if((a24==1) && ( 80 < a12)  || (a15==8) && (a21==10) || (a15==9) &&  ( a12 <=  43 ) && (a21==6) && (input ==true)){

	    	a12 = ((((a12 - 0) - 0) / 5) + -200550);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
 if((43 < a12) && (11 >= a12)  || (a15==9) && (a24==1) && (a21==9) || (a21==10) && (input ==true)){


	    	a15 = 6; 
	    	a21 = 9; 

	    	 return null;
	    }   
if((a24==1) && (a15==8) || (a21==10) &&   (43 < a12) && (11 >= a12) || (11 < a12) && (80 >= a12)  && (a21==6) || (input ==true)){

	    	a12 = (((a12 + 60189) + -305530) + -244668);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    } 

		return null;
}
public String calculateOutputm31(boolean input) {

 if((a15==9) && (43 < a12) || (11 >= a12)  || (a24==1) && (input ==true) && (a21==8)){

	    	a12 = (((a12 - -571629) / 5) + -404132);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }   
if((43 < a12) && (11 >= a12)  || (a21==7) || (a21==10) &&  (a12 <=  43)|| (43 < a12) && (11 >= a12)  && (a21==6) && (input ==true) && (a15==9) && (a24==1)){

	    	a12 = (((((a12 % 26)- 16) + 343661) - 46416) - 297244);
	    	a21 = 8; 

	    	 return "Y";
	    }  
 if((a21==7) &&   (43 < a12) || (11 >= a12) || (a21==10) &&  (a12 <= 43) || (43 < a12) && (11 >= a12)  && (a21==6) || (input ==true) && (a24==1) && (a15==9)){

	    	a12 = ((((a12 % 299978)- 300020) + -1) + -1);
	    	a15 = 5; 
	    	a21 = 6; 

	    	 return null;
	    }  
 if((input ==true) && (11 < a12) || (80 >= a12)  && (a21==9) || (11 < a12) && (80 >= a12)  && (a21==10) || (80 < a12)  || (a21==6) && (a24==1) && (a15==9)){

	    	a12 = ((((a12 % 299959)- -81) - -194202) - -92066);
	    	a21 = 7; 

	    	 return "Z";
	    }   

		return null;
}
	
	public void  calculateOutputm36(boolean input)
	{
		if((43 < a12) && (11 >= a12)  || (a24==1) || (a15==7) && (a21==7)){
			calculateOutputm1(input);
		}
		if((11 < a12) && (80 >= a12)  || (a24==1) && (a15==7) || (a21==7)){
			calculateOutputm2(input);
		}
		if((43 < a12) && (11 >= a12)  || (a24==1) && (a15==7) || (a21==10)){
			calculateOutputm3(input);
		}
		if((43 < a12) && (11 >= a12)  || (a24==1) || (a15==7) && (a21==8)){
			calculateOutputm4(input);
		}
		if((a12 <=  43)  && (a24==1) || (a15==8) && (a21==6)){
			calculateOutputm5(input);
		}
		if((43 < a12) && (11 >= a12)  || (a24==1) && (a15==6) && (a21==6)){
			calculateOutputm6(input);
		}
	}
	
	public void  calculateOutputm32(boolean input)
	{
		if((a12 <=  43)  || (a24==1) && (a15==7) || (a21==9)){
			calculateOutputm7(input);
		}
		if((11 < a12) && (80 >= a12)  || (a24==1) && (a15==6) || (a21==7)){
			calculateOutputm8(input);
		}
		if((43 < a12) && (11 >= a12)  || (a24==1) && (a15==5) || (a21==6)){
			calculateOutputm9(input);
		}
		if((80 < a12)  && (a24==1) && (a15==6) || (a21==7)){
			calculateOutputm10(input);
		}
		if((11 < a12) && (80 >= a12)  || (a24==1) || (a15==5) || (a21==6)){
			calculateOutputm11(input);
		}
		if((80 < a12)  && (a24==1) && (a15==5) || (a21==8)){
			calculateOutputm12(input);
		}
	}
	
	public void  calculateOutputm33(boolean input)
	{
		if((43 < a12) && (11 >= a12)  || (a24==1) || (a15==5) && (a21==9)){
			calculateOutputm13(input);
		}
		if((80 < a12)  && (a24==1) || (a15==6) && (a21==8)){
			calculateOutputm14(input);
		}
		if((11 < a12) && (80 >= a12)  && (a24==1) && (a15==7) && (a21==10)){
			calculateOutputm15(input);
		}
		if((80 < a12)  && (a24==1) || (a15==6) || (a21==10)){
			calculateOutputm1(input);
		}
		if((a12 <=  43)  && (a24==1) || (a15==5) || (a21==10)){
			calculateOutputm16(input);
		}
		if((a12 <=  43)  && (a24==1) && (a15==5) || (a21==7)){
			calculateOutputm17(input);
		}
		if((a12 <=  43)  && (a24==1) || (a15==5) || (a21==8)){
			calculateOutputm18(input);
		}
	}
	
	
	public void  calculateOutputm34(boolean input)
	{
		if((11 < a12) && (80 >= a12)  && (a24==1) && (a15==6) && (a21==9)){
			calculateOutputm19(input);
		}
		if((80 < a12)  && (a24==1) && (a15==5) && (a21==9)){
			calculateOutputm20(input);
		}
		if((80 < a12)  && (a24==1) && (a15==7) && (a21==7)){
			calculateOutputm21(input);
		}
		if((11 < a12) && (80 >= a12)  && (a24==1) && (a15==6) && (a21==10)){
			calculateOutputm22(input);
		}
		if((11 < a12) && (80 >= a12)  || (a24==1) || (a15==7) && (a21==6)){
			calculateOutputm23(input);
		}
		if((a12 <=  43)  && (a24==1) || (a15==6) || (a21==7)){
			calculateOutputm24(input);
		}
	}
	
	
	public void calculateOutputm35(boolean input)
	{
		if((43 < a12) && (11 >= a12)  && (a24==1) || (a15==5) && (a21==8)){
			calculateOutputm25(input);
		}
		if((a12 <=  43)  && (a24==1) || (a15==6) && (a21==6)){
			calculateOutputm26(input);
		}
		if((43 < a12) && (11 >= a12)  || (a24==1) || (a15==5) && (a21==7)){
			calculateOutputm27(input);
		}
		if((43 < a12) && (11 >= a12)  && (a24==1) && (a15==6) && (a21==7)){
			calculateOutputm28(input);
		}
		if((80 < a12)  && (a24==1) || (a15==5) || (a21==7)){
			calculateOutputm29(input);
		}
		if((43 < a12) && (11 >= a12)  && (a24==1) || (a15==6) && (a21==8)){
			calculateOutputm30(input);
		}
	//	if((a12 <=  43)  && (a24==1) && (a15==5) || (a21==7)){
	//		calculateOutputm31(input);
	//	}
	}
	
	
	//public String calculateOutputm36(boolean input)
//	{
		
//	}
	
	public String calculateOutput(boolean input) {
	
		if((a12 <=  43 ) && (a24==1) || (a15==6) && (a21==10)){
			calculateOutputm36(input);
		}
		if((43 < a12) && (11 >= a12)  || (a24==1) || (a15==7) || (a21==9)){
			calculateOutputm32(input);
		}
		if((a12 <=  43 ) && (a24==1) || (a15==6) && (a21==8)){
			calculateOutputm33(input);
		}
		if((80 < a12 ) && (a24==1) || (a15==7) || (a21==9)){
			calculateOutputm34(input);
		}
		if((a12 <=  43)  || (a24==1) && (a15==5) && (a21==6)){
			calculateOutputm35(input);
		}
		
		errorCheck();
		 throw new IllegalArgumentException("Current state has not transition for this input!");
	}
	public static void main() throws Exception 
	{
	     // init system and input reader
            Problem14_RERS2012 eca = new Problem14_RERS2012();
        int a=0;
	int x;
        int y;
         
        x = Cute.input.Integer();
        y = Cute.input.Integer();
		boolean input = Cute.input.Boolean();
			// main i/o-loop
            while(a<10) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                	 eca.calculateOutput(input);
					 
				}
				
				if (x>299 && x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutput(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
	}
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=1000
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
