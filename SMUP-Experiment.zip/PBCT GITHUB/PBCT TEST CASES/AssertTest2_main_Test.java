
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class AssertTest2_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public AssertTest2_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(752518635);
        input[i++] = new Integer(1064228561);
        input[i++] = new Integer(685410088);
        input[i++] = new Integer(-363580271);
        input[i++] = new Integer(1759655471);
        input[i++] = new Integer(1703027521);
        input[i++] = new Integer(786169641);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1064228561);
        input[i++] = new Integer(685410088);
        input[i++] = new Integer(-363580271);
        input[i++] = new Integer(1759655471);
        input[i++] = new Integer(1703027521);
        input[i++] = new Integer(786169641);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(685410088);
        input[i++] = new Integer(-363580271);
        input[i++] = new Integer(1759655471);
        input[i++] = new Integer(1703027521);
        input[i++] = new Integer(786169641);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(685410088);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1759655471);
        input[i++] = new Integer(1703027521);
        input[i++] = new Integer(786169641);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(685410088);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1759655471);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(786169641);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(685410088);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1759655471);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1759655471);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test8(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test11(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(150);
        input[i++] = new Integer(9);
        input[i++] = new Integer(10);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test12(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(150);
        input[i++] = new Integer(9);
        input[i++] = new Integer(10);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test14(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(299);
        input[i++] = new Integer(9);
        input[i++] = new Integer(10);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test15(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(9);
        input[i++] = new Integer(10);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test16(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(9);
        input[i++] = new Integer(900);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test17(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(9);
        input[i++] = new Integer(900);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(900);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test19(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(0);
        input[i++] = new Integer(9);
        input[i++] = new Integer(900);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(900);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test20(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(0);
        input[i++] = new Integer(90);
        input[i++] = new Integer(900);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(900);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test25(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(150);
        input[i++] = new Integer(90);
        input[i++] = new Integer(1501);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test26(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(299);
        input[i++] = new Integer(90);
        input[i++] = new Integer(1501);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test37(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(299);
        input[i++] = new Integer(10);
        input[i++] = new Integer(10);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test51(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(0);
        input[i++] = new Integer(90);
        input[i++] = new Integer(10);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test53(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(0);
        input[i++] = new Integer(90);
        input[i++] = new Integer(10);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(900);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test73(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(90);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test75(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(90);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(900);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test177(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(299);
        input[i++] = new Integer(90);
        input[i++] = new Integer(9);
        input[i++] = new Integer(101);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test202(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(150);
        input[i++] = new Integer(10);
        input[i++] = new Integer(900);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test203(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(150);
        input[i++] = new Integer(10);
        input[i++] = new Integer(900);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

    public void test453(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(299);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1501);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        AssertTest2.main(null);
    }

}
