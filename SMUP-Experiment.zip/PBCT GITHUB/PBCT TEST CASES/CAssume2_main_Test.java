
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class CAssume2_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public CAssume2_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-182173240);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(97115174);
        input[i++] = new Integer(-548445941);
        input[i++] = new Integer(554092006);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(97115174);
        input[i++] = new Integer(-548445941);
        input[i++] = new Integer(554092006);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(554092006);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(0);
        input[i++] = new Integer(800);
        input[i++] = new Integer(554092006);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(0);
        input[i++] = new Integer(800);
        input[i++] = new Integer(554092006);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(1);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(0);
        input[i++] = new Integer(800);
        input[i++] = new Integer(554092006);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(100);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(0);
        input[i++] = new Integer(800);
        input[i++] = new Integer(554092006);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test11(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        input[i++] = new Integer(554092006);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test12(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(801);
        input[i++] = new Integer(800);
        input[i++] = new Integer(554092006);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test13(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(801);
        input[i++] = new Integer(800);
        input[i++] = new Integer(554092006);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test18(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(200);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(801);
        input[i++] = new Integer(800);
        input[i++] = new Integer(554092006);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test21(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(800);
        input[i++] = new Integer(800);
        input[i++] = new Integer(800);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test22(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(1001);
        input[i++] = new Integer(1001);
        input[i++] = new Integer(1001);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test25(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test29(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(0);
        input[i++] = new Integer(800);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

    public void test44(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(1327740119);
        input[i++] = new Integer(1001);
        input[i++] = new Integer(1001);
        input[i++] = new Integer(1002);
        i=0;
        cute.Cute.input = this;
        CAssume2.main(null);
    }

}
