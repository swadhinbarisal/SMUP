package jxnct;
import cute.Cute;

/**
 * Author: Koushik Sen <ksen@cs.uiuc.edu>
 */
public class AssertTest2jxnct extends Thread{

    synchronized public void run() {
        try {
            System.out.println("Nothing");
            this.wait();
        } catch (InterruptedException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public static void main(String[] args) {
		int l,m,n,o,p,q,r;
		l=Cute.input.Integer();
		m=Cute.input.Integer();
		n=Cute.input.Integer();
		o=Cute.input.Integer();
		p=Cute.input.Integer();
		q=Cute.input.Integer();
		r=Cute.input.Integer();
//************************Modified code Start***********************************
 if((m>=150)){
if(l<=200){}
else if(!(l<=200)){}
}
else{}
 if((l<=200)){
if(m>=150){}
else if(!(m>=150)){}
}
else{}
//************************Modified code end***********************************
		if((l<=200)||(m>=150))
                {
                    System.out.println("This a new trial");
                }
                else
                    {
//************************Modified code Start***********************************
 if((l>=150)){
if(n!=90){}
else if(!(n!=90)){}
}
else{}
 if((n!=90)){
if(l>=150){}
else if(!(l>=150)){}
}
else{}
//************************Modified code end***********************************
                        if((n!=90)||(l>=150))
                            {
                                System.out.println("This a new trial");
                            }

                    System.out.println("This a not new trial");
                     }


//************************Modified code Start***********************************
 if(!(p>=0)||(q==2000)){
if(o!=9){}
else if(!(o!=9)){}
}
else{}
 if(!(o!=9)||(q==2000)){
if(p>=0){}
else if(!(p>=0)){}
}
else{}
 if((o!=9)&&(p>=0)){
if(q==2000){}
else if(!(q==2000)){}
}
else{}
//************************Modified code end***********************************
                if((o!=9)&&(p>=0)||(q==2000))
                {
                    System.out.println("This a new ...............trial");
                }
//************************Modified code Start***********************************
 if((q==2000)&&(m>=299)&&(p<=100)||(o>=1501)){
if(r!=89){}
else if(!(r!=89)){}
}
else{}
 if((q==2000)&&(m>=299)&&(p<=100)||(r!=89)){
if(o>=1501){}
else if(!(o>=1501)){}
}
else{}
 if(!(m>=299)||!(p<=100)||(o>=1501)||(r!=89)){
if(q==2000){}
else if(!(q==2000)){}
}
else{}
 if(!(q==2000)||!(p<=100)||(o>=1501)||(r!=89)){
if(m>=299){}
else if(!(m>=299)){}
}
else{}
 if(!(q==2000)||!(m>=299)||(o>=1501)||(r!=89)){
if(p<=100){}
else if(!(p<=100)){}
}
else{}
//************************Modified code end***********************************
                if((r!=89)||(o>=1501)||(q==2000)&&(m>=299)&&(p<=100))
                {
                    System.out.println("This a new ...............trial");
                }
//************************Modified code Start***********************************
 if(!(l>=1500)||(m==2000)){
if(n!=9){}
else if(!(n!=9)){}
}
else{}
 if(!(n!=9)||(m==2000)){
if(l>=1500){}
else if(!(l>=1500)){}
}
else{}
 if((n!=9)&&(l>=1500)){
if(m==2000){}
else if(!(m==2000)){}
}
else{}
//************************Modified code end***********************************
                if((n!=9)&&(l>=1500)||(m==2000))
                {
                    System.out.println("This a new ...............trial");
                }
//************************Modified code Start***********************************
 if(!(l>=1500)||!(p==2000)){
if(o!=900){}
else if(!(o!=900)){}
}
else{}
 if(!(o!=900)||!(p==2000)){
if(l>=1500){}
else if(!(l>=1500)){}
}
else{}
 if(!(o!=900)||!(l>=1500)){
if(p==2000){}
else if(!(p==2000)){}
}
else{}
//************************Modified code end***********************************
                if((o!=900)&&(l>=1500)&&(p==2000))
                {
                    System.out.println("This a new ...............trial");
                }
//************************Modified code Start***********************************
 if(!(p>=1500)||!(m==2000)){
if(q!=900){}
else if(!(q!=900)){}
}
else{}
 if(!(q!=900)||!(m==2000)){
if(p>=1500){}
else if(!(p>=1500)){}
}
else{}
 if(!(q!=900)||!(p>=1500)){
if(m==2000){}
else if(!(m==2000)){}
}
else{}
//************************Modified code end***********************************
                if((q!=900)&&(p>=1500)&&(m==2000))
                {
                    System.out.println("This a new ...............trial");
                }


        AssertTest2jxnct at = new AssertTest2jxnct();
        at.start();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
