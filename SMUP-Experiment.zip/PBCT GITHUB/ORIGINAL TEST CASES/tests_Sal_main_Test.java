
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class tests_Sal_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public tests_Sal_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[1];
        input[i++] = new Integer(-602314105);
        i=0;
        cute.Cute.input = this;
        tests.Sal.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[1];
        input[i++] = new Integer(20000);
        i=0;
        cute.Cute.input = this;
        tests.Sal.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[1];
        input[i++] = new Integer(10000);
        i=0;
        cute.Cute.input = this;
        tests.Sal.main(null);
    }

}
