package jxnct;

import cute.Cute;

public class Problem5RVjxnct {
	
	private String[] inputs = {"E","F","A","G","B","H","C","I","J","D"};

	
	public int a583 =Cute.input.Integer();
	public int a202 =Cute.input.Integer();
	public int a368 = Cute.input.Integer();
	public int a362 =Cute.input.Integer();
	public int a318 =Cute.input.Integer();
	public int a586 =Cute.input.Integer();
	public int a50 =Cute.input.Integer();
	public int a153 =Cute.input.Integer();
	public int a587 =Cute.input.Integer();
	public int a22 =Cute.input.Integer();
	public int a214 =Cute.input.Integer();
	public int a389 =Cute.input.Integer();
	public int a398 = Cute.input.Integer();
	public int a84 =Cute.input.Integer();
	public int a351 =Cute.input.Integer();
	public int a360 = Cute.input.Integer();
	public int a112 =Cute.input.Integer();
	public int a120 =Cute.input.Integer();
	public int a175 =Cute.input.Integer();
	public int a78 =Cute.input.Integer();
	public int a261 = Cute.input.Integer();
	public int a400 =Cute.input.Integer();
	public int a349 =Cute.input.Integer();
	public int a317 =Cute.input.Integer();
	public int a83 =Cute.input.Integer();
	public int a146 =Cute.input.Integer();
	public int a314 =Cute.input.Integer();
	public int a337 =Cute.input.Integer();
	public int a178 =Cute.input.Integer();
	public int a467 =Cute.input.Integer();
	public int a26 = Cute.input.Integer();
	public int a358 = Cute.input.Integer();
	public int a119 =Cute.input.Integer();
	public int a336 =Cute.input.Integer();
	public int a135 =Cute.input.Integer();
	public int a81 = Cute.input.Integer();
	public int a197 =Cute.input.Integer();
	public int a103 =Cute.input.Integer();
	public int a307 =Cute.input.Integer();
	public int a448 =Cute.input.Integer();
	public int a378 =Cute.input.Integer();
	public int a596 =Cute.input.Integer();
	public int a325 =Cute.input.Integer();
	public int a287 = Cute.input.Integer();
	public int a199 =Cute.input.Integer();
	public int a597 =Cute.input.Integer();
	public int a340 =Cute.input.Integer();
	public int a100 =Cute.input.Integer();
	public int a383 =Cute.input.Integer();
	public int a16 =Cute.input.Integer();
	public int a38 = Cute.input.Integer();
	public int a545 =Cute.input.Integer();
	public int a225 =Cute.input.Integer();
	public int a60 = Cute.input.Integer();
	public int a579 =Cute.input.Integer();
	public int a73 =Cute.input.Integer();
	public int a245 =Cute.input.Integer();
	public int a371 =Cute.input.Integer();
	public int a385 =Cute.input.Integer();
	public int a151 =Cute.input.Integer();
	public int a59 =Cute.input.Integer();
	public int a44 =Cute.input.Integer();
	public int a510 =Cute.input.Integer();
	public int a284 =Cute.input.Integer();
	public int a288 =Cute.input.Integer();
	public int a61 =Cute.input.Integer();
	public int a327 =Cute.input.Integer();
	public int a17 = Cute.input.Integer();
	public int a598 =Cute.input.Integer();
	public int a82 =Cute.input.Integer();
	public int a483 =Cute.input.Integer();
	public int a518 =Cute.input.Integer();
	public int a237 =Cute.input.Integer();
	public int a37 =Cute.input.Integer();
	public int a384 = Cute.input.Integer();
	public int a279 = Cute.input.Integer();
	public int a406 =Cute.input.Integer();
	public int a299 =Cute.input.Integer();
	public int a446 =Cute.input.Integer();
	public int a565 =Cute.input.Integer();
	public int a387 = Cute.input.Integer();
	public int a322 = Cute.input.Integer();
	public int a264 = Cute.input.Integer();
	public int a290 =Cute.input.Integer();
	public int a207 =Cute.input.Integer();
	public int a278 =Cute.input.Integer();
	public int a211 =Cute.input.Integer();
	public int a155 =Cute.input.Integer();
	public int a190 =Cute.input.Integer();
	public int a114 = Cute.input.Integer();
	public int a226 =Cute.input.Integer();
	public int a239 =Cute.input.Integer();
	public int a193 = Cute.input.Integer();
	public int a219 =Cute.input.Integer();
	public int a66 =Cute.input.Integer();
	public int a265 =Cute.input.Integer();
	public int a241 =Cute.input.Integer();
	public int a86 =Cute.input.Integer();
	public int a294 = Cute.input.Integer();
	public int a232 =Cute.input.Integer();
	public int a72 = Cute.input.Integer();
	public int a209 =Cute.input.Integer();
	public int a527 =Cute.input.Integer();
	public int a260 = Cute.input.Integer();
	public int a141 = Cute.input.Integer();
	public int a242 =Cute.input.Integer();
	public int a366 =Cute.input.Integer();
	public int a350 = Cute.input.Integer();
	public int a210 = Cute.input.Integer();
	public int a148 =Cute.input.Integer();
	public int a303 =Cute.input.Integer();
	public int a248 =Cute.input.Integer();
	public int a184 =Cute.input.Integer();
	public int a341 =Cute.input.Integer();
	public int a370 =Cute.input.Integer();
	public int a41 = Cute.input.Integer();
	public int a271 =Cute.input.Integer();
	public int a355 = Cute.input.Integer();
	public int a8 =Cute.input.Integer();
	public int a339 =Cute.input.Integer();
	public int a257 =Cute.input.Integer();
	public int a273 =Cute.input.Integer();
	public int a430 =Cute.input.Integer();
	public int a422 =Cute.input.Integer();
	public int a222 = Cute.input.Integer();
	public int a93 = Cute.input.Integer();
	public int a277 =Cute.input.Integer();
	public int a206 = Cute.input.Integer();
	public int a508 =Cute.input.Integer();
	public int a274 = Cute.input.Integer();
	public int a18 =Cute.input.Integer();
	public int a305 = Cute.input.Integer();
	public int a393 = Cute.input.Integer();
	public int a11 =Cute.input.Integer();
	public int a1 =Cute.input.Integer();
	public int a286 =Cute.input.Integer();
	public int a296 =Cute.input.Integer();
	public int a373 =Cute.input.Integer();
	public int a361 =Cute.input.Integer();
	public int a158 = Cute.input.Integer();
	public int a289 =Cute.input.Integer();
	public int a582 =Cute.input.Integer();
	public int a188 =Cute.input.Integer();
	public int a297 =Cute.input.Integer();
	public int a181 =Cute.input.Integer();
	public int a313 =Cute.input.Integer();
	public int a127 =Cute.input.Integer();
	public int a159 = Cute.input.Integer();
	public int a180 = Cute.input.Integer();
	public int a348 = Cute.input.Integer();
	public int a374 = Cute.input.Integer();
	public int a117 =Cute.input.Integer();
	public int a229 = Cute.input.Integer();
	public int a130 =Cute.input.Integer();
	public int a185 =Cute.input.Integer();
	public int a92 =Cute.input.Integer();
	public int a74 =Cute.input.Integer();
	public int a109 =Cute.input.Integer();
	public int a107 =Cute.input.Integer();
	public int a101 =Cute.input.Integer();
	public int a14 =Cute.input.Integer();
	public int a24 =Cute.input.Integer();
	public int a111 =Cute.input.Integer();
	public int a30 =Cute.input.Integer();
	public int a171 =Cute.input.Integer();
	public int a98 =Cute.input.Integer();
	public int a194 =Cute.input.Integer();
	public int a169 =Cute.input.Integer();
	public int a68 =Cute.input.Integer();
	public int a132 =Cute.input.Integer();
	public int a34 =Cute.input.Integer();
	public int a25 =Cute.input.Integer();
	public int a54 =Cute.input.Integer();
	public int a40 =Cute.input.Integer();
	public int a63 =Cute.input.Integer();
	public int a192 =Cute.input.Integer();
	public int a55 =Cute.input.Integer();
	public int a166 =Cute.input.Integer();
	public int a79 =Cute.input.Integer();
	public int a145 =Cute.input.Integer();
	public int a191 =Cute.input.Integer();
	
	
	
	public boolean a19 = Cute.input.Boolean();
	public boolean a47 = Cute.input.Boolean();
	public boolean cf = Cute.input.Boolean();
	public boolean a324 = Cute.input.Boolean();
	public boolean a250 = Cute.input.Boolean();
	public boolean a272 = Cute.input.Boolean();
	public boolean a262 = Cute.input.Boolean();
	public boolean a401 = Cute.input.Boolean();
	public boolean a344 = Cute.input.Boolean();
	public boolean a270 = Cute.input.Boolean();
	public boolean a333 = Cute.input.Boolean();
	public boolean a204 = Cute.input.Boolean();
	public boolean a395 = Cute.input.Boolean();
	public boolean a258 = Cute.input.Boolean();
	public boolean a397 = Cute.input.Boolean();
	public boolean a320 = Cute.input.Boolean();
	public boolean a363 = Cute.input.Boolean();
	public boolean a331 = Cute.input.Boolean();
	public boolean a365 = Cute.input.Boolean();
	public boolean a253 = Cute.input.Boolean();
	public boolean a293 = Cute.input.Boolean();
	public boolean a23 = Cute.input.Boolean();
	public boolean a139 = Cute.input.Boolean();
	public boolean a149 = Cute.input.Boolean();
	public boolean a399 = Cute.input.Boolean();
	public boolean a97 = Cute.input.Boolean();
	public boolean a283 = Cute.input.Boolean();
	public boolean a308 = Cute.input.Boolean();
	public boolean a233 = Cute.input.Boolean();
	public boolean a285 = Cute.input.Boolean();
	public boolean a221 = Cute.input.Boolean();
	public boolean a215 = Cute.input.Boolean();
	public boolean a208 = Cute.input.Boolean();
	public boolean a244 = Cute.input.Boolean();
	public boolean a224 = Cute.input.Boolean();
	public boolean a329 = Cute.input.Boolean();
	public boolean a267 = Cute.input.Boolean();
	public boolean a186 = Cute.input.Boolean();
	public boolean a386 = Cute.input.Boolean();
	public boolean a133 = Cute.input.Boolean();
	public boolean a106 = Cute.input.Boolean();
	public boolean a27 = Cute.input.Boolean();
	public boolean a157 = Cute.input.Boolean();
	public boolean a90 = Cute.input.Boolean();
	public boolean a309 = Cute.input.Boolean();
	public boolean a311 = Cute.input.Boolean();
	public boolean a118 = Cute.input.Boolean();
	public boolean a104 = Cute.input.Boolean();
	public boolean a298 = Cute.input.Boolean();
	public boolean a176 = Cute.input.Boolean();
	public boolean a123 = Cute.input.Boolean();
	
	
	 public int a377 = Cute.input.Integer();
	public int a234 =Cute.input.Integer();
	public int a174 =Cute.input.Integer();
	public int a52= Cute.input.Integer();
	public int a144 =Cute.input.Integer();
	public int a391 = Cute.input.Integer();
	public int a2 = Cute.input.Integer();
	public int a354 = Cute.input.Integer();
	public int a223 = Cute.input.Integer();
	public int a108 = Cute.input.Integer();
	public int a310 = Cute.input.Integer();
	public int a359 = Cute.input.Integer();
	public int a292 = Cute.input.Integer();
	public int a21 = Cute.input.Integer();
	public int a189 = Cute.input.Integer();
	public int a330 = Cute.input.Integer();
	public int a57 = Cute.input.Integer();
	public int a177 = Cute.input.Integer();
	public int a390 = Cute.input.Integer();
	public int a218 = Cute.input.Integer();
	public int a85 = Cute.input.Integer();
	public int a51 =Cute.input.Integer();
	public int a213 = Cute.input.Integer();
	public int a312 = Cute.input.Integer();
	public int a70 = Cute.input.Integer();
	public int a201 = Cute.input.Integer();
	public int a142 = Cute.input.Integer();
	public int a315 =Cute.input.Integer();
	public int a58 = Cute.input.Integer();


	public void update61(int a, int b, int c)
	{
		a312 = ((a + b) + c);
	}

	public void update62(int a, int b, int c)
	{
		a218 = ((a + b) + c);
	}

	public void update105(int a, int b, int c)
	{
		a177 = ((a * b) - c);
	}

	public void update106(int a, int b, int c)
	{
		a51 = ((a - b) - c);
	}

	public void update47(int a, int b, int c)
	{
		a391 = ((a / b) - c);
	}

	public void update48(int a, int b, int c)
	{
		a58 = ((a - b) + c);
	}

	public void update41(int a, int b, int c)
	{
		a85 = ((a + b) - c);
	}

	public void update42(int a, int b, int c)
	{
		a189 = ((a / b) + c);
	}

	public void update7(int a, int b, int c)
	{
		a58 = ((a / b) - c);
	}

	public void update8(int a, int b, int c)
	{
		a174 = ((a - b) + c);
	}

	public void update103(int a, int b, int c)
	{
		a223 = ((a / b) + c);
	}

	public void update104(int a, int b, int c)
	{
		a142 = ((a / b) - c);
	}

	public void update33(int a, int b, int c)
	{
		a218 = ((a / b) + c);
	}

	public void update34(int a, int b, int c)
	{
		a223 = ((a - b) + c);
	}

	public void update67(int a, int b, int c)
	{
		a51 = ((a + b) + c);
	}

	public void update68(int a, int b, int c)
	{
		a359 = ((a * b) + c);
	}

	public void update65(int a, int b, int c)
	{
		a330 = ((a / b) + c);
	}

	public void update66(int a, int b, int c)
	{
		a292 = ((a / b) - c);
	}

	public void update51(int a, int b, int c)
	{
		a51 = ((a * b) + c);
	}

	public void update52(int a, int b, int c)
	{
		a213 = ((a + b) - c);
	}

	public void update63(int a, int b, int c)
	{
		a58 = ((a * b) - c);
	}

	public void update64(int a, int b, int c)
	{
		a292 = ((a + b) - c);
	}

	public void update81(int a, int b, int c)
	{
		a189 = ((a / b) - c);
	}

	public void update82(int a, int b, int c)
	{
		a142 = ((a + b) - c);
	}

	public void update69(int a, int b, int c)
	{
		a330 = ((a - b) + c);
	}

	public void update70(int a, int b, int c)
	{
		a315 = ((a - b) + c);
	}

	public void update53(int a, int b, int c)
	{
		a223 = ((a - b) - c);
	}

	public void update54(int a, int b, int c)
	{
		a354 = ((a * b) + c);
	}

	public void update49(int a, int b, int c)
	{
		a359 = ((a - b) - c);
	}

	public void update50(int a, int b, int c)
	{
		a354 = ((a / b) + c);
	}

	public void update99(int a, int b, int c)
	{
		a21 = ((a - b) - c);
	}

	public void update100(int a, int b, int c)
	{
		a292 = ((a / b) + c);
	}

	public void update13(int a, int b, int c)
	{
		a51 = ((a * b) + c);
	}

	public void update14(int a, int b, int c)
	{
		a213 = ((a + b) - c);
	}

	public void update31(int a, int b, int c)
	{
		a330 = ((a / b) + c);
	}

	public void update32(int a, int b, int c)
	{
		a234 = ((a + b) + c);
	}

	public void update73(int a, int b, int c)
	{
		a312 = ((a - b) - c);
	}

	public void update74(int a, int b, int c)
	{
		a391 = ((a - b) - c);
	}

	public void update55(int a, int b, int c)
	{
		a354 = ((a * b) - c);
	}

	public void update56(int a, int b, int c)
	{
		a52 = ((a / b) + c);
	}

	public void update11(int a, int b, int c)
	{
		a85 = ((a * b) + c);
	}

	public void update12(int a, int b, int c)
	{
		a312 = ((a + b) - c);
	}

	public void update35(int a, int b, int c)
	{
		a391 = ((a + b) + c);
	}

	public void update36(int a, int b, int c)
	{
		a142 = ((a * b) - c);
	}

	public void update57(int a, int b, int c)
	{
		a390 = ((a - b) + c);
	}

	public void update58(int a, int b, int c)
	{
		a292 = ((a / b) - c);
	}

	public void update75(int a, int b, int c)
	{
		a51 = ((a + b) + c);
	}

	public void update76(int a, int b, int c)
	{
		a310 = ((a - b) + c);
	}

	public void update89(int a, int b, int c)
	{
		a390 = ((a * b) + c);
	}

	public void update90(int a, int b, int c)
	{
		a218 = ((a / b) + c);
	}

	public void update27(int a, int b, int c)
	{
		a315 = ((a - b) + c);
	}

	public void update28(int a, int b, int c)
	{
		a201 = ((a / b) + c);
	}

	public void update43(int a, int b, int c)
	{
		a174 = ((a * b) + c);
	}

	public void update44(int a, int b, int c)
	{
		a142 = ((a + b) - c);
	}

	public void update83(int a, int b, int c)
	{
		a51 = ((a / b) - c);
	}

	public void update84(int a, int b, int c)
	{
		a189 = ((a + b) - c);
	}

	public void update9(int a, int b, int c)
	{
		a52 = ((a + b) - c);
	}

	public void update10(int a, int b, int c)
	{
		a57 = ((a + b) - c);
	}

	
	
	
	private void errorCheck() {
//************************Modified code Start***********************************
 if((a100==0)||(a297==0)&&(a289==01)){
if(a22==0){}
else if(!(a22==0)){}
}
else{}
 if(!(a289==01)||(a100==0)||(a22==0)){
if(a297==0){}
else if(!(a297==0)){}
}
else{}
 if(!(a297==0)||(a100==0)||(a22==0)){
if(a289==01){}
else if(!(a289==01)){}
}
else{}
 if((a297==0)&&(a289==01)||(a22==0)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a22 ==0) || (a297 ==0) && (a289 ==01) || (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_0" );
	    }
//************************Modified code Start***********************************
 if(!(a103==0)||(a100==0)){
if(a127==0){}
else if(!(a127==0)){}
}
else{}
 if(!(a127==0)||(a100==0)){
if(a103==0){}
else if(!(a103==0)){}
}
else{}
 if((a127==0)&&(a103==0)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a127 ==0) && (a103 ==0) || (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_1" );
	    }
//************************Modified code Start***********************************
 if(!(57>=a72)||(106>=a114)||(55<a114)){
if(2<a72){}
else if(!(2<a72)){}
}
else{}
 if(!(2<a72)||(106>=a114)||(55<a114)){
if(57>=a72){}
else if(!(57>=a72)){}
}
else{}
 if((106>=a114)||(2<a72)&&(57>=a72)){
if(55<a114){}
else if(!(55<a114)){}
}
else{}
 if((55<a114)||(2<a72)&&(57>=a72)){
if(106>=a114){}
else if(!(106>=a114)){}
}
else{}
//************************Modified code end***********************************
	    if((2 < a72) && (57 >= a72) || (55 < a114) || (106 >= a114) ){
	    	cf = false;
	    	throw new IllegalStateException( "error_2" );
	    }
//************************Modified code Start***********************************
 if(!(a289==0)||(a100==0)){
if(a153==01){}
else if(!(a153==01)){}
}
else{}
 if(!(a153==01)||(a100==0)){
if(a289==0){}
else if(!(a289==0)){}
}
else{}
 if((a153==01)&&(a289==0)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a153 ==01) && (a289 ==0) || (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_3" );
	    }
//************************Modified code Start***********************************
 if((a100==0)||(a371==0)&&(a16==0)){
if(94<a180){}
else if(!(94<a180)){}
}
else{}
 if(!(a16==0)||(a100==0)||(94<a180)){
if(a371==0){}
else if(!(a371==0)){}
}
else{}
 if(!(a371==0)||(a100==0)||(94<a180)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
 if((a371==0)&&(a16==0)||(94<a180)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((94 < a180) || (a371==0) && (a16 ==0) || (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_4" );
	    }
//************************Modified code Start***********************************
 if(!(331<a274)||(a103==0)&&(a100==0)){
if(a340==06){}
else if(!(a340==06)){}
}
else{}
 if(!(a340==06)||(a103==0)&&(a100==0)){
if(331<a274){}
else if(!(331<a274)){}
}
else{}
 if(!(a100==0)||(a340==06)&&(331<a274)){
if(a103==0){}
else if(!(a103==0)){}
}
else{}
 if(!(a103==0)||(a340==06)&&(331<a274)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a340 ==06) && (331 < a274) || (a103 ==0) && (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_5" );
	    }
//************************Modified code Start***********************************
 if((303>=a141)||(a339==0)&&(140<a141)){
if(a239==0){}
else if(!(a239==0)){}
}
else{}
 if(!(140<a141)||(303>=a141)||(a239==0)){
if(a339==0){}
else if(!(a339==0)){}
}
else{}
 if(!(a339==0)||(303>=a141)||(a239==0)){
if(140<a141){}
else if(!(140<a141)){}
}
else{}
 if((a339==0)&&(140<a141)||(a239==0)){
if(303>=a141){}
else if(!(303>=a141)){}
}
else{}
//************************Modified code end***********************************
	    if((a239 ==0) || (a339==0) && (140 < a141) || (303 >= a141)){
	    	cf = false;
	    	throw new IllegalStateException( "error_6" );
	    }
//************************Modified code Start***********************************
 if(!(a59==02)||(a100==0)){
if(352<a159){}
else if(!(352<a159)){}
}
else{}
 if(!(352<a159)||(a100==0)){
if(a59==02){}
else if(!(a59==02)){}
}
else{}
 if((352<a159)&&(a59==02)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((352 < a159) && (a59 ==02) || (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_7" );
	    }
//************************Modified code Start***********************************
 if((a103==0)||(191>=a274)||(5<a274)){
if(a118==true){}
else if(!(a118==true)){}
}
else{}
 if((a103==0)||(191>=a274)||(a118==true)){
if(5<a274){}
else if(!(5<a274)){}
}
else{}
 if((a103==0)||(5<a274)||(a118==true)){
if(191>=a274){}
else if(!(191>=a274)){}
}
else{}
 if((191>=a274)||(5<a274)||(a118==true)){
if(a103==0){}
else if(!(a103==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a118==true) || (5 < a274) || (191 >= a274) || (a103 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_8" );
	    }
//************************Modified code Start***********************************
 if(!(a127==0)||(a100==0)||(a103==0)){
if(a151==0){}
else if(!(a151==0)){}
}
else{}
 if(!(a151==0)||(a100==0)||(a103==0)){
if(a127==0){}
else if(!(a127==0)){}
}
else{}
 if((a100==0)||(a151==0)&&(a127==0)){
if(a103==0){}
else if(!(a103==0)){}
}
else{}
 if((a103==0)||(a151==0)&&(a127==0)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a151==0) && (a127 ==0) || (a103 ==0) || (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_9" );
	    }
//************************Modified code Start***********************************
 if((a16==0)&&(a100==0)||(a351==03)){
if(a38<=14){}
else if(!(a38<=14)){}
}
else{}
 if((a16==0)&&(a100==0)||(a38<=14)){
if(a351==03){}
else if(!(a351==03)){}
}
else{}
 if(!(a100==0)||(a351==03)||(a38<=14)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
 if(!(a16==0)||(a351==03)||(a38<=14)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a38 <=  14) || (a351 ==03) || (a16 ==0) && (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_10" );
	    }
//************************Modified code Start***********************************
 if(!(a383==0)||(a100==0)||(a103==0)){
if(a237==02){}
else if(!(a237==02)){}
}
else{}
 if(!(a237==02)||(a100==0)||(a103==0)){
if(a383==0){}
else if(!(a383==0)){}
}
else{}
 if((a100==0)||(a237==02)&&(a383==0)){
if(a103==0){}
else if(!(a103==0)){}
}
else{}
 if((a103==0)||(a237==02)&&(a383==0)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a237 ==02) && (a383 ==0) || (a103 ==0) || (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_11" );
	    }
//************************Modified code Start***********************************
 if((73>=a261)&&(a274<=5)&&(a103==0)){
if(6<a261){}
else if(!(6<a261)){}
}
else{}
 if(!(a274<=5)||!(a103==0)||(6<a261)){
if(73>=a261){}
else if(!(73>=a261)){}
}
else{}
 if(!(73>=a261)||!(a103==0)||(6<a261)){
if(a274<=5){}
else if(!(a274<=5)){}
}
else{}
 if(!(73>=a261)||!(a274<=5)||(6<a261)){
if(a103==0){}
else if(!(a103==0)){}
}
else{}
//************************Modified code end***********************************
	    if((6 < a261) || (73 >= a261) && (a274 <=  5) && (a103 ==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_12" );
	    }
//************************Modified code Start***********************************
 if((a289==01)&&(a100==0)){
if(a297==0){}
else if(!(a297==0)){}
}
else{}
 if(!(a100==0)||(a297==0)){
if(a289==01){}
else if(!(a289==01)){}
}
else{}
 if(!(a289==01)||(a297==0)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a297 ==0) || (a289 ==01) && (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_13" );
	    }
//************************Modified code Start***********************************
 if((a16==0)&&(a100==0)){
if(a258==true){}
else if(!(a258==true)){}
}
else{}
 if(!(a100==0)||(a258==true)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
 if(!(a16==0)||(a258==true)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a258==true) ||  (a16 ==0) && (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_14" );
	    }
//************************Modified code Start***********************************
 if(!(a103==0)||(a100==0)){
if(a146==0){}
else if(!(a146==0)){}
}
else{}
 if(!(a146==0)||(a100==0)){
if(a103==0){}
else if(!(a103==0)){}
}
else{}
 if((a146==0)&&(a103==0)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a146==0) && (a103 ==0) || (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_15" );
	    }
//************************Modified code Start***********************************
 if(!(224>=a114)||(a100==0)||(a289==0)){
if(106<a114){}
else if(!(106<a114)){}
}
else{}
 if(!(106<a114)||(a100==0)||(a289==0)){
if(224>=a114){}
else if(!(224>=a114)){}
}
else{}
 if((a100==0)||(106<a114)&&(224>=a114)){
if(a289==0){}
else if(!(a289==0)){}
}
else{}
 if((a289==0)||(106<a114)&&(224>=a114)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((106 < a114) && (224 >= a114) || (a289 ==0) || (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_16" );
	    }
//************************Modified code Start***********************************
 if(!(a289==00)||(a100==0)){
if(a273==0){}
else if(!(a273==0)){}
}
else{}
 if(!(a273==0)||(a100==0)){
if(a289==00){}
else if(!(a289==00)){}
}
else{}
 if((a273==0)&&(a289==00)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a273==0) && (a289 ==00) || (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_17" );
	    }
//************************Modified code Start***********************************
 if(!(a289==0)||(a100==0)){
if(a175==0){}
else if(!(a175==0)){}
}
else{}
 if(!(a175==0)||(a100==0)){
if(a289==0){}
else if(!(a289==0)){}
}
else{}
 if((a175==0)&&(a289==0)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a175==0) && (a289 ==0) || (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_18" );
	    }
//************************Modified code Start***********************************
 if((a289==0)&&(a100==0)){
if(a340==05){}
else if(!(a340==05)){}
}
else{}
 if(!(a100==0)||(a340==05)){
if(a289==0){}
else if(!(a289==0)){}
}
else{}
 if(!(a289==0)||(a340==05)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a340 ==05) || (a289 ==0) && (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_19" );
	    }
//************************Modified code Start***********************************
 if((a16==0)&&(a100==0)||(a314==00)){
if(a11==07){}
else if(!(a11==07)){}
}
else{}
 if((a16==0)&&(a100==0)||(a11==07)){
if(a314==00){}
else if(!(a314==00)){}
}
else{}
 if(!(a100==0)||(a314==00)||(a11==07)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
 if(!(a16==0)||(a314==00)||(a11==07)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a11 ==07) || (a314 ==00) || (a16 ==0) && (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_20" );
	    }
//************************Modified code Start***********************************
 if((a100==0)||(a117==0)&&(a103==0)){
if(a351==0){}
else if(!(a351==0)){}
}
else{}
 if(!(a103==0)||(a100==0)||(a351==0)){
if(a117==0){}
else if(!(a117==0)){}
}
else{}
 if(!(a117==0)||(a100==0)||(a351==0)){
if(a103==0){}
else if(!(a103==0)){}
}
else{}
 if((a117==0)&&(a103==0)||(a351==0)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a351 ==0) || (a117==0) && (a103 ==0) || (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_21" );
	    }
//************************Modified code Start***********************************
 if(!(a16==0)||(a100==0)||(a289==0)){
if(a82==0){}
else if(!(a82==0)){}
}
else{}
 if(!(a82==0)||(a100==0)||(a289==0)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
 if((a100==0)||(a82==0)&&(a16==0)){
if(a289==0){}
else if(!(a289==0)){}
}
else{}
 if((a289==0)||(a82==0)&&(a16==0)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a82 ==0) && (a16 ==0) || (a289 ==0) || (a100==0)){
			cf = false;
	    	throw new IllegalStateException( "error_22" );
			
	    }
//************************Modified code Start***********************************
 if(!(a8==02)||(a100==0)||(a103==00)){
if(a26<=135){}
else if(!(a26<=135)){}
}
else{}
 if(!(a26<=135)||(a100==0)||(a103==00)){
if(a8==02){}
else if(!(a8==02)){}
}
else{}
 if((a100==0)||(a26<=135)&&(a8==02)){
if(a103==00){}
else if(!(a103==00)){}
}
else{}
 if((a103==00)||(a26<=135)&&(a8==02)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a26 <=  135) && (a8 ==02) || (a103 ==00) || (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_23" );
	    }
//************************Modified code Start***********************************
 if(!(a289==01)||(a100==0)){
if(a297==0){}
else if(!(a297==0)){}
}
else{}
 if(!(a297==0)||(a100==0)){
if(a289==01){}
else if(!(a289==01)){}
}
else{}
 if((a297==0)&&(a289==01)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a297 ==0) && (a289 ==01) || (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_24" );
	    }
//************************Modified code Start***********************************
 if((a16==0)&&(a100==0)){
if(a314==0){}
else if(!(a314==0)){}
}
else{}
 if(!(a100==0)||(a314==0)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
 if(!(a16==0)||(a314==0)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a314 ==0) || (a16 ==0) && (a100==0)){
	    	cf = false;
	    	throw new IllegalStateException( "error_25" );
	    }
	    
		
}


private  void calculateOutputm2(boolean input) {
//************************Modified code Start***********************************
 if((cf==true)||(a278==00)&&(a100==0)){
if(input==true){}
else if(!(input==true)){}
}
else{}
 if(!(a100==0)||(cf==true)||(input==true)){
if(a278==00){}
else if(!(a278==00)){}
}
else{}
 if(!(a278==00)||(cf==true)||(input==true)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
 if((a278==00)&&(a100==0)||(input==true)){
if(cf==true){}
else if(!(cf==true)){}
}
else{}
//************************Modified code end***********************************
    if((input==true) || (a278 ==00) && (a100==0) || (cf==true) ){
    	cf = false;
    	a59 = ((a16 / a318) + 11);
    	a586 = 1;
    	a248 = a361;
    	a483 = 1;
    	a508 = 0;
    	a100 = 1;
    	a265 = (a362 + 9);
    	a244 = false;
         update57(a362,a209,12);
    	a159 = (((((92 * 10) / 9) + -1) - 3169) + 3282);
    	a206 = (((((((a294 * a348) % 14999) % 83) - -203) * 1) + -16801) - -16799);
    	a202 = (a362 - -4);
    	a565 = 1;
    	a272 = true;
    	a430 = 0;
    	a222 = ((((((a222 * a206) % 14999) % 27) - -297) - -8352) + -8353);
    	a250 = true;
    	a318 = (a59 - 8);
    	a387 = ((((((a387 * a260) % 14999) % 43) + 88) + 2) * 1);
    	a362 = ((a209 + a288) + -10);
    	a210 = (((((((a210 * a336) % 14999) * 2) % 74) - -212) / 5) - -160);
    	a209 = ((a290 / a361) + 5);
    	a336 = ((((((a336 * a398) % 14999) - -8222) / 5) % 103) + 110); 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm4(boolean input) {
//************************Modified code Start***********************************
 if((a100==0)&&(a583==0)||(a344==true)){
if(a318==0){}
else if(!(a318==0)){}
}
else{}
 if((a100==0)&&(a583==0)||(a318==0)){
if(a344==true){}
else if(!(a344==true)){}
}
else{}
 if(!(a583==0)||(a344==true)||(a318==0)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
 if(!(a100==0)||(a344==true)||(a318==0)){
if(a583==0){}
else if(!(a583==0)){}
}
else{}
//************************Modified code end***********************************
    if((a318 ==0) || (a344==true) || (a100==0) && (a583==0) ){
    	a74 += (a74 + 20) > a74 ? 2 : 0;
    	cf = false;
    	 update84(a325,a307,13);
    	a100 = 13;
    	a103 = (a16 + 2);
    	 update13(a103,a16,-5); 
    	System.out.println("X");
    } 
}
private  void calculateOutputm10(boolean input) {
//************************Modified code Start***********************************
 if(!(a398<=2)||!(a232<=70)||(cf==true)){
if(input==true){}
else if(!(input==true)){}
}
else{}
 if(!(input==true)||!(a232<=70)||(cf==true)){
if(a398<=2){}
else if(!(a398<=2)){}
}
else{}
 if(!(input==true)||!(a398<=2)||(cf==true)){
if(a232<=70){}
else if(!(a232<=70)){}
}
else{}
 if((input==true)&&(a398<=2)&&(a232<=70)){
if(cf==true){}
else if(!(cf==true)){}
}
else{}
//************************Modified code end***********************************
    if((input==true) && (a398 <=  2) && (a232 <=  70) || (cf==true)){
    	cf = false;
    	a318 = ((a370 / a211) + 4);
    	a518 = 0;
    	a272 = false;
    	a215 = false;
    	a398 = (((((((a398 * a287) % 14999) % 17) - -20) + 20989) / 5) + -4184);
    	a582 = 0;
    	a313 = (a278 - 3);
    	a370 = (a313 + -4);
    	a289 = ((a16 + a239) + -3);
    	a385 = ((a202 + a366) + -4);
    	a508 = 0;
    	a232 = (((((((a232 * a287) % 14999) % 27) + -42) - 11683) - 263) - -11945);
    	a211 = (a385 + -1);
    	a100 = 0;
    	a153 = (a289 + 8);
    	a395 = false;
    	a248 = (a307 - 3);
    	a127 = (a153 + -7); 
    	System.out.println("W");
    } 
}
private  void calculateOutputm11(boolean input) {
//************************Modified code Start***********************************
 if((a239==0)||(a100==0)||(a386==false)){
if(a320==true){}
else if(!(a320==true)){}
}
else{}
 if((a239==0)||(a100==0)||(a320==true)){
if(a386==false){}
else if(!(a386==false)){}
}
else{}
 if((a239==0)||(a386==false)||(a320==true)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
 if((a100==0)||(a386==false)||(a320==true)){
if(a239==0){}
else if(!(a239==0)){}
}
else{}
//************************Modified code end***********************************
    if((a320==true) || (a386==false) || (a100==0) || (a239 ==0)){
    	a169 += (a169 + 20) > a169 ? 2 : 0;
    	cf = false;
    	a127 = ((a209 - a209) - -11);
    	a209 = (a361 + 3);
    	a597 = 1;
    	a518 = 0;
    	a483 = 0;
    	a219 = (a239 - 1);
    	a103 = (a361 - -5);
    	a430 = 0;
    	a313 = (a16 + 4);
    	a545 = 1;
    	a508 = 0;
    	a510 = 0;
    	a386 = false;
    	a582 = 0;
    	a279 = ((((((((a279 * a360) % 14999) % 54) - -95) / 5) / 5) * 239) / 10);
    	a1 = ((a127 + a307) - 7);
    	a100 = 13;
    	a307 = ((a248 - a265) - -14);
    	a325 = (a299 - -8); 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm14(boolean input) {
//************************Modified code Start***********************************
 if((a100==0)||(a16==0)||(a362==0)){
if(a260<=108){}
else if(!(a260<=108)){}
}
else{}
 if((a100==0)||(a16==0)||(a260<=108)){
if(a362==0){}
else if(!(a362==0)){}
}
else{}
 if((a100==0)||(a362==0)||(a260<=108)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
 if((a16==0)||(a362==0)||(a260<=108)){
if(a100==0){}
else if(!(a100==0)){}
}
else{}
//************************Modified code end***********************************
    if((a260 <=  108) || (a362 ==0) || (a16 ==0) || (a100==0)){
    	a130 -= (a130 - 20) < a130 ? 3 : 0;
    	cf = false;
    	a350 = (((((((a260 * a264) % 14999) + -10180) % 48) - -307) + 23624) - 23624);
    	a204 = false;
    	a59 = (a373 - -7);
    	a159 = ((((((a384 * a384) % 14999) - -3348) * 1) % 73) + 170);
    	a272 = false;
    	a287 = (((((((a287 * a398) % 14999) + -2150) % 105) + -45) - 21721) + 21720);
    	a248 = (a325 + -7);
    	a508 = 0;
    	a290 = ((a325 - a362) + -3);
    	a100 = 1;
    	a430 = 0;
    	a483 = 1;
    	a422 = 0;
    	a348 = (((((((a348 * a159) % 14999) % 77) - -328) - 1) - -7580) - 7578);
    	a222 = ((((((a222 * a350) % 14999) * 2) % 70) + 196) - 0);
    	a398 = ((((((((a294 * a384) % 14999) % 80) + 117) + 3) * 5) % 80) - -90);
    	a518 = 0;
    	a397 = true;
    	 update57(a59,a59,12);
    	a373 = ((a16 - a288) + 14);
    	a362 = (a16 - -1);
    	a294 = (((((((a294 * a384) % 14999) % 67) - -317) + -1) + -10294) - -10294); 
    	System.out.println("X");
    } 
}
private  void calculateOutputm18(boolean input) {
//************************Modified code Start***********************************
 if((a265==00)&&(a365==true)||(a303==0)){
if(a313==0){}
else if(!(a313==0)){}
}
else{}
 if((a265==00)&&(a365==true)||(a313==0)){
if(a303==0){}
else if(!(a303==0)){}
}
else{}
 if(!(a365==true)||(a303==0)||(a313==0)){
if(a265==00){}
else if(!(a265==00)){}
}
else{}
 if(!(a265==00)||(a303==0)||(a313==0)){
if(a365==true){}
else if(!(a365==true)){}
}
else{}
//************************Modified code end***********************************
    if((a313 ==0) || (a303 ==0) ||  (a265 ==00) && (a365==true)){
    	cf = false;
    	a508 = 1;
    	a264 = (((((((a264 * a348) % 14999) * 2) % 77) + 310) + -14780) - -14778);
    	a344 = false;
    	a272 = true;
    	 update69(a307,a361,8);
    	a370 = ((a313 + a219) + -8);
    	a361 = a318;
    	a395 = true;
    	a365 = false;
    	a250 = true;
    	a66 = ((((87 * -1) / 10) * 5) + 21);
    	a59 = (a288 - -1);
    	a260 = ((((((((a260 * a222) % 14999) - 13958) % 38) + 356) * 5) % 38) + 322);
    	a233 = false;
    	a210 = ((((((a210 * a348) % 14999) % 54) - -343) + 14106) - 14104);
    	a100 = 1;
    	a313 = ((a16 / a307) + 8);
    	a348 = (((((((a348 * a287) % 14999) - 10958) - -4590) + 4843) % 77) + 328);
    	a360 = ((((((a360 * a296) % 14999) - -7659) - -4933) % 22) + 8); 
    	System.out.println("V");
    } 
}
private  void calculateOutputm27(boolean input) {
//************************Modified code Start***********************************
 if((cf==true)||(a393<=145)&&(input==true)){
if(a333==false){}
else if(!(a333==false)){}
}
else{}
 if(!(input==true)||(cf==true)||(a333==false)){
if(a393<=145){}
else if(!(a393<=145)){}
}
else{}
 if(!(a393<=145)||(cf==true)||(a333==false)){
if(input==true){}
else if(!(input==true)){}
}
else{}
 if((a393<=145)&&(input==true)||(a333==false)){
if(cf==true){}
else if(!(cf==true)){}
}
else{}
//************************Modified code end***********************************
    if((a333==false) || (a393 <=  145) && (input==true) || (cf==true) ){
    	a63 += (a63 + 20) > a63 ? 2 : 0;
    	cf = false;
    	a293 = false;
    	a290 = ((a265 - a361) - 1);
    	a289 = (a209 + 5);
    	a309 = false;
    	a100 = 0;
    	a350 = ((((((a350 * a398) % 14999) + -5099) - -1216) % 85) + 173);
    	a333 = false;
    	a288 = (a299 + 5);
    	a16 = ((a289 * a289) - 79);
    	a378 = (((((((a193 * a193) % 14999) / 5) / 5) - -14766) % 100) + 39);
    	a510 = 0;
    	a296 = (((((((a296 * a348) % 14999) % 19) - 130) + -2) - -1621) - 1620);
    	a583 = 0;
    	a448 = 0;
    	a483 = 0;
    	a215 = false;
    	a260 = ((((((a260 * a264) % 14999) * 2) % 104) + 212) * 1);
    	a348 = ((((((a348 * a393) % 14999) % 38) + 211) + 0) + 0); 
    	System.out.println("O");
    } 
}

	public  void calculateOutput(boolean input) {
 	cf = true;
   
//************************Modified code Start***********************************
 if(!(a385==0)||(a518==0)||(a248==0)){
if(a222<=126){}
else if(!(a222<=126)){}
}
else{}
 if(!(a222<=126)||(a518==0)||(a248==0)){
if(a385==0){}
else if(!(a385==0)){}
}
else{}
 if((a518==0)||(a222<=126)&&(a385==0)){
if(a248==0){}
else if(!(a248==0)){}
}
else{}
 if((a248==0)||(a222<=126)&&(a385==0)){
if(a518==0){}
else if(!(a518==0)){}
}
else{}
//************************Modified code end***********************************
    	if((a222 <=  126) && (a385 ==0) || (a248 ==0) || (a518==0) ){
    		calculateOutputm4(input);
    	} 
//************************Modified code Start***********************************
 if((a384<=146)&&(a448==0)&&(a260<=108)){
if(a430==0){}
else if(!(a430==0)){}
}
else{}
 if(!(a448==0)||!(a260<=108)||(a430==0)){
if(a384<=146){}
else if(!(a384<=146)){}
}
else{}
 if(!(a384<=146)||!(a260<=108)||(a430==0)){
if(a448==0){}
else if(!(a448==0)){}
}
else{}
 if(!(a384<=146)||!(a448==0)||(a430==0)){
if(a260<=108){}
else if(!(a260<=108)){}
}
else{}
//************************Modified code end***********************************
    	if((a430==0) || (a384 <= 146) && (a448==0) && (a260 <=  108) ){
    		calculateOutputm10(input);
    	} 
//************************Modified code Start***********************************
 if((a307==0)||(a215==false)&&(a467==0)){
if(a244=true){}
else if(!(a244=true)){}
}
else{}
 if(!(a467==0)||(a307==0)||(a244=true)){
if(a215==false){}
else if(!(a215==false)){}
}
else{}
 if(!(a215==false)||(a307==0)||(a244=true)){
if(a467==0){}
else if(!(a467==0)){}
}
else{}
 if((a215==false)&&(a467==0)||(a244=true)){
if(a307==0){}
else if(!(a307==0)){}
}
else{}
//************************Modified code end***********************************
    	if((a244=true) || (a215==false) && (a467==0) || (a307 ==0) ){
    		calculateOutputm11(input);
    	} 
//************************Modified code Start***********************************
 if((a284<=124)&&(a318==0)&&(cf==true)){
if(a406==0){}
else if(!(a406==0)){}
}
else{}
 if(!(a318==0)||!(cf==true)||(a406==0)){
if(a284<=124){}
else if(!(a284<=124)){}
}
else{}
 if(!(a284<=124)||!(cf==true)||(a406==0)){
if(a318==0){}
else if(!(a318==0)){}
}
else{}
 if(!(a284<=124)||!(a318==0)||(a406==0)){
if(cf==true){}
else if(!(cf==true)){}
}
else{}
//************************Modified code end***********************************
    	if((a406==0) || (a284 <=  124) && (a318 ==0) && (cf==true) ){
    		calculateOutputm14(input);
    	} 
//************************Modified code Start***********************************
 if(!(a350<=87)||(a16==0)||(cf==true)){
if(a265==00){}
else if(!(a265==00)){}
}
else{}
 if(!(a265==00)||(a16==0)||(cf==true)){
if(a350<=87){}
else if(!(a350<=87)){}
}
else{}
 if((a16==0)||(a265==00)&&(a350<=87)){
if(cf==true){}
else if(!(cf==true)){}
}
else{}
 if((cf==true)||(a265==00)&&(a350<=87)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
//************************Modified code end***********************************
    	if((a265 ==00) && (a350 <=  87) || (cf==true) || (a16 ==0) ){
    		calculateOutputm18(input);
    	} 
//************************Modified code Start***********************************
 if((a545==0)||(cf==true)||(a16==0)){
if(a253==true){}
else if(!(a253==true)){}
}
else{}
 if((a545==0)||(cf==true)||(a253==true)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
 if((a545==0)||(a16==0)||(a253==true)){
if(cf==true){}
else if(!(cf==true)){}
}
else{}
 if((cf==true)||(a16==0)||(a253==true)){
if(a545==0){}
else if(!(a545==0)){}
}
else{}
//************************Modified code end***********************************
    	if((a253==true) || (a16 ==0) || (cf==true) || (a545==0) ){
    		//calculateOutputm20(input);
    	} 
//************************Modified code Start***********************************
 if((a16==0)||(a284<=124)&&(cf==true)){
if(a422==0){}
else if(!(a422==0)){}
}
else{}
 if(!(cf==true)||(a16==0)||(a422==0)){
if(a284<=124){}
else if(!(a284<=124)){}
}
else{}
 if(!(a284<=124)||(a16==0)||(a422==0)){
if(cf==true){}
else if(!(cf==true)){}
}
else{}
 if((a284<=124)&&(cf==true)||(a422==0)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
//************************Modified code end***********************************
    	if((a422==0) || (a284 <=  124) && (cf==true) || (a16 ==0) ){
    		calculateOutputm27(input);
    	} 
	
   

   errorCheck();
    if(cf==true)
    	throw new IllegalArgumentException("Current state has no transition for this input!");
}
	
	public static void main() throws Exception 
	{
	       Problem5RVjxnct eca = new Problem5RVjxnct();
				int a=0;
	int x;
        int y;
         
        x = Cute.input.Integer();
        y = Cute.input.Integer();
		boolean input = Cute.input.Boolean();
			// main i/o-loop
            while(a<10) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
//************************Modified code Start***********************************
 if(!(x>y)){
if(x>199){}
else if(!(x>199)){}
}
else{}
 if(!(x>199)){
if(x>y){}
else if(!(x>y)){}
}
else{}
//************************Modified code end***********************************
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                	 eca.calculateOutput(input);
					 
				}
				
//************************Modified code Start***********************************
 if(!(x<y)){
if(x>299){}
else if(!(x>299)){}
}
else{}
 if(!(x>299)){
if(x<y){}
else if(!(x<y)){}
}
else{}
//************************Modified code end***********************************
				if (x>299 && x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutput(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
	}
}


//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
