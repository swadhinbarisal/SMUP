
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class jxnct_wildLife2jxnct_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public jxnct_wildLife2jxnct_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(1485225302);
        input[i++] = new Integer(1311729795);
        input[i++] = new Integer(842349323);
        input[i++] = new Integer(-33819858);
        i=0;
        cute.Cute.input = this;
        jxnct.wildLife2jxnct.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-1000);
        input[i++] = new Integer(1311729795);
        input[i++] = new Integer(842349323);
        input[i++] = new Integer(-33819858);
        i=0;
        cute.Cute.input = this;
        jxnct.wildLife2jxnct.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1311729795);
        input[i++] = new Integer(842349323);
        input[i++] = new Integer(-33819858);
        i=0;
        cute.Cute.input = this;
        jxnct.wildLife2jxnct.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(1000);
        input[i++] = new Integer(1311729795);
        input[i++] = new Integer(842349323);
        input[i++] = new Integer(-33819858);
        i=0;
        cute.Cute.input = this;
        jxnct.wildLife2jxnct.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(1000);
        input[i++] = new Integer(1311729795);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-33819858);
        i=0;
        cute.Cute.input = this;
        jxnct.wildLife2jxnct.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(1000);
        input[i++] = new Integer(1311729795);
        input[i++] = new Integer(908);
        input[i++] = new Integer(-33819858);
        i=0;
        cute.Cute.input = this;
        jxnct.wildLife2jxnct.main(null);
    }

    public void test8(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(1000);
        input[i++] = new Integer(0);
        input[i++] = new Integer(908);
        input[i++] = new Integer(-33819858);
        i=0;
        cute.Cute.input = this;
        jxnct.wildLife2jxnct.main(null);
    }

    public void test13(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(1000);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1000);
        input[i++] = new Integer(-33819858);
        i=0;
        cute.Cute.input = this;
        jxnct.wildLife2jxnct.main(null);
    }

    public void test16(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1000);
        input[i++] = new Integer(920);
        i=0;
        cute.Cute.input = this;
        jxnct.wildLife2jxnct.main(null);
    }

    public void test25(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1000);
        input[i++] = new Integer(908);
        input[i++] = new Integer(200);
        i=0;
        cute.Cute.input = this;
        jxnct.wildLife2jxnct.main(null);
    }

}
