package jxnct;

import cute.Cute;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Problem10_RERS2017jxnct {
	static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

	private String[] inputs = {"B","E","C","A","D"};

	public int a41 = Cute.input.Integer();
	public int a13 = Cute.input.Integer();
	public int a175 = Cute.input.Integer();
	public int a161 = Cute.input.Integer();
	public int a196 = Cute.input.Integer();
	public int a11 = Cute.input.Integer();
	public boolean cf = Cute.input.Boolean();
	public boolean input = Cute.input.Boolean();
	public int a137 = Cute.input.Integer();
	public int a69 = Cute.input.Integer();
	public int a165 = Cute.input.Integer();
	public int a141 = Cute.input.Integer();
	public int a187 = Cute.input.Integer();
	public int a179 = Cute.input.Integer();
	public int a168 = Cute.input.Integer();
	public int a19 = Cute.input.Integer();
	public int a55 = Cute.input.Integer();
	public int a149 = Cute.input.Integer();
	public int a49 = Cute.input.Integer();
	public int a62 = Cute.input.Integer();
	public int a26 = Cute.input.Integer();
	public int a114 = Cute.input.Integer();
	public int a3 = Cute.input.Integer();
	public int a73 = Cute.input.Integer();
	public int a188 = Cute.input.Integer();
	public int a16 = Cute.input.Integer();
	public int a50 = Cute.input.Integer();
	public int a97 = Cute.input.Integer();
	public int a68 = Cute.input.Integer();
	public int a65 = Cute.input.Integer();
	public int a148 = Cute.input.Integer();
	public int a126 = Cute.input.Integer();
	public int a170 = Cute.input.Integer();
	public int a173 = Cute.input.Integer();
	public int a152 = Cute.input.Integer();
	public int a169 = Cute.input.Integer();

	private void errorCheck() {
//************************Modified code Start***********************************
 if(!(a41==0)||(a62==0)){
if(a169==0){}
else if(!(a169==0)){}
}
else{}
 if(!(a169==0)||(a62==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if((a169==0)&&(a41==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a169 ==0) && (a41==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("0");
	    }
//************************Modified code Start***********************************
 if((a173==0)&&(a62==0)){
if(a126==0){}
else if(!(a126==0)){}
}
else{}
 if(!(a62==0)||(a126==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)||(a126==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a126 ==0) || (a173 ==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("1");
	    }
//************************Modified code Start***********************************
 if(!(a50==0)||(a62==0)){
if(a196==0){}
else if(!(a196==0)){}
}
else{}
 if(!(a196==0)||(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if((a196==0)&&(a50==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a196 ==0) && (a50 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("2");
	    }
//************************Modified code Start***********************************
 if((a114==0)&&(a62==0)){
if(a3==0){}
else if(!(a3==0)){}
}
else{}
 if(!(a62==0)||(a3==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a114==0)||(a3==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a3 ==0) || (a114==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("3");
	    }
//************************Modified code Start***********************************
 if(!(a114==0)||(a62==0)){
if(a137==0){}
else if(!(a137==0)){}
}
else{}
 if(!(a137==0)||(a62==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if((a137==0)&&(a114==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a137==0) && (a114==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("4");
	    }
//************************Modified code Start***********************************
 if(!(a173==0)||(a62==0)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if(!(a152==0)||(a62==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if((a152==0)&&(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a152==0) && (a173 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("5");
	    }
//************************Modified code Start***********************************
 if((a50==0)&&(a62==0)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
 if(!(a62==0)||(a16==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)||(a16==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a16 ==0) || (a50 ==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("6");
	    }
//************************Modified code Start***********************************
 if(!(a50==0)||(a62==0)){
if(a65==0){}
else if(!(a65==0)){}
}
else{}
 if(!(a65==0)||(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if((a65==0)&&(a50==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a65 ==0) && (a50 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("7");
	    }
//************************Modified code Start***********************************
 if((a161==00)&&(a62==0)){
if(a187==0){}
else if(!(a187==0)){}
}
else{}
 if(!(a62==0)||(a187==0)){
if(a161==00){}
else if(!(a161==00)){}
}
else{}
 if(!(a161==00)||(a187==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a187 ==0) || (a161 ==00) && (a62==0)){
	    	cf = false;
	    	System.out.println("8");
	    }
//************************Modified code Start***********************************
 if(!(a173==0)||(a62==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a41==0)||(a62==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if((a41==0)&&(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a41==0) && (a173 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("9");
	    }
//************************Modified code Start***********************************
 if((a50==00)&&(a62==0)){
if(a141==0){}
else if(!(a141==0)){}
}
else{}
 if(!(a62==0)||(a141==0)){
if(a50==00){}
else if(!(a50==00)){}
}
else{}
 if(!(a50==00)||(a141==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a141 ==0) || (a50 ==00) && (a62==0)){
	    	cf = false;
	    	System.out.println("10");
	    }
//************************Modified code Start***********************************
 if(!(a114==0)||(a62==0)){
if(a3==0){}
else if(!(a3==0)){}
}
else{}
 if(!(a3==0)||(a62==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if((a3==0)&&(a114==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a3 ==0) && (a114==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("11");
	    }
//************************Modified code Start***********************************
 if((a50==0)&&(a62==0)){
if(a196==0){}
else if(!(a196==0)){}
}
else{}
 if(!(a62==0)||(a196==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)||(a196==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a196 ==0) || (a50 ==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("12");
	    }
//************************Modified code Start***********************************
 if((a161==0)&&(a62==0)){
if(a179==0){}
else if(!(a179==0)){}
}
else{}
 if(!(a62==0)||(a179==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a161==0)||(a179==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a179==0) || (a161 ==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("13");
	    }
//************************Modified code Start***********************************
 if(!(a50==0)||(a62==0)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
 if(!(a16==0)||(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if((a16==0)&&(a50==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a16 ==0) && (a50 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("14");
	    }
//************************Modified code Start***********************************
 if(!(a173==0)||(a62==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a41==0)||(a62==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if((a41==0)&&(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a41==0) && (a173 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("15");
	    }
//************************Modified code Start***********************************
 if(!(a161==0)||(a62==0)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
 if(!(a26==0)||(a62==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if((a26==0)&&(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a26 ==0) && (a161 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("16");
	    }
//************************Modified code Start***********************************
 if((a161==00)&&(a62==0)){
if(a187==0){}
else if(!(a187==0)){}
}
else{}
 if(!(a62==0)||(a187==0)){
if(a161==00){}
else if(!(a161==00)){}
}
else{}
 if(!(a161==00)||(a187==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a187 ==0) || (a161 ==00) && (a62==0)){
	    	cf = false;
	    	System.out.println("17");
	    }
//************************Modified code Start***********************************
 if((a50==0)&&(a62==0)){
if(a65==0){}
else if(!(a65==0)){}
}
else{}
 if(!(a62==0)||(a65==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)||(a65==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a65 ==0) || (a50 ==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("18");
	    }
//************************Modified code Start***********************************
 if((a173==0)&&(a62==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a62==0)||(a161==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)||(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a161 ==0) || (a173 ==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("19");
	    }
//************************Modified code Start***********************************
 if(!(a41==0)||(a62==0)){
if(a55==0){}
else if(!(a55==0)){}
}
else{}
 if(!(a55==0)||(a62==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if((a55==0)&&(a41==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a55==0) && (a41==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("20");
	    }
//************************Modified code Start***********************************
 if(!(a50==0)||(a62==0)){
if(a175==0){}
else if(!(a175==0)){}
}
else{}
 if(!(a175==0)||(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if((a175==0)&&(a50==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a175 ==0) && (a50 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("21");
	    }
//************************Modified code Start***********************************
 if(!(a114==0)||(a62==0)){
if(a69==0){}
else if(!(a69==0)){}
}
else{}
 if(!(a69==0)||(a62==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if((a69==0)&&(a114==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a69==0) && (a114==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("22");
	    }
//************************Modified code Start***********************************
 if((a41==0)&&(a62==0)){
if(a165==00){}
else if(!(a165==00)){}
}
else{}
 if(!(a62==0)||(a165==00)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a41==0)||(a165==00)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a165 ==00) || (a41==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("23");
	    }
//************************Modified code Start***********************************
 if((a41==0)&&(a62==0)){
if(a188==0){}
else if(!(a188==0)){}
}
else{}
 if(!(a62==0)||(a188==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a41==0)||(a188==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a188==0) || (a41==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("24");
	    }
//************************Modified code Start***********************************
 if(!(a161==0)||(a62==0)){
if(a168==0){}
else if(!(a168==0)){}
}
else{}
 if(!(a168==0)||(a62==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if((a168==0)&&(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a168==0) && (a161 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("25");
	    }
//************************Modified code Start***********************************
 if(!(a50==0)||(a62==0)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
 if(!(a11==0)||(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if((a11==0)&&(a50==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a11 ==0) && (a50 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("26");
	    }
//************************Modified code Start***********************************
 if((a114==0)&&(a62==0)){
if(a3==0){}
else if(!(a3==0)){}
}
else{}
 if(!(a62==0)||(a3==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a114==0)||(a3==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a3 ==0) || (a114==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("27");
	    }
//************************Modified code Start***********************************
 if(!(a173==0)||(a62==0)){
if(a126==0){}
else if(!(a126==0)){}
}
else{}
 if(!(a126==0)||(a62==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if((a126==0)&&(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a126 ==0) && (a173 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("28");
	    }
//************************Modified code Start***********************************
 if(!(a161==0)||(a62==0)){
if(a49==0){}
else if(!(a49==0)){}
}
else{}
 if(!(a49==0)||(a62==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if((a49==0)&&(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a49 ==0) && (a161 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("29");
	    }
//************************Modified code Start***********************************
 if((a50==0)&&(a62==0)){
if(a65==0){}
else if(!(a65==0)){}
}
else{}
 if(!(a62==0)||(a65==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)||(a65==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
	    if((a65 ==0) || (a50 ==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("30");
	    }
	    

	}
	
private  void calculateOutputm35(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)&&(a62==0)&&(a173==0)||(input==false)){
if(a161==00){}
else if(!(a161==00)){}
}
else{}
 if((cf==false)&&(a62==0)&&(a173==0)||(a161==00)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||!(a173==0)||(input==false)||(a161==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a173==0)||(input==false)||(a161==00)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(cf==false)||!(a62==0)||(input==false)||(a161==00)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==00) || (input==false) || (cf==false) && (a62==0) && (a173 ==0)){
    	cf = false;
    	a62 =0;
    	a73 =0;
    	a50 = 13; 
    	System.out.println("Y");
    } 
//************************Modified code Start***********************************
 if(!(a173==0)||(cf==false)&&(a62==0)||(a161==00)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a62==0)||(a161==00)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if((cf==false)&&(a62==0)||(input==false)&&(a173==0)){
if(a161==00){}
else if(!(a161==00)){}
}
else{}
 if(!(a62==0)||(a161==00)||(input==false)&&(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a161==00)||(input==false)&&(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a173 ==0) || (a161 ==00) || (cf==false) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a173 = 7; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm37(boolean input) {
//************************Modified code Start***********************************
 if((a173==0)&&(a62==0)||(input==false)&&(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(cf==false)||(a173==0)&&(a62==0)||(a161==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a173==0)&&(a62==0)||(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||(input==false)&&(cf==false)||(a161==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)||(input==false)&&(cf==false)||(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==0) || (input==false) && (cf==false) || (a173 ==0) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a188 =0; 
    	System.out.println("Z");
    } 
//************************Modified code Start***********************************
 if((a62==0)&&(cf==false)&&(input==false)&&(a161==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(cf==false)||!(input==false)||!(a161==0)||(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(a161==0)||(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a161==0)||(a173==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(input==false)||(a173==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
//************************Modified code end***********************************
    if((a173 ==0) || (a62==0) && (cf==false) && (input==false) && (a161 ==0)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a152 =0; 
    	System.out.println("Z");
    } 
//************************Modified code Start***********************************
 if((input==false)||(a62==0)||(cf==false)&&(a161==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a161==0)||(input==false)||(a62==0)||(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(input==false)||(a62==0)||(a173==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if((input==false)||(cf==false)&&(a161==0)||(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((a62==0)||(cf==false)&&(a161==0)||(a173==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a173 ==0) || (cf==false) && (a161 ==0) || (a62==0) || (input==false)){
    	cf = false;
    	a50 = 11;
    	a62 =0;
    	a11 = 7; 
    	System.out.println("S");
    } 
}
private  void calculateOutputm1(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a161==00){}
else if(!(a161==00)){}
}
else{}
 if(!(a161==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==00) && (cf==false)) {
    	calculateOutputm35(input);
    } 
//************************Modified code Start***********************************
 if((cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if((a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==0) || (cf==false)) {
    	calculateOutputm37(input);
    } 
}
private  void calculateOutputm40(boolean input) {
//************************Modified code Start***********************************
 if(!(a62==0)||(a173==0)&&(input==false)||(cf==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if(!(a68==0)||(a173==0)&&(input==false)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((a173==0)&&(input==false)||(a68==0)&&(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||(cf==false)||(a68==0)&&(a62==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)||(cf==false)||(a68==0)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a68==0) && (a62==0) || (cf==false) || (a173 ==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a161 = 9;
    	a49 = 9; 
    	System.out.println("Y");
    } 
//************************Modified code Start***********************************
 if((a173==0)&&(a68==0)||(a62==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||(a173==0)&&(a68==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a173==0)&&(a68==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a68==0)||(a62==0)&&(cf==false)||(input==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)||(a62==0)&&(cf==false)||(input==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (a62==0) && (cf==false) || (a173 ==0) && (a68==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a188 =0; 
    	System.out.println("X");
    } 
//************************Modified code Start***********************************
 if(!(a62==0)||(cf==false)&&(a173==0)||(input==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if(!(a68==0)||(cf==false)&&(a173==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((cf==false)&&(a173==0)||(a68==0)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a173==0)||(input==false)||(a68==0)&&(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(input==false)||(a68==0)&&(a62==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
//************************Modified code end***********************************
    if((a68==0) && (a62==0) || (input==false) || (cf==false) && (a173 ==0)){
    	cf = false;
    	a173 = 12;
    	a126 = 7; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm41(boolean input) {
//************************Modified code Start***********************************
 if(!(a68==0)||(a173==0)||(input==false)&&(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a173==0)||(input==false)&&(cf==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if(!(cf==false)||(a173==0)||(a62==0)&&(a68==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a173==0)||(a62==0)&&(a68==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((input==false)&&(cf==false)||(a62==0)&&(a68==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (a68==0) || (input==false) && (cf==false) || (a173 ==0)){
    	cf = false;
    	a161 = 9;
    	a62 =0;
    	a49 = 5; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if((a173==0)||(a62==0)&&(input==false)&&(cf==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||(a173==0)||(a68==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||(a173==0)||(a68==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||!(input==false)||(a173==0)||(a68==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a62==0)&&(input==false)&&(cf==false)||(a68==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
//************************Modified code end***********************************
    if((a68==0) || (a62==0) && (input==false) && (cf==false) || (a173 ==0)){
    	cf = false;
    	 
    	System.out.println("T");
    } 
}
private  void calculateOutputm2(boolean input) {
//************************Modified code Start***********************************
 if((a68==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a68==0)){
    	calculateOutputm40(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if(!(a68==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a68==0) && (cf==false)) {
    	calculateOutputm41(input);
    } 
}
private  void calculateOutputm46(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)&&(input==false)&&(a62==0)||(a41==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if((cf==false)&&(input==false)&&(a62==0)||(a173==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(input==false)||!(a62==0)||(a41==0)||(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a62==0)||(a41==0)||(a173==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||!(input==false)||(a41==0)||(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a173 ==0) || (a41==0) || (cf==false) && (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a73 =0;
    	a50 = 13; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm47(boolean input) {
//************************Modified code Start***********************************
 if((input==false)||(a62==0)&&(a41==0)&&(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a41==0)||!(a173==0)||(input==false)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(a173==0)||(input==false)||(cf==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a62==0)||!(a41==0)||(input==false)||(cf==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if((a62==0)&&(a41==0)&&(a173==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a62==0) && (a41==0) && (a173 ==0) || (input==false)){
    	cf = false;
    	a62 =0;
    	a50 = 14;
    	a16 = 7; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||(a62==0)&&(input==false)||(a41==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)||(a62==0)&&(input==false)||(a41==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a62==0)&&(input==false)||(a173==0)&&(cf==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(input==false)||(a41==0)||(a173==0)&&(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a41==0)||(a173==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a173 ==0) && (cf==false) || (a41==0) || (a62==0) && (input==false)){
    	cf = false;
    	a50 = 11;
    	a62 =0;
    	a11 = 12; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm3(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a41==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a41==0) && (cf==false)) {
    	calculateOutputm46(input);
    } 
//************************Modified code Start***********************************
 if((a41==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a41==0)){
    	calculateOutputm47(input);
    } 
}
private  void calculateOutputm48(boolean input) {
//************************Modified code Start***********************************
 if((a152==0)&&(a173==0)||(a62==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||(a152==0)&&(a173==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a152==0)&&(a173==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a173==0)||(a62==0)&&(cf==false)||(input==false)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if(!(a152==0)||(a62==0)&&(cf==false)||(input==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (a62==0) && (cf==false) || (a152==0) && (a173 ==0)){
    	cf = false;
    	a62 =0;
    	a50 = 8;
    	a196 = 6; 
    	System.out.println("Z");
    } 
//************************Modified code Start***********************************
 if(!(a62==0)||(cf==false)&&(a152==0)||(input==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)||(cf==false)&&(a152==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((cf==false)&&(a152==0)||(a173==0)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a152==0)||(input==false)||(a173==0)&&(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(input==false)||(a173==0)&&(a62==0)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
//************************Modified code end***********************************
    if((a173 ==0) && (a62==0) || (input==false) || (cf==false) && (a152==0)){
    	cf = false;
    	a173 = 5;
    	a161 = 12; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm49(boolean input) {
//************************Modified code Start***********************************
 if(!(a173==0)||(input==false)&&(a62==0)||(cf==false)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if(!(a152==0)||(input==false)&&(a62==0)||(cf==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if((input==false)&&(a62==0)||(a152==0)&&(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||(cf==false)||(a152==0)&&(a173==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)||(a152==0)&&(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a152==0) && (a173 ==0) || (cf==false) || (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a165 = 16; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if(!(a173==0)||(cf==false)&&(a62==0)||(input==false)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if(!(a152==0)||(cf==false)&&(a62==0)||(input==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if((cf==false)&&(a62==0)||(a152==0)&&(a173==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||(input==false)||(a152==0)&&(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(input==false)||(a152==0)&&(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a152==0) && (a173 ==0) || (input==false) || (cf==false) && (a62==0)){
    	cf = false;
    	a173 = 12;
    	a126 = 11; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if((a173==0)&&(a152==0)||(cf==false)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||(a173==0)&&(a152==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a173==0)&&(a152==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a152==0)||(cf==false)&&(a62==0)||(input==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)||(cf==false)&&(a62==0)||(input==false)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (cf==false) && (a62==0) || (a173 ==0) && (a152==0)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a69 =0; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm51(boolean input) {
//************************Modified code Start***********************************
 if((a62==0)&&(cf==false)&&(a152==0)||(input==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if((a62==0)&&(cf==false)&&(a152==0)||(a173==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||!(a152==0)||(input==false)||(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(a152==0)||(input==false)||(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||(input==false)||(a173==0)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
//************************Modified code end***********************************
    if((a173 ==0) || (input==false) || (a62==0) && (cf==false) && (a152==0)){
    	cf = false;
    	a62 =0;
    	a161 = 14;
    	a26 = 15; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a173==0)||(cf==false)&&(input==false)||(a152==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(cf==false)&&(input==false)||(a152==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if((cf==false)&&(input==false)||(a62==0)&&(a173==0)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if(!(input==false)||(a152==0)||(a62==0)&&(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a152==0)||(a62==0)&&(a173==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (a173 ==0) || (a152==0) || (cf==false) && (input==false)){
    	cf = false;
    	a149 =0;
    	a173 = 11; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm52(boolean input) {
//************************Modified code Start***********************************
 if(!(a152==0)||(cf==false)&&(input==false)||(a62==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)||(cf==false)&&(input==false)||(a62==0)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if((cf==false)&&(input==false)||(a173==0)&&(a152==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(input==false)||(a62==0)||(a173==0)&&(a152==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a62==0)||(a173==0)&&(a152==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a173 ==0) && (a152==0) || (a62==0) || (cf==false) && (input==false)){
    	cf = false;
    	a50 = 11;
    	a62 =0;
    	a11 = 9; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a173==0)||(a152==0)&&(a62==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a152==0)&&(a62==0)||(cf==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if((a152==0)&&(a62==0)||(input==false)&&(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||(cf==false)||(input==false)&&(a173==0)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if(!(a152==0)||(cf==false)||(input==false)&&(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a173 ==0) || (cf==false) || (a152==0) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a169 = 5; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm4(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if(!(a152==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a152==0) && (cf==false)) {
    	calculateOutputm48(input);
    } 
//************************Modified code Start***********************************
 if((cf==false)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if((a152==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a152==0) || (cf==false)) {
    	calculateOutputm49(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if(!(a152==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a152==0) && (cf==false)) {
    	calculateOutputm51(input);
    } 
//************************Modified code Start***********************************
 if((a152==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a152==0)){
    	calculateOutputm52(input);
    } 
}
private  void calculateOutputm54(boolean input) {
//************************Modified code Start***********************************
 if((input==false)&&(a62==0)||(a173==0)&&(cf==false)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
 if(!(cf==false)||(input==false)&&(a62==0)||(a26==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)||(input==false)&&(a62==0)||(a26==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||(a173==0)&&(cf==false)||(a26==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a173==0)&&(cf==false)||(a26==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a26 ==0) || (a173 ==0) && (cf==false) || (input==false) && (a62==0)){
    	cf = false;
    	a26 = 17; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm55(boolean input) {
//************************Modified code Start***********************************
 if(!(a62==0)||(a173==0)&&(a26==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a173==0)&&(a26==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((a173==0)&&(a26==0)||(cf==false)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a26==0)||(input==false)||(cf==false)&&(a62==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)||(input==false)||(cf==false)&&(a62==0)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a62==0) || (input==false) || (a173 ==0) && (a26 ==0)){
    	cf = false;
    	a62 =0;
    	a179 =0;
    	a161 = 13; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if((input==false)||(cf==false)||(a26==0)&&(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a173==0)||(input==false)||(cf==false)||(a62==0)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
 if(!(a26==0)||(input==false)||(cf==false)||(a62==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if((input==false)||(a26==0)&&(a173==0)||(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)||(a26==0)&&(a173==0)||(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) || (a26 ==0) && (a173 ==0) || (cf==false) || (input==false)){
    	cf = false;
    	a173 = 10;
    	a13 = 14; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm57(boolean input) {
//************************Modified code Start***********************************
 if((a62==0)&&(cf==false)&&(a26==0)||(input==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if((a62==0)&&(cf==false)&&(a26==0)||(a173==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||!(a26==0)||(input==false)||(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(a26==0)||(input==false)||(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||(input==false)||(a173==0)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
//************************Modified code end***********************************
    if((a173 ==0) || (input==false) || (a62==0) && (cf==false) && (a26 ==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a188 =0; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm60(boolean input) {
//************************Modified code Start***********************************
 if(!(input==false)||(a62==0)&&(a173==0)||(cf==false)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
 if(!(a26==0)||(a62==0)&&(a173==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a62==0)&&(a173==0)||(a26==0)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a173==0)||(cf==false)||(a26==0)&&(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(cf==false)||(a26==0)&&(input==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
//************************Modified code end***********************************
    if((a26 ==0) && (input==false) || (cf==false) || (a62==0) && (a173 ==0)){
    	cf = false;
    	a62 =0;
    	a50 = 15;
    	a170 = 16; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm5(boolean input) {
//************************Modified code Start***********************************
 if((a26==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a26 ==0)){
    	calculateOutputm54(input);
    } 
//************************Modified code Start***********************************
 if(!(a26==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a26 ==0)){
    	calculateOutputm55(input);
    } 
//************************Modified code Start***********************************
 if((cf==false)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
 if((a26==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a26 ==0) || (cf==false)) {
    	calculateOutputm57(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
 if(!(a26==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a26 ==0) && (cf==false)) {
    	calculateOutputm60(input);
    } 
}
private  void calculateOutputm61(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)&&(a173==00)||(a62==0)&&(input==false)){
if(a13==0){}
else if(!(a13==0)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a173==00)||(a13==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(cf==false)&&(a173==00)||(a13==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a173==00)||(a62==0)&&(input==false)||(a13==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a62==0)&&(input==false)||(a13==0)){
if(a173==00){}
else if(!(a173==00)){}
}
else{}
//************************Modified code end***********************************
    if((a13 ==0) || (a62==0) && (input==false) || (cf==false) && (a173 ==00)){
    	cf = false;
    	a161 = 9;
    	a62 =0;
    	a49 = 9; 
    	System.out.println("Y");
    } 
//************************Modified code Start***********************************
 if(!(a173==00)||(input==false)&&(a62==0)||(cf==false)){
if(a13==0){}
else if(!(a13==0)){}
}
else{}
 if(!(a13==0)||(input==false)&&(a62==0)||(cf==false)){
if(a173==00){}
else if(!(a173==00)){}
}
else{}
 if((input==false)&&(a62==0)||(a13==0)&&(a173==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||(cf==false)||(a13==0)&&(a173==00)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)||(a13==0)&&(a173==00)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a13 ==0) && (a173 ==00) || (cf==false) || (input==false) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a188 =0; 
    	System.out.println("X");
    } 
//************************Modified code Start***********************************
 if((a13==0)||(a62==0)&&(a173==00)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a173==00)||!(cf==false)||(a13==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||(a13==0)||(input==false)){
if(a173==00){}
else if(!(a173==00)){}
}
else{}
 if(!(a62==0)||!(a173==00)||(a13==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a62==0)&&(a173==00)&&(cf==false)||(input==false)){
if(a13==0){}
else if(!(a13==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (a62==0) && (a173 ==00) && (cf==false) || (a13 ==0)){
    	cf = false;
    	a50 = 15;
    	a62 =0;
    	a170 = 11; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm62(boolean input) {
//************************Modified code Start***********************************
 if((a173==00)&&(a13==0)||(a62==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a173==00)&&(a13==0)||(a62==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a173==00)&&(a13==0)||(cf==false)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a13==0)||(a62==0)||(cf==false)||(input==false)){
if(a173==00){}
else if(!(a173==00)){}
}
else{}
 if(!(a173==00)||(a62==0)||(cf==false)||(input==false)){
if(a13==0){}
else if(!(a13==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (cf==false) || (a62==0) || (a173 ==00) && (a13 ==0)){
    	cf = false;
    	a50 = 14;
    	a62 =0;
    	a16 = 6; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm64(boolean input) {
//************************Modified code Start***********************************
 if((a173==00)&&(a13==0)||(cf==false)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||(a173==00)&&(a13==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a173==00)&&(a13==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a13==0)||(cf==false)&&(a62==0)||(input==false)){
if(a173==00){}
else if(!(a173==00)){}
}
else{}
 if(!(a173==00)||(cf==false)&&(a62==0)||(input==false)){
if(a13==0){}
else if(!(a13==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (cf==false) && (a62==0) || (a173 ==00) && (a13 ==0)){
    	cf = false;
    	a62 =0;
    	a50 = 11;
    	a11 = 8; 
    	System.out.println("Z");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||(a173==00)||(a13==0)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a173==00)||(a13==0)&&(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||(a173==00)||(input==false)&&(cf==false)){
if(a13==0){}
else if(!(a13==0)){}
}
else{}
 if(!(a13==0)||(a173==00)||(input==false)&&(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((a13==0)&&(a62==0)||(input==false)&&(cf==false)){
if(a173==00){}
else if(!(a173==00)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (cf==false) || (a13 ==0) && (a62==0) || (a173 ==00)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a55 =0; 
    	System.out.println("S");
    } 
//************************Modified code Start***********************************
 if((cf==false)&&(input==false)||(a62==0)&&(a173==0)){
if(a13==0){}
else if(!(a13==0)){}
}
else{}
 if(!(a173==0)||(cf==false)&&(input==false)||(a13==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(cf==false)&&(input==false)||(a13==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(input==false)||(a62==0)&&(a173==0)||(a13==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a62==0)&&(a173==0)||(a13==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a13 ==0) || (a62==0) && (a173 ==0) || (cf==false) && (input==false)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a55 =0; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if(!(a13==0)||!(cf==false)||!(a173==0)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a173==0)||!(input==false)){
if(a13==0){}
else if(!(a13==0)){}
}
else{}
 if(!(a62==0)||!(a13==0)||!(a173==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(a13==0)||!(cf==false)||!(input==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a62==0)||!(a13==0)||!(cf==false)||!(a173==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (a13 ==0) && (cf==false) && (a173 ==0) && (input==false)){
    	cf = false;
    	a68 =0;
    	a62 =0;
    	a161 = 15; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm6(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a13==0){}
else if(!(a13==0)){}
}
else{}
 if(!(a13==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a13 ==0) && (cf==false)) {
    	calculateOutputm61(input);
    } 
//************************Modified code Start***********************************
 if((a13==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a13==0){}
else if(!(a13==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a13 ==0)){
    	calculateOutputm62(input);
    } 
//************************Modified code Start***********************************
 if(!(a13==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a13==0){}
else if(!(a13==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a13 ==0)){
    	calculateOutputm64(input);
    } 
}
private  void calculateOutputm65(boolean input) {
//************************Modified code Start***********************************
 if((a62==0)&&(a173==0)||(input==false)&&(cf==false)){
if(a149==0){}
else if(!(a149==0)){}
}
else{}
 if(!(cf==false)||(a62==0)&&(a173==0)||(a149==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a62==0)&&(a173==0)||(a149==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a173==0)||(input==false)&&(cf==false)||(a149==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(input==false)&&(cf==false)||(a149==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
//************************Modified code end***********************************
    if((a149==0) || (input==false) && (cf==false) || (a62==0) && (a173 ==0)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a69 =0; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if((a62==0)&&(a149==0)||(a173==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||(a62==0)&&(a149==0)||(input==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)||(a62==0)&&(a149==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a149==0)||(a173==0)&&(cf==false)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a173==0)&&(cf==false)||(input==false)){
if(a149==0){}
else if(!(a149==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (a173 ==0) && (cf==false) || (a62==0) && (a149==0)){
    	cf = false;
    	a173 = 9;
    	a26 = 14; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm68(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)&&(a62==0)||(input==false)&&(a173==0)){
if(a149==0){}
else if(!(a149==0)){}
}
else{}
 if(!(a173==0)||(cf==false)&&(a62==0)||(a149==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a62==0)||(a149==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a62==0)||(input==false)&&(a173==0)||(a149==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(input==false)&&(a173==0)||(a149==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a149==0) || (input==false) && (a173 ==0) || (cf==false) && (a62==0)){
    	cf = false;
    	a161 = 9;
    	a62 =0;
    	a49 = 5; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if((input==false)&&(a149==0)||(cf==false)&&(a62==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a62==0)||(input==false)&&(a149==0)||(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(input==false)&&(a149==0)||(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a149==0)||(cf==false)&&(a62==0)||(a173==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a62==0)||(a173==0)){
if(a149==0){}
else if(!(a149==0)){}
}
else{}
//************************Modified code end***********************************
    if((a173 ==0) || (cf==false) && (a62==0) || (input==false) && (a149==0)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a69 =0; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm7(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a149==0){}
else if(!(a149==0)){}
}
else{}
 if(!(a149==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a149==0) && (cf==false)) {
    	calculateOutputm65(input);
    } 
//************************Modified code Start***********************************
 if((a149==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a149==0){}
else if(!(a149==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a149==0)){
    	calculateOutputm68(input);
    } 
}
private  void calculateOutputm69(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)&&(input==false)||(a126==0)&&(a173==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a173==0)||(cf==false)&&(input==false)||(a62==0)){
if(a126==0){}
else if(!(a126==0)){}
}
else{}
 if(!(a126==0)||(cf==false)&&(input==false)||(a62==0)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(input==false)||(a126==0)&&(a173==0)||(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a126==0)&&(a173==0)||(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) || (a126 ==0) && (a173 ==0) || (cf==false) && (input==false)){
    	cf = false;
    	a126 = 13; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if((a62==0)&&(a173==0)||(cf==false)&&(a126==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a126==0)||(a62==0)&&(a173==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a62==0)&&(a173==0)||(input==false)){
if(a126==0){}
else if(!(a126==0)){}
}
else{}
 if(!(a173==0)||(cf==false)&&(a126==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(cf==false)&&(a126==0)||(input==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (cf==false) && (a126 ==0) || (a62==0) && (a173 ==0)){
    	cf = false;
    	a179 =0;
    	a62 =0;
    	a161 = 13; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm8(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a126==0){}
else if(!(a126==0)){}
}
else{}
 if(!(a126==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a126 ==0) && (cf==false)) {
    	calculateOutputm69(input);
    } 
}
private  void calculateOutputm78(boolean input) {
//************************Modified code Start***********************************
 if((a62==0)&&(input==false)||(cf==false)&&(a41==0)){
if(a55==0){}
else if(!(a55==0)){}
}
else{}
 if(!(a41==0)||(a62==0)&&(input==false)||(a55==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a62==0)&&(input==false)||(a55==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a41==0)||(a55==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(cf==false)&&(a41==0)||(a55==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a55==0) || (cf==false) && (a41==0) || (a62==0) && (input==false)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a3 = 14; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if(!(a55==0)||(input==false)&&(a41==0)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(input==false)&&(a41==0)||(cf==false)){
if(a55==0){}
else if(!(a55==0)){}
}
else{}
 if((input==false)&&(a41==0)||(a62==0)&&(a55==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a41==0)||(cf==false)||(a62==0)&&(a55==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)||(a62==0)&&(a55==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (a55==0) || (cf==false) || (input==false) && (a41==0)){
    	cf = false;
    	a68 =0;
    	a62 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm9(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a55==0){}
else if(!(a55==0)){}
}
else{}
 if(!(a55==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a55==0) && (cf==false)) {
    	calculateOutputm78(input);
    } 
}
private  void calculateOutputm82(boolean input) {
//************************Modified code Start***********************************
 if((a169==0)&&(input==false)||(cf==false)&&(a41==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a41==0)||(a169==0)&&(input==false)||(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a169==0)&&(input==false)||(a62==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a41==0)||(a62==0)){
if(a169==0){}
else if(!(a169==0)){}
}
else{}
 if(!(a169==0)||(cf==false)&&(a41==0)||(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) || (cf==false) && (a41==0) || (a169 ==0) && (input==false)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a137 =0; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if(!(a62==0)||(cf==false)&&(a169==0)||(a41==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a169==0)||(a41==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((cf==false)&&(a169==0)||(input==false)&&(a62==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a169==0)||(a41==0)||(input==false)&&(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a41==0)||(input==false)&&(a62==0)){
if(a169==0){}
else if(!(a169==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a62==0) || (a41==0) || (cf==false) && (a169 ==0)){
    	cf = false;
    	a50 = 15;
    	a62 =0;
    	a170 = 14; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm10(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a169==0){}
else if(!(a169==0)){}
}
else{}
 if(!(a169==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a169 ==0) && (cf==false)) {
    	calculateOutputm82(input);
    } 
}
private  void calculateOutputm84(boolean input) {
//************************Modified code Start***********************************
 if((a62==0)&&(a41==0)||(a188==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||(a62==0)&&(a41==0)||(input==false)){
if(a188==0){}
else if(!(a188==0)){}
}
else{}
 if(!(a188==0)||(a62==0)&&(a41==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a41==0)||(a188==0)&&(cf==false)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a188==0)&&(cf==false)||(input==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (a188==0) && (cf==false) || (a62==0) && (a41==0)){
    	cf = false;
    	a188 =0; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(a62==0)||(a188==0)&&(input==false)||(cf==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a41==0)||(a188==0)&&(input==false)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((a188==0)&&(input==false)||(a41==0)&&(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||(cf==false)||(a41==0)&&(a62==0)){
if(a188==0){}
else if(!(a188==0)){}
}
else{}
 if(!(a188==0)||(cf==false)||(a41==0)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a41==0) && (a62==0) || (cf==false) || (a188==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a137 =0; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm85(boolean input) {
//************************Modified code Start***********************************
 if(!(a62==0)||(input==false)&&(a41==0)||(cf==false)){
if(a188==0){}
else if(!(a188==0)){}
}
else{}
 if(!(a188==0)||(input==false)&&(a41==0)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((input==false)&&(a41==0)||(a188==0)&&(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a41==0)||(cf==false)||(a188==0)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)||(a188==0)&&(a62==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    if((a188==0) && (a62==0) || (cf==false) || (input==false) && (a41==0)){
    	cf = false;
    	a62 =0;
    	a161 = 12;
    	a148 = 4; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if((a188==0)&&(a41==0)||(a62==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||(a188==0)&&(a41==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a188==0)&&(a41==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a41==0)||(a62==0)&&(cf==false)||(input==false)){
if(a188==0){}
else if(!(a188==0)){}
}
else{}
 if(!(a188==0)||(a62==0)&&(cf==false)||(input==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (a62==0) && (cf==false) || (a188==0) && (a41==0)){
    	cf = false;
    	a188 =0; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm86(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||(a188==0)&&(a41==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a188==0)&&(a41==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a188==0)&&(a41==0)||(a62==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a41==0)||(input==false)||(a62==0)&&(cf==false)){
if(a188==0){}
else if(!(a188==0)){}
}
else{}
 if(!(a188==0)||(input==false)||(a62==0)&&(cf==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (cf==false) || (input==false) || (a188==0) && (a41==0)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a69 =0; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(a188==0)||!(a41==0)||!(cf==false)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(a41==0)||!(cf==false)||!(input==false)){
if(a188==0){}
else if(!(a188==0)){}
}
else{}
 if(!(a62==0)||!(a188==0)||!(cf==false)||!(input==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a62==0)||!(a188==0)||!(a41==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(a188==0)||!(a41==0)||!(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (a188==0) && (a41==0) && (cf==false) && (input==false)){
    	cf = false;
    	a41 =0;
    	a165 = 16; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm87(boolean input) {
//************************Modified code Start***********************************
 if((a41==0)&&(a62==0)||(input==false)&&(a188==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a188==0)||(a41==0)&&(a62==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a41==0)&&(a62==0)||(cf==false)){
if(a188==0){}
else if(!(a188==0)){}
}
else{}
 if(!(a62==0)||(input==false)&&(a188==0)||(cf==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a41==0)||(input==false)&&(a188==0)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (input==false) && (a188==0) || (a41==0) && (a62==0)){
    	cf = false;
    	a161 = 9;
    	a62 =0;
    	a49 = 9; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm11(boolean input) {
//************************Modified code Start***********************************
 if(!(a188==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a188==0){}
else if(!(a188==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a188==0)){
    	calculateOutputm84(input);
    } 
//************************Modified code Start***********************************
 if((a188==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a188==0){}
else if(!(a188==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a188==0)){
    	calculateOutputm85(input);
    } 
//************************Modified code Start***********************************
 if(!(a188==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a188==0){}
else if(!(a188==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a188==0)){
    	calculateOutputm86(input);
    } 
//************************Modified code Start***********************************
 if((cf==false)){
if(a188==0){}
else if(!(a188==0)){}
}
else{}
 if((a188==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a188==0) || (cf==false)) {
    	calculateOutputm87(input);
    } 
}
private  void calculateOutputm89(boolean input) {
//************************Modified code Start***********************************
 if((a62==0)&&(a165==0)&&(a41==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a62==0)&&(a165==0)&&(a41==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a165==0)||!(a41==0)||(cf==false)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(a41==0)||(cf==false)||(input==false)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if(!(a62==0)||!(a165==0)||(cf==false)||(input==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (cf==false) || (a62==0) && (a165 ==0) && (a41==0)){
    	cf = false;
    	a168 =0;
    	a62 =0;
    	a161 = 11; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(input==false)||(a62==0)&&(a41==0)||(cf==false)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if(!(a165==0)||(a62==0)&&(a41==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a62==0)&&(a41==0)||(a165==0)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a41==0)||(cf==false)||(a165==0)&&(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(cf==false)||(a165==0)&&(input==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    if((a165 ==0) && (input==false) || (cf==false) || (a62==0) && (a41==0)){
    	cf = false;
    	a41 =0;
    	a165 = 11; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm90(boolean input) {
//************************Modified code Start***********************************
 if((a41==0)&&(a62==0)||(input==false)&&(a165==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a165==00)||(a41==0)&&(a62==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a41==0)&&(a62==0)||(cf==false)){
if(a165==00){}
else if(!(a165==00)){}
}
else{}
 if(!(a62==0)||(input==false)&&(a165==00)||(cf==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a41==0)||(input==false)&&(a165==00)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (input==false) && (a165 ==00) || (a41==0) && (a62==0)){
    	cf = false;
    	a68 =0;
    	a62 =0;
    	a173 = 6; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if(!(a165==00)||(a62==0)&&(a41==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a62==0)&&(a41==0)||(cf==false)){
if(a165==00){}
else if(!(a165==00)){}
}
else{}
 if((a62==0)&&(a41==0)||(input==false)&&(a165==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a41==0)||(cf==false)||(input==false)&&(a165==00)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(cf==false)||(input==false)&&(a165==00)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a165 ==00) || (cf==false) || (a62==0) && (a41==0)){
    	cf = false;
    	a50 = 8;
    	a62 =0;
    	a196 = 5; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm93(boolean input) {
//************************Modified code Start***********************************
 if((a165==0)||(input==false)||(cf==false)&&(a62==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a62==0)||(a165==0)||(input==false)||(a41==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a165==0)||(input==false)||(a41==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((a165==0)||(cf==false)&&(a62==0)||(a41==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((input==false)||(cf==false)&&(a62==0)||(a41==0)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
//************************Modified code end***********************************
    if((a41==0) || (cf==false) && (a62==0) || (input==false) || (a165 ==0)){
    	cf = false;
    	a41 =0;
    	a188 =0; 
    	System.out.println("Z");
    } 
//************************Modified code Start***********************************
 if((a41==0)&&(cf==false)&&(a62==0)||(input==false)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if((a41==0)&&(cf==false)&&(a62==0)||(a165==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||!(a62==0)||(input==false)||(a165==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a41==0)||!(a62==0)||(input==false)||(a165==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a41==0)||!(cf==false)||(input==false)||(a165==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a165 ==0) || (input==false) || (a41==0) && (cf==false) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a188 =0; 
    	System.out.println("Z");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||(a165==0)&&(a62==0)||(a41==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a165==0)&&(a62==0)||(a41==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a165==0)&&(a62==0)||(input==false)&&(cf==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a62==0)||(a41==0)||(input==false)&&(cf==false)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if(!(a165==0)||(a41==0)||(input==false)&&(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (cf==false) || (a41==0) || (a165 ==0) && (a62==0)){
    	cf = false;
    	a41 =0; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm94(boolean input) {
//************************Modified code Start***********************************
 if((a165==0)&&(a41==0)||(input==false)&&(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(cf==false)||(a165==0)&&(a41==0)||(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a165==0)&&(a41==0)||(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a41==0)||(input==false)&&(cf==false)||(a62==0)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if(!(a165==0)||(input==false)&&(cf==false)||(a62==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) || (input==false) && (cf==false) || (a165 ==0) && (a41==0)){
    	cf = false;
    	a161 = 14;
    	a62 =0;
    	a26 = 10; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a41==0)||(cf==false)&&(input==false)||(a165==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(cf==false)&&(input==false)||(a165==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if((cf==false)&&(input==false)||(a62==0)&&(a41==0)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if(!(input==false)||(a165==0)||(a62==0)&&(a41==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a165==0)||(a62==0)&&(a41==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (a41==0) || (a165 ==0) || (cf==false) && (input==false)){
    	cf = false;
    	a19 =0;
    	a62 =0;
    	a161 = 16; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm12(boolean input) {
//************************Modified code Start***********************************
 if(!(a165==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a165 ==0)){
    	calculateOutputm89(input);
    } 
//************************Modified code Start***********************************
 if((cf==false)){
if(a165==00){}
else if(!(a165==00)){}
}
else{}
 if((a165==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a165 ==00) || (cf==false)) {
    	calculateOutputm90(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if(!(a165==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a165 ==0) && (cf==false)) {
    	calculateOutputm93(input);
    } 
//************************Modified code Start***********************************
 if((a165==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a165 ==0)){
    	calculateOutputm94(input);
    } 
}
private  void calculateOutputm99(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)&&(a41==0)||(input==false)&&(a62==0)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if(!(a62==0)||(cf==false)&&(a41==0)||(a165==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a41==0)||(a165==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a41==0)||(input==false)&&(a62==0)||(a165==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(input==false)&&(a62==0)||(a165==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    if((a165 ==0) || (input==false) && (a62==0) || (cf==false) && (a41==0)){
    	cf = false;
    	a41 =0;
    	a188 =0; 
    	System.out.println("Z");
    } 
//************************Modified code Start***********************************
 if((a165==0)&&(a41==0)||(cf==false)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||(a165==0)&&(a41==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a165==0)&&(a41==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a41==0)||(cf==false)&&(a62==0)||(input==false)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if(!(a165==0)||(cf==false)&&(a62==0)||(input==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (cf==false) && (a62==0) || (a165 ==0) && (a41==0)){
    	cf = false;
    	a41 =0;
    	a188 =0; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm101(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||(input==false)&&(a62==0)||(a165==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a41==0)||(input==false)&&(a62==0)||(a165==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((input==false)&&(a62==0)||(a41==0)&&(cf==false)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if(!(a62==0)||(a165==0)||(a41==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a165==0)||(a41==0)&&(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a41==0) && (cf==false) || (a165 ==0) || (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a50 = 15;
    	a170 = 16; 
    	System.out.println("Y");
    } 
//************************Modified code Start***********************************
 if((input==false)&&(cf==false)&&(a41==0)||(a165==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((input==false)&&(cf==false)&&(a41==0)||(a62==0)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if(!(cf==false)||!(a41==0)||(a165==0)||(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a41==0)||(a165==0)||(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||(a165==0)||(a62==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) || (a165 ==0) || (input==false) && (cf==false) && (a41==0)){
    	cf = false;
    	a62 =0;
    	a149 =0;
    	a173 = 11; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm102(boolean input) {
//************************Modified code Start***********************************
 if(!(a62==0)||(a41==0)&&(input==false)||(a165==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a41==0)&&(input==false)||(a165==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((a41==0)&&(input==false)||(cf==false)&&(a62==0)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if(!(input==false)||(a165==0)||(cf==false)&&(a62==0)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a41==0)||(a165==0)||(cf==false)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a62==0) || (a165 ==0) || (a41==0) && (input==false)){
    	cf = false;
    	a41 =0;
    	a188 =0; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm13(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if(!(a165==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a165 ==0) && (cf==false)) {
    	calculateOutputm99(input);
    } 
//************************Modified code Start***********************************
 if((cf==false)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if((a165==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a165 ==0) || (cf==false)) {
    	calculateOutputm101(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a165==0){}
else if(!(a165==0)){}
}
else{}
 if(!(a165==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a165 ==0) && (cf==false)) {
    	calculateOutputm102(input);
    } 
}
private  void calculateOutputm104(boolean input) {
//************************Modified code Start***********************************
 if((input==false)||(cf==false)&&(a49==0)||(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((input==false)||(cf==false)&&(a49==0)||(a62==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a49==0)||(input==false)||(a161==0)||(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(input==false)||(a161==0)||(a62==0)){
if(a49==0){}
else if(!(a49==0)){}
}
else{}
 if((cf==false)&&(a49==0)||(a161==0)||(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) || (a161 ==0) || (cf==false) && (a49 ==0) || (input==false)){
    	cf = false;
    	a19 =0;
    	a161 = 16; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm105(boolean input) {
//************************Modified code Start***********************************
 if(!(a62==0)||(input==false)&&(a161==0)||(cf==false)){
if(a49==0){}
else if(!(a49==0)){}
}
else{}
 if(!(a49==0)||(input==false)&&(a161==0)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((input==false)&&(a161==0)||(a49==0)&&(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a161==0)||(cf==false)||(a49==0)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)||(a49==0)&&(a62==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
//************************Modified code end***********************************
    if((a49 ==0) && (a62==0) || (cf==false) || (input==false) && (a161 ==0)){
    	cf = false;
    	a161 = 12;
    	a148 = 4; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(input==false)||(a49==0)&&(a62==0)||(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a161==0)||(a49==0)&&(a62==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a49==0)&&(a62==0)||(a161==0)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||(cf==false)||(a161==0)&&(input==false)){
if(a49==0){}
else if(!(a49==0)){}
}
else{}
 if(!(a49==0)||(cf==false)||(a161==0)&&(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==0) && (input==false) || (cf==false) || (a49 ==0) && (a62==0)){
    	cf = false;
    	a50 = 14;
    	a62 =0;
    	a16 = 10; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm108(boolean input) {
//************************Modified code Start***********************************
 if(!(input==false)||(cf==false)&&(a62==0)||(a49==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a161==0)||(cf==false)&&(a62==0)||(a49==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((cf==false)&&(a62==0)||(a161==0)&&(input==false)){
if(a49==0){}
else if(!(a49==0)){}
}
else{}
 if(!(a62==0)||(a49==0)||(a161==0)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a49==0)||(a161==0)&&(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==0) && (input==false) || (a49 ==0) || (cf==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a69 =0; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm110(boolean input) {
//************************Modified code Start***********************************
 if((a161==0)&&(input==false)||(a49==0)&&(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||(a161==0)&&(input==false)||(cf==false)){
if(a49==0){}
else if(!(a49==0)){}
}
else{}
 if(!(a49==0)||(a161==0)&&(input==false)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(input==false)||(a49==0)&&(a62==0)||(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a161==0)||(a49==0)&&(a62==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a49 ==0) && (a62==0) || (a161 ==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a188 =0; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||(input==false)&&(a49==0)||(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(input==false)&&(a49==0)||(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((input==false)&&(a49==0)||(a62==0)&&(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a49==0)||(a161==0)||(a62==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a161==0)||(a62==0)&&(cf==false)){
if(a49==0){}
else if(!(a49==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (cf==false) || (a161 ==0) || (input==false) && (a49 ==0)){
    	cf = false;
    	a62 =0;
    	a152 =0;
    	a173 = 8; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm14(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a49==0){}
else if(!(a49==0)){}
}
else{}
 if(!(a49==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a49 ==0) && (cf==false)) {
    	calculateOutputm104(input);
    } 
//************************Modified code Start***********************************
 if((cf==false)){
if(a49==0){}
else if(!(a49==0)){}
}
else{}
 if((a49==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a49 ==0) || (cf==false)) {
    	calculateOutputm105(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a49==0){}
else if(!(a49==0)){}
}
else{}
 if(!(a49==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a49 ==0) && (cf==false)) {
    	calculateOutputm108(input);
    } 
//************************Modified code Start***********************************
 if((cf==false)){
if(a49==0){}
else if(!(a49==0)){}
}
else{}
 if((a49==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a49 ==0) || (cf==false)) {
    	calculateOutputm110(input);
    } 
}
private  void calculateOutputm111(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||(a187==0)&&(input==false)||(a161==00)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a187==0)&&(input==false)||(a161==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a187==0)&&(input==false)||(a62==0)&&(cf==false)){
if(a161==00){}
else if(!(a161==00)){}
}
else{}
 if(!(input==false)||(a161==00)||(a62==0)&&(cf==false)){
if(a187==0){}
else if(!(a187==0)){}
}
else{}
 if(!(a187==0)||(a161==00)||(a62==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (cf==false) || (a161 ==00) || (a187 ==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a152 =0;
    	a173 = 8; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm115(boolean input) {
//************************Modified code Start***********************************
 if((a62==0)&&(input==false)||(cf==false)&&(a161==00)){
if(a187==0){}
else if(!(a187==0)){}
}
else{}
 if(!(a161==00)||(a62==0)&&(input==false)||(a187==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a62==0)&&(input==false)||(a187==0)){
if(a161==00){}
else if(!(a161==00)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a161==00)||(a187==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(cf==false)&&(a161==00)||(a187==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a187 ==0) || (cf==false) && (a161 ==00) || (a62==0) && (input==false)){
    	cf = false;
    	a187 = 10; 
    	System.out.println("Y");
    } 
//************************Modified code Start***********************************
 if((a187==0)&&(input==false)||(cf==false)&&(a62==0)){
if(a161==00){}
else if(!(a161==00)){}
}
else{}
 if(!(a62==0)||(a187==0)&&(input==false)||(a161==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a187==0)&&(input==false)||(a161==00)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(input==false)||(cf==false)&&(a62==0)||(a161==00)){
if(a187==0){}
else if(!(a187==0)){}
}
else{}
 if(!(a187==0)||(cf==false)&&(a62==0)||(a161==00)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==00) || (cf==false) && (a62==0) || (a187 ==0) && (input==false)){
    	cf = false;
    	a68 =0;
    	a62 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if((cf==false)&&(a187==0)&&(a161==00)||(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((cf==false)&&(a187==0)&&(a161==00)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a187==0)||!(a161==00)||(a62==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a161==00)||(a62==0)||(input==false)){
if(a187==0){}
else if(!(a187==0)){}
}
else{}
 if(!(cf==false)||!(a187==0)||(a62==0)||(input==false)){
if(a161==00){}
else if(!(a161==00)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (a62==0) || (cf==false) && (a187 ==0) && (a161 ==00)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a137 =0; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm15(boolean input) {
//************************Modified code Start***********************************
 if(!(a187==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a187==0){}
else if(!(a187==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a187 ==0)){
    	calculateOutputm111(input);
    } 
//************************Modified code Start***********************************
 if((a187==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a187==0){}
else if(!(a187==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a187 ==0)){
    	calculateOutputm115(input);
    } 
}
private  void calculateOutputm121(boolean input) {
//************************Modified code Start***********************************
 if((a168==0)&&(input==false)||(a62==0)&&(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a161==0)||(a168==0)&&(input==false)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a168==0)&&(input==false)||(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(input==false)||(a62==0)&&(a161==0)||(cf==false)){
if(a168==0){}
else if(!(a168==0)){}
}
else{}
 if(!(a168==0)||(a62==0)&&(a161==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a62==0) && (a161 ==0) || (a168==0) && (input==false)){
    	cf = false;
    	a179 =0;
    	a161 = 13; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if((a168==0)||(input==false)||(cf==false)&&(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a161==0)||(a168==0)||(input==false)||(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a168==0)||(input==false)||(a62==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if((a168==0)||(cf==false)&&(a161==0)||(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((input==false)||(cf==false)&&(a161==0)||(a62==0)){
if(a168==0){}
else if(!(a168==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) || (cf==false) && (a161 ==0) || (input==false) || (a168==0)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a69 =0; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(a161==0)||(a168==0)&&(cf==false)||(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a168==0)&&(cf==false)||(a62==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if((a168==0)&&(cf==false)||(input==false)&&(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(cf==false)||(a62==0)||(input==false)&&(a161==0)){
if(a168==0){}
else if(!(a168==0)){}
}
else{}
 if(!(a168==0)||(a62==0)||(input==false)&&(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a161 ==0) || (a62==0) || (a168==0) && (cf==false)){
    	cf = false;
    	a68 =0;
    	a161 = 15; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm122(boolean input) {
//************************Modified code Start***********************************
 if(!(a168==0)||(input==false)&&(a62==0)||(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a161==0)||(input==false)&&(a62==0)||(cf==false)){
if(a168==0){}
else if(!(a168==0)){}
}
else{}
 if((input==false)&&(a62==0)||(a161==0)&&(a168==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||(cf==false)||(a161==0)&&(a168==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)||(a161==0)&&(a168==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==0) && (a168==0) || (cf==false) || (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a152 =0; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm16(boolean input) {
//************************Modified code Start***********************************
 if((a168==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a168==0){}
else if(!(a168==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a168==0)){
    	calculateOutputm121(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a168==0){}
else if(!(a168==0)){}
}
else{}
 if(!(a168==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a168==0) && (cf==false)) {
    	calculateOutputm122(input);
    } 
}
private  void calculateOutputm126(boolean input) {
//************************Modified code Start***********************************
 if(!(a161==0)||(a148==0)&&(input==false)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a148==0)&&(input==false)||(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if((a148==0)&&(input==false)||(a62==0)&&(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||(cf==false)||(a62==0)&&(a161==0)){
if(a148==0){}
else if(!(a148==0)){}
}
else{}
 if(!(a148==0)||(cf==false)||(a62==0)&&(a161==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (a161 ==0) || (cf==false) || (a148 ==0) && (input==false)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a165 = 11; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm17(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a148==0){}
else if(!(a148==0)){}
}
else{}
 if(!(a148==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a148 ==0) && (cf==false)) {
    	calculateOutputm126(input);
    } 
}
private  void calculateOutputm130(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)&&(a62==0)&&(a161==0)||(input==false)){
if(a179==0){}
else if(!(a179==0)){}
}
else{}
 if((cf==false)&&(a62==0)&&(a161==0)||(a179==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||!(a161==0)||(input==false)||(a179==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a161==0)||(input==false)||(a179==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(cf==false)||!(a62==0)||(input==false)||(a179==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
//************************Modified code end***********************************
    if((a179==0) || (input==false) || (cf==false) && (a62==0) && (a161 ==0)){
    	cf = false;
    	a161 = 9;
    	a49 = 6; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm131(boolean input) {
//************************Modified code Start***********************************
 if(!(input==false)||(a161==0)&&(a179==0)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a161==0)&&(a179==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a161==0)&&(a179==0)||(a62==0)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a179==0)||(cf==false)||(a62==0)&&(input==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a161==0)||(cf==false)||(a62==0)&&(input==false)){
if(a179==0){}
else if(!(a179==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (input==false) || (cf==false) || (a161 ==0) && (a179==0)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a173 = 7; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm133(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||(a179==0)&&(input==false)||(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a179==0)&&(input==false)||(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a179==0)&&(input==false)||(a62==0)&&(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(input==false)||(a161==0)||(a62==0)&&(cf==false)){
if(a179==0){}
else if(!(a179==0)){}
}
else{}
 if(!(a179==0)||(a161==0)||(a62==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (cf==false) || (a161 ==0) || (a179==0) && (input==false)){
    	cf = false;
    	a50 = 9;
    	a62 =0;
    	a175 = 9; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if((cf==false)&&(a179==0)||(a62==0)&&(a161==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a161==0)||(cf==false)&&(a179==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(cf==false)&&(a179==0)||(input==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a179==0)||(a62==0)&&(a161==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a62==0)&&(a161==0)||(input==false)){
if(a179==0){}
else if(!(a179==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (a62==0) && (a161 ==0) || (cf==false) && (a179==0)){
    	cf = false;
    	a168 =0;
    	a161 = 11; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm18(boolean input) {
//************************Modified code Start***********************************
 if(!(a179==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a179==0){}
else if(!(a179==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a179==0)){
    	calculateOutputm130(input);
    } 
//************************Modified code Start***********************************
 if((a179==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a179==0){}
else if(!(a179==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a179==0)){
    	calculateOutputm131(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a179==0){}
else if(!(a179==0)){}
}
else{}
 if(!(a179==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a179==0) && (cf==false)) {
    	calculateOutputm133(input);
    } 
}
private  void calculateOutputm134(boolean input) {
//************************Modified code Start***********************************
 if((input==false)&&(a62==0)||(a26==0)&&(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(cf==false)||(input==false)&&(a62==0)||(a161==0)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
 if(!(a26==0)||(input==false)&&(a62==0)||(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||(a26==0)&&(cf==false)||(a161==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a26==0)&&(cf==false)||(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==0) || (a26 ==0) && (cf==false) || (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a62==0)||(input==false)&&(a161==0)||(cf==false)){
if(a26==00){}
else if(!(a26==00)){}
}
else{}
 if(!(a26==00)||(input==false)&&(a161==0)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((input==false)&&(a161==0)||(a26==00)&&(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a161==0)||(cf==false)||(a26==00)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)||(a26==00)&&(a62==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
//************************Modified code end***********************************
    if((a26 ==00) && (a62==0) || (cf==false) || (input==false) && (a161 ==0)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a97 =0; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm136(boolean input) {
//************************Modified code Start***********************************
 if(!(a26==0)||(a161==0)||(input==false)&&(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a161==0)||(input==false)&&(cf==false)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
 if(!(cf==false)||(a161==0)||(a62==0)&&(a26==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a161==0)||(a62==0)&&(a26==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((input==false)&&(cf==false)||(a62==0)&&(a26==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (a26 ==0) || (input==false) && (cf==false) || (a161 ==0)){
    	cf = false;
    	a62 =0;
    	a50 = 10;
    	a141 = 8; 
    	System.out.println("X");
    } 
//************************Modified code Start***********************************
 if((input==false)&&(a26==0)||(a161==0)&&(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(cf==false)||(input==false)&&(a26==0)||(a62==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a161==0)||(input==false)&&(a26==0)||(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a26==0)||(a161==0)&&(cf==false)||(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a161==0)&&(cf==false)||(a62==0)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) || (a161 ==0) && (cf==false) || (input==false) && (a26 ==0)){
    	cf = false;
    	a62 =0;
    	a173 = 9;
    	a26 = 13; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if((a26==0)&&(a62==0)||(cf==false)||(input==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if((a26==0)&&(a62==0)||(cf==false)||(a161==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a26==0)&&(a62==0)||(input==false)||(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||(cf==false)||(input==false)||(a161==0)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
 if(!(a26==0)||(cf==false)||(input==false)||(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==0) || (input==false) || (cf==false) || (a26 ==0) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a3 = 10; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||(a62==0)||(a161==0)&&(input==false)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
 if(!(a26==0)||(a62==0)||(a161==0)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||(a62==0)||(a26==0)&&(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a161==0)||(a62==0)||(a26==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((a161==0)&&(input==false)||(a26==0)&&(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a26 ==0) && (cf==false) || (a161 ==0) && (input==false) || (a62==0)){
    	cf = false;
    	a161 = 9;
    	a49 = 5; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm137(boolean input) {
//************************Modified code Start***********************************
 if((input==false)&&(a26==0)||(a62==0)&&(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(cf==false)||(input==false)&&(a26==0)||(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(input==false)&&(a26==0)||(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a26==0)||(a62==0)&&(cf==false)||(a161==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a62==0)&&(cf==false)||(a161==0)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==0) || (a62==0) && (cf==false) || (input==false) && (a26 ==0)){
    	cf = false;
    	a50 = 9;
    	a62 =0;
    	a175 = 7; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm19(boolean input) {
//************************Modified code Start***********************************
 if((cf==false)){
if(a26==00){}
else if(!(a26==00)){}
}
else{}
 if((a26==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a26 ==00) || (cf==false)) {
    	calculateOutputm134(input);
    } 
//************************Modified code Start***********************************
 if(!(a26==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a26 ==0)){
    	calculateOutputm136(input);
    } 
//************************Modified code Start***********************************
 if((cf==false)){
if(a26==0){}
else if(!(a26==0)){}
}
else{}
 if((a26==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a26 ==0) || (cf==false)) {
    	calculateOutputm137(input);
    } 
}
private  void calculateOutputm139(boolean input) {
//************************Modified code Start***********************************
 if(!(a62==0)||(input==false)&&(a161==0)||(cf==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if(!(a68==0)||(input==false)&&(a161==0)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((input==false)&&(a161==0)||(a68==0)&&(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a161==0)||(cf==false)||(a68==0)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)||(a68==0)&&(a62==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
//************************Modified code end***********************************
    if((a68==0) && (a62==0) || (cf==false) || (input==false) && (a161 ==0)){
    	cf = false;
    	a73 =0;
    	a62 =0;
    	a50 = 13; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if(!(a161==0)||(a62==0)&&(a68==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a62==0)&&(a68==0)||(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if((a62==0)&&(a68==0)||(input==false)&&(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a68==0)||(cf==false)||(input==false)&&(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(cf==false)||(input==false)&&(a161==0)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a161 ==0) || (cf==false) || (a62==0) && (a68==0)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if((a62==0)&&(cf==false)&&(input==false)||(a161==0)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if((a62==0)&&(cf==false)&&(input==false)||(a68==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(cf==false)||!(input==false)||(a161==0)||(a68==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(input==false)||(a161==0)||(a68==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||(a161==0)||(a68==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a68==0) || (a161 ==0) || (a62==0) && (cf==false) && (input==false)){
    	cf = false;
    	a161 = 9;
    	a49 = 5; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm140(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||(a68==0)&&(a161==0)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a68==0)&&(a161==0)&&(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a161==0)||!(a62==0)||(input==false)&&(cf==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if(!(a68==0)||!(a62==0)||(input==false)&&(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a68==0)||!(a161==0)||(input==false)&&(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (cf==false) || (a68==0) && (a161 ==0) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a50 = 15;
    	a170 = 10; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if(!(input==false)||(cf==false)&&(a62==0)||(a68==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a161==0)||(cf==false)&&(a62==0)||(a68==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if((cf==false)&&(a62==0)||(a161==0)&&(input==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if(!(a62==0)||(a68==0)||(a161==0)&&(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a68==0)||(a161==0)&&(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==0) && (input==false) || (a68==0) || (cf==false) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a165 = 9; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a161==0)||(input==false)&&(a62==0)||(cf==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if(!(a68==0)||(input==false)&&(a62==0)||(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if((input==false)&&(a62==0)||(a68==0)&&(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||(cf==false)||(a68==0)&&(a161==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)||(a68==0)&&(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a68==0) && (a161 ==0) || (cf==false) || (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a188 =0; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if((cf==false)&&(a62==0)&&(input==false)||(a161==0)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if((cf==false)&&(a62==0)&&(input==false)||(a68==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a62==0)||!(input==false)||(a161==0)||(a68==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(input==false)||(a161==0)||(a68==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(cf==false)||!(a62==0)||(a161==0)||(a68==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a68==0) || (a161 ==0) || (cf==false) && (a62==0) && (input==false)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a3 = 13; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm141(boolean input) {
//************************Modified code Start***********************************
 if((a68==0)&&(a62==0)||(cf==false)&&(a161==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a161==0)||(a68==0)&&(a62==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a68==0)&&(a62==0)||(input==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a62==0)||(cf==false)&&(a161==0)||(input==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if(!(a68==0)||(cf==false)&&(a161==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (cf==false) && (a161 ==0) || (a68==0) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a188 =0; 
    	System.out.println("X");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||(a62==0)&&(input==false)||(a161==0)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if(!(a68==0)||(a62==0)&&(input==false)||(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((a62==0)&&(input==false)||(a68==0)&&(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(input==false)||(a161==0)||(a68==0)&&(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a161==0)||(a68==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a68==0) && (cf==false) || (a161 ==0) || (a62==0) && (input==false)){
    	cf = false;
    	a50 = 9;
    	a62 =0;
    	a175 = 13; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm142(boolean input) {
//************************Modified code Start***********************************
 if((a62==0)&&(input==false)||(a68==0)&&(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a161==0)||(a62==0)&&(input==false)||(cf==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if(!(a68==0)||(a62==0)&&(input==false)||(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(input==false)||(a68==0)&&(a161==0)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(a68==0)&&(a161==0)||(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a68==0) && (a161 ==0) || (a62==0) && (input==false)){
    	cf = false;
    	a161 = 12;
    	a148 = 4; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if((cf==false)&&(a68==0)||(a161==0)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||(cf==false)&&(a68==0)||(input==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a161==0)||(cf==false)&&(a68==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a68==0)||(a161==0)&&(a62==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a161==0)&&(a62==0)||(input==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (a161 ==0) && (a62==0) || (cf==false) && (a68==0)){
    	cf = false;
    	a152 =0;
    	a62 =0;
    	a173 = 8; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm20(boolean input) {
//************************Modified code Start***********************************
 if((a68==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a68==0)){
    	calculateOutputm139(input);
    } 
//************************Modified code Start***********************************
 if(!(a68==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a68==0)){
    	calculateOutputm140(input);
    } 
//************************Modified code Start***********************************
 if((cf==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
 if((a68==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a68==0) || (cf==false)) {
    	calculateOutputm141(input);
    } 
//************************Modified code Start***********************************
 if(!(a68==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a68==0){}
else if(!(a68==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a68==0)){
    	calculateOutputm142(input);
    } 
}
private  void calculateOutputm143(boolean input) {
//************************Modified code Start***********************************
 if(!(a62==0)||(input==false)&&(a19==0)||(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a161==0)||(input==false)&&(a19==0)||(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((input==false)&&(a19==0)||(a161==0)&&(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a19==0)||(cf==false)||(a161==0)&&(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(cf==false)||(a161==0)&&(a62==0)){
if(a19==0){}
else if(!(a19==0)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==0) && (a62==0) || (cf==false) || (input==false) && (a19==0)){
    	cf = false;
    	a68 =0;
    	a62 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if((input==false)||(a19==0)||(cf==false)&&(a62==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a62==0)||(input==false)||(a19==0)||(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(input==false)||(a19==0)||(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if((input==false)||(cf==false)&&(a62==0)||(a161==0)){
if(a19==0){}
else if(!(a19==0)){}
}
else{}
 if((a19==0)||(cf==false)&&(a62==0)||(a161==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==0) || (cf==false) && (a62==0) || (a19==0) || (input==false)){
    	cf = false;
    	 
    	System.out.println("V");
    } 
}
private  void calculateOutputm145(boolean input) {
//************************Modified code Start***********************************
 if((a62==0)&&(a19==0)||(cf==false)&&(input==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(input==false)||(a62==0)&&(a19==0)||(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a62==0)&&(a19==0)||(a161==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a19==0)||(cf==false)&&(input==false)||(a161==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(cf==false)&&(input==false)||(a161==0)){
if(a19==0){}
else if(!(a19==0)){}
}
else{}
//************************Modified code end***********************************
    if((a161 ==0) || (cf==false) && (input==false) || (a62==0) && (a19==0)){
    	cf = false;
    	a173 = 9;
    	a62 =0;
    	a26 = 16; 
    	System.out.println("Z");
    } 
//************************Modified code Start***********************************
 if((cf==false)&&(a62==0)||(a19==0)&&(a161==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a161==0)||(cf==false)&&(a62==0)||(input==false)){
if(a19==0){}
else if(!(a19==0)){}
}
else{}
 if(!(a19==0)||(cf==false)&&(a62==0)||(input==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a62==0)||(a19==0)&&(a161==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a19==0)&&(a161==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (a19==0) && (a161 ==0) || (cf==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a161==0)||(input==false)||(cf==false)&&(a19==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(input==false)||(cf==false)&&(a19==0)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a19==0)||(input==false)||(a62==0)&&(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(input==false)||(a62==0)&&(a161==0)){
if(a19==0){}
else if(!(a19==0)){}
}
else{}
 if((cf==false)&&(a19==0)||(a62==0)&&(a161==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (a161 ==0) || (cf==false) && (a19==0) || (input==false)){
    	cf = false;
    	a19 =0; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm21(boolean input) {
//************************Modified code Start***********************************
 if(!(a19==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a19==0){}
else if(!(a19==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a19==0)){
    	calculateOutputm143(input);
    } 
//************************Modified code Start***********************************
 if((a19==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((cf==false)){
if(a19==0){}
else if(!(a19==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) || (a19==0)){
    	calculateOutputm145(input);
    } 
}
private  void calculateOutputm147(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||(input==false)&&(a50==0)||(a196==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(input==false)&&(a50==0)||(a196==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if((input==false)&&(a50==0)||(a62==0)&&(cf==false)){
if(a196==0){}
else if(!(a196==0)){}
}
else{}
 if(!(a50==0)||(a196==0)||(a62==0)&&(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a196==0)||(a62==0)&&(cf==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (cf==false) || (a196 ==0) || (input==false) && (a50 ==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a165 = 14; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if((a62==0)&&(a196==0)||(input==false)&&(cf==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(cf==false)||(a62==0)&&(a196==0)||(a50==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||(a62==0)&&(a196==0)||(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a196==0)||(input==false)&&(cf==false)||(a50==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||(input==false)&&(cf==false)||(a50==0)){
if(a196==0){}
else if(!(a196==0)){}
}
else{}
//************************Modified code end***********************************
    if((a50 ==0) || (input==false) && (cf==false) || (a62==0) && (a196 ==0)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a3 = 8; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm149(boolean input) {
//************************Modified code Start***********************************
 if((a62==0)||(a50==0)||(cf==false)&&(a196==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a196==0)||(a62==0)||(a50==0)||(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||(a62==0)||(a50==0)||(input==false)){
if(a196==0){}
else if(!(a196==0)){}
}
else{}
 if((a62==0)||(cf==false)&&(a196==0)||(input==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if((a50==0)||(cf==false)&&(a196==0)||(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) || (cf==false) && (a196 ==0) || (a50 ==0) || (a62==0)){
    	cf = false;
    	a50 = 12;
    	a65 = 5; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(a50==0)||!(a62==0)||!(cf==false)||!(input==false)){
if(a196==0){}
else if(!(a196==0)){}
}
else{}
 if(!(a196==0)||!(a62==0)||!(cf==false)||!(input==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a196==0)||!(a50==0)||!(cf==false)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a196==0)||!(a50==0)||!(a62==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a196==0)||!(a50==0)||!(a62==0)||!(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a196 ==0) && (a50 ==0) && (a62==0) && (cf==false) && (input==false)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a169 = 3; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(a196==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a196==0){}
else if(!(a196==0)){}
}
else{}
 if(!(a50==0)||!(a196==0)||!(input==false)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a50==0)||!(a196==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a50==0)||!(a196==0)||!(cf==false)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a50 ==0) && (a196 ==0) && (cf==false) && (input==false) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a165 = 10; 
    	System.out.println("Y");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||!(a50==0)||!(a196==0)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(a196==0)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a196==0)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a50==0)||!(a62==0)){
if(a196==0){}
else if(!(a196==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a50==0)||!(a196==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (cf==false) && (a50 ==0) && (a196 ==0) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a173 = 6; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm22(boolean input) {
//************************Modified code Start***********************************
 if(!(a196==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a196==0){}
else if(!(a196==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a196 ==0)){
    	calculateOutputm147(input);
    } 
//************************Modified code Start***********************************
 if(!(a196==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a196==0){}
else if(!(a196==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a196 ==0)){
    	calculateOutputm149(input);
    } 
}
private  void calculateOutputm153(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(input==false)||!(a50==0)||!(a175==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(a50==0)||!(a175==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a50==0)||!(a175==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(input==false)||!(a175==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(input==false)||!(a50==0)){
if(a175==0){}
else if(!(a175==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (cf==false) && (input==false) && (a50 ==0) && (a175 ==0)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(input==false)||!(a175==0)||!(cf==false)||!(a50==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(a175==0)||!(cf==false)||!(a50==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(cf==false)||!(a50==0)){
if(a175==0){}
else if(!(a175==0)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(a175==0)||!(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(a175==0)||!(cf==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (input==false) && (a175 ==0) && (cf==false) && (a50 ==0)){
    	cf = false;
    	a62 =0;
    	a19 =0;
    	a161 = 16; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||!(input==false)||!(a175==0)||!(a50==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(a175==0)||!(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a175==0)||!(a50==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(input==false)||!(a50==0)){
if(a175==0){}
else if(!(a175==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(input==false)||!(a175==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (cf==false) && (input==false) && (a175 ==0) && (a50 ==0)){
    	cf = false;
    	a62 =0;
    	a161 = 9;
    	a49 = 4; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm154(boolean input) {
//************************Modified code Start***********************************
 if(!(a175==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a175==0){}
else if(!(a175==0)){}
}
else{}
 if(!(a50==0)||!(a175==0)||!(input==false)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a50==0)||!(a175==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a50==0)||!(a175==0)||!(cf==false)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a50 ==0) && (a175 ==0) && (cf==false) && (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a188 =0; 
    	System.out.println("Z");
    } 
//************************Modified code Start***********************************
 if(!(a175==0)||!(input==false)||!(cf==false)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)||!(input==false)||!(cf==false)||!(a62==0)){
if(a175==0){}
else if(!(a175==0)){}
}
else{}
 if(!(a50==0)||!(a175==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a50==0)||!(a175==0)||!(input==false)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a50==0)||!(a175==0)||!(input==false)||!(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a50 ==0) && (a175 ==0) && (input==false) && (cf==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a161 = 15; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm156(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(a62==0)||!(a50==0)||!(a175==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a62==0)||!(a50==0)||!(a175==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a50==0)||!(a175==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a62==0)||!(a175==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a62==0)||!(a50==0)){
if(a175==0){}
else if(!(a175==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (cf==false) && (a62==0) && (a50 ==0) && (a175 ==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a173 = 7; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm23(boolean input) {
//************************Modified code Start***********************************
 if(!(a175==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a175==0){}
else if(!(a175==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a175 ==0)){
    	calculateOutputm153(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a175==0){}
else if(!(a175==0)){}
}
else{}
 if(!(a175==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a175 ==0) && (cf==false)) {
    	calculateOutputm154(input);
    } 
//************************Modified code Start***********************************
 if(!(a175==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a175==0){}
else if(!(a175==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a175 ==0)){
    	calculateOutputm156(input);
    } 
}
private  void calculateOutputm169(boolean input) {
//************************Modified code Start***********************************
 if(!(a11==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
 if(!(a50==0)||!(a11==0)||!(input==false)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a50==0)||!(a11==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a50==0)||!(a11==0)||!(cf==false)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a50 ==0) && (a11 ==0) && (cf==false) && (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a188 =0; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||!(a50==0)||!(a11==0)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(a50==0)||!(a11==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a11==0)||!(input==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a50==0)||!(input==false)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a50==0)||!(a11==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (cf==false) && (a50 ==0) && (a11 ==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a161 = 12;
    	a148 = 4; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||!(a50==0)||!(a11==0)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(a50==0)||!(a11==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a11==0)||!(input==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a50==0)||!(input==false)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a50==0)||!(a11==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (cf==false) && (a50 ==0) && (a11 ==0) && (input==false)){
    	cf = false;
    	a50 = 10;
    	a141 = 10; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm170(boolean input) {
//************************Modified code Start***********************************
 if(!(input==false)||!(cf==false)||!(a50==0)||!(a62==0)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
 if(!(a11==0)||!(cf==false)||!(a50==0)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a11==0)||!(input==false)||!(a50==0)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a11==0)||!(input==false)||!(cf==false)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a11==0)||!(input==false)||!(cf==false)||!(a50==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a11 ==0) && (input==false) && (cf==false) && (a50 ==0) && (a62==0)){
    	cf = false;
    	a149 =0;
    	a62 =0;
    	a173 = 11; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a50==0)||!(input==false)||!(cf==false)||!(a62==0)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
 if(!(a11==0)||!(input==false)||!(cf==false)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a11==0)||!(a50==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a11==0)||!(a50==0)||!(input==false)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a11==0)||!(a50==0)||!(input==false)||!(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a11 ==0) && (a50 ==0) && (input==false) && (cf==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a161 = 9;
    	a49 = 5; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm171(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(a11==00)||!(a50==0)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(a11==00)||!(a50==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a50==0)||!(input==false)){
if(a11==00){}
else if(!(a11==00)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a11==00)||!(input==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a11==00)||!(a50==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (cf==false) && (a11 ==00) && (a50 ==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a173 = 9;
    	a26 = 12; 
    	System.out.println("Z");
    } 
//************************Modified code Start***********************************
 if(!(a62==0)||!(cf==false)||!(input==false)||!(a11==00)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(input==false)||!(a11==00)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a50==0)||!(a62==0)||!(input==false)||!(a11==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a50==0)||!(a62==0)||!(cf==false)||!(a11==00)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a50==0)||!(a62==0)||!(cf==false)||!(input==false)){
if(a11==00){}
else if(!(a11==00)){}
}
else{}
//************************Modified code end***********************************
    if((a50 ==0) && (a62==0) && (cf==false) && (input==false) && (a11 ==00)){
    	cf = false;
    	a62 =0;
    	a161 = 10;
    	a187 = 3; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm173(boolean input) {
//************************Modified code Start***********************************
 if(!(a62==0)||!(input==false)||!(cf==false)||!(a50==0)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
 if(!(a11==0)||!(input==false)||!(cf==false)||!(a50==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a11==0)||!(a62==0)||!(cf==false)||!(a50==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a11==0)||!(a62==0)||!(input==false)||!(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a11==0)||!(a62==0)||!(input==false)||!(cf==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
//************************Modified code end***********************************
    if((a11 ==0) && (a62==0) && (input==false) && (cf==false) && (a50 ==0)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a69 =0; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(a50==0)||!(a11==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a11==0)||!(cf==false)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(cf==false)||!(a62==0)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(a11==0)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(a11==0)||!(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a50 ==0) && (a11 ==0) && (cf==false) && (a62==0)){
    	cf = false;
    	a179 =0;
    	a62 =0;
    	a161 = 13; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm174(boolean input) {
//************************Modified code Start***********************************
 if(!(a62==0)||!(input==false)||!(a50==0)||!(a11==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(input==false)||!(a50==0)||!(a11==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(cf==false)||!(a62==0)||!(a50==0)||!(a11==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||!(a62==0)||!(input==false)||!(a11==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(cf==false)||!(a62==0)||!(input==false)||!(a50==0)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a62==0) && (input==false) && (a50 ==0) && (a11 ==0)){
    	cf = false;
    	a50 = 8;
    	a196 = 9; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if(!(input==false)||!(cf==false)||!(a11==0)||!(a50==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a11==0)||!(a50==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(a11==0)||!(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(cf==false)||!(a50==0)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(cf==false)||!(a11==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (input==false) && (cf==false) && (a11 ==0) && (a50 ==0)){
    	cf = false;
    	a50 = 15;
    	a170 = 12; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if(!(a11==0)||!(a50==0)||!(input==false)||!(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(a50==0)||!(input==false)||!(cf==false)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
 if(!(a62==0)||!(a11==0)||!(input==false)||!(cf==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a62==0)||!(a11==0)||!(a50==0)||!(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||!(a11==0)||!(a50==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (a11 ==0) && (a50 ==0) && (input==false) && (cf==false)){
    	cf = false;
    	a68 =0;
    	a62 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm25(boolean input) {
//************************Modified code Start***********************************
 if(!(a11==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a11 ==0)){
    	calculateOutputm169(input);
    } 
//************************Modified code Start***********************************
 if(!(a11==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a11 ==0)){
    	calculateOutputm170(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a11==00){}
else if(!(a11==00)){}
}
else{}
 if(!(a11==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a11 ==00) && (cf==false)) {
    	calculateOutputm171(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
 if(!(a11==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a11 ==0) && (cf==false)) {
    	calculateOutputm173(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a11==0){}
else if(!(a11==0)){}
}
else{}
 if(!(a11==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a11 ==0) && (cf==false)) {
    	calculateOutputm174(input);
    } 
}
private  void calculateOutputm176(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(a65==0)||!(input==false)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)||!(a65==0)||!(input==false)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a65==0){}
else if(!(a65==0)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(a65==0)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(a65==0)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a50 ==0) && (cf==false) && (a65 ==0) && (input==false) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a55 =0; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a50==0)||!(a65==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a65==0)||!(cf==false)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(cf==false)||!(a62==0)){
if(a65==0){}
else if(!(a65==0)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(a65==0)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(a65==0)||!(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a50 ==0) && (a65 ==0) && (cf==false) && (a62==0)){
    	cf = false;
    	a161 = 9;
    	a62 =0;
    	a49 = 5; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm26(boolean input) {
//************************Modified code Start***********************************
 if(!(a65==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a65==0){}
else if(!(a65==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a65 ==0)){
    	calculateOutputm176(input);
    } 
}
private  void calculateOutputm181(boolean input) {
//************************Modified code Start***********************************
 if(!(a50==0)||!(cf==false)||!(a62==0)||!(a73==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a62==0)||!(a73==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(a62==0)||!(a73==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(cf==false)||!(a73==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(cf==false)||!(a62==0)){
if(a73==0){}
else if(!(a73==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a50 ==0) && (cf==false) && (a62==0) && (a73==0)){
    	cf = false;
    	a173 = 10;
    	a62 =0;
    	a13 = 12; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if(!(a73==0)||!(a62==0)||!(cf==false)||!(a50==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a62==0)||!(cf==false)||!(a50==0)){
if(a73==0){}
else if(!(a73==0)){}
}
else{}
 if(!(input==false)||!(a73==0)||!(cf==false)||!(a50==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(input==false)||!(a73==0)||!(a62==0)||!(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a73==0)||!(a62==0)||!(cf==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a73==0) && (a62==0) && (cf==false) && (a50 ==0)){
    	cf = false;
    	a62 =0;
    	a173 = 9;
    	a26 = 11; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm183(boolean input) {
//************************Modified code Start***********************************
 if(!(a73==0)||!(cf==false)||!(a62==0)||!(a50==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a62==0)||!(a50==0)){
if(a73==0){}
else if(!(a73==0)){}
}
else{}
 if(!(input==false)||!(a73==0)||!(a62==0)||!(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a73==0)||!(cf==false)||!(a50==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(input==false)||!(a73==0)||!(cf==false)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a73==0) && (cf==false) && (a62==0) && (a50 ==0)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a97 =0; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm27(boolean input) {
//************************Modified code Start***********************************
 if(!(a73==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a73==0){}
else if(!(a73==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a73==0)){
    	calculateOutputm181(input);
    } 
//************************Modified code Start***********************************
 if(!(a73==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a73==0){}
else if(!(a73==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a73==0)){
    	calculateOutputm183(input);
    } 
}
private  void calculateOutputm187(boolean input) {
//************************Modified code Start***********************************
 if(!(a50==0)||!(a16==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a16==0)||!(cf==false)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(cf==false)||!(a62==0)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(a16==0)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(a16==0)||!(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a50 ==0) && (a16 ==0) && (cf==false) && (a62==0)){
    	cf = false;
    	a152 =0;
    	a62 =0;
    	a173 = 8; 
    	System.out.println("Z");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||!(input==false)||!(a16==0)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)||!(input==false)||!(a16==0)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(a16==0)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(input==false)||!(a16==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a50 ==0) && (cf==false) && (input==false) && (a16 ==0) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a161 = 9;
    	a49 = 11; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm188(boolean input) {
//************************Modified code Start***********************************
 if(!(a50==0)||!(cf==false)||!(a16==0)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a16==0)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(a16==0)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(cf==false)||!(a62==0)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
 if(!(input==false)||!(a50==0)||!(cf==false)||!(a16==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a50 ==0) && (cf==false) && (a16 ==0) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a173 = 10;
    	a13 = 16; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm191(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(input==false)||!(a62==0)||!(a16==00)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)||!(input==false)||!(a62==0)||!(a16==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(a62==0)||!(a16==00)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(input==false)||!(a16==00)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a16==00){}
else if(!(a16==00)){}
}
else{}
//************************Modified code end***********************************
    if((a50 ==0) && (cf==false) && (input==false) && (a62==0) && (a16 ==00)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a165 = 16; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||!(a50==0)||!(a62==0)||!(input==false)){
if(a16==00){}
else if(!(a16==00)){}
}
else{}
 if(!(a16==00)||!(a50==0)||!(a62==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a16==00)||!(cf==false)||!(a62==0)||!(input==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a16==00)||!(cf==false)||!(a50==0)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a16==00)||!(cf==false)||!(a50==0)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a16 ==00) && (cf==false) && (a50 ==0) && (a62==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a161 = 9;
    	a49 = 10; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if(!(a16==00)||!(a50==0)||!(cf==false)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(a50==0)||!(cf==false)||!(input==false)){
if(a16==00){}
else if(!(a16==00)){}
}
else{}
 if(!(a62==0)||!(a16==00)||!(cf==false)||!(input==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a62==0)||!(a16==00)||!(a50==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(a16==00)||!(a50==0)||!(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (a16 ==00) && (a50 ==0) && (cf==false) && (input==false)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a69 =0; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm28(boolean input) {
//************************Modified code Start***********************************
 if(!(a16==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a16 ==0)){
    	calculateOutputm187(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a16==0){}
else if(!(a16==0)){}
}
else{}
 if(!(a16==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a16 ==0) && (cf==false)) {
    	calculateOutputm188(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a16==00){}
else if(!(a16==00)){}
}
else{}
 if(!(a16==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a16 ==00) && (cf==false)) {
    	calculateOutputm191(input);
    } 
}
private  void calculateOutputm193(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(a170==0)||!(a62==0)||!(input==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)||!(a170==0)||!(a62==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(a62==0)||!(input==false)){
if(a170==0){}
else if(!(a170==0)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(a170==0)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(a170==0)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a50 ==0) && (cf==false) && (a170 ==0) && (a62==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a179 =0;
    	a161 = 13; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm194(boolean input) {
//************************Modified code Start***********************************
 if(!(a50==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a170==0){}
else if(!(a170==0)){}
}
else{}
 if(!(a170==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a170==0)||!(a50==0)||!(input==false)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a170==0)||!(a50==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a170==0)||!(a50==0)||!(cf==false)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a170 ==0) && (a50 ==0) && (cf==false) && (input==false) && (a62==0)){
    	cf = false;
    	a50 = 9;
    	a175 = 6; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm196(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(a50==0)||!(a170==0)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(a50==0)||!(a170==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a170==0)||!(input==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a50==0)||!(input==false)){
if(a170==0){}
else if(!(a170==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a50==0)||!(a170==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (cf==false) && (a50 ==0) && (a170 ==0) && (input==false)){
    	cf = false;
    	a50 = 11;
    	a11 = 13; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a50==0)||!(cf==false)||!(input==false)||!(a170==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(input==false)||!(a170==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a62==0)||!(a50==0)||!(input==false)||!(a170==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(a50==0)||!(cf==false)||!(a170==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||!(a50==0)||!(cf==false)||!(input==false)){
if(a170==0){}
else if(!(a170==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (a50 ==0) && (cf==false) && (input==false) && (a170 ==0)){
    	cf = false;
    	a73 =0;
    	a50 = 13; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm198(boolean input) {
//************************Modified code Start***********************************
 if(!(input==false)||!(cf==false)||!(a170==0)||!(a50==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a170==0)||!(a50==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(a170==0)||!(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(cf==false)||!(a50==0)){
if(a170==0){}
else if(!(a170==0)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(cf==false)||!(a170==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (input==false) && (cf==false) && (a170 ==0) && (a50 ==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a173 = 7; 
    	System.out.println("S");
    } 
//************************Modified code Start***********************************
 if(!(input==false)||!(cf==false)||!(a170==0)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)||!(cf==false)||!(a170==0)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a50==0)||!(input==false)||!(a170==0)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a50==0)||!(input==false)||!(cf==false)||!(a62==0)){
if(a170==0){}
else if(!(a170==0)){}
}
else{}
 if(!(a50==0)||!(input==false)||!(cf==false)||!(a170==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a50 ==0) && (input==false) && (cf==false) && (a170 ==0) && (a62==0)){
    	cf = false;
    	a73 =0;
    	a50 = 13; 
    	System.out.println("W");
    } 
//************************Modified code Start***********************************
 if(!(a50==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a170==0){}
else if(!(a170==0)){}
}
else{}
 if(!(a170==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a170==0)||!(a50==0)||!(input==false)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a170==0)||!(a50==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a170==0)||!(a50==0)||!(cf==false)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a170 ==0) && (a50 ==0) && (cf==false) && (input==false) && (a62==0)){
    	cf = false;
    	a173 = 5;
    	a62 =0;
    	a161 = 10; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm29(boolean input) {
//************************Modified code Start***********************************
 if(!(a170==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a170==0){}
else if(!(a170==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a170 ==0)){
    	calculateOutputm193(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a170==0){}
else if(!(a170==0)){}
}
else{}
 if(!(a170==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a170 ==0) && (cf==false)) {
    	calculateOutputm194(input);
    } 
//************************Modified code Start***********************************
 if(!(a170==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a170==0){}
else if(!(a170==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a170 ==0)){
    	calculateOutputm196(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a170==0){}
else if(!(a170==0)){}
}
else{}
 if(!(a170==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a170 ==0) && (cf==false)) {
    	calculateOutputm198(input);
    } 
}
private  void calculateOutputm200(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(a62==0)||!(a97==0)||!(a114==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a62==0)||!(a97==0)||!(a114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a97==0)||!(a114==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a62==0)||!(a114==0)){
if(a97==0){}
else if(!(a97==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a62==0)||!(a97==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (cf==false) && (a62==0) && (a97==0) && (a114==0)){
    	cf = false;
    	a62 =0;
    	a152 =0;
    	a173 = 8; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||!(a62==0)||!(a114==0)||!(input==false)){
if(a97==0){}
else if(!(a97==0)){}
}
else{}
 if(!(a97==0)||!(a62==0)||!(a114==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a97==0)||!(cf==false)||!(a114==0)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a97==0)||!(cf==false)||!(a62==0)||!(input==false)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a97==0)||!(cf==false)||!(a62==0)||!(a114==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a97==0) && (cf==false) && (a62==0) && (a114==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a161 = 15; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(input==false)||!(a62==0)||!(a114==0)||!(a97==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)||!(a62==0)||!(a114==0)||!(a97==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(cf==false)||!(input==false)||!(a114==0)||!(a97==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(cf==false)||!(input==false)||!(a62==0)||!(a97==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(cf==false)||!(input==false)||!(a62==0)||!(a114==0)){
if(a97==0){}
else if(!(a97==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (input==false) && (a62==0) && (a114==0) && (a97==0)){
    	cf = false;
    	a62 =0;
    	a19 =0;
    	a161 = 16; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm201(boolean input) {
//************************Modified code Start***********************************
 if(!(input==false)||!(a114==0)||!(cf==false)||!(a97==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(a114==0)||!(cf==false)||!(a97==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(cf==false)||!(a97==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(a114==0)||!(a97==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(a114==0)||!(cf==false)){
if(a97==0){}
else if(!(a97==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (input==false) && (a114==0) && (cf==false) && (a97==0)){
    	cf = false;
    	a161 = 10;
    	a62 =0;
    	a187 = 7; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm30(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a97==0){}
else if(!(a97==0)){}
}
else{}
 if(!(a97==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a97==0) && (cf==false)) {
    	calculateOutputm200(input);
    } 
//************************Modified code Start***********************************
 if(!(a97==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a97==0){}
else if(!(a97==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a97==0)){
    	calculateOutputm201(input);
    } 
}
private  void calculateOutputm203(boolean input) {
//************************Modified code Start***********************************
 if(!(a114==0)||!(cf==false)||!(a69==0)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a69==0)||!(input==false)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a62==0)||!(a114==0)||!(a69==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(a114==0)||!(cf==false)||!(input==false)){
if(a69==0){}
else if(!(a69==0)){}
}
else{}
 if(!(a62==0)||!(a114==0)||!(cf==false)||!(a69==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (a114==0) && (cf==false) && (a69==0) && (input==false)){
    	cf = false;
    	a179 =0;
    	a62 =0;
    	a161 = 13; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm205(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(a62==0)||!(a69==0)||!(a114==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a62==0)||!(a69==0)||!(a114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a69==0)||!(a114==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a62==0)||!(a114==0)){
if(a69==0){}
else if(!(a69==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a62==0)||!(a69==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (cf==false) && (a62==0) && (a69==0) && (a114==0)){
    	cf = false;
    	a69 =0; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a62==0)||!(a114==0)||!(input==false)||!(cf==false)){
if(a69==0){}
else if(!(a69==0)){}
}
else{}
 if(!(a69==0)||!(a114==0)||!(input==false)||!(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a69==0)||!(a62==0)||!(input==false)||!(cf==false)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a69==0)||!(a62==0)||!(a114==0)||!(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a69==0)||!(a62==0)||!(a114==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a69==0) && (a62==0) && (a114==0) && (input==false) && (cf==false)){
    	cf = false;
    	a50 = 12;
    	a62 =0;
    	a65 = 4; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a69==0)||!(input==false)||!(cf==false)||!(a62==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a114==0)||!(input==false)||!(cf==false)||!(a62==0)){
if(a69==0){}
else if(!(a69==0)){}
}
else{}
 if(!(a114==0)||!(a69==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a114==0)||!(a69==0)||!(input==false)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a114==0)||!(a69==0)||!(input==false)||!(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a114==0) && (a69==0) && (input==false) && (cf==false) && (a62==0)){
    	cf = false;
    	a161 = 9;
    	a62 =0;
    	a49 = 5; 
    	System.out.println("V");
    } 
//************************Modified code Start***********************************
 if(!(input==false)||!(cf==false)||!(a69==0)||!(a114==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a69==0)||!(a114==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(a69==0)||!(a114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(cf==false)||!(a114==0)){
if(a69==0){}
else if(!(a69==0)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(cf==false)||!(a69==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (input==false) && (cf==false) && (a69==0) && (a114==0)){
    	cf = false;
    	a50 = 8;
    	a62 =0;
    	a196 = 4; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm206(boolean input) {
//************************Modified code Start***********************************
 if(!(input==false)||!(a114==0)||!(cf==false)||!(a62==0)){
if(a69==0){}
else if(!(a69==0)){}
}
else{}
 if(!(a69==0)||!(a114==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a69==0)||!(input==false)||!(cf==false)||!(a62==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a69==0)||!(input==false)||!(a114==0)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a69==0)||!(input==false)||!(a114==0)||!(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a69==0) && (input==false) && (a114==0) && (cf==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a165 = 11; 
    	System.out.println("Z");
    } 
//************************Modified code Start***********************************
 if(!(a69==0)||!(a62==0)||!(cf==false)||!(a114==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a62==0)||!(cf==false)||!(a114==0)){
if(a69==0){}
else if(!(a69==0)){}
}
else{}
 if(!(input==false)||!(a69==0)||!(cf==false)||!(a114==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(input==false)||!(a69==0)||!(a62==0)||!(a114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a69==0)||!(a62==0)||!(cf==false)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a69==0) && (a62==0) && (cf==false) && (a114==0)){
    	cf = false;
    	a50 = 12;
    	a62 =0;
    	a65 = 11; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm31(boolean input) {
//************************Modified code Start***********************************
 if(!(a69==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a69==0){}
else if(!(a69==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a69==0)){
    	calculateOutputm203(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a69==0){}
else if(!(a69==0)){}
}
else{}
 if(!(a69==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a69==0) && (cf==false)) {
    	calculateOutputm205(input);
    } 
//************************Modified code Start***********************************
 if(!(a69==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a69==0){}
else if(!(a69==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a69==0)){
    	calculateOutputm206(input);
    } 
}
private  void calculateOutputm207(boolean input) {
//************************Modified code Start***********************************
 if(!(a152==0)||!(a62==0)||!(cf==false)||!(input==false)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a114==0)||!(a62==0)||!(cf==false)||!(input==false)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if(!(a114==0)||!(a152==0)||!(cf==false)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a114==0)||!(a152==0)||!(a62==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a114==0)||!(a152==0)||!(a62==0)||!(cf==false)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a114==0) && (a152==0) && (a62==0) && (cf==false) && (input==false)){
    	cf = false;
    	a62 =0;
    	a168 =0;
    	a161 = 11; 
    	System.out.println("U");
    } 
//************************Modified code Start***********************************
 if(!(cf==false)||!(a62==0)||!(a152==0)||!(input==false)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a114==0)||!(a62==0)||!(a152==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a114==0)||!(cf==false)||!(a152==0)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a114==0)||!(cf==false)||!(a62==0)||!(input==false)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if(!(a114==0)||!(cf==false)||!(a62==0)||!(a152==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a114==0) && (cf==false) && (a62==0) && (a152==0) && (input==false)){
    	cf = false;
    	a114 =0;
    	a69 =0; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm209(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(a152==0)||!(input==false)||!(a62==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a114==0)||!(a152==0)||!(input==false)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a114==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if(!(a114==0)||!(cf==false)||!(a152==0)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a114==0)||!(cf==false)||!(a152==0)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a114==0) && (cf==false) && (a152==0) && (input==false)&& (a62==0)){
    	cf = false;
    	a50 = 8;
    	a62 =0;
    	a196 = 7; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm32(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if(!(a152==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a152==0) && (cf==false)) {
    	calculateOutputm207(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a152==0){}
else if(!(a152==0)){}
}
else{}
 if(!(a152==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a152==0) && (cf==false)) {
    	calculateOutputm209(input);
    } 
}
private  void calculateOutputm211(boolean input) {
//************************Modified code Start***********************************
 if(!(a62==0)||!(cf==false)||!(a137==0)||!(a114==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a137==0)||!(a114==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(input==false)||!(a62==0)||!(a137==0)||!(a114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a62==0)||!(cf==false)||!(a114==0)){
if(a137==0){}
else if(!(a137==0)){}
}
else{}
 if(!(input==false)||!(a62==0)||!(cf==false)||!(a137==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a62==0) && (cf==false) && (a137==0) && (a114==0)){
    	cf = false;
    	a62 =0;
    	a161 = 14;
    	a26 = 14; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a137==0)||!(input==false)||!(cf==false)||!(a62==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a114==0)||!(input==false)||!(cf==false)||!(a62==0)){
if(a137==0){}
else if(!(a137==0)){}
}
else{}
 if(!(a114==0)||!(a137==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a114==0)||!(a137==0)||!(input==false)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a114==0)||!(a137==0)||!(input==false)||!(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((a114==0) && (a137==0) && (input==false) && (cf==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a165 = 14; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm212(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(input==false)||!(a137==0)||!(a114==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a62==0)||!(input==false)||!(a137==0)||!(a114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(a137==0)||!(a114==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(input==false)||!(a114==0)){
if(a137==0){}
else if(!(a137==0)){}
}
else{}
 if(!(a62==0)||!(cf==false)||!(input==false)||!(a137==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
//************************Modified code end***********************************
    if((a62==0) && (cf==false) && (input==false) && (a137==0) && (a114==0)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a114==0)||!(cf==false)||!(a137==0)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a137==0)||!(a62==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(input==false)||!(a114==0)||!(a137==0)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a114==0)||!(cf==false)||!(a62==0)){
if(a137==0){}
else if(!(a137==0)){}
}
else{}
 if(!(input==false)||!(a114==0)||!(cf==false)||!(a137==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a114==0) && (cf==false) && (a137==0) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a161 = 12;
    	a148 = 2; 
    	System.out.println("Y");
    } 
//************************Modified code Start***********************************
 if(!(a137==0)||!(a114==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a114==0)||!(cf==false)||!(a62==0)){
if(a137==0){}
else if(!(a137==0)){}
}
else{}
 if(!(input==false)||!(a137==0)||!(cf==false)||!(a62==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(input==false)||!(a137==0)||!(a114==0)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a137==0)||!(a114==0)||!(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a137==0) && (a114==0) && (cf==false) && (a62==0)){
    	cf = false;
    	a19 =0;
    	a62 =0;
    	a161 = 16; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm214(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(a62==0)||!(a114==0)||!(input==false)){
if(a137==0){}
else if(!(a137==0)){}
}
else{}
 if(!(a137==0)||!(a62==0)||!(a114==0)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a137==0)||!(cf==false)||!(a114==0)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a137==0)||!(cf==false)||!(a62==0)||!(input==false)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a137==0)||!(cf==false)||!(a62==0)||!(a114==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a137==0) && (cf==false) && (a62==0) && (a114==0) && (input==false)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a165 = 13; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm33(boolean input) {
//************************Modified code Start***********************************
 if(!(a137==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a137==0){}
else if(!(a137==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a137==0)){
    	calculateOutputm211(input);
    } 
//************************Modified code Start***********************************
 if(!(a137==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a137==0){}
else if(!(a137==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a137==0)){
    	calculateOutputm212(input);
    } 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a137==0){}
else if(!(a137==0)){}
}
else{}
 if(!(a137==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    if((a137==0) && (cf==false)) {
    	calculateOutputm214(input);
    } 
}
private  void calculateOutputm216(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(a62==0)||!(a114==0)||!(a3==00)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a62==0)||!(a114==0)||!(a3==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a114==0)||!(a3==00)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a62==0)||!(a3==00)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(input==false)||!(cf==false)||!(a62==0)||!(a114==0)){
if(a3==00){}
else if(!(a3==00)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (cf==false) && (a62==0) && (a114==0) && (a3 ==00)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a3==00)||!(a114==0)||!(cf==false)||!(a62==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(input==false)||!(a114==0)||!(cf==false)||!(a62==0)){
if(a3==00){}
else if(!(a3==00)){}
}
else{}
 if(!(input==false)||!(a3==00)||!(cf==false)||!(a62==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(input==false)||!(a3==00)||!(a114==0)||!(a62==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(input==false)||!(a3==00)||!(a114==0)||!(cf==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
//************************Modified code end***********************************
    if((input==false) && (a3 ==00) && (a114==0) && (cf==false) && (a62==0)){
    	cf = false;
    	a173 = 12;
    	a62 =0;
    	a126 = 10; 
    	System.out.println("T");
    } 
//************************Modified code Start***********************************
 if(!(a62==0)||!(cf==false)||!(a3==00)||!(input==false)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a114==0)||!(cf==false)||!(a3==00)||!(input==false)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a114==0)||!(a62==0)||!(a3==00)||!(input==false)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a114==0)||!(a62==0)||!(cf==false)||!(input==false)){
if(a3==00){}
else if(!(a3==00)){}
}
else{}
 if(!(a114==0)||!(a62==0)||!(cf==false)||!(a3==00)){
if(input==false){}
else if(!(input==false)){}
}
else{}
//************************Modified code end***********************************
    if((a114==0) && (a62==0) && (cf==false) && (a3 ==00) && (input==false)){
    	cf = false;
    	a161 = 9;
    	a62 =0;
    	a49 = 5; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm220(boolean input) {
//************************Modified code Start***********************************
 if(!(cf==false)||!(input==false)||!(a62==0)||!(a3==0)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a114==0)||!(input==false)||!(a62==0)||!(a3==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(a114==0)||!(cf==false)||!(a62==0)||!(a3==0)){
if(input==false){}
else if(!(input==false)){}
}
else{}
 if(!(a114==0)||!(cf==false)||!(input==false)||!(a3==0)){
if(a62==0){}
else if(!(a62==0)){}
}
else{}
 if(!(a114==0)||!(cf==false)||!(input==false)||!(a62==0)){
if(a3==0){}
else if(!(a3==0)){}
}
else{}
//************************Modified code end***********************************
    if((a114==0) && (cf==false) && (input==false) && (a62==0) && (a3 ==0)){
    	cf = false;
    	a62 =0;
    	a19 =0;
    	a161 = 16; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm34(boolean input) {
//************************Modified code Start***********************************
 if(!(a3==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a3==00){}
else if(!(a3==00)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a3 ==00)){
    	calculateOutputm216(input);
    } 
//************************Modified code Start***********************************
 if(!(a3==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a3==0){}
else if(!(a3==0)){}
}
else{}
//************************Modified code end***********************************
    if((cf==false) && (a3 ==0)){
    	calculateOutputm220(input);
    } 
}



public  void calculateOutput(boolean input) {
 	cf = true;
//************************Modified code Start***********************************
 if(!(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a173 ==0)){
    		calculateOutputm1(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a173 ==0) && (cf==false)) {
    		calculateOutputm2(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a173 ==0) && (cf==false)) {
    		calculateOutputm3(input);
    	} 
//************************Modified code Start***********************************
 if(!(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a173 ==0)){
    		calculateOutputm4(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a173 ==0) && (cf==false)) {
    		calculateOutputm5(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a173==00){}
else if(!(a173==00)){}
}
else{}
 if(!(a173==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a173 ==00) && (cf==false)) {
    		calculateOutputm6(input);
    	} 
//************************Modified code Start***********************************
 if(!(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a173 ==0)){
    		calculateOutputm7(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a173==0){}
else if(!(a173==0)){}
}
else{}
 if(!(a173==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a173 ==0) && (cf==false)) {
    		calculateOutputm8(input);
    	} 
//************************Modified code Start***********************************
 if(!(a41==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a41==0)){
    		calculateOutputm9(input);
    	} 
//************************Modified code Start***********************************
 if(!(a41==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a41==0)){
    		calculateOutputm10(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a41==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a41==0) && (cf==false)) {
    		calculateOutputm11(input);
    	} 
//************************Modified code Start***********************************
 if(!(a41==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a41==0)){
    		calculateOutputm12(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a41==0){}
else if(!(a41==0)){}
}
else{}
 if(!(a41==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a41==0) && (cf==false)) {
    		calculateOutputm13(input);
    	} 
//************************Modified code Start***********************************
 if(!(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a161 ==0)){
    		calculateOutputm14(input);
    	} 
//************************Modified code Start***********************************
 if(!(a161==00)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a161==00){}
else if(!(a161==00)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a161 ==00)){
    		calculateOutputm15(input);
    	} 
//************************Modified code Start***********************************
 if(!(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a161 ==0)){
    		calculateOutputm16(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a161 ==0) && (cf==false)) {
    		calculateOutputm17(input);
    	} 
//************************Modified code Start***********************************
 if(!(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a161 ==0)){
    		calculateOutputm18(input);
    	} 
//************************Modified code Start***********************************
 if(!(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a161 ==0)){
    		calculateOutputm19(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a161 ==0) && (cf==false)) {
    		calculateOutputm20(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a161==0){}
else if(!(a161==0)){}
}
else{}
 if(!(a161==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a161 ==0) && (cf==false)) {
    		calculateOutputm21(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a50 ==0) && (cf==false)) {
    		calculateOutputm22(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a50 ==0) && (cf==false)) {
    		calculateOutputm23(input);
    	} 
//************************Modified code Start***********************************
 if(!(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a50 ==0)){
    		calculateOutputm25(input);
    	} 
//************************Modified code Start***********************************
 if(!(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a50 ==0)){
    		calculateOutputm26(input);
    	} 
//************************Modified code Start***********************************
 if(!(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a50 ==0)){
    		calculateOutputm27(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
 if(!(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a50 ==0) && (cf==false)) {
    		calculateOutputm28(input);
    	} 
//************************Modified code Start***********************************
 if(!(a50==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a50==0){}
else if(!(a50==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a50 ==0)){
    		calculateOutputm29(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a114==0) && (cf==false)) {
    		calculateOutputm30(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a114==0) && (cf==false)) {
    		calculateOutputm31(input);
    	} 
//************************Modified code Start***********************************
 if(!(a114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a114==0)){
    		calculateOutputm32(input);
    	} 
//************************Modified code Start***********************************
 if(!(cf==false)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
 if(!(a114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
//************************Modified code end***********************************
    	if((a114==0) && (cf==false)) {
    		calculateOutputm33(input);
    	} 
//************************Modified code Start***********************************
 if(!(a114==0)){
if(cf==false){}
else if(!(cf==false)){}
}
else{}
 if(!(cf==false)){
if(a114==0){}
else if(!(a114==0)){}
}
else{}
//************************Modified code end***********************************
    	if((cf==false) && (a114==0)){
    		calculateOutputm34(input);
    	} 
    

    errorCheck();
    if(cf==false)
    	throw new IllegalArgumentException("Current state has no transition for this input!");
}


public static void main() throws Exception 
	{
	     // init system and input reader
            Problem10_RERS2017jxnct eca = new Problem10_RERS2017jxnct();
        int a=0;
	int x;
        int y;
         
        x = Cute.input.Integer();
        y = Cute.input.Integer();
		boolean input = Cute.input.Boolean();
			// main i/o-loop
            while(a<10) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
//************************Modified code Start***********************************
 if(!(x>y)){
if(x>199){}
else if(!(x>199)){}
}
else{}
 if(!(x>199)){
if(x>y){}
else if(!(x>y)){}
}
else{}
//************************Modified code end***********************************
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                	 eca.calculateOutput(input);
					 
				}
				
//************************Modified code Start***********************************
 if(!(x<y)){
if(x>299){}
else if(!(x>299)){}
}
else{}
 if(!(x>299)){
if(x<y){}
else if(!(x<y)){}
}
else{}
//************************Modified code end***********************************
				if (x>299 && x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutput(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
	}
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
