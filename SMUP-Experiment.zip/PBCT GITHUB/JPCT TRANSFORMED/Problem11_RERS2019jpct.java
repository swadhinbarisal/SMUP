package jpct;

import cute.Cute;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Problem11_RERS2019jpct {
	static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

	private String[] inputs = {"B","D","J","F","E","G","I","C","A","H"};

	public int a130053513 =Cute.input.Integer();
	public int a868982691 = Cute.input.Integer();
	public int a2128198108 = Cute.input.Integer();
	public int a1228149849 = Cute.input.Integer();
	public int a548397256 =Cute.input.Integer();
	public boolean cf = Cute.input.Boolean();
	public boolean input = Cute.input.Boolean();
	public int a1644705049 =Cute.input.Integer();
	public int a605263457 = Cute.input.Integer();
	public int a1342468697 = Cute.input.Integer();
	public int a1781711932 = Cute.input.Integer();
	public int a2000983237 =Cute.input.Integer();
	public int a1240310412 = Cute.input.Integer();
	public int a2135110469 = Cute.input.Integer();
	public int a1225824710 =Cute.input.Integer();
	public int a975106081 =Cute.input.Integer();
	public int a1488435031 =Cute.input.Integer();
	public int a1115144307 =Cute.input.Integer();
	public int a1293654158 = Cute.input.Integer();
	public int a1224468176 =Cute.input.Integer();
	public int a2062504165 = Cute.input.Integer();
	public int a599095469 = Cute.input.Integer();
	public int a589537721 = Cute.input.Integer();
	public int a1790587420 = Cute.input.Integer();
	public int a1553956613 =Cute.input.Integer();
	public int a1857660363 = Cute.input.Integer();
	public int a1840028630 =Cute.input.Integer();
	public int a554980914 = Cute.input.Integer();
	public int a1840022387 = Cute.input.Integer();
	public int a892451458 = Cute.input.Integer();
	public int a344522688 =Cute.input.Integer();
	public int a1386707288 =Cute.input.Integer();
	public int a930233571 = Cute.input.Integer();
	public int a1074202851 =Cute.input.Integer();
	public int a183334438 = Cute.input.Integer();
	public int a286091846 =Cute.input.Integer();
	public int a1071154797 = Cute.input.Integer();
	public int a1718050978 =Cute.input.Integer();
	public int a898912231 = Cute.input.Integer();
	public int a1227434655 =Cute.input.Integer();
	public int a261374011 = Cute.input.Integer();

	private void errorCheck() {
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a1840022387==0){
if(a930233571==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1840022387==0) && (a930233571 ==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("0");
	    }
//******************Transformed code started****************************
if(a1227434655==0){
 }
 else {}
if(a1074202851==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1227434655==0) || (a1074202851==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("1");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a130053513==0){
if(a1644705049==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a130053513==0) && (a1644705049==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("2");
	    }
//******************Transformed code started****************************
if(a2000983237==0){
 }
 else {}
if(a344522688==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a2000983237==0) || (a344522688==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("3");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a1857660363==0){
if(a1228149849==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1857660363==0) && (a1228149849 ==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("4");
	    }
//******************Transformed code started****************************
if(a605263457==0){
 }
 else {}
if(a261374011==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a605263457 ==0) || (a261374011==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("5");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a892451458==0){
if(a1115144307==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a892451458 ==0) && (a1115144307==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("6");
	    }
//******************Transformed code started****************************
if(a548397256==0){
 }
 else {}
if(a2128198108==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a548397256==0) || (a2128198108 ==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("7");
	    }
//******************Transformed code started****************************
if(a1224468176==0){
 }
 else {}
if(a1228149849==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1224468176==0) || (a1228149849 ==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("8");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a1488435031==0){
if(a1644705049==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1488435031==0) && (a1644705049==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("9");
	    }
//******************Transformed code started****************************
if(a868982691==0){
 }
 else {}
if(a1074202851==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a868982691 ==0) || (a1074202851==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("10");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a1840022387==0){
if(a1228149849==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1840022387==0) && (a1228149849 ==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("11");
	    }
//******************Transformed code started****************************
if(a1553956613==0){
 }
 else {}
if(a930233571==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1553956613==0) || (a930233571 ==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("12");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a930233571==0){
if(a344522688==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a930233571 ==0) && (a344522688==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("13");
	    }
//******************Transformed code started****************************
if(a2128198108==0){
 }
 else {}
if(a344522688==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a2128198108 ==0) || (a344522688==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("14");
	    }
//******************Transformed code started****************************
if(a1790587420==0){
 }
 else {}
if(a1228149849==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1790587420 ==0) || (a1228149849 ==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("15");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a1718050978==0){
if(a344522688==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1718050978==0) && (a344522688==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("16");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a589537721==0){
if(a2128198108==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a589537721 ==0) && (a2128198108 ==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("17");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a1790587420==0){
if(a1228149849==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1790587420 ==0) && (a1228149849 ==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("18");
	    }
//******************Transformed code started****************************
if(a1488435031==0){
 }
 else {}
if(a1644705049==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1488435031==0) || (a1644705049==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("19");
	    }
//******************Transformed code started****************************
if(a554980914==0){
 }
 else {}
if(a1115144307==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a554980914 ==0) || (a1115144307==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("20");
	    }
//******************Transformed code started****************************
if(a1553956613==0){
 }
 else {}
if(a930233571==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1553956613==0) || (a930233571 ==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("21");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a1857660363==0){
if(a1228149849==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1857660363==0) && (a1228149849 ==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("22");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a1224468176==0){
if(a1228149849==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1224468176==0) && (a1228149849 ==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("23");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a898912231==0){
if(a2128198108==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a898912231==0) && (a2128198108 ==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("24");
	    }
//******************Transformed code started****************************
if(a1553956613==0){
 }
 else {}
if(a930233571==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1553956613==0) || (a930233571 ==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("25");
	    }
//******************Transformed code started****************************
if(a1225824710==0){
 }
 else {}
if(a1115144307==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1225824710==0) || (a1115144307==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("26");
	    }
//******************Transformed code started****************************
if(a1488435031==0){
 }
 else {}
if(a1644705049==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1488435031==0) || (a1644705049==0) && (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("27");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a1386707288==0){
if(a344522688==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1386707288==0) && (a344522688==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("28");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a930233571==0){
if(a344522688==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a930233571 ==0) && (a344522688==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("29");
	    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a1225824710==0){
if(a1115144307==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1225824710==0) && (a1115144307==0) || (a2135110469 ==0)){
	    	cf = false;
	    	System.out.println("30");
	    }
	   	    
	}
private  void calculateOutputm50(boolean input) {
//******************Transformed code started****************************
if(a130053513==0){
 }
 else {}
if(a1644705049==0){
 }
 else {}
if(a2135110469==0){
if(input==false){}
 else{}
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1644705049==0) || (a2135110469 ==0) && (input==false) && (cf==false) || (a130053513==0)){
    	cf = false;
    	a1718050978 =0;
    	a344522688 =0;
    	a2135110469 = 8; 
    	System.out.println("Y");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a2135110469==0){
 }
 else {}
if(a130053513==0){
if(cf==false){}
 else{}
if(a1644705049==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a2135110469 ==0) || (input==false) || (a130053513==0) && (cf==false) && (a1644705049==0)){
    	cf = false;
    	a1228149849 = 3;
    	a2135110469 = 7;
    	a2128198108 = 12; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm1(boolean input) {
//******************Transformed code started****************************
if(cf==false){
if(a130053513==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a130053513==0)){
    	calculateOutputm50(input);
    } 
}
private  void calculateOutputm53(boolean input) {
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a2135110469==0){
if(a1644705049==0){}
 else{}
 }
 else {}
if(a286091846==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) || (a286091846==0) && (cf==false) || (a2135110469 ==0) && (a1644705049==0)){
    	cf = false;
    	a2135110469 = 10;
    	a975106081 =0;
    	a930233571 = 9; 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(a286091846==0){
 }
 else {}
if(a2135110469==0){
if(cf==false){}
 else{}
 }
 else {}
if(a1644705049==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a286091846==0) || (a1644705049==0) && (input==false) || (a2135110469 ==0) && (cf==false)){
    	cf = false;
    	a2135110469 = 5;
    	a2128198108 = 10;
    	a183334438 = 9; 
    	System.out.println("R");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(cf==false){
 }
 else {}
if(a286091846==0){
 }
 else {}
if(a1644705049==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a286091846==0) || (a1644705049==0) && (a2135110469 ==0) || (cf==false) || (input==false)){
    	cf = false;
    	 
    	System.out.println("U");
    } 
//******************Transformed code started****************************
if(a286091846==0){
 }
 else {}
if(cf==false){
if(a2135110469==0){}
 else{}
 }
 else {}
if(a1644705049==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a1644705049==0) && (input==false) || (cf==false) && (a2135110469 ==0) || (a286091846==0)){
    	cf = false;
    	a898912231 =0;
    	a2135110469 = 5;
    	a2128198108 = 11; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm2(boolean input) {
//******************Transformed code started****************************
if(cf==false){
if(a286091846==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a286091846==0)){
    	calculateOutputm53(input);
    } 
}
private  void calculateOutputm69(boolean input) {
//******************Transformed code started****************************
if(a599095469==0){
 }
 else {}
if(a1074202851==0){
 }
 else {}
if(input==false){
 }
 else {}
if(cf==false){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) || (a1074202851==0) || (cf==false) && (a2135110469 ==0) || (a599095469==0)){
    	cf = false;
    	a930233571 = 10;
    	a2135110469 = 10;
    	a1071154797 = 8; 
    	System.out.println("W");
    } 
//******************Transformed code started****************************
if(a599095469==0){
 }
 else {}
if(input==false){
if(cf==false){}
 else{}
 }
 else {}
if(a2135110469==0){
if(a1074202851==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a2135110469 ==0) && (a1074202851==0) || (a599095469==0) || (input==false) && (cf==false)){
    	cf = false;
    	a2135110469 = 10;
    	a1488435031 =0;
    	a930233571 = 5; 
    	System.out.println("W");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a2135110469==0){
if(a599095469==0){}
 else{}
 }
 else {}
if(cf==false){
if(a1074202851==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((cf==false) && (a1074202851==0) || (input==false) || (a2135110469 ==0) && (a599095469==0)){
    	cf = false;
    	a2128198108 = 9;
    	a2135110469 = 5;
    	a2062504165 = 7; 
    	System.out.println("Z");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(cf==false){
if(a1074202851==0){}
 else{}
 }
 else {}
if(a599095469==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((input==false) || (a599095469==0) && (a2135110469 ==0) || (cf==false) && (a1074202851==0)){
    	cf = false;
    	a2135110469 = 5;
    	a2128198108 = 9;
    	a2062504165 = 8; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm9(boolean input) {
//******************Transformed code started****************************
if(cf==false){
if(a599095469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a599095469==0)){
    	calculateOutputm69(input);
    } 
}
private  void calculateOutputm72(boolean input) {
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a286091846==0){
if(a2128198108==0){}
 else{}
 }
 else {}
if(a2135110469==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) || (a2135110469 ==0) && (cf==false) || (a286091846==0) && (a2128198108 ==0)){
    	cf = false;
    	a2135110469 = 10;
    	a975106081 =0;
    	a930233571 = 9; 
    	System.out.println("X");
    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(input==false){
if(a286091846==0){}
 else{}
 }
 else {}
if(cf==false){
if(a2128198108==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a2135110469 ==0) || (cf==false) && (a2128198108 ==0) || (input==false) && (a286091846==0)){
    	cf = false;
    	 
    	System.out.println("S");
    } 
//******************Transformed code started****************************
if(a286091846==0){
 }
 else {}
if(a2128198108==0){
if(input==false){}
 else{}
 }
 else {}
if(a2135110469==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a286091846==0) || (a2135110469 ==0) && (cf==false) || (a2128198108 ==0) && (input==false)){
    	cf = false;
    	a930233571 = 10;
    	a2135110469 = 10;
    	a1071154797 = 8; 
    	System.out.println("U");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a286091846==0){
if(a2135110469==0){}
 else{}
 }
 else {}
if(cf==false){
if(a2128198108==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((input==false) || (cf==false) && (a2128198108 ==0) || (a286091846==0) && (a2135110469 ==0)){
    	cf = false;
    	a344522688 =0;
    	a2135110469 = 8;
    	a930233571 = 5; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm73(boolean input) {
//******************Transformed code started****************************
if(a286091846==0){
 }
 else {}
if(a2135110469==0){
if(input==false){}
 else{}
 }
 else {}
if(cf==false){
if(a2128198108==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a286091846==0) || (cf==false) && (a2128198108 ==0) || (a2135110469 ==0) && (input==false)){
    	cf = false;
    	a1240310412 =0;
    	a2128198108 = 14; 
    	System.out.println("R");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a2128198108==0){
if(a286091846==0){}
 else{}
 }
 else {}
if(a2135110469==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((input==false) || (a2135110469 ==0) && (cf==false) || (a2128198108 ==0) && (a286091846==0)){
    	cf = false;
    	a2128198108 = 10;
    	a183334438 = 12; 
    	System.out.println("W");
    } 
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(cf==false){
 }
 else {}
if(input==false){
if(a2128198108==0){}
 else{}
if(a286091846==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((cf==false) || (a2135110469 ==0) || (input==false) && (a2128198108 ==0) && (a286091846==0)){
    	cf = false;
    	a1386707288 =0;
    	a344522688 =0;
    	a2135110469 = 8; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm11(boolean input) {
//******************Transformed code started****************************
if(a286091846==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a286091846==0)){
    	calculateOutputm72(input);
    } 
//******************Transformed code started****************************
if(cf==false){
if(a286091846==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a286091846==0)){
    	calculateOutputm73(input);
    } 
}
private  void calculateOutputm76(boolean input) {
//******************Transformed code started****************************
if(a2128198108==0){
 }
 else {}
if(input==false){
if(cf==false){}
 else{}
 }
 else {}
if(a2135110469==0){
if(a2062504165==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a2128198108 ==0) || (a2135110469 ==0) && (a2062504165 ==0) || (input==false) && (cf==false)){
    	cf = false;
    	a1228149849 = 7;
    	a2135110469 = 7;
    	a1790587420 = 12; 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(a2062504165==0){
 }
 else {}
if(input==false){
if(a2135110469==0){}
 else{}
 }
 else {}
if(a2128198108==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a2062504165 ==0) || (a2128198108 ==0) && (cf==false) || (input==false) && (a2135110469 ==0)){
    	cf = false;
    	a1074202851 =0;
    	a1227434655 =0;
    	a2135110469 = 4; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm12(boolean input) {
//******************Transformed code started****************************
if(a2062504165==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a2062504165 ==0) && (cf==false)) {
    	calculateOutputm76(input);
    } 
}
private  void calculateOutputm80(boolean input) {
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a183334438==0){
if(cf==false){}
 else{}
 }
 else {}
if(a2128198108==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a2135110469 ==0) || (a2128198108 ==0) && (input==false) || (a183334438 ==0) && (cf==false)){
    	cf = false;
    	a130053513 =0;
    	a1644705049 =0;
    	a2135110469 = 3; 
    	System.out.println("V");
    } 
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(input==false){
if(a2128198108==0){}
 else{}
 }
 else {}
if(cf==false){
if(a183334438==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a2135110469 ==0) || (cf==false) && (a183334438 ==0) || (input==false) && (a2128198108 ==0)){
    	cf = false;
    	a1228149849 = 3;
    	a2135110469 = 7;
    	a2128198108 = 8; 
    	System.out.println("P");
    } 
//******************Transformed code started****************************
if(a183334438==0){
 }
 else {}
if(a2135110469==0){
if(a2128198108==0){}
 else{}
 }
 else {}
if(input==false){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a183334438 ==0) || (input==false) && (cf==false) || (a2135110469 ==0) && (a2128198108 ==0)){
    	cf = false;
    	a1718050978 =0;
    	a344522688 =0;
    	a2135110469 = 8; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm81(boolean input) {
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(cf==false){
if(a2128198108==0){}
 else{}
 }
 else {}
if(a183334438==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a2135110469 ==0) || (a183334438 ==0) && (input==false) || (cf==false) && (a2128198108 ==0)){
    	cf = false;
    	a2135110469 = 7;
    	a1228149849 = 7;
    	a1790587420 = 12; 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(input==false){
if(a2135110469==0){}
 else{}
 }
 else {}
if(a183334438==0){
if(a2128198108==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a183334438 ==0) && (a2128198108 ==0) || (cf==false) || (input==false) && (a2135110469 ==0)){
    	cf = false;
    	a1074202851 =0;
    	a599095469 =0;
    	a2135110469 = 4; 
    	System.out.println("T");
    } 
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(cf==false){
if(a183334438==0){}
 else{}
 }
 else {}
if(a2128198108==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a2135110469 ==0) || (a2128198108 ==0) && (input==false) || (cf==false) && (a183334438 ==0)){
    	cf = false;
    	a1225824710 =0;
    	a1115144307 =0;
    	a2135110469 = 9; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm13(boolean input) {
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a183334438==0){
 }
 else {}
//******************Transformed code end****************************
    if((a183334438 ==0) || (cf==false)) {
    	calculateOutputm80(input);
    } 
//******************Transformed code started****************************
if(cf==false){
if(a183334438==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a183334438 ==0)){
    	calculateOutputm81(input);
    } 
}
private  void calculateOutputm90(boolean input) {
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a1240310412==0){
if(a2128198108==0){}
 else{}
 }
 else {}
if(input==false){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a2135110469 ==0) || (input==false) && (cf==false) || (a1240310412==0) && (a2128198108 ==0)){
    	cf = false;
    	a2135110469 = 7;
    	a1228149849 = 7;
    	a1790587420 = 12; 
    	System.out.println("U");
    } 
//******************Transformed code started****************************
if(a1240310412==0){
 }
 else {}
if(a2135110469==0){
if(a2128198108==0){}
 else{}
 }
 else {}
if(cf==false){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((cf==false) && (input==false) || (a1240310412==0) || (a2135110469 ==0) && (a2128198108 ==0)){
    	cf = false;
    	a2135110469 = 10;
    	a930233571 = 10;
    	a1071154797 = 13; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm17(boolean input) {
//******************Transformed code started****************************
if(a1240310412==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1240310412==0) && (cf==false)) {
    	calculateOutputm90(input);
    } 
}
private  void calculateOutputm96(boolean input) {
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a975106081==0){
if(cf==false){}
 else{}
 }
 else {}
if(a261374011==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) || (a261374011==0) && (a2135110469 ==0) || (a975106081==0) && (cf==false)){
    	cf = false;
    	a1074202851 =0;
    	a599095469 =0;
    	a2135110469 = 4; 
    	System.out.println("T");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(cf==false){
if(a975106081==0){}
 else{}
 }
 else {}
if(a261374011==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a261374011==0) && (a2135110469 ==0) || (input==false) || (cf==false) && (a975106081==0)){
    	cf = false;
    	a1553956613 =0;
    	a2135110469 = 10;
    	a930233571 = 8; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm20(boolean input) {
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a975106081==0){
 }
 else {}
//******************Transformed code end****************************
    if((a975106081==0) || (cf==false)) {
    	calculateOutputm96(input);
    } 
}
private  void calculateOutputm98(boolean input) {
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a1293654158==0){
if(a261374011==0){}
 else{}
 }
 else {}
if(input==false){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a2135110469 ==0) || (input==false) && (cf==false) || (a1293654158 ==0) && (a261374011==0)){
    	cf = false;
    	 
    	System.out.println("P");
    } 
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a1293654158==0){
if(cf==false){}
 else{}
 }
 else {}
if(a261374011==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a261374011==0) && (input==false) || (a2135110469 ==0) || (a1293654158 ==0) && (cf==false)){
    	cf = false;
    	a1553956613 =0;
    	a2135110469 = 10;
    	a930233571 = 8; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm21(boolean input) {
//******************Transformed code started****************************
if(a1293654158==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a1293654158 ==0)){
    	calculateOutputm98(input);
    } 
}
private  void calculateOutputm103(boolean input) {
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a2135110469==0){
if(a605263457==0){}
 else{}
 }
 else {}
if(cf==false){
if(a261374011==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) || (cf==false) && (a261374011==0) || (a2135110469 ==0) && (a605263457 ==0)){
    	cf = false;
    	a261374011 =0;
    	a975106081 =0; 
    	System.out.println("V");
    } 
//******************Transformed code started****************************
if(a605263457==0){
 }
 else {}
if(input==false){
if(a261374011==0){}
 else{}
 }
 else {}
if(cf==false){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a605263457 ==0) || (cf==false) && (a2135110469 ==0) || (input==false) && (a261374011==0)){
    	cf = false;
    	a1115144307 =0;
    	a130053513 =0;
    	a2135110469 = 9; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm22(boolean input) {
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a605263457==0){
 }
 else {}
//******************Transformed code end****************************
    if((a605263457 ==0) || (cf==false)) {
    	calculateOutputm103(input);
    } 
}
private  void calculateOutputm107(boolean input) {
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a2135110469==0){
 }
 else {}
if(a1228149849==0){
if(input==false){}
 else{}
if(a2128198108==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a2135110469 ==0) || (cf==false) || (a1228149849 ==0) && (input==false) && (a2128198108 ==0)){
    	cf = false;
    	a261374011 =0;
    	a2135110469 = 6;
    	a1293654158 = 7; 
    	System.out.println("U");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(cf==false){
if(a1228149849==0){}
 else{}
 }
 else {}
if(a2135110469==0){
if(a2128198108==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((input==false) || (a2135110469 ==0) && (a2128198108 ==0) || (cf==false) && (a1228149849 ==0)){
    	cf = false;
    	a286091846 =0;
    	a1644705049 =0;
    	a2135110469 = 3; 
    	System.out.println("U");
    }
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a2128198108==0){
if(input==false){}
 else{}
 }
 else {}
if(a1228149849==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a1228149849 ==0) && (cf==false) || (a2135110469 ==0) || (a2128198108 ==0) && (input==false)){
    	cf = false;
    	a1074202851 =0;
    	a2135110469 = 4;
    	a1781711932 = 10; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm110(boolean input) {
//******************Transformed code started****************************
if(a1228149849==0){
 }
 else {}
if(cf==false){
if(a2128198108==0){}
 else{}
 }
 else {}
if(a2135110469==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1228149849 ==0) || (a2135110469 ==0) && (input==false) || (cf==false) && (a2128198108 ==0)){
    	cf = false;
    	a286091846 =0;
    	a2135110469 = 5;
    	a2128198108 = 8; 
    	System.out.println("R");
    } 
//******************Transformed code started****************************
if(a2128198108==0){
 }
 else {}
if(cf==false){
if(a1228149849==0){}
 else{}
 }
 else {}
if(input==false){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a2128198108 ==0) || (input==false) && (a2135110469 ==0) || (cf==false) && (a1228149849 ==0)){
    	cf = false;
    	a130053513 =0;
    	a1644705049 =0;
    	a2135110469 = 3; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm24(boolean input) {
//******************Transformed code started****************************
if(a2128198108==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a2128198108 ==0)){
    	calculateOutputm107(input);
    } 
//******************Transformed code started****************************
if(a2128198108==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a2128198108 ==0) && (cf==false)) {
    	calculateOutputm110(input);
    } 
}
private  void calculateOutputm120(boolean input) {
//******************Transformed code started****************************
if(a1790587420==0){
 }
 else {}
if(a1228149849==0){
if(input==false){}
 else{}
 }
 else {}
if(a2135110469==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1790587420 ==0) || (a2135110469 ==0) && (cf==false) || (a1228149849 ==0) && (input==false)){
    	cf = false;
    	 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a1790587420==0){
if(input==false){}
 else{}
 }
 else {}
if(a1228149849==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a1228149849 ==0) && (cf==false) || (a2135110469 ==0) || (a1790587420 ==0) && (input==false)){
    	cf = false;
    	a286091846 =0;
    	a2135110469 = 5;
    	a2128198108 = 8; 
    	System.out.println("Z");
    } 
//******************Transformed code started****************************
if(a1790587420==0){
 }
 else {}
if(cf==false){
if(a2135110469==0){}
 else{}
 }
 else {}
if(a1228149849==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a1228149849 ==0) && (input==false) || (a1790587420 ==0) || (cf==false) && (a2135110469 ==0)){
    	cf = false;
    	a261374011 =0;
    	a2135110469 = 6;
    	a1293654158 = 11; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm28(boolean input) {
//******************Transformed code started****************************
if(cf==false){
if(a1790587420==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a1790587420 ==0)){
    	calculateOutputm120(input);
    } 
}
private  void calculateOutputm135(boolean input) {
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(input==false){
if(a2135110469==0){}
 else{}
 }
 else {}
if(a344522688==0){
if(a1718050978==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a344522688==0) && (a1718050978==0) || (input==false) && (a2135110469 ==0)){
    	cf = false;
    	a1644705049 =0;
    	a130053513 =0;
    	a2135110469 = 3; 
    	System.out.println("V");
    } 
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(cf==false){
if(a1718050978==0){}
 else{}
 }
 else {}
if(a344522688==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a2135110469 ==0) || (a344522688==0) && (input==false) || (cf==false) && (a1718050978==0)){
    	cf = false;
    	a2135110469 = 10;
    	a930233571 = 6;
    	a1342468697 = 7; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm34(boolean input) {
//******************Transformed code started****************************
if(cf==false){
if(a1718050978==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a1718050978==0)){
    	calculateOutputm135(input);
    } 
}
private  void calculateOutputm139(boolean input) {
//******************Transformed code started****************************
if(a130053513==0){
 }
 else {}
if(cf==false){
if(a1115144307==0){}
 else{}
 }
 else {}
if(input==false){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a130053513==0) || (input==false) && (a2135110469 ==0) || (cf==false) && (a1115144307==0)){
    	cf = false;
    	a2135110469 = 5;
    	a2128198108 = 10;
    	a183334438 = 9; 
    	System.out.println("R");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a1115144307==0){
if(a2135110469==0){}
 else{}
 }
 else {}
if(a130053513==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((input==false) || (a130053513==0) && (cf==false) || (a1115144307==0) && (a2135110469 ==0)){
    	cf = false;
    	a2135110469 = 5;
    	a548397256 =0;
    	a2128198108 = 13; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm36(boolean input) {
//******************Transformed code started****************************
if(cf==false){
if(a130053513==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a130053513==0)){
    	calculateOutputm139(input);
    } 
}
private  void calculateOutputm144(boolean input) {
//******************Transformed code started****************************
if(a1115144307==0){
 }
 else {}
if(a2135110469==0){
 }
 else {}
if(input==false){
 }
 else {}
if(a892451458==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) || (a892451458 ==0) && (cf==false) || (a2135110469 ==0) || (a1115144307==0)){
    	cf = false;
    	a2135110469 = 10;
    	a930233571 = 10;
    	a1071154797 = 8; 
    	System.out.println("U");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(cf==false){
if(a1115144307==0){}
 else{}
 }
 else {}
if(a2135110469==0){
if(a892451458==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((input==false) || (a2135110469 ==0) && (a892451458 ==0) || (cf==false) && (a1115144307==0)){
    	cf = false;
    	a1857660363 =0;
    	a2135110469 = 7;
    	a1228149849 = 9; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm39(boolean input) {
//******************Transformed code started****************************
if(a892451458==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a892451458 ==0) && (cf==false)) {
    	calculateOutputm144(input);
    } 
}
private  void calculateOutputm151(boolean input) {
//******************Transformed code started****************************
if(a2135110469==0){
 }
 else {}
if(a930233571==0){
if(cf==false){}
 else{}
 }
 else {}
if(input==false){
if(a1488435031==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a2135110469 ==0) || (input==false) && (a1488435031==0) || (a930233571 ==0) && (cf==false)){
    	cf = false;
    	a975106081 =0;
    	a930233571 = 9; 
    	System.out.println("V");
//******************Transformed code started****************************
if(a1488435031==0){
 }
 else {}
if(a930233571==0){
if(a2135110469==0){}
 else{}
 }
 else {}
if(input==false){
if(cf==false){}
 else{}
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    } if((a1488435031==0) || (((input==false) && (cf==false) || (a930233571 ==0))) && (a2135110469 ==0)){
    	cf = false;
    	a1228149849 = 3;
    	a2135110469 = 7;
    	a2128198108 = 14; 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(a1488435031==0){
 }
 else {}
if(cf==false){
if(input==false){}
 else{}
 }
 else {}
if(a930233571==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a1488435031==0) || (a930233571 ==0) && (a2135110469 ==0) || (cf==false) && (input==false)){
    	cf = false;
    	a1718050978 =0;
    	a1074202851 =0;
    	a2135110469 = 4; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm41(boolean input) {
//******************Transformed code started****************************
if(cf==false){
if(a1488435031==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a1488435031==0)){
    	calculateOutputm151(input);
    } 
}
private  void calculateOutputm162(boolean input) {
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a975106081==0){
if(input==false){}
 else{}
 }
 else {}
if(a930233571==0){
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a930233571 ==0) && (a2135110469 ==0) || (a975106081==0) && (input==false)){
    	cf = false;
    	a599095469 =0;
    	a1074202851 =0;
    	a2135110469 = 4; 
    	System.out.println("T");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a2135110469==0){
if(a975106081==0){}
 else{}
 }
 else {}
if(cf==false){
if(a930233571==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((input==false) || (cf==false) && (a930233571 ==0) || (a2135110469 ==0) && (a975106081==0)){
    	cf = false;
    	a1228149849 = 7;
    	a2135110469 = 7;
    	a1790587420 = 12; 
    	System.out.println("U");
    } 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a975106081==0){
if(a930233571==0){}
 else{}
 }
 else {}
if(a2135110469==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a2135110469 ==0) && (input==false) || (cf==false) || (a975106081==0) && (a930233571 ==0)){
    	cf = false;
    	a2135110469 = 5;
    	a1240310412 =0;
    	a2128198108 = 14; 
    	System.out.println("Z");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a2135110469==0){
if(a930233571==0){}
 else{}
 }
 else {}
if(a975106081==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((input==false) || (a975106081==0) && (cf==false) || (a2135110469 ==0) && (a930233571 ==0)){
    	cf = false;
    	a1840028630 =0;
    	a930233571 = 7; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm45(boolean input) {
//******************Transformed code started****************************
if(cf==false){
if(a975106081==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a975106081==0)){
    	calculateOutputm162(input);
    } 
}
private  void calculateOutputm164(boolean input) {
//******************Transformed code started****************************
if(a1071154797==0){
 }
 else {}
if(a2135110469==0){
if(input==false){}
 else{}
 }
 else {}
if(a930233571==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1071154797 ==0) || (a930233571 ==0) && (cf==false) || (a2135110469 ==0) && (input==false)){
    	cf = false;
    	a2135110469 = 9;
    	a1115144307 =0;
    	a892451458 = 10; 
    	System.out.println("R");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a930233571==0){
 }
 else {}
if(a1071154797==0){
if(cf==false){}
 else{}
if(a2135110469==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	if((a930233571 ==0) || (a1071154797 ==0) && (cf==false) && (a2135110469 ==0) || (input==false)){
    	cf = false;
    	a2135110469 = 5;
    	a286091846 =0;
    	a2128198108 = 8; 
    	System.out.println("V");
    } 
}

public  void calculateOutput(boolean input) {
 	cf = true;
//******************Transformed code started****************************
if(a1644705049==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a1644705049==0) && (cf==false)) {
    		calculateOutputm1(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1644705049==0){
 }
 else {}
//******************Transformed code end****************************
    	if((a1644705049==0) || (cf==false)) {
    		calculateOutputm2(input);
    	} 
//******************Transformed code started****************************
if(a1074202851==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) || (a1074202851==0)){
    		calculateOutputm9(input);
    	} 
//******************Transformed code started****************************
if(a2128198108==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) || (a2128198108 ==0)){
    		calculateOutputm11(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
if(a2128198108==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) && (a2128198108 ==0)){
    		calculateOutputm12(input);
    	} 
//******************Transformed code started****************************
if(a2128198108==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) || (a2128198108 ==0)){
    		calculateOutputm13(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
if(a2128198108==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) && (a2128198108 ==0)){
    		calculateOutputm17(input);
    	} 
//******************Transformed code started****************************
if(a261374011==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) || (a261374011==0)){
    		calculateOutputm20(input);
    	} 
//******************Transformed code started****************************
if(a261374011==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a261374011==0) && (cf==false)) {
    		calculateOutputm21(input);
    	} 
//******************Transformed code started****************************
if(a261374011==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) || (a261374011==0)){
    		calculateOutputm22(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
if(a1228149849==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) && (a1228149849 ==0)){
    		calculateOutputm24(input);
    	} 
//******************Transformed code started****************************
if(a1228149849==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a1228149849 ==0) && (cf==false)) {
    		calculateOutputm28(input);
    	} 
//******************Transformed code started****************************
if(a344522688==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a344522688==0) && (cf==false)) {
    		calculateOutputm34(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1115144307==0){
 }
 else {}
//******************Transformed code end****************************
    	if((a1115144307==0) || (cf==false)) {
    		calculateOutputm36(input);
    	} 
//******************Transformed code started****************************
if(a1115144307==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a1115144307==0) && (cf==false)) {
    		calculateOutputm39(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
if(a930233571==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) && (a930233571 ==0)){
    		calculateOutputm41(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
if(a930233571==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) && (a930233571 ==0)){
    		calculateOutputm45(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a930233571==0){
 }
 else {}
//******************Transformed code end****************************
    	if((a930233571 ==0) || (cf==false)) {
    		calculateOutputm164(input);
    	} 

    errorCheck();
    if(cf==false)
    	throw new IllegalArgumentException("Current state has no transition for this input!");
}


public static void main() throws Exception 
	{
	     // init system and input reader
            Problem11_RERS2019jpct eca = new Problem11_RERS2019jpct();
        int a=0;
     
		 int x = Cute.input.Integer();
         int y = Cute.input.Integer();
		boolean input = Cute.input.Boolean();
			// main i/o-loop
            while(a<10) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
//******************Transformed code started****************************
if(x>199){
if(x>y){}
 else{}
 }
 else {}
//******************Transformed code end****************************
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                	 eca.calculateOutput(input);
					 
				}
				
//******************Transformed code started****************************
if(x>299){
if(x<y){}
 else{}
 }
 else {}
//******************Transformed code end****************************
				if (x>299 && x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutput(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
	}
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
