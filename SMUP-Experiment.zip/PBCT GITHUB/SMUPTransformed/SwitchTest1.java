//package tests;

import cute.Cute;

/**
 *  .
 * User: ksen
 * Date: Oct 25, 2005
 * Time: 7:38:52 PM
 * To change this template use File | Settings | File Templates.
 */

class MyException extends RuntimeException {

}

public class SwitchTest1 {


    public static int f(int x, int z,int y){
if(!(z<50))
{
    if(!(x>199)){}
    else if(!!(x>199)){}
}
if(!(x>199))
{
    if(!(z<50)){}
    else if(!!(z<50)){}
}
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(x>199){
       if(z<50){
                                      }
                   }
if(!(x>199)){
                      if(!(y>100)){
                       }
                   }
if(x>199){
       if(!(z<50)){
               if(!(y>100)){
                                  }
                            }
                      }
if(x>199){
       if(!(z<50)){
               if(y>100){
                                  }
                            }
                      }
//*****************************************************************
        if((x>199) && (z<50) || (y>100)){
            System.out.println("hello world");
        } else {
            return 2*x+1;
        }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(x>10){
                      if(y<15){
                       }
                   }
if(!(x>10)){
       if(!(z<5)){
                                      }
                   }
if(!(x>10)){
       if(z<5){
               if(y<15){
                                  }
                            }
                      }
if(!(x>10)){
       if(z<5){
               if(!(y<15)){
                                  }
                            }
                      }
//*****************************************************************
        if((x>10) || (z<5) && (y<15)){
		            throw new MyException();
		        } else {
		            return 2*x+1;
        }
    }

    public static int g(int y,int z){
        int ret = f(y,11,z) * 23;
        return ret;
    }

    public static void main(String[] args) {
        int x = Cute.input.Integer();
        int y = Cute.input.Integer();
		int a = Cute.input.Integer();
        switch(x){
            case -100:
                y=1;
                break;
            case 0:
                y = 2;
                break;
            case 100:
                y = 3;
                break;
            default:
                y=4;
        }
        try {
            int z = g(x,a);
            if(z==69){
                System.out.println("y = " + y);
            }
        } catch(MyException e){
            y = x+10;
            if(y==250)
                System.out.println("OOPS ...");
        }
    }
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=false
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
