/* JUnit test case generated automatically by CUTE */

import junit.framework.*;

public class jxnct_Problem14_RERS2012jxnct_main_Test extends TestCase implements cute.Input {
	private Object[] input;
	private int i;

	jxnct_Problem14_RERS2012jxnct_main_Test_main_Test(String name){
		super(name);
	}
	public boolean Boolean() {
		return ((Boolean)input[i++]).booleanValue();
	}

	public short Short() {
		return ((Short)input[i++]).shortValue();
	}

	public int Integer() {
		return ((Integer)input[i++]).intValue();
	}

	public long Long() {
		return ((Long)input[i++]).longValue();
	}

	public float Float() {
		return ((Float)input[i++]).floatValue();
	}

	public double Double() {
		return ((Double)input[i++]).doubleValue();
	}

	public char Character() {
		return ((Character)input[i++]).charValue();
	}

	public byte Byte() {
		return ((Byte)input[i++]).byteValue();
	}

	public Object Object(String type) {
		return input[i++];
	}

	public void test1(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(-320735181);
		input[i++] = new Integer(-1366573976);
		input[i++] = new Integer(498951814);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test2(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(1004176399);
		input[i++] = new Integer(-1905525549);
		input[i++] = new Integer(104848058);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test3(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(1004176399);
		input[i++] = new Integer(-1905525549);
		input[i++] = new Integer(104848058);
		input[i++] = new Integer(-223248563);
		input[i++] = new Integer(2134411495);
		input[i++] = new Integer(-954370854);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test4(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(-1905525549);
		input[i++] = new Integer(6);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test5(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(7);
		input[i++] = new Integer(6);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test6(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(7);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test7(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(7);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test8(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(7);
		input[i++] = new Integer(10);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test9(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(6);
		input[i++] = new Integer(8);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test10(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(-320735181);
		input[i++] = new Integer(-1366573976);
		input[i++] = new Integer(498951814);
		input[i++] = new Integer(-1980924120);
		input[i++] = new Integer(438698623);
		input[i++] = new Integer(-448713122);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test11(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(6);
		input[i++] = new Integer(10);
		input[i++] = new Integer(2);
		input[i++] = new Integer(300);
		input[i++] = new Integer(301);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test12(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(6);
		input[i++] = new Integer(9);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test13(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(5);
		input[i++] = new Integer(9);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test14(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(5);
		input[i++] = new Integer(10);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test15(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(6);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test16(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(7);
		input[i++] = new Integer(10);
		input[i++] = new Integer(2);
		input[i++] = new Integer(300);
		input[i++] = new Integer(301);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test17(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(6);
		input[i++] = new Integer(9);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test18(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(7);
		input[i++] = new Integer(11);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test19(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(1004176399);
		input[i++] = new Integer(7);
		input[i++] = new Integer(104848058);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test20(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(6);
		input[i++] = new Integer(11);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test21(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(7);
		input[i++] = new Integer(8);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test22(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(6);
		input[i++] = new Integer(7);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test23(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(7);
		input[i++] = new Integer(8);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test24(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(5);
		input[i++] = new Integer(8);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test25(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(7);
		input[i++] = new Integer(9);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test26(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(7);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test27(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(8);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test28(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(6);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test29(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(-320735181);
		input[i++] = new Integer(6);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test30(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(9);
		input[i++] = new Integer(6);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test31(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(6);
		input[i++] = new Integer(10);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test32(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(8);
		input[i++] = new Integer(11);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test33(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(8);
		input[i++] = new Integer(9);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test34(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(8);
		input[i++] = new Integer(9);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test35(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(1004176399);
		input[i++] = new Integer(8);
		input[i++] = new Integer(104848058);
		input[i++] = new Integer(-223248563);
		input[i++] = new Integer(2134411495);
		input[i++] = new Integer(-954370854);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test36(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(1004176399);
		input[i++] = new Integer(8);
		input[i++] = new Integer(104848058);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test37(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(9);
		input[i++] = new Integer(6);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test38(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(9);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1191938093);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test39(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(9);
		input[i++] = new Integer(8);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test40(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(1004176399);
		input[i++] = new Integer(9);
		input[i++] = new Integer(104848058);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test41(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(7);
		input[i++] = new Integer(6);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test42(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(8);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test43(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(9);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test44(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(9);
		input[i++] = new Integer(8);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test45(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(7);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test46(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(9);
		input[i++] = new Integer(6);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test47(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(-80);
		input[i++] = new Integer(9);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test48(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(6);
		input[i++] = new Integer(8);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test49(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(6);
		input[i++] = new Integer(8);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test50(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(8);
		input[i++] = new Integer(8);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test51(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(8);
		input[i++] = new Integer(8);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test52(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(8);
		input[i++] = new Integer(7);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test53(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(8);
		input[i++] = new Integer(7);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test54(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(8);
		input[i++] = new Integer(7);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test55(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(8);
		input[i++] = new Integer(7);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test56(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(9);
		input[i++] = new Integer(7);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test57(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(8);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test58(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(8);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test59(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(8);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test60(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(8);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1191938093);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test61(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(6);
		input[i++] = new Integer(7);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test62(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(8);
		input[i++] = new Integer(8);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test63(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(9);
		input[i++] = new Integer(8);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test64(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(1785629298);
		input[i++] = new Integer(7);
		input[i++] = new Integer(7);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test65(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(9);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test66(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(9);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test67(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(7);
		input[i++] = new Integer(7);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test68(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(7);
		input[i++] = new Integer(7);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test69(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(7);
		input[i++] = new Integer(7);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test70(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(8);
		input[i++] = new Integer(7);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test71(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(8);
		input[i++] = new Integer(7);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test72(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(-80);
		input[i++] = new Integer(9);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test73(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(9);
		input[i++] = new Integer(11);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test74(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(9);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test75(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(9);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test76(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(7);
		input[i++] = new Integer(6);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test77(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(7);
		input[i++] = new Integer(10);
		input[i++] = new Integer(2);
		input[i++] = new Integer(300);
		input[i++] = new Integer(301);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test78(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(8);
		input[i++] = new Integer(10);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test79(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(-80);
		input[i++] = new Integer(8);
		input[i++] = new Integer(10);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test80(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(1785629298);
		input[i++] = new Integer(6);
		input[i++] = new Integer(186060765);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test81(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(8);
		input[i++] = new Integer(10);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test82(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(7);
		input[i++] = new Integer(8);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test83(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(8);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test84(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(487610223);
		input[i++] = new Integer(1581383724);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1191938093);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test85(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(9);
		input[i++] = new Integer(10);
		input[i++] = new Integer(2);
		input[i++] = new Integer(300);
		input[i++] = new Integer(301);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test86(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(-80);
		input[i++] = new Integer(9);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test87(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(-320735181);
		input[i++] = new Integer(9);
		input[i++] = new Integer(10);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test88(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(6);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test89(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(8);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test90(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(8);
		input[i++] = new Integer(6);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test91(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(8);
		input[i++] = new Integer(6);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test92(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(8);
		input[i++] = new Integer(7);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test93(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(7);
		input[i++] = new Integer(7);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test94(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(7);
		input[i++] = new Integer(11);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test95(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(9);
		input[i++] = new Integer(11);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test96(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(9);
		input[i++] = new Integer(11);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test97(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(-80);
		input[i++] = new Integer(6);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test98(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(8);
		input[i++] = new Integer(9);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test99(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(7);
		input[i++] = new Integer(11);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test100(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(1004176399);
		input[i++] = new Integer(9);
		input[i++] = new Integer(104848058);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test101(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(6);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test102(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(9);
		input[i++] = new Integer(9);
		input[i++] = new Integer(1191938093);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test103(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(6);
		input[i++] = new Integer(8);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test104(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(8);
		input[i++] = new Integer(6);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test105(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(8);
		input[i++] = new Integer(11);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test106(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(9);
		input[i++] = new Integer(7);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test107(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(7);
		input[i++] = new Integer(11);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test108(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(6);
		input[i++] = new Integer(10);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test109(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(12);
		input[i++] = new Integer(8);
		input[i++] = new Integer(6);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test110(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(1004176399);
		input[i++] = new Integer(-1905525549);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test111(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(6);
		input[i++] = new Integer(6);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test112(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(6);
		input[i++] = new Integer(6);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test113(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(-320735181);
		input[i++] = new Integer(5);
		input[i++] = new Integer(498951814);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test114(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(-320735181);
		input[i++] = new Integer(6);
		input[i++] = new Integer(498951814);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test115(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(1785629298);
		input[i++] = new Integer(6);
		input[i++] = new Integer(186060765);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test116(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(1785629298);
		input[i++] = new Integer(6);
		input[i++] = new Integer(186060765);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test117(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(1004176399);
		input[i++] = new Integer(5);
		input[i++] = new Integer(104848058);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test118(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(1785629298);
		input[i++] = new Integer(7);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test119(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(7);
		input[i++] = new Integer(7);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test120(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(7);
		input[i++] = new Integer(6);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test121(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(5);
		input[i++] = new Integer(7);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test122(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(0);
		input[i++] = new Integer(6);
		input[i++] = new Integer(8);
		input[i++] = new Integer(2);
		input[i++] = new Integer(200);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test123(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(-320735181);
		input[i++] = new Integer(-1366573976);
		input[i++] = new Integer(498951814);
		input[i++] = new Integer(-1980924120);
		input[i++] = new Integer(1);
		input[i++] = new Integer(0);
		input[i++] = new Boolean(true);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test124(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(6);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(200);
		input[i++] = new Integer(201);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

	public void test125(){
		i=0;
		input=new Object[7];
		input[i++] = new Integer(44);
		input[i++] = new Integer(6);
		input[i++] = new Integer(10);
		input[i++] = new Integer(1);
		input[i++] = new Integer(300);
		input[i++] = new Integer(301);
		input[i++] = new Boolean(false);
		i=0;
		cute.Cute.input = this;
		jxnct_Problem14_RERS2012jxnct_main_Test.main(null);
	}

}