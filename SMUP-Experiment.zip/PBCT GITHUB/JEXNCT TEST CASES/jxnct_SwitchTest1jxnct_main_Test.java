
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class jxnct_SwitchTest1jxnct_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public jxnct_SwitchTest1jxnct_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(206981663);
        input[i++] = new Integer(1979849188);
        input[i++] = new Integer(2071996747);
        i=0;
        cute.Cute.input = this;
        jxnct.SwitchTest1jxnct.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(1979849188);
        input[i++] = new Integer(2071996747);
        i=0;
        cute.Cute.input = this;
        jxnct.SwitchTest1jxnct.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(1979849188);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        jxnct.SwitchTest1jxnct.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1979849188);
        input[i++] = new Integer(101);
        i=0;
        cute.Cute.input = this;
        jxnct.SwitchTest1jxnct.main(null);
    }

    public void test18(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(1);
        input[i++] = new Integer(1979849188);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        jxnct.SwitchTest1jxnct.main(null);
    }

    public void test19(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(100);
        input[i++] = new Integer(1979849188);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        jxnct.SwitchTest1jxnct.main(null);
    }

    public void test44(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(200);
        input[i++] = new Integer(1979849188);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        jxnct.SwitchTest1jxnct.main(null);
    }

}
