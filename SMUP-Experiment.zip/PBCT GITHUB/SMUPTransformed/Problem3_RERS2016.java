package A1;

import cute.Cute;

public class FinalProblem2016 {
	

	private String[] inputs = {"B","E","C","A","D"};

	public int a171 = Cute.input.Integer();
	public int a5 = Cute.input.Integer();
	public int a37 = Cute.input.Integer();
	public int a131 = Cute.input.Integer();
	public int a157 = Cute.input.Integer();
	public int a6 = Cute.input.Integer();
	public int a165 = Cute.input.Integer();
	public int a112 = Cute.input.Integer();
	public int a103 = Cute.input.Integer();
	public int a182 = Cute.input.Integer();
	public int a155 = Cute.input.Integer();
	public int a135 = Cute.input.Integer();
	public int a184 = Cute.input.Integer();
	public int a161 = Cute.input.Integer();
	public int a183 = Cute.input.Integer();
	public int a52 = Cute.input.Integer();
	public int a77 = Cute.input.Integer();
	public int a118 = Cute.input.Integer();
	public int a105 = Cute.input.Integer();
	public int a17 = Cute.input.Integer();
	public int a75 = Cute.input.Integer();
	public int a122 = Cute.input.Integer();
	public int a82 = Cute.input.Integer();
	public int a7 = Cute.input.Integer();
	public int a163 = Cute.input.Integer();
	public int a142 = Cute.input.Integer();
	public int a128 = Cute.input.Integer();
	public int a104 = Cute.input.Integer();
	public int a199 = Cute.input.Integer();
	public int a3 = Cute.input.Integer();
	public int a176 = Cute.input.Integer();
	public int a47 = Cute.input.Integer();
	public int a53 = Cute.input.Integer();
	public int a150 = Cute.input.Integer();
	public int a138 = Cute.input.Integer();
	public int a12 = Cute.input.Integer();
	public int a36 = Cute.input.Integer();
	public int a85 = Cute.input.Integer();
	public int a119 = Cute.input.Integer();
	public int a180 = Cute.input.Integer();
	public int a84 = Cute.input.Integer();
	public int a110 = Cute.input.Integer();
	public int a57 = Cute.input.Integer();
	public int a87 = Cute.input.Integer();
	public int a44 = Cute.input.Integer();
	public int a15 = Cute.input.Integer();
	public int a175 = Cute.input.Integer();
	public int a145 = Cute.input.Integer();
	public int a16 = Cute.input.Integer();
	public int a190 = Cute.input.Integer();
	
	
	public boolean cf = Cute.input.Boolean();
	public boolean input = Cute.input.Boolean();


private void errorCheck() {
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a150==0){
                      if(a138==0){
                       }
                   }
if(!(a150==0)){
       if(!(a6==0)){
                                      }
                   }
if(!(a150==0)){
       if(a6==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a150==0)){
       if(a6==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if ((a150==0) || (a6==0) && (a138==0)){
	    	cf = false;
			
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a17 ==0){
       if(a6==0){
                                      }
                   }
if(!(a17 ==0)){
                      if(!(a138==0)){
                       }
                   }
if(a17 ==0){
       if(!(a6==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a17 ==0){
       if(!(a6==0)){
               if(a138==0){
                                  }
                            }
                      }
//*****************************************************************
	    if ((a17 ==0) && (a6==0) || (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a3 ==0){
                      if(a138==0){
                       }
                   }
if(!(a3 ==0)){
       if(!(a145 ==0)){
                                      }
                   }
if(!(a3 ==0)){
       if(a145 ==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a3 ==0)){
       if(a145 ==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if ((a3 ==0) || (a145 ==0) && (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a44 ==0){
       if(a105 ==0){
                                      }
                   }
if(!(a44 ==0)){
                      if(!(a138==0)){
                       }
                   }
if(a44 ==0){
       if(!(a105 ==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a44 ==0){
       if(!(a105 ==0)){
               if(a138==0){
                                  }
                            }
                      }
//*****************************************************************
	    if ((a44 ==0) && (a105 ==0) || (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a36 ==0){
                      if(a138==0){
                       }
                   }
if(!(a36 ==0)){
       if(!(a145 ==0)){
                                      }
                   }
if(!(a36 ==0)){
       if(a145 ==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a36 ==0)){
       if(a145 ==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if ((a36 ==0) || (a145 ==0) && (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a52==0){
       if(a105 ==0){
                                      }
                   }
if(!(a52==0)){
                      if(!(a138==0)){
                       }
                   }
if(a52==0){
       if(!(a105 ==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a52==0){
       if(!(a105 ==0)){
               if(a138==0){
                                  }
                            }
                      }
//*****************************************************************
	    if ((a52==0) && (a105 ==0) || (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a36 ==0){
                      if(a138==0){
                       }
                   }
if(!(a36 ==0)){
       if(!(a145 ==0)){
                                      }
                   }
if(!(a36 ==0)){
       if(a145 ==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a36 ==0)){
       if(a145 ==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if ((a36 ==0) || (a145 ==0) && (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a7 ==0){
       if(a145 ==0){
                                      }
                   }
if(!(a7 ==0)){
                      if(!(a138==0)){
                       }
                   }
if(a7 ==0){
       if(!(a145 ==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a7 ==0){
       if(!(a145 ==0)){
               if(a138==0){
                                  }
                            }
                      }
//*****************************************************************
	    if ((a7 ==0) && (a145 ==0) || (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a110 ==0){
                      if(a138==0){
                       }
                   }
if(!(a110 ==0)){
       if(!(a82==0)){
                                      }
                   }
if(!(a110 ==0)){
       if(a82==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a110 ==0)){
       if(a82==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if ((a110 ==0) || (a82==0) && (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a119==0){
                      if(a138==0){
                       }
                   }
if(!(a119==0)){
       if(!(a82==0)){
                                      }
                   }
if(!(a119==0)){
       if(a82==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a119==0)){
       if(a82==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if ((a119==0) || (a82==0) && (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(a165==0)){
       if(!(a105 ==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a165==0){
       if(!(a105 ==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(!(a165==0)){
       if(a105 ==0){
               if(!(a138==0)){
                                  }
                            }
                      }
if(!(a165==0)){
       if(!(a105 ==0)){
               if(a138==0){
                                  }
                            }
                      }
//*********************************************************************
	    if ((a165==0) || (a105 ==0) || (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a3 ==0){
                      if(a138==0){
                       }
                   }
if(!(a3 ==0)){
       if(!(a145 ==0)){
                                      }
                   }
if(!(a3 ==0)){
       if(a145 ==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a3 ==0)){
       if(a145 ==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if ((a3 ==0) || (a145 ==0) && (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a112 ==0){
                      if(a138==0){
                       }
                   }
if(!(a112 ==0)){
       if(!(a105 ==0)){
                                      }
                   }
if(!(a112 ==0)){
       if(a105 ==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a112 ==0)){
       if(a105 ==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if ((a112 ==0) || (a105 ==0) && (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a77==0){
       if(a145 ==0){
                                      }
                   }
if(!(a77==0)){
                      if(!(a138==0)){
                       }
                   }
if(a77==0){
       if(!(a145 ==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a77==0){
       if(!(a145 ==0)){
               if(a138==0){
                                  }
                            }
                      }
//*****************************************************************
	    if ((a77==0) && (a145 ==0) || (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a183==0){
       if(a6==0){
                                      }
                   }
if(!(a183==0)){
                      if(!(a138==0)){
                       }
                   }
if(a183==0){
       if(!(a6==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a183==0){
       if(!(a6==0)){
               if(a138==0){
                                  }
                            }
                      }
//*****************************************************************
	    if ((a183==0) && (a6==0) || (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing only OR operator
if(!(a190==0)){
       if(!(a6==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a190==0){
       if(!(a6==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(!(a190==0)){
       if(a6==0){
               if(!(a138==0)){
                                  }
                            }
                      }
if(!(a190==0)){
       if(!(a6==0)){
               if(a138==0){
                                  }
                            }
                      }
//*********************************************************************
	    if ((a190==0) || (a6==0) || (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a199 ==0){
       if(a6==0){
                                      }
                   }
if(!(a199 ==0)){
                      if(!(a138==0)){
                       }
                   }
if(a199 ==0){
       if(!(a6==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a199 ==0){
       if(!(a6==0)){
               if(a138==0){
                                  }
                            }
                      }
//*****************************************************************
		if((a199 ==0) && (a6==0) || (a138==0)){
	    	cf = false;
	    	   
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a36 ==03){
                      if(a138==0){
                       }
                   }
if(!(a36 ==03)){
       if(!(a145 ==0)){
                                      }
                   }
if(!(a36 ==03)){
       if(a145 ==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a36 ==03)){
       if(a145 ==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a36 ==03) || (a145 ==0) && (a138==0)){
	    	cf = false;
	    	   
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a17 ==0){
                      if(a138==0){
                       }
                   }
if(!(a17 ==0)){
       if(!(a6==0)){
                                      }
                   }
if(!(a17 ==0)){
       if(a6==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a17 ==0)){
       if(a6==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a17 ==0) || (a6==0) && (a138==0)){
	    	cf = false;
	    	   
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a104 ==0){
       if(a145 ==0){
                                      }
                   }
if(!(a104 ==0)){
                      if(!(a138==0)){
                       }
                   }
if(a104 ==0){
       if(!(a145 ==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a104 ==0){
       if(!(a145 ==0)){
               if(a138==0){
                                  }
                            }
                      }
//*****************************************************************
	    if((a104 ==0) && (a145 ==0) || (a138==0)){
	    	cf = false;
	    	   
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a180==0){
                      if(a138==0){
                       }
                   }
if(!(a180==0)){
       if(!(a105 ==0)){
                                      }
                   }
if(!(a180==0)){
       if(a105 ==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a180==0)){
       if(a105 ==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a180==0) || (a105 ==0) && (a138==0)){
	    	cf = false;
	    	
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a150==0){
       if(a6==0){
                                      }
                   }
if(!(a150==0)){
                      if(!(a138==0)){
                       }
                   }
if(a150==0){
       if(!(a6==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a150==0){
       if(!(a6==0)){
               if(a138==0){
                                  }
                            }
                      }
//*****************************************************************
	    if((a150==0) && (a6==0) || (a138==0)){
	    	cf = false;
	    	
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a190==0){
                      if(a138==0){
                       }
                   }
if(!(a190==0)){
       if(!(a6==0)){
                                      }
                   }
if(!(a190==0)){
       if(a6==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a190==0)){
       if(a6==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a190==0)|| (a6==0) && (a138==0)){
	    	cf = false;
	    	
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a118==0){
       if(a6==0){
                                      }
                   }
if(!(a118==0)){
                      if(!(a138==0)){
                       }
                   }
if(a118==0){
       if(!(a6==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a118==0){
       if(!(a6==0)){
               if(a138==0){
                                  }
                            }
                      }
//*****************************************************************
	    if((a118==0) && (a6==0) || (a138==0)){
	    	cf = false;
	    	
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a87==0){
                      if(a138==0){
                       }
                   }
if(!(a87==0)){
       if(!(a82==0)){
                                      }
                   }
if(!(a87==0)){
       if(a82==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a87==0)){
       if(a82==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a87==0) || (a82==0) && (a138==0)){
	    	cf = false;
	    	
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a36 ==0){
       if(a145 ==0){
                                      }
                   }
if(!(a36 ==0)){
                      if(!(a138==0)){
                       }
                   }
if(a36 ==0){
       if(!(a145 ==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a36 ==0){
       if(!(a145 ==0)){
               if(a138==0){
                                  }
                            }
                      }
//*****************************************************************
	    if((a36 ==0) && (a145 ==0) || (a138==0)){
	    	cf = false;
	    	
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a112 ==00){
                      if(a138==0){
                       }
                   }
if(!(a112 ==00)){
       if(!(a105 ==0)){
                                      }
                   }
if(!(a112 ==00)){
       if(a105 ==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a112 ==00)){
       if(a105 ==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a112 ==00) || (a105 ==0) && (a138==0)){
	    	cf = false;
	    	     
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a7 ==0){
       if(a145 ==0){
                                      }
                   }
if(!(a7 ==0)){
                      if(!(a138==0)){
                       }
                   }
if(a7 ==0){
       if(!(a145 ==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a7 ==0){
       if(!(a145 ==0)){
               if(a138==0){
                                  }
                            }
                      }
//*****************************************************************
	    if((a7 ==0) && (a145 ==0) || (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a5==0){
                      if(a138==0){
                       }
                   }
if(!(a5==0)){
       if(!(a6==0)){
                                      }
                   }
if(!(a5==0)){
       if(a6==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a5==0)){
       if(a6==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a5==0) || (a6==0) && (a138==0)){
	    	cf = false;
	    	  
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a87==0){
       if(a82==0){
                                      }
                   }
if(!(a87==0)){
                      if(!(a138==0)){
                       }
                   }
if(a87==0){
       if(!(a82==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a87==0){
       if(!(a82==0)){
               if(a138==0){
                                  }
                            }
                      }
//*****************************************************************
	    if((a87==0) && (a82==0) || (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a119==0){
                      if(a138==0){
                       }
                   }
if(!(a119==0)){
       if(!(a82==0)){
                                      }
                   }
if(!(a119==0)){
       if(a82==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a119==0)){
       if(a82==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a119==0) || (a82==0) && (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a150==0){
                      if(a138==0){
                       }
                   }
if(!(a150==0)){
       if(!(a145 ==0)){
                                      }
                   }
if(!(a150==0)){
       if(a145 ==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a150==0)){
       if(a145 ==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a150==0) || (a145 ==0) && (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a87==0){
       if(a82==0){
                                      }
                   }
if(!(a87==0)){
                      if(!(a138==0)){
                       }
                   }
if(a87==0){
       if(!(a82==0)){
               if(!(a138==0)){
                                  }
                            }
                      }
if(a87==0){
       if(!(a82==0)){
               if(a138==0){
                                  }
                            }
                      }
//*****************************************************************
	    if((a87==0) && (a82==0) || (a138==0)){
	    	cf = false;
	    	 
	    }
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a183==0){
                      if(a138==0){
                       }
                   }
if(!(a183==0)){
       if(!(a6==0)){
                                      }
                   }
if(!(a183==0)){
       if(a6==0){
               if(a138==0){
                                  }
                            }
                      }
if(!(a183==0)){
       if(a6==0){
               if(!(a138==0)){
                                  }
                            }
                      }
//*****************************************************************
	    if((a183==0) || (a6==0) && (a138==0)){
	    	cf = false;
	    	 
	    }
	    
	    
}

private  void calculateOutputm1(boolean input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input==false){
       if(cf==false){
               if(a135==0){
                       if(a47 ==0){
                               if(a84==0){
                                       if(a171==0){
                                               if(a176==0){
                                                       if(a142 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(input==false)){
       if(cf==false){
               if(a135==0){
                       if(a47 ==0){
                               if(a84==0){
                                       if(a171==0){
                                               if(a176==0){
                                                       if(a142 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(input==false){
       if(!(cf==false)){
               if(a135==0){
                       if(a47 ==0){
                               if(a84==0){
                                       if(a171==0){
                                               if(a176==0){
                                                       if(a142 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(input==false){
       if(cf==false){
               if(!(a135==0)){
                       if(a47 ==0){
                               if(a84==0){
                                       if(a171==0){
                                               if(a176==0){
                                                       if(a142 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(input==false){
       if(cf==false){
               if(a135==0){
                       if(!(a47 ==0)){
                               if(a84==0){
                                       if(a171==0){
                                               if(a176==0){
                                                       if(a142 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(input==false){
       if(cf==false){
               if(a135==0){
                       if(a47 ==0){
                               if(!(a84==0)){
                                       if(a171==0){
                                               if(a176==0){
                                                       if(a142 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(input==false){
       if(cf==false){
               if(a135==0){
                       if(a47 ==0){
                               if(a84==0){
                                       if(!(a171==0)){
                                               if(a176==0){
                                                       if(a142 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(input==false){
       if(cf==false){
               if(a135==0){
                       if(a47 ==0){
                               if(a84==0){
                                       if(a171==0){
                                               if(!(a176==0)){
                                                       if(a142 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(input==false){
       if(cf==false){
               if(a135==0){
                       if(a47 ==0){
                               if(a84==0){
                                       if(a171==0){
                                               if(a176==0){
                                                       if(!(a142 ==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*********************************************************************
		if((input==false) && (cf==false) && (a135==0) && (a47 ==0) && (a84==0) && (a171==0) && (a176==0) && (a142 ==0)) {
    	cf = false;
    	a135 = 1;
    	a57 = 2;
    	a176 = 1;
    	a84 = 1;
    	a47 = 8;
    	a180 = 1;
    	a75 = 1;
    	a131 = 6;
    	a103 = 1;
    	a122 = 1;
    	a53 = 1;
    	a184 = 4;
    	a138 = 1;
    	a105 = 14; 
    	System.out.println("Y");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a75==1){
       if(a84==0){
               if(a47 ==0){
                       if(a103==0){
                                                                      if(a161 ==0){
                                                                                                      if(input==false){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a75==1)){
                                                                            if(!(a37 ==0)){
                                                                                      if(!(cf==false)){
                                                                                         }
                            }
                      }
if(a75==1){
       if(!(a84==0)){
                                                                     if(!(a37 ==0)){
                                                                                      if(!(cf==false)){
                                                                                                    }
                                     }
                             }
                     }
if(a75==1){
       if(a84==0){
               if(!(a47 ==0)){
                                                      if(!(a37 ==0)){
                                                                                      if(!(cf==false)){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(a75==1){
       if(a84==0){
               if(a47 ==0){
                       if(!(a103==0)){
                               if(!(a37 ==0)){
                                                                                      if(!(cf==false)){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(a75==1){
       if(a84==0){
               if(a47 ==0){
                       if(!(a103==0)){
                               if(a37 ==0){
                                       if(a161 ==0){
                                                                                                      if(input==false){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a75==1){
       if(a84==0){
               if(a47 ==0){
                       if(!(a103==0)){
                               if(a37 ==0){
                                       if(!(a161 ==0)){
                                               if(!(cf==false)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a75==1){
       if(a84==0){
               if(a47 ==0){
                       if(!(a103==0)){
                               if(a37 ==0){
                                       if(!(a161 ==0)){
                                               if(cf==false){
                                                       if(input==false){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a75==1){
       if(a84==0){
               if(a47 ==0){
                       if(!(a103==0)){
                               if(a37 ==0){
                                       if(!(a161 ==0)){
                                               if(cf==false){
                                                       if(!(input==false)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a75==1) && (a84==0) && (a47 ==0) && (a103==0) || (a37 ==0) && (a161 ==0) || (cf==false) && (input==false)) {
    	cf = false;
    	a145 = 3;
    	a37 = 4;
    	a57 = 3;
    	a84 = 1;
    	a75 = 1;
    	a184 = 5;
    	a131 = 7;
    	a175 = 4;
    	a15 = 1;
    	a155 = 8;
    	a138 = 1;
    	a85 = 12;
    	a36 = 10; 
    	System.out.println("V");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a84==0){
       if(a75==1){
                                      if(a131 ==0){
                               if(a176==0){
                                                                                      if(input==false){
                                                       if(cf==false){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a84==0)){
                      if(!(a57 ==0)){
                                                                                             if(!(a103==0)){
                                                                                                                                        }
                            }
                      }
if(a84==0){
       if(!(a75==1)){
               if(!(a57 ==0)){
                                                                                             if(!(a103==0)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(a84==0){
       if(!(a75==1)){
               if(a57 ==0){
                       if(a131 ==0){
                               if(a176==0){
                                                                                      if(input==false){
                                                       if(cf==false){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a84==0){
       if(!(a75==1)){
               if(a57 ==0){
                       if(!(a131 ==0)){
                                                                      if(!(a103==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(a84==0){
       if(!(a75==1)){
               if(a57 ==0){
                       if(a131 ==0){
                               if(!(a176==0)){
                                       if(!(a103==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(a84==0){
       if(!(a75==1)){
               if(a57 ==0){
                       if(a131 ==0){
                               if(!(a176==0)){
                                       if(a103==0){
                                               if(input==false){
                                                       if(cf==false){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a84==0){
       if(!(a75==1)){
               if(a57 ==0){
                       if(a131 ==0){
                               if(!(a176==0)){
                                       if(a103==0){
                                               if(!(input==false)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a84==0){
       if(!(a75==1)){
               if(a57 ==0){
                       if(a131 ==0){
                               if(!(a176==0)){
                                       if(a103==0){
                                               if(input==false){
                                                       if(!(cf==false)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a84==0) && (a75==1) || (a57 ==0) && (a131 ==0) && (a176==0) || (a103==0) && (input==false) && (cf==false)) {
    	cf = false;
    	a176 = 1;
    	a85 = 11;
    	a53 = 1;
    	a142 = 9;
    	a138 = 1;
    	a15 = 1;
    	a122 = 1;
    	a103 = 1;
    	a57 = 2;
    	a47 = 8;
    	a105 = 9;
    	a131 = 6;
    	a37 = 3;
    	a12 = 13; 
    	System.out.println("W");
    }
}
    
private  void calculateOutputm4(boolean input) {
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a15==0){
       if(a103==0){
                                      if(input==false){
                               if(a171==0){
                                                                                      if(a103==0){
                                                       if(a84==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a15==0)){
                      if(!(cf==false)){
                                                                                             if(!(a131 ==0)){
                                                                                                                                        }
                            }
                      }
if(a15==0){
       if(!(a103==0)){
               if(!(cf==false)){
                                                                                             if(!(a131 ==0)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(a15==0){
       if(!(a103==0)){
               if(cf==false){
                       if(input==false){
                               if(a171==0){
                                                                                      if(!(a103==0)){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(a15==0){
       if(!(a103==0)){
               if(cf==false){
                       if(!(input==false)){
                                                                      if(!(a131 ==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(a15==0){
       if(!(a103==0)){
               if(cf==false){
                       if(input==false){
                               if(!(a171==0)){
                                       if(!(a131 ==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(a15==0){
       if(!(a103==0)){
               if(cf==false){
                       if(input==false){
                               if(!(a171==0)){
                                       if(a131 ==0){
                                               if(!(a103==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a15==0){
       if(!(a103==0)){
               if(cf==false){
                       if(input==false){
                               if(!(a171==0)){
                                       if(a131 ==0){
                                               if(!(a103==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a15==0){
       if(!(a103==0)){
               if(cf==false){
                       if(input==false){
                               if(!(a171==0)){
                                       if(a131 ==0){
                                               if(!(a103==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
//*****************************************************************
    if((a15==0) && (a103==0) || (cf==false) && (input==false) && (a171==0) || (a131 ==0) && (a103==0) && (a84==0)) {
    	cf = false;
    	a122 = 1;
    	a57 = 2;
    	a138 = 0;
    	a85 = 11;
    	a155 = 7;
    	a103 = 1;
    	a161 = 5;
    	a171 = 1;
    	a131 = 6;
    	a6 = 0;
    	a175 = 3;
    	a37 = 3;
    	a17 = 13; 
    	System.out.println("W");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a135==0){
       if(a184 ==0){
                                      if(a175 ==0){
                                                                      if(cf==false){
                                               if(a135==0){
                                                       if(a37 ==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a135==0)){
                      if(!(a85 ==0)){
                                                      if(!(input==false)){
                                                                                                                                                                               }
                            }
                      }
if(a135==0){
       if(!(a184 ==0)){
               if(!(a85 ==0)){
                                                      if(!(input==false)){
                                                                                                                                                                                          }
                                     }
                             }
                     }
if(a135==0){
       if(!(a184 ==0)){
               if(a85 ==0){
                       if(a175 ==0){
                                                                      if(cf==false){
                                               if(a135==0){
                                                       if(a37 ==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a135==0){
       if(!(a184 ==0)){
               if(a85 ==0){
                       if(!(a175 ==0)){
                               if(!(input==false)){
                                                                                                                                                                                                     }
                                              }
                                    }
                          }
                }
if(a135==0){
       if(!(a184 ==0)){
               if(a85 ==0){
                       if(!(a175 ==0)){
                               if(input==false){
                                       if(cf==false){
                                               if(a135==0){
                                                       if(a37 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a135==0){
       if(!(a184 ==0)){
               if(a85 ==0){
                       if(!(a175 ==0)){
                               if(input==false){
                                       if(!(cf==false)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(a135==0){
       if(!(a184 ==0)){
               if(a85 ==0){
                       if(!(a175 ==0)){
                               if(input==false){
                                       if(cf==false){
                                               if(a135==0){
                                                       if(a37 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a135==0){
       if(!(a184 ==0)){
               if(a85 ==0){
                       if(!(a175 ==0)){
                               if(input==false){
                                       if(cf==false){
                                               if(a135==0){
                                                       if(!(a37 ==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a135==0) && (a184 ==0) || (a85 ==0) && (a175 ==0) || (input==false) && (cf==false) && (a135==0) && (a37 ==0)) {
    	cf = false;
    	a84 = 1;
    	a6 = 1;
    	a163 = 0;
    	a118 = 1; 
    	System.out.println("U");
    }
}
	
private  void calculateOutputm128(boolean input) {
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a53==0){
                      if(a142 ==0){
                       if(a122==0){
                                                                      if(input==false){
                                                                                                      if(a37 ==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a53==0)){
       if(!(a57 ==0)){
                                                                     if(!(cf==false)){
                                                                                      if(a122==0){
                                                       if(a37 ==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a53==0)){
       if(a57 ==0){
               if(a142 ==0){
                       if(a122==0){
                                                                      if(input==false){
                                                                                                      if(a37 ==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a53==0)){
       if(a57 ==0){
               if(!(a142 ==0)){
                                                      if(!(cf==false)){
                                                                                      if(a122==0){
                                                       if(a37 ==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a53==0)){
       if(a57 ==0){
               if(a142 ==0){
                       if(!(a122==0)){
                               if(!(cf==false)){
                                                                                      if(!(a122==0)){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a53==0)){
       if(a57 ==0){
               if(a142 ==0){
                       if(!(a122==0)){
                               if(cf==false){
                                       if(input==false){
                                                                                                      if(a37 ==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a53==0)){
       if(a57 ==0){
               if(a142 ==0){
                       if(!(a122==0)){
                               if(cf==false){
                                       if(!(input==false)){
                                               if(!(a122==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a53==0)){
       if(a57 ==0){
               if(a142 ==0){
                       if(!(a122==0)){
                               if(cf==false){
                                       if(!(input==false)){
                                               if(!(a122==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a53==0)){
       if(a57 ==0){
               if(a142 ==0){
                       if(!(a122==0)){
                               if(cf==false){
                                       if(!(input==false)){
                                               if(!(a122==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
//*****************************************************************
    if((a53==0) || (a57 ==0) && (a142 ==0) && (a122==0) || (cf==false) && (input==false) || (a122==0) && (a37 ==0)) {
    	cf = false;
    	a57 = 1;
    	a47 = 7;
    	a37 = 2;
    	a131 = 5;
    	a135 = 1;
    	a163 = 0;
    	a6 = 1;
    	a138 = 1;
    	a15 = 1;
    	a84 = 1;
    	a122 = 1;
    	a53 = 1;
    	a75 = 1;
    	a142 = 8;
    	a103 = 1;
    	a5 = 0;
    	a176 = 1;
    	a155 = 6; 
    	System.out.println("S");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a103==0){
       if(a155 ==0){
                                      if(cf==false){
                               if(a135==0){
                                                                                      if(a163==0){
                                                       if(a176==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a103==0)){
                      if(!(input==false)){
                                                                                             if(!(a75==0)){
                                                                                                                                        }
                            }
                      }
if(a103==0){
       if(!(a155 ==0)){
               if(!(input==false)){
                                                                                             if(!(a75==0)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(a103==0){
       if(!(a155 ==0)){
               if(input==false){
                       if(cf==false){
                               if(a135==0){
                                                                                      if(a163==0){
                                                       if(a176==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a103==0){
       if(!(a155 ==0)){
               if(input==false){
                       if(!(cf==false)){
                                                                      if(!(a75==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(a103==0){
       if(!(a155 ==0)){
               if(input==false){
                       if(cf==false){
                               if(!(a135==0)){
                                       if(!(a75==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(a103==0){
       if(!(a155 ==0)){
               if(input==false){
                       if(cf==false){
                               if(!(a135==0)){
                                       if(a75==0){
                                               if(a163==0){
                                                       if(a176==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a103==0){
       if(!(a155 ==0)){
               if(input==false){
                       if(cf==false){
                               if(!(a135==0)){
                                       if(a75==0){
                                               if(!(a163==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a103==0){
       if(!(a155 ==0)){
               if(input==false){
                       if(cf==false){
                               if(!(a135==0)){
                                       if(a75==0){
                                               if(a163==0){
                                                       if(!(a176==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a103==0) && (a155 ==0) ||(input==false) && (cf==false) && (a135==0) || (a75==0) && (a163==0) && (a176==0)) {
    	cf = false;
    	a6 = 0;
    	a53 = 1;
    	a135 = 1;
    	a163 = 1;
    	a138 = 1;
    	a47 = 7;
    	a57 = 1;
    	a183 = 0;
    	a122 = 1;
    	a176 = 1;
    	a103 = 1;
    	a155 = 6; 
    	System.out.println("U");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a75==0){
       if(a163==0){
                                                                                                            if(a135==0){
                                               if(a37 ==0){
                                                       if(a131 ==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a75==0)){
                      if(!(input==false)){
                       if(!(cf==false)){
                               if(!(a84==0)){
                                                                                                                                                                                          }
                                     }
                             }
                     }
if(a75==0){
       if(!(a163==0)){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(!(a84==0)){
                                                                                                                                                                                                     }
                                              }
                                    }
                          }
                }
if(a75==0){
       if(!(a163==0)){
               if(input==false){
                                                                                             if(a135==0){
                                               if(a37 ==0){
                                                       if(a131 ==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(a75==0){
       if(!(a163==0)){
               if(!(input==false)){
                       if(cf==false){
                                                                      if(a135==0){
                                               if(a37 ==0){
                                                       if(a131 ==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a75==0){
       if(!(a163==0)){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(a84==0){
                                       if(a135==0){
                                               if(a37 ==0){
                                                       if(a131 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a75==0){
       if(!(a163==0)){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(a84==0){
                                       if(!(a135==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(a75==0){
       if(!(a163==0)){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(a84==0){
                                       if(a135==0){
                                               if(!(a37 ==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a75==0){
       if(!(a163==0)){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(a84==0){
                                       if(a135==0){
                                               if(a37 ==0){
                                                       if(!(a131 ==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a75==0) && (a163==0) || (input==false) || (cf==false) || (a84==0) && (a135==0) && (a37 ==0) && (a131 ==0)) {
    	cf = false;
    	a37 = 3;
    	a53 = 0;
    	a75 = 0;
    	a84 = 0;
    	a138 = 0;
    	a122 = 0;
    	a57 = 2;
    	a47 = 8;
    	a15 = 0;
    	a163 = 0;
    	a105 = 13;
    	a161 = 5;
    	a103 = 0;
    	a176 = 0;
    	a128 = 10; 
    	System.out.println("T");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a57 ==0){
       if(a176==0){
                                      if(a155 ==0){
                               if(cf==false){
                                       if(input==false){
                                               if(a176==0){
                                                       if(a84==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a57 ==0)){
                      if(!(a47 ==0)){
                                                                                                                                                                                                                          }
                   }
if(a57 ==0){
       if(!(a176==0)){
               if(!(a47 ==0)){
                                                                                                                                                                                                                                     }
                            }
                      }
if(a57 ==0){
       if(!(a176==0)){
               if(a47 ==0){
                       if(a155 ==0){
                               if(cf==false){
                                       if(input==false){
                                               if(!(a176==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a57 ==0){
       if(!(a176==0)){
               if(a47 ==0){
                       if(!(a155 ==0)){
                                                                                                                                                                                                                         }
                                     }
                             }
                     }
if(a57 ==0){
       if(!(a176==0)){
               if(a47 ==0){
                       if(a155 ==0){
                               if(!(cf==false)){
                                                                                                                                                                                                     }
                                              }
                                    }
                          }
                }
if(a57 ==0){
       if(!(a176==0)){
               if(a47 ==0){
                       if(a155 ==0){
                               if(cf==false){
                                       if(!(input==false)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(a57 ==0){
       if(!(a176==0)){
               if(a47 ==0){
                       if(a155 ==0){
                               if(cf==false){
                                       if(input==false){
                                               if(!(a176==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a57 ==0){
       if(!(a176==0)){
               if(a47 ==0){
                       if(a155 ==0){
                               if(cf==false){
                                       if(input==false){
                                               if(!(a176==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
//*****************************************************************
    if((a57 ==0) && (a176==0) || (a47 ==0) && (a155 ==0) && (cf==false) && (input==false) && (a176==0) && (a84==0)) {
    	cf = false;
    	a122 = 1;
    	a53 = 1;
    	a5 = 0;
    	a176 = 1;
    	a103 = 1;
    	a47 = 7;
    	a142 = 8;
    	a135 = 1;
    	a138 = 1;
    	a131 = 5;
    	a6 = 1;
    	a155 = 6; 
    	System.out.println("U");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a103==0){
       if(cf==false){
               if(input==false){
                                                                                                                                            if(a135==0){
                                                       if(a84==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a103==0)){
                                             if(!(a142 ==0)){
                               if(!(a57 ==0)){
                                       if(!(a15==0)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(a103==0){
       if(!(cf==false)){
                                      if(!(a142 ==0)){
                               if(!(a57 ==0)){
                                       if(!(a15==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(a103==0){
       if(cf==false){
               if(!(input==false)){
                       if(!(a142 ==0)){
                               if(!(a57 ==0)){
                                       if(!(a15==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(a103==0){
       if(cf==false){
               if(!(input==false)){
                       if(a142 ==0){
                                                                                                                     if(a135==0){
                                                       if(a84==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(a103==0){
       if(cf==false){
               if(!(input==false)){
                       if(!(a142 ==0)){
                               if(a57 ==0){
                                                                                      if(a135==0){
                                                       if(a84==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a103==0){
       if(cf==false){
               if(!(input==false)){
                       if(!(a142 ==0)){
                               if(!(a57 ==0)){
                                       if(a15==0){
                                               if(a135==0){
                                                       if(a84==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a103==0){
       if(cf==false){
               if(!(input==false)){
                       if(!(a142 ==0)){
                               if(!(a57 ==0)){
                                       if(a15==0){
                                               if(!(a135==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a103==0){
       if(cf==false){
               if(!(input==false)){
                       if(!(a142 ==0)){
                               if(!(a57 ==0)){
                                       if(a15==0){
                                               if(a135==0){
                                                       if(!(a84==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a103==0) && (cf==false) && (input==false) || (a142 ==0) || (a57 ==0) || (a15==0) && (a135==0) && (a84==0)) {
    	cf = false;
    	a85 = 12;
    	a184 = 5;
    	a171 = 0;
    	a145 = 3;
    	a161 = 6;
    	a53 = 0;
    	a175 = 4;
    	a36 = 11; 
    	System.out.println("Y");
    } 
}

private  void calculateOutputm130(boolean input) {
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a155 ==0){
                                             if(a84==0){
                                                                      if(input==false){
                                               if(cf==false){
                                                       if(a15==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a155 ==0)){
       if(!(a171==0)){
               if(!(a122==0)){
                                                      if(!(a142 ==0)){
                                                                                                                                                                                          }
                                     }
                             }
                     }
if(!(a155 ==0)){
       if(a171==0){
                                      if(a84==0){
                                                                      if(input==false){
                                               if(cf==false){
                                                       if(a15==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a155 ==0)){
       if(!(a171==0)){
               if(a122==0){
                       if(a84==0){
                                                                      if(input==false){
                                               if(cf==false){
                                                       if(a15==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a155 ==0)){
       if(!(a171==0)){
               if(a122==0){
                       if(!(a84==0)){
                               if(!(a142 ==0)){
                                                                                                                                                                                                     }
                                              }
                                    }
                          }
                }
if(!(a155 ==0)){
       if(!(a171==0)){
               if(a122==0){
                       if(!(a84==0)){
                               if(a142 ==0){
                                       if(input==false){
                                               if(cf==false){
                                                       if(a15==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a155 ==0)){
       if(!(a171==0)){
               if(a122==0){
                       if(!(a84==0)){
                               if(a142 ==0){
                                       if(!(input==false)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a155 ==0)){
       if(!(a171==0)){
               if(a122==0){
                       if(!(a84==0)){
                               if(a142 ==0){
                                       if(input==false){
                                               if(!(cf==false)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a155 ==0)){
       if(!(a171==0)){
               if(a122==0){
                       if(!(a84==0)){
                               if(a142 ==0){
                                       if(input==false){
                                               if(cf==false){
                                                       if(!(a15==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a155 ==0) || (a171==0) || (a122==0) && (a84==0) || (a142 ==0) && (input==false) && (cf==false) && (a15==0)) {
    	cf = false;
    	a176 = 0;
    	a47 = 8;
    	a155 = 7;
    	a131 = 6;
    	a138 = 0;
    	a105 = 10;
    	a122 = 0;
    	a142 = 9;
    	a15 = 0;
    	a103 = 0;
    	a85 = 11;
    	a84 = 0;
    	a163 = 0;
    	a37 = 3;
    	a184 = 4;
    	a112 = 10; 
    	System.out.println("U");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a142 ==0){
                      if(cf==false){
                                                      if(a155 ==0){
                                                                                      if(a142 ==0){
                                                       if(a37 ==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a142 ==0)){
       if(!(input==false)){
                                      if(!(a103==0)){
                                                                      if(!(a84==0)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(a142 ==0)){
       if(input==false){
               if(cf==false){
                                                      if(a155 ==0){
                                                                                      if(!(a142 ==0)){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(!(a142 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(!(a103==0)){
                                                                      if(!(a84==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(!(a142 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a103==0){
                               if(a155 ==0){
                                                                                      if(!(a142 ==0)){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a142 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a103==0){
                               if(!(a155 ==0)){
                                       if(!(a84==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a142 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a103==0){
                               if(!(a155 ==0)){
                                       if(a84==0){
                                               if(!(a142 ==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a142 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a103==0){
                               if(!(a155 ==0)){
                                       if(a84==0){
                                               if(!(a142 ==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a142 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a103==0){
                               if(!(a155 ==0)){
                                       if(a84==0){
                                               if(!(a142 ==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
//*****************************************************************
    if((a142 ==0) || (input==false) && (cf==false) || (a103==0) && (a155 ==0) || (a84==0) && (a142 ==0) && (a37 ==0)) {
    	cf = false;
    	a155 = 7;
    	a176 = 0;
    	a75 = 0;
    	a105 = 11;
    	a184 = 4;
    	a84 = 0;
    	a85 = 11;
    	a122 = 0;
    	a57 = 2;
    	a103 = 0;
    	a138 = 0;
    	a47 = 8;
    	a15 = 0;
    	a142 = 9;
    	a161 = 5;
    	a44 = 12; 
    	System.out.println("U");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a75==0){
                      if(input==false){
                                                      if(a163==0){
                                                                                      if(!(a122==0)){
                                                                                                    }
                                     }
                             }
                     }
if(!(a75==0)){
       if(!(cf==false)){
                                      if(!(a122==0)){
                                                                      if(!(a171==0)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(a75==0)){
       if(cf==false){
               if(input==false){
                                                      if(a163==0){
                                                                                      if(!(a122==0)){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(!(a75==0)){
       if(cf==false){
               if(!(input==false)){
                       if(!(a122==0)){
                                                                      if(!(a171==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(!(a75==0)){
       if(cf==false){
               if(!(input==false)){
                       if(a122==0){
                               if(a163==0){
                                                                                      if(a122==0){
                                                       if(a15==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a75==0)){
       if(cf==false){
               if(!(input==false)){
                       if(a122==0){
                               if(!(a163==0)){
                                       if(!(a171==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a75==0)){
       if(cf==false){
               if(!(input==false)){
                       if(a122==0){
                               if(!(a163==0)){
                                       if(a171==0){
                                               if(a122==0){
                                                       if(a15==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a75==0)){
       if(cf==false){
               if(!(input==false)){
                       if(a122==0){
                               if(!(a163==0)){
                                       if(a171==0){
                                               if(a122==0){
                                                       if(a15==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a75==0)){
       if(cf==false){
               if(!(input==false)){
                       if(a122==0){
                               if(!(a163==0)){
                                       if(a171==0){
                                               if(a122==0){
                                                       if(!(a15==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a75==0) || (cf==false) && (input==false) || (a122==0) && (a163==0) || (a171==0) && (a122==0) && (a15==0)) {
    	cf = false;
    	 
    	System.out.println("Y");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a161 ==0){
                      if(cf==false){
                                                      if(a176==0){
                                                                                      if(a75==0){
                                                       if(a135==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a161 ==0)){
       if(!(a57 ==0)){
                                      if(!(input==false)){
                                                                      if(!(a122==0)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(a161 ==0)){
       if(a57 ==0){
               if(cf==false){
                                                      if(a176==0){
                                                                                      if(a75==0){
                                                       if(a135==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a161 ==0)){
       if(a57 ==0){
               if(!(cf==false)){
                       if(!(input==false)){
                                                                      if(!(a122==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(!(a161 ==0)){
       if(a57 ==0){
               if(!(cf==false)){
                       if(input==false){
                               if(a176==0){
                                                                                      if(a75==0){
                                                       if(a135==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a161 ==0)){
       if(a57 ==0){
               if(!(cf==false)){
                       if(input==false){
                               if(!(a176==0)){
                                       if(!(a122==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a161 ==0)){
       if(a57 ==0){
               if(!(cf==false)){
                       if(input==false){
                               if(!(a176==0)){
                                       if(a122==0){
                                               if(a75==0){
                                                       if(a135==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a161 ==0)){
       if(a57 ==0){
               if(!(cf==false)){
                       if(input==false){
                               if(!(a176==0)){
                                       if(a122==0){
                                               if(!(a75==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a161 ==0)){
       if(a57 ==0){
               if(!(cf==false)){
                       if(input==false){
                               if(!(a176==0)){
                                       if(a122==0){
                                               if(a75==0){
                                                       if(!(a135==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a161 ==0) || (a57 ==0) && (cf==false) || (input==false) && (a176==0)|| (a122==0) && (a75==0) && (a135==0)) {
    	cf = false;
    	a47 = 7;
    	a135 = 1;
    	a131 = 5;
    	a15 = 1;
    	a175 = 2;
    	a53 = 1;
    	a155 = 6;
    	a138 = 1;
    	a118 = 0;
    	a122 = 1;
    	a37 = 2;
    	a176 = 1;
    	a6 = 0;
    	a85 = 10; 
    	System.out.println("S");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a57 ==0){
                      if(a135==0){
                       if(a37 ==0){
                                                                      if(a122==0){
                                               if(input==false){
                                                       if(cf==false){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a57 ==0)){
       if(!(a85 ==0)){
                                                                     if(!(a47 ==0)){
                                                                                                                                                                               }
                            }
                      }
if(!(a57 ==0)){
       if(a85 ==0){
               if(a135==0){
                       if(a37 ==0){
                                                                      if(a122==0){
                                               if(input==false){
                                                       if(cf==false){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a57 ==0)){
       if(a85 ==0){
               if(!(a135==0)){
                                                      if(!(a47 ==0)){
                                                                                                                                                                                          }
                                     }
                             }
                     }
if(!(a57 ==0)){
       if(a85 ==0){
               if(a135==0){
                       if(!(a37 ==0)){
                               if(!(a47 ==0)){
                                                                                                                                                                                                     }
                                              }
                                    }
                          }
                }
if(!(a57 ==0)){
       if(a85 ==0){
               if(a135==0){
                       if(!(a37 ==0)){
                               if(a47 ==0){
                                       if(a122==0){
                                               if(input==false){
                                                       if(cf==false){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a57 ==0)){
       if(a85 ==0){
               if(a135==0){
                       if(!(a37 ==0)){
                               if(a47 ==0){
                                       if(!(a122==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a57 ==0)){
       if(a85 ==0){
               if(a135==0){
                       if(!(a37 ==0)){
                               if(a47 ==0){
                                       if(a122==0){
                                               if(!(input==false)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a57 ==0)){
       if(a85 ==0){
               if(a135==0){
                       if(!(a37 ==0)){
                               if(a47 ==0){
                                       if(a122==0){
                                               if(input==false){
                                                       if(!(cf==false)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a57 ==0) || (a85 ==0) && (a135==0) && (a37 ==0) || (a47 ==0) && (a122==0) && (input==false) && (cf==false)){
    	cf = false;
    	a145 = 6;
    	a7 = 11; 
    	System.out.println("U");
    } 
}

private  void calculateOutputm144(boolean input) {
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a142 ==0){
       if(a184 ==0){
                                      if(a85 ==0){
                                                                      if(a103==0){
                                                                                                      if(cf==false){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a142 ==0)){
                      if(!(a142 ==0)){
                                                      if(!(a176==0)){
                                                                                      if(!(input==false)){
                                                                                                    }
                                     }
                             }
                     }
if(a142 ==0){
       if(!(a184 ==0)){
               if(a142 ==0){
                       if(a85 ==0){
                                                                      if(a103==0){
                                                                                                      if(cf==false){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(a142 ==0){
       if(!(a184 ==0)){
               if(a142 ==0){
                       if(a85 ==0){
                                                                      if(a103==0){
                                                                                                      if(cf==false){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(a142 ==0){
       if(!(a184 ==0)){
               if(a142 ==0){
                       if(!(a85 ==0)){
                               if(!(a176==0)){
                                                                                      if(!(input==false)){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(a142 ==0){
       if(!(a184 ==0)){
               if(a142 ==0){
                       if(!(a85 ==0)){
                               if(a176==0){
                                       if(a103==0){
                                                                                                      if(cf==false){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a142 ==0){
       if(!(a184 ==0)){
               if(a142 ==0){
                       if(!(a85 ==0)){
                               if(a176==0){
                                       if(!(a103==0)){
                                               if(!(input==false)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a142 ==0){
       if(!(a184 ==0)){
               if(a142 ==0){
                       if(!(a85 ==0)){
                               if(a176==0){
                                       if(!(a103==0)){
                                               if(input==false){
                                                       if(cf==false){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a142 ==0){
       if(!(a184 ==0)){
               if(a142 ==0){
                       if(!(a85 ==0)){
                               if(a176==0){
                                       if(!(a103==0)){
                                               if(input==false){
                                                       if(!(cf==false)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a142 ==0) && (a184 ==0) || (a142 ==0) && (a85 ==0) || (a176==0) && (a103==0) || (input==false) && (cf==false)) {
    	cf = false;
    	a82 = 0;
    	a138 = 0;
    	a5 = 0 ;
    	System.out.println("U");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(cf==false){
                      if(a135==0){
                       if(a175 ==0){
                                                                                                                     if(a163==0){
                                                       if(a53==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(cf==false)){
       if(!(input==false)){
                                                                     if(!(a84==0)){
                                       if(!(a171==0)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(cf==false)){
       if(input==false){
               if(a135==0){
                       if(a175 ==0){
                                                                                                                     if(a163==0){
                                                       if(a53==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(cf==false)){
       if(input==false){
               if(!(a135==0)){
                                                      if(!(a84==0)){
                                       if(!(a171==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(!(cf==false)){
       if(input==false){
               if(a135==0){
                       if(!(a175 ==0)){
                               if(!(a84==0)){
                                       if(!(a171==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(cf==false)){
       if(input==false){
               if(a135==0){
                       if(!(a175 ==0)){
                               if(a84==0){
                                                                                      if(a163==0){
                                                       if(a53==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(cf==false)){
       if(input==false){
               if(a135==0){
                       if(!(a175 ==0)){
                               if(!(a84==0)){
                                       if(a171==0){
                                               if(a163==0){
                                                       if(a53==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(cf==false)){
       if(input==false){
               if(a135==0){
                       if(!(a175 ==0)){
                               if(!(a84==0)){
                                       if(a171==0){
                                               if(!(a163==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(cf==false)){
       if(input==false){
               if(a135==0){
                       if(!(a175 ==0)){
                               if(!(a84==0)){
                                       if(a171==0){
                                               if(a163==0){
                                                       if(!(a53==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((cf==false) || (input==false)&& (a135==0) && (a175 ==0) || (a84==0) || (a171==0) && (a163==0) && (a53==0)) {
    	cf = false;
    	a75 = 0;
    	a85 = 11;
    	a15 = 0;
    	a37 = 3;
    	a53 = 0;
    	a155 = 7;
    	a122 = 0;
    	a176 = 0;
    	a142 = 9;
    	a103 = 0;
    	a135 = 0;
    	a47 = 8;
    	a161 = 5;
    	a131 = 6;
    	a105 = 11;
    	a175 = 3;
    	a84 = 0;
    	a184 = 4;
    	a163 = 0;
    	a138 = 0;
    	a57 = 2;
    	a171 = 0;
    	a44 = 11; 
    	System.out.println("S");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a57 ==0){
                      if(a171==0){
                       if(a15==0){
                                                                      if(cf==false){
                                                                                                      if(a131 ==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a57 ==0)){
       if(!(a155 ==0)){
                                                                     if(!(a37 ==0)){
                                                                                      if(!(input==false)){
                                                                                                    }
                                     }
                             }
                     }
if(!(a57 ==0)){
       if(a155 ==0){
               if(a171==0){
                       if(a15==0){
                                                                      if(cf==false){
                                                                                                      if(a131 ==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a57 ==0)){
       if(a155 ==0){
               if(!(a171==0)){
                                                      if(!(a37 ==0)){
                                                                                      if(!(input==false)){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(!(a57 ==0)){
       if(a155 ==0){
               if(a171==0){
                       if(!(a15==0)){
                               if(!(a37 ==0)){
                                                                                      if(!(input==false)){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a57 ==0)){
       if(a155 ==0){
               if(a171==0){
                       if(!(a15==0)){
                               if(a37 ==0){
                                       if(cf==false){
                                                                                                      if(a131 ==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a57 ==0)){
       if(a155 ==0){
               if(a171==0){
                       if(!(a15==0)){
                               if(a37 ==0){
                                       if(!(cf==false)){
                                               if(!(input==false)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a57 ==0)){
       if(a155 ==0){
               if(a171==0){
                       if(!(a15==0)){
                               if(a37 ==0){
                                       if(!(cf==false)){
                                               if(input==false){
                                                       if(a131 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a57 ==0)){
       if(a155 ==0){
               if(a171==0){
                       if(!(a15==0)){
                               if(a37 ==0){
                                       if(!(cf==false)){
                                               if(input==false){
                                                       if(!(a131 ==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a57 ==0) || (a155 ==0) && (a171==0) && (a15==0) || (a37 ==0) && (cf==false) || (input==false) && (a131 ==0)) {
    	cf = false;
    	a155 = 7;
    	a47 = 8;
    	a53 = 0;
    	a135 = 0;
    	a85 = 11;
    	a37 = 3;
    	a161 = 5;
    	a103 = 0;
    	a75 = 0;
    	a122 = 0;
    	a52 = 0;
    	a163 = 0;
    	a138 = 0;
    	a105 = 16; 
    	System.out.println("Z");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a142 ==0){
                      if(a131 ==0){
                                                      if(input==false){
                                                                                      if(a85 ==0){
                                                       if(a47 ==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a142 ==0)){
       if(!(a37 ==0)){
                                      if(!(cf==false)){
                                                                      if(!(a15==0)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(a142 ==0)){
       if(a37 ==0){
               if(a131 ==0){
                                                      if(input==false){
                                                                                      if(a85 ==0){
                                                       if(a47 ==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a142 ==0)){
       if(a37 ==0){
               if(!(a131 ==0)){
                       if(!(cf==false)){
                                                                      if(!(a15==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(!(a142 ==0)){
       if(a37 ==0){
               if(!(a131 ==0)){
                       if(cf==false){
                               if(input==false){
                                                                                      if(a85 ==0){
                                                       if(a47 ==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a142 ==0)){
       if(a37 ==0){
               if(!(a131 ==0)){
                       if(cf==false){
                               if(!(input==false)){
                                       if(!(a15==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a142 ==0)){
       if(a37 ==0){
               if(!(a131 ==0)){
                       if(cf==false){
                               if(!(input==false)){
                                       if(a15==0){
                                               if(a85 ==0){
                                                       if(a47 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a142 ==0)){
       if(a37 ==0){
               if(!(a131 ==0)){
                       if(cf==false){
                               if(!(input==false)){
                                       if(a15==0){
                                               if(!(a85 ==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a142 ==0)){
       if(a37 ==0){
               if(!(a131 ==0)){
                       if(cf==false){
                               if(!(input==false)){
                                       if(a15==0){
                                               if(a85 ==0){
                                                       if(!(a47 ==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a142 ==0) || (a37 ==0) && (a131 ==0) || (cf==false) && (input==false) || (a15==0) && (a85 ==0) && (a47 ==0)) {
    	cf = false;
    	a57 = 2;
    	a53 = 0;
    	a131 = 6;
    	a122 = 0;
    	a75 = 0;
    	a105 = 13;
    	a175 = 3;
    	a171 = 0;
    	a47 = 8;
    	a103 = 0;
    	a155 = 7;
    	a15 = 0;
    	a161 = 5;
    	a138 = 0;
    	a128 = 7; 
    	System.out.println("Y");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a131 ==0){
                      if(cf==false){
                                                      if(a75==0){
                                                                                      if(a184 ==0){
                                                       if(a103==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a131 ==0)){
       if(!(input==false)){
                                      if(!(a47 ==0)){
                                                                      if(!(a142 ==0)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(a131 ==0)){
       if(input==false){
               if(cf==false){
                                                      if(a75==0){
                                                                                      if(a184 ==0){
                                                       if(a103==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a131 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(!(a47 ==0)){
                                                                      if(!(a142 ==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(!(a131 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a47 ==0){
                               if(a75==0){
                                                                                      if(a184 ==0){
                                                       if(a103==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a131 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a47 ==0){
                               if(!(a75==0)){
                                       if(!(a142 ==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a131 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a47 ==0){
                               if(!(a75==0)){
                                       if(a142 ==0){
                                               if(a184 ==0){
                                                       if(a103==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a131 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a47 ==0){
                               if(!(a75==0)){
                                       if(a142 ==0){
                                               if(!(a184 ==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a131 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a47 ==0){
                               if(!(a75==0)){
                                       if(a142 ==0){
                                               if(a184 ==0){
                                                       if(!(a103==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a131 ==0) || (input==false) && (cf==false) || (a47 ==0) && (a75==0) || (a142 ==0) && (a184 ==0) && (a103==0)) {
    	cf = false;
    	a77 = 0;
    	a145 = 8; 
    	System.out.println("S");
    } 
}

private  void calculateOutputm121(boolean input) {
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a155 ==0){
                      if(a155 ==0){
                       if(a47 ==0){
                               if(a175 ==0){
                                                                                      if(cf==false){
                                                       if(a135==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a155 ==0)){
       if(!(a85 ==0)){
                                                                                                            if(!(input==false)){
                                                                                                                                        }
                            }
                      }
if(!(a155 ==0)){
       if(a85 ==0){
               if(!(a155 ==0)){
                                                                                             if(!(input==false)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(a155 ==0)){
       if(a85 ==0){
               if(!(a155 ==0)){
                                                                                             if(!(input==false)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(a155 ==0)){
       if(a85 ==0){
               if(!(a155 ==0)){
                                                                                             if(!(input==false)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(a155 ==0)){
       if(a85 ==0){
               if(!(a155 ==0)){
                                                                                             if(!(input==false)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(a155 ==0)){
       if(a85 ==0){
               if(!(a155 ==0)){
                                                                                             if(input==false){
                                               if(cf==false){
                                                       if(a135==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a155 ==0)){
       if(a85 ==0){
               if(!(a155 ==0)){
                                                                                             if(input==false){
                                               if(!(cf==false)){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(!(a155 ==0)){
       if(a85 ==0){
               if(!(a155 ==0)){
                                                                                             if(input==false){
                                               if(cf==false){
                                                       if(!(a135==0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
//*****************************************************************
    if((a155 ==0) || (a85 ==0) && (a155 ==0) && (a47 ==0) && (a175 ==0) || (input==false) && (cf==false) && (a135==0)) {
    	cf = false;
    	a131 = 6;
    	a142 = 9;
    	a175 = 3;
    	a138 = 1;
    	a57 = 2;
    	a75 = 0;
    	a6 = 0;
    	a184 = 3;
    	a37 = 3;
    	a47 = 8;
    	a84 = 0;
    	a85 = 10;
    	a163 = 0;
    	a171 = 0;
    	a15 = 0;
    	a155 = 7;
    	a122 = 0;
    	a161 = 5;
    	a176 = 0;
    	a199 = 16; 
    	System.out.println("W");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a85 ==0){
                      if(cf==false){
                       if(input==false){
                                                                      if(a175 ==0){
                                                                                            }
                                     }
                             }
                     }
if(!(a85 ==0)){
       if(!(a184 ==0)){
                                                                     if(!(a184 ==0)){
                                                                                      if(!(a122==0)){
                                             }
                                     }
                             }
                     }
if(!(a85 ==0)){
       if(a184 ==0){
               if(cf==false){
                       if(input==false){
                                                                      if(a175 ==0){
                                                                                                       }
                                              }
                                    }
                          }
                }
if(!(a85 ==0)){
       if(a184 ==0){
               if(!(cf==false)){
                                                      if(a184 ==0){
                                       if(a175 ==0){
                                                                                                       }
                                              }
                                    }
                          }
                }
if(!(a85 ==0)){
       if(a184 ==0){
               if(cf==false){
                       if(!(input==false)){
                               if(a184 ==0){
                                       if(a175 ==0){
                                                                                                                  }
                                                       }
                                           }
                               }
                   }
       }
if(!(a85 ==0)){
       if(a184 ==0){
               if(cf==false){
                       if(!(input==false)){
                               if(a184 ==0){
                                       if(a175 ==0){
                                                                                                                  }
                                                       }
                                           }
                               }
                   }
       }
if(!(a85 ==0)){
       if(a184 ==0){
               if(cf==false){
                       if(!(input==false)){
                               if(a184 ==0){
                                       if(!(a175 ==0)){
                                               if(!(a122==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a85 ==0)){
       if(a184 ==0){
               if(cf==false){
                       if(!(input==false)){
                               if(a184 ==0){
                                       if(!(a175 ==0)){
                                               if(a122==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
//*****************************************************************
    if((a85 ==0) || (a184 ==0) && (cf==false) && (input==false) || (a184 ==0) && (a175 ==0) || (a122==0)) {
    	cf = false;
    	a82 = 0;
    	a138 = 1;
    	a110 = 5; 
    	System.out.println("T");
    } 
}

private  void calculateOutputm122(boolean input) {
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(input==false){
                      if(a142 ==0){
                       if(a161 ==0){
                                                                 }
                            }
                      }
if(!(input==false)){
       if(!(cf==false)){
                                                                     if(!(a184 ==0)){
                                  }
                            }
                      }
if(!(input==false)){
       if(cf==false){
               if(a142 ==0){
                       if(a161 ==0){
                                                                            }
                                     }
                             }
                     }
if(!(input==false)){
       if(cf==false){
               if(!(a142 ==0)){
                                                      if(!(a184 ==0)){
                                             }
                                     }
                             }
                     }
if(!(input==false)){
       if(cf==false){
               if(a142 ==0){
                       if(!(a161 ==0)){
                               if(!(a184 ==0)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(input==false)){
       if(cf==false){
               if(a142 ==0){
                       if(!(a161 ==0)){
                               if(a184 ==0){
                                                        }
                                              }
                                    }
                          }
                }
//*****************************************************************
    if((input==false) || (cf==false) &&  (a142 ==0) &&  (a161 ==0) || (a184 ==0)) {
    	cf = false;
    	a85 = 11;
    	a5 = 0;
    	a37 = 2;
    	a57 = 1;
    	a171 = 0;
    	a176 = 0;
    	a135 = 0;
    	a138 = 0;
    	a161 = 4;
    	a47 = 7;
    	a75 = 0;
    	a163 = 0;
    	a84 = 0;
    	a103 = 0;
    	a6 = 0;
    	a155 = 6;
    	a175 = 2;
    	a184 = 3;
    	a131 = 5;
    	a122 = 0;
    	a15 = 0;
    	a53 = 0;
    	a142 = 8; 
    	System.out.println("U");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a37 ==0){
                      if(input==false){
                       if(cf==false){
                                  }
                            }
                      }
if(!(a37 ==0)){
       if(!(a37 ==0)){
                                                             }
                   }
if(!(a37 ==0)){
       if(!(a37 ==0)){
                                                             }
                   }
if(!(a37 ==0)){
       if(!(a37 ==0)){
                                                             }
                   }
if(!(a37 ==0)){
       if(!(a37 ==0)){
                                                             }
                   }
//*****************************************************************
    if((a37 ==0) || (a37 ==0) && (input==false) && (cf==false)) {
    	cf = false;
    	a6 = 1;
    	a184 = 4;
    	a175 = 3;
    	a163 = 1;
    	a176 = 1;
    	a135 = 1;
    	a161 = 5;
    	a138 = 1;
    	a155 = 7;
    	a122 = 1;
    	a131 = 6;
    	a103 = 1;
    	a57 = 2;
    	a142 = 9;
    	a53 = 1;
    	a37 = 3;
    	a17 = 12; 
    	System.out.println("Z");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(cf==false){
                      if(a175 ==0){
                       if(a122==0){
                                                                      if(a171==0){
                                                                                            }
                                     }
                             }
                     }
if(!(cf==false)){
       if(!(input==false)){
                                                                     if(!(a84==0)){
                                                                                      if(!(a57 ==0)){
                                             }
                                     }
                             }
                     }
if(!(cf==false)){
       if(input==false){
               if(a175 ==0){
                       if(a122==0){
                                                                      if(a171==0){
                                                                                                       }
                                              }
                                    }
                          }
                }
if(!(cf==false)){
       if(input==false){
               if(!(a175 ==0)){
                                                      if(!(a84==0)){
                                                                                      if(!(a57 ==0)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(cf==false)){
       if(input==false){
               if(a175 ==0){
                       if(!(a122==0)){
                               if(!(a84==0)){
                                                                                      if(!(a57 ==0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(cf==false)){
       if(input==false){
               if(a175 ==0){
                       if(!(a122==0)){
                               if(a84==0){
                                       if(a171==0){
                                                                                                                  }
                                                       }
                                           }
                               }
                   }
       }
if(!(cf==false)){
       if(input==false){
               if(a175 ==0){
                       if(!(a122==0)){
                               if(a84==0){
                                       if(!(a171==0)){
                                               if(!(a57 ==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(cf==false)){
       if(input==false){
               if(a175 ==0){
                       if(!(a122==0)){
                               if(a84==0){
                                       if(!(a171==0)){
                                               if(a57 ==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
//*****************************************************************
    if((cf==false) || (input==false) && (a175 ==0) && (a122==0) || (a84==0) && (a171==0) || (a57 ==0)) {
    	cf = false;
    	a6 = 1;
    	a75 = 0;
    	a53 = 0;
    	a122 = 0;
    	a135 = 0;
    	a138 = 0;
    	a131 = 5;
    	a85 = 10;
    	a142 = 8;
    	a84 = 0;
    	a176 = 0;
    	a47 = 7;
    	a171 = 0;
    	a184 = 3;
    	a44 = 12; 
    	System.out.println("V");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a135==0){
                                             if(cf==false){
                               if(a84==0){
                                       if(a85 ==0){
                                                                                            }
                                     }
                             }
                     }
if(!(a135==0)){
       if(!(a75==1)){
               if(!(input==false)){
                                                                                                                                            if(a85 ==0){
                                             }
                                     }
                             }
                     }
if(!(a135==0)){
       if(a75==1){
                                      if(cf==false){
                               if(a84==0){
                                       if(a85 ==0){
                                                                                                       }
                                              }
                                    }
                          }
                }
if(!(a135==0)){
       if(!(a75==1)){
               if(input==false){
                       if(cf==false){
                               if(a84==0){
                                       if(a85 ==0){
                                                                                                                  }
                                                       }
                                           }
                               }
                   }
       }
if(!(a135==0)){
       if(!(a75==1)){
               if(input==false){
                       if(!(cf==false)){
                                                                                                                     if(a85 ==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a135==0)){
       if(!(a75==1)){
               if(input==false){
                       if(cf==false){
                               if(!(a84==0)){
                                                                                      if(a85 ==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a135==0)){
       if(!(a75==1)){
               if(input==false){
                       if(cf==false){
                               if(a84==0){
                                       if(!(a85 ==0)){
                                               if(!(a85 ==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a135==0)){
       if(!(a75==1)){
               if(input==false){
                       if(cf==false){
                               if(a84==0){
                                       if(!(a85 ==0)){
                                               if(!(a85 ==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
//*****************************************************************
    if((a135==0) || (a75==1) || (input==false) && (cf==false)&& (a84==0) && (a85 ==0) || (a85 ==0)) {
    	cf = false;
    	a145 = 6;
    	a7 = 14; 
    	System.out.println("V");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a175 ==0){
                      if(input==false){
                                                                                             if(a131 ==0){
                                               if(a122==0){
                                                       if(a15==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a175 ==0)){
       if(!(a155 ==0)){
                                      if(!(cf==false)){
                               if(!(a184 ==0)){
                                                                                                                                                                                          }
                                     }
                             }
                     }
if(!(a175 ==0)){
       if(a155 ==0){
               if(input==false){
                                                                                             if(a131 ==0){
                                               if(a122==0){
                                                       if(a15==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a175 ==0)){
       if(a155 ==0){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(!(a184 ==0)){
                                                                                                                                                                                                     }
                                              }
                                    }
                          }
                }
if(!(a175 ==0)){
       if(a155 ==0){
               if(!(input==false)){
                       if(cf==false){
                                                                      if(a131 ==0){
                                               if(a122==0){
                                                       if(a15==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a175 ==0)){
       if(a155 ==0){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(a184 ==0){
                                       if(a131 ==0){
                                               if(a122==0){
                                                       if(a15==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a175 ==0)){
       if(a155 ==0){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(a184 ==0){
                                       if(!(a131 ==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a175 ==0)){
       if(a155 ==0){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(a184 ==0){
                                       if(a131 ==0){
                                               if(!(a122==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a175 ==0)){
       if(a155 ==0){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(a184 ==0){
                                       if(a131 ==0){
                                               if(a122==0){
                                                       if(!(a15==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a175 ==0) || (a155 ==0) && (input==false) || (cf==false) || (a184 ==0) && (a131 ==0) && (a122==0) && (a15==0)) {
    	cf = false;
    	a138 = 0;
    	a82 = 0;
    	a119 = 1; 
    	System.out.println("U");
    } 
}

private  void calculateOutputm146(boolean input) {
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a155 ==0){
                      if(input==false){
                                                      if(a53==0){
                                                                                      if(a47 ==0){
                                                       if(!(a131 ==0)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a155 ==0)){
       if(!(cf==false)){
                                      if(!(a142 ==0)){
                                                                      if(!(a131 ==0)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(a155 ==0)){
       if(cf==false){
               if(input==false){
                                                      if(a53==0){
                                                                                      if(a47 ==0){
                                                       if(!(a131 ==0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a155 ==0)){
       if(cf==false){
               if(!(input==false)){
                       if(!(a142 ==0)){
                                                                      if(!(a131 ==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(!(a155 ==0)){
       if(cf==false){
               if(!(input==false)){
                       if(a142 ==0){
                               if(a53==0){
                                                                                      if(a47 ==0){
                                                       if(!(a131 ==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a155 ==0)){
       if(cf==false){
               if(!(input==false)){
                       if(a142 ==0){
                               if(!(a53==0)){
                                       if(!(a131 ==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a155 ==0)){
       if(cf==false){
               if(!(input==false)){
                       if(a142 ==0){
                               if(!(a53==0)){
                                       if(a131 ==0){
                                               if(a47 ==0){
                                                       if(a131 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a155 ==0)){
       if(cf==false){
               if(!(input==false)){
                       if(a142 ==0){
                               if(!(a53==0)){
                                       if(a131 ==0){
                                               if(!(a47 ==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a155 ==0)){
       if(cf==false){
               if(!(input==false)){
                       if(a142 ==0){
                               if(!(a53==0)){
                                       if(a131 ==0){
                                               if(a47 ==0){
                                                       if(a131 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a155 ==0) || (cf==false) && (input==false) || (a142 ==0) && (a53==0) || (a131 ==0) && (a47 ==0) && (a131 ==0)){
    	cf = false;
    	a82 =0;
    	a138 =0;
    	a110 = 4; 
    	System.out.println("V");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a131 ==0){
       if(a37 ==0){
                                      if(input==false){
                                                                      if(a47 ==0){
                                               if(a85 ==0){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(!(a131 ==0)){
                      if(!(cf==false)){
                                                      if(!(a175 ==0)){
                                                                                                                                             if(!(a163==0)){
                                             }
                                     }
                             }
                     }
if(a131 ==0){
       if(!(a37 ==0)){
               if(!(cf==false)){
                                                      if(!(a175 ==0)){
                                                                                                                                             if(!(a163==0)){
                                                        }
                                              }
                                    }
                          }
                }
if(a131 ==0){
       if(!(a37 ==0)){
               if(cf==false){
                       if(input==false){
                                                                      if(a47 ==0){
                                               if(a85 ==0){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(a131 ==0){
       if(!(a37 ==0)){
               if(cf==false){
                       if(!(input==false)){
                               if(!(a175 ==0)){
                                                                                                                                             if(!(a163==0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(a131 ==0){
       if(!(a37 ==0)){
               if(cf==false){
                       if(!(input==false)){
                               if(a175 ==0){
                                       if(a47 ==0){
                                               if(a85 ==0){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a131 ==0){
       if(!(a37 ==0)){
               if(cf==false){
                       if(!(input==false)){
                               if(a175 ==0){
                                       if(!(a47 ==0)){
                                                                                                      if(!(a163==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a131 ==0){
       if(!(a37 ==0)){
               if(cf==false){
                       if(!(input==false)){
                               if(a175 ==0){
                                       if(a47 ==0){
                                               if(!(a85 ==0)){
                                                       if(!(a163==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a131 ==0){
       if(!(a37 ==0)){
               if(cf==false){
                       if(!(input==false)){
                               if(a175 ==0){
                                       if(a47 ==0){
                                               if(!(a85 ==0)){
                                                       if(a163==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a131 ==0) && (a37 ==0) || (cf==false) && (input==false) || (a175 ==0) && (a47 ==0) && (a85 ==0) || (a163==0)){
    	cf = false;
    	a161 = 5;
    	a171 =1;
    	a175 = 3;
    	a138 =1;
    	a155 = 7;
    	a131 = 6;
    	a176 =1;
    	a103 =1;
    	a47 = 8;
    	a135 =1;
    	a163 =1;
    	a184 = 4;
    	a75 =1;
    	a52 =0;
    	a122 =1;
    	a15 =1;
    	a53 =1;
    	a37 = 3;
    	a85 = 11;
    	a142 = 9;
    	a105 = 16; 
    	System.out.println("V");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a47 ==0){
                      if(a175 ==0){
                                                      if(a155 ==0){
                                                                                      if(input==false){
                                                       if(cf==false){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a47 ==0)){
       if(!(a122==0)){
                                      if(!(a103==0)){
                                                                      if(!(a142 ==00)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(a47 ==0)){
       if(a122==0){
               if(a175 ==0){
                                                      if(a155 ==0){
                                                                                      if(input==false){
                                                       if(cf==false){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a47 ==0)){
       if(a122==0){
               if(!(a175 ==0)){
                       if(!(a103==0)){
                                                                      if(!(a142 ==00)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(!(a47 ==0)){
       if(a122==0){
               if(!(a175 ==0)){
                       if(a103==0){
                               if(a155 ==0){
                                                                                      if(input==false){
                                                       if(cf==false){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a47 ==0)){
       if(a122==0){
               if(!(a175 ==0)){
                       if(a103==0){
                               if(!(a155 ==0)){
                                       if(!(a142 ==00)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a47 ==0)){
       if(a122==0){
               if(!(a175 ==0)){
                       if(a103==0){
                               if(!(a155 ==0)){
                                       if(a142 ==00){
                                               if(input==false){
                                                       if(cf==false){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a47 ==0)){
       if(a122==0){
               if(!(a175 ==0)){
                       if(a103==0){
                               if(!(a155 ==0)){
                                       if(a142 ==00){
                                               if(!(input==false)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a47 ==0)){
       if(a122==0){
               if(!(a175 ==0)){
                       if(a103==0){
                               if(!(a155 ==0)){
                                       if(a142 ==00){
                                               if(input==false){
                                                       if(!(cf==false)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a47 ==0) || (a122==0) && (a175 ==0) || (a103==0) && (a155 ==0) || (a142 ==00) && (input==false) && (cf==false)){
    	cf = false;
    	a176 =1;
    	a163 =1;
    	a85 = 11;
    	a15 =1;
    	a52 =0;
    	a47 = 8;
    	a142 = 9;
    	a131 = 6;
    	a161 = 5;
    	a138 =1;
    	a135 =1;
    	a103 =1;
    	a175 = 3;
    	a171 =1;
    	a75 =1;
    	a53 =1;
    	a184 = 4;
    	a155 = 7;
    	a122 =1;
    	a37 = 3;
    	a105 = 16; 
    	System.out.println("V");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a53==0){
                      if(a142 ==0){
                                                                                             if(a122==0){
                                               if(a163==0){
                                                                                                    }
                                     }
                             }
                     }
if(!(a53==0)){
       if(!(a184 ==0)){
                                      if(!(cf==false)){
                               if(!(input==false)){
                                                                                                                                             if(!(a57 ==0)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a53==0)){
       if(a184 ==0){
               if(a142 ==0){
                                                                                             if(a122==0){
                                               if(a163==0){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(!(a53==0)){
       if(a184 ==0){
               if(!(a142 ==0)){
                       if(!(cf==false)){
                               if(!(input==false)){
                                                                                                                                             if(!(a57 ==0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a53==0)){
       if(a184 ==0){
               if(!(a142 ==0)){
                       if(cf==false){
                                                                      if(a122==0){
                                               if(a163==0){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a53==0)){
       if(a184 ==0){
               if(!(a142 ==0)){
                       if(!(cf==false)){
                               if(input==false){
                                       if(a122==0){
                                               if(a163==0){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a53==0)){
       if(a184 ==0){
               if(!(a142 ==0)){
                       if(!(cf==false)){
                               if(input==false){
                                       if(!(a122==0)){
                                                                                                      if(!(a57 ==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a53==0)){
       if(a184 ==0){
               if(!(a142 ==0)){
                       if(!(cf==false)){
                               if(input==false){
                                       if(a122==0){
                                               if(!(a163==0)){
                                                       if(!(a57 ==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a53==0)){
       if(a184 ==0){
               if(!(a142 ==0)){
                       if(!(cf==false)){
                               if(input==false){
                                       if(a122==0){
                                               if(!(a163==0)){
                                                       if(a57 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a53==0) || (a184 ==0) && (a142 ==0) || (cf==false) || (input==false) && (a122==0) && (a163==0) || (a57 ==0)){
    	cf = false;
    	a145 = 6;
    	a7 = 8; 
    	System.out.println("U");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a184 ==0){
                                                                            if(a155 ==0){
                                       if(input==false){
                                               if(cf==false){
                                                                                                    }
                                     }
                             }
                     }
if(!(a184 ==0)){
       if(!(a131 ==0)){
               if(!(a161 ==0)){
                       if(!(a85 ==0)){
                                                                                                                                                                            if(!(a53==0)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a184 ==0)){
       if(a131 ==0){
                                                                     if(a155 ==0){
                                       if(input==false){
                                               if(cf==false){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(!(a184 ==0)){
       if(!(a131 ==0)){
               if(a161 ==0){
                                                      if(a155 ==0){
                                       if(input==false){
                                               if(cf==false){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a184 ==0)){
       if(!(a131 ==0)){
               if(!(a161 ==0)){
                       if(a85 ==0){
                               if(a155 ==0){
                                       if(input==false){
                                               if(cf==false){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a184 ==0)){
       if(!(a131 ==0)){
               if(!(a161 ==0)){
                       if(a85 ==0){
                               if(!(a155 ==0)){
                                                                                                                                             if(!(a53==0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a184 ==0)){
       if(!(a131 ==0)){
               if(!(a161 ==0)){
                       if(a85 ==0){
                               if(a155 ==0){
                                       if(!(input==false)){
                                                                                                      if(!(a53==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a184 ==0)){
       if(!(a131 ==0)){
               if(!(a161 ==0)){
                       if(a85 ==0){
                               if(a155 ==0){
                                       if(input==false){
                                               if(!(cf==false)){
                                                       if(!(a53==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a184 ==0)){
       if(!(a131 ==0)){
               if(!(a161 ==0)){
                       if(a85 ==0){
                               if(a155 ==0){
                                       if(input==false){
                                               if(!(cf==false)){
                                                       if(a53==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a184 ==0) || (a131 ==0) || (a161 ==0) || (a85 ==0) && (a155 ==0) && (input==false) && (cf==false) || (a53==0)){
    	cf = false;
    	a138 =1;
    	a171 =1;
    	a52 =0;
    	a176 =1;
    	a155 = 7;
    	a175 = 3;
    	a131 = 6;
    	a122 =1;
    	a161 = 5;
    	a47 = 8;
    	a75 =1;
    	a53 =1;
    	a37 = 3;
    	a163 =1;
    	a184 = 4;
    	a103 =1;
    	a135 =1;
    	a142 = 9;
    	a85 = 11;
    	a15 =1;
    	a105 = 16; 
    	System.out.println("V");
    } 
}

private  void calculateOutputm100(boolean input) {
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a131 ==0){
                      if(cf==false){
                                                      if(a75==0){
                                                                                      if(a75==0){
                                                       if(a142 ==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a131 ==0)){
       if(!(input==false)){
                                      if(!(a84==0)){
                                                                      if(!(a84==0)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(a131 ==0)){
       if(input==false){
               if(cf==false){
                                                      if(a75==0){
                                                                                      if(a75==0){
                                                       if(a142 ==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a131 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(!(a84==0)){
                                                                      if(!(a84==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(!(a131 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a84==0){
                               if(a75==0){
                                                                                      if(a75==0){
                                                       if(a142 ==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a131 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a84==0){
                               if(!(a75==0)){
                                       if(a84==0){
                                               if(!(a75==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a131 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a84==0){
                               if(!(a75==0)){
                                       if(a84==0){
                                               if(!(a75==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a131 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a84==0){
                               if(!(a75==0)){
                                       if(a84==0){
                                               if(!(a75==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a131 ==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a84==0){
                               if(!(a75==0)){
                                       if(a84==0){
                                               if(!(a75==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
//*****************************************************************
    if((a131 ==0) || (input==false) && (cf==false) || (a84==0) && (a75==0) || (a84==0) && (a75==0) && (a142 ==0)){
    	cf = false;
    	a138 =1;
    	a57 = 3;
    	a184 = 4;
    	a84 =0;
    	a53 =1;
    	a52 =0;
    	a103 =1;
    	a85 = 11;
    	a135 =1;
    	a105 = 16; 
    	System.out.println("V");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a57 ==0){
                      if(a47 ==0){
                                                      if(input==false){
                                                                                      if(!(a142 ==0)){
                                                       if(!(a75==0)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a57 ==0)){
       if(!(a142 ==0)){
                                      if(!(cf==false)){
                                                                      if(!(a75==0)){
                                                                                                      if(!(a75==0)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a57 ==0)){
       if(a142 ==0){
               if(a47 ==0){
                                                      if(input==false){
                                                                                      if(a142 ==0){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(!(a57 ==0)){
       if(a142 ==0){
               if(!(a47 ==0)){
                       if(!(cf==false)){
                                                                      if(!(a75==0)){
                                                                                                      if(!(a75==0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a57 ==0)){
       if(a142 ==0){
               if(!(a47 ==0)){
                       if(cf==false){
                               if(input==false){
                                                                                      if(a142 ==0){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a57 ==0)){
       if(a142 ==0){
               if(!(a47 ==0)){
                       if(cf==false){
                               if(!(input==false)){
                                       if(!(a75==0)){
                                                                                                      if(!(a75==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a57 ==0)){
       if(a142 ==0){
               if(!(a47 ==0)){
                       if(cf==false){
                               if(!(input==false)){
                                       if(a75==0){
                                               if(a142 ==0){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a57 ==0)){
       if(a142 ==0){
               if(!(a47 ==0)){
                       if(cf==false){
                               if(!(input==false)){
                                       if(a75==0){
                                               if(a142 ==0){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a57 ==0)){
       if(a142 ==0){
               if(!(a47 ==0)){
                       if(cf==false){
                               if(!(input==false)){
                                       if(a75==0){
                                               if(a142 ==0){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
//*****************************************************************
    if((a57 ==0) || (a142 ==0) && (a47 ==0) || (cf==false) && (input==false) || (a75==0) && (a142 ==0) || (a75==0)){
    	cf = false;
    	a84 =0;
    	a145 = 2;
    	a155 = 8;
    	a176 =0;
    	a75 =0;
    	a47 = 9;
    	a163 =0;
    	a57 = 3;
    	a131 = 7;
    	a37 = 4;
    	a138 =0;
    	a175 = 2;
    	a122 =0;
    	a15 =0;
    	a171 =0;
    	a142 = 10;
    	a161 = 4;
    	a3 = 17; 
    	System.out.println("T");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a171==0){
                      if(cf==false){
                                                      if(!(a75==0)){
                                       if(!(a161 ==0)){
                                                                                                      if(!(a161 ==0)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a171==0)){
       if(!(input==false)){
                                      if(!(a75==0)){
                                                                      if(!(a161 ==0)){
                                                                                                      if(!(a161 ==0)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a171==0)){
       if(input==false){
               if(cf==false){
                                                      if(!(a75==0)){
                                       if(!(a161 ==0)){
                                                                                                      if(!(a161 ==0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a171==0)){
       if(input==false){
               if(!(cf==false)){
                       if(!(a75==0)){
                                                                      if(!(a161 ==0)){
                                                                                                      if(!(a161 ==0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a171==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a75==0){
                               if(a75==0){
                                                                                      if(a176==0){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a171==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a75==0){
                               if(a75==0){
                                                                                      if(a176==0){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a171==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a75==0){
                               if(a75==0){
                                                                                      if(a176==0){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a171==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a75==0){
                               if(a75==0){
                                                                                      if(!(a176==0)){
                                                       if(a161 ==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a171==0)){
       if(input==false){
               if(!(cf==false)){
                       if(a75==0){
                               if(a75==0){
                                                                                      if(!(a176==0)){
                                                       if(a161 ==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
//*****************************************************************
    if((a171==0) || (input==false) && (cf==false) || (a75==0) && (a75==0) || (a161 ==0) && (a176==0) || (a161 ==0)){
    	cf = false;
    	a135 =1;
    	a103 =1;
    	a171 =0;
    	a85 = 11;
    	a53 =1;
    	a105 = 10;
    	a184 = 4;
    	a138 =1;
    	a161 = 4;
    	a112 = 9; 
    	System.out.println("U");
    } 
}

private  void calculateOutputm81(boolean input) {
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a184 ==0){
                      if(a15==0){
                                                      if(a75==0){
                                                                                      if(cf==false){
                                                                                                    }
                                     }
                             }
                     }
if(!(a184 ==0)){
       if(!(a176==0)){
                                      if(!(a171==0)){
                                                                      if(!(input==false)){
                                                                                                      if(!(a85 ==0)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a184 ==0)){
       if(a176==0){
               if(a15==0){
                                                      if(a75==0){
                                                                                      if(cf==false){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(!(a184 ==0)){
       if(a176==0){
               if(!(a15==0)){
                       if(!(a171==0)){
                                                                      if(!(input==false)){
                                                                                                      if(!(a85 ==0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a184 ==0)){
       if(a176==0){
               if(!(a15==0)){
                       if(a171==0){
                               if(a75==0){
                                                                                      if(cf==false){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a184 ==0)){
       if(a176==0){
               if(!(a15==0)){
                       if(a171==0){
                               if(!(a75==0)){
                                       if(!(input==false)){
                                                                                                      if(!(a85 ==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a184 ==0)){
       if(a176==0){
               if(!(a15==0)){
                       if(a171==0){
                               if(!(a75==0)){
                                       if(input==false){
                                               if(cf==false){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a184 ==0)){
       if(a176==0){
               if(!(a15==0)){
                       if(a171==0){
                               if(!(a75==0)){
                                       if(input==false){
                                               if(!(cf==false)){
                                                       if(!(a85 ==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a184 ==0)){
       if(a176==0){
               if(!(a15==0)){
                       if(a171==0){
                               if(!(a75==0)){
                                       if(input==false){
                                               if(!(cf==false)){
                                                       if(a85 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a184 ==0) || (a176==0) && (a15==0) || (a171==0) && (a75==0) || (input==false) && (cf==false) || (a85 ==0)){
    	cf = false;
    	a15 =0;
    	a176 =0;
    	a171 =0;
    	a82 =1;
    	a103 =0;
    	a85 = 12;
    	a161 = 6;
    	a184 = 5;
    	a138 =0;
    	a131 = 7;
    	a163 =0;
    	a175 = 4;
    	a53 =0;
    	a135 =0;
    	a7 = 11; 
    	System.out.println("V");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a184 ==0){
                                             if(!(a131 ==0)){
                               if(!(a103==0)){
                                                                                                                                             if(!(a171==0)){
                                             }
                                     }
                             }
                     }
if(!(a184 ==0)){
       if(!(a37 ==0)){
               if(!(a131 ==0)){
                                                      if(!(a103==0)){
                                                                                                                                             if(!(a171==0)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a184 ==0)){
       if(a37 ==0){
                                      if(!(a131 ==0)){
                               if(!(a103==0)){
                                                                                                                                             if(!(a171==0)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a184 ==0)){
       if(!(a37 ==0)){
               if(a131 ==0){
                       if(a131 ==0){
                                                                      if(cf==false){
                                               if(input==false){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a184 ==0)){
       if(!(a37 ==0)){
               if(a131 ==0){
                       if(a131 ==0){
                                                                      if(cf==false){
                                               if(input==false){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a184 ==0)){
       if(!(a37 ==0)){
               if(a131 ==0){
                       if(a131 ==0){
                                                                      if(cf==false){
                                               if(input==false){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a184 ==0)){
       if(!(a37 ==0)){
               if(a131 ==0){
                       if(a131 ==0){
                                                                      if(!(cf==false)){
                                                                                                      if(!(a171==0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a184 ==0)){
       if(!(a37 ==0)){
               if(a131 ==0){
                       if(a131 ==0){
                                                                      if(cf==false){
                                               if(!(input==false)){
                                                       if(!(a171==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a184 ==0)){
       if(!(a37 ==0)){
               if(a131 ==0){
                       if(a131 ==0){
                                                                      if(cf==false){
                                               if(!(input==false)){
                                                       if(a171==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
//*****************************************************************
    if((a184 ==0) || (a37 ==0) || (a131 ==0) && (a131 ==0) || (a103==0) && (cf==false) && (input==false) || (a171==0)){
    	cf = false;
    	a184 = 5;
    	a145 = 2;
    	a15 =0;
    	a175 = 4;
    	a53 =0;
    	a131 = 7;
    	a47 = 9;
    	a155 = 8;
    	a171 =0;
    	a135 =0;
    	a75 =0;
    	a37 = 4;
    	a103 =0;
    	a138 =0;
    	a85 = 12;
    	a163 =0;
    	a161 = 6;
    	a176 =0;
    	a122 =0;
    	a142 = 10;
    	a3 = 10; 
    	System.out.println("V");
    } 
}

private  void calculateOutputm56(boolean input) {
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a15==0){
                      if(a37 == 0){
                                                                                                                                            if(input==false){
                                                                                         }
                            }
                      }
if(!(a15==0)){
       if(!(a57 == 0)){
                                      if(!(a142 == 0)){
                               if(!(a85 == 0)){
                                       if(!(cf==false)){
                                                                                                      if(!(a84==0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a15==0)){
       if(a57 == 0){
               if(a37 == 0){
                                                                                                                                            if(input==false){
                                                                                                    }
                                     }
                             }
                     }
if(!(a15==0)){
       if(a57 == 0){
               if(!(a37 == 0)){
                       if(!(a142 == 0)){
                               if(!(a85 == 0)){
                                       if(!(cf==false)){
                                                                                                      if(!(a84==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a15==0)){
       if(a57 == 0){
               if(!(a37 == 0)){
                       if(a142 == 0){
                                                                                                                     if(input==false){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(!(a15==0)){
       if(a57 == 0){
               if(!(a37 == 0)){
                       if(!(a142 == 0)){
                               if(a85 == 0){
                                                                                      if(input==false){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a15==0)){
       if(a57 == 0){
               if(!(a37 == 0)){
                       if(!(a142 == 0)){
                               if(!(a85 == 0)){
                                       if(cf==false){
                                               if(input==false){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a15==0)){
       if(a57 == 0){
               if(!(a37 == 0)){
                       if(!(a142 == 0)){
                               if(!(a85 == 0)){
                                       if(cf==false){
                                               if(!(input==false)){
                                                       if(!(a84==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a15==0)){
       if(a57 == 0){
               if(!(a37 == 0)){
                       if(!(a142 == 0)){
                               if(!(a85 == 0)){
                                       if(cf==false){
                                               if(!(input==false)){
                                                       if(a84==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a15==0) || (a57 == 0) && (a37 == 0) || (a142 == 0) || (a85 == 0) || (cf==false) && (input==false) || (a84==0)){
    	cf = false;
    	a184 = 5;
    	a122 =0;
    	a84 =0;
    	a57 = 3;
    	a176 =0;
    	a145 = 3;
    	a75 =0;
    	a175 = 4;
    	a53 =0;
    	a138 =0;
    	a131 = 7;
    	a37 = 4;
    	a85 = 12;
    	a36 = 17; 
    	System.out.println("Z");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a176==0){
                                             if(a135==0){
                                                                                                                     if(a155 == 7){
                                                       if(a15==0){
                                             }
                                     }
                             }
                     }
if(!(a176==0)){
       if(!(input==false)){
               if(!(cf==false)){
                                                      if(!(a84==0)){
                                       if(!(a47 == 8)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(!(a176==0)){
       if(input==false){
                                      if(a135==0){
                                                                                                                     if(a155 == 7){
                                                       if(a15==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a176==0)){
       if(!(input==false)){
               if(cf==false){
                       if(a135==0){
                                                                                                                     if(a155 == 7){
                                                       if(a15==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a176==0)){
       if(!(input==false)){
               if(cf==false){
                       if(!(a135==0)){
                               if(!(a84==0)){
                                       if(!(a47 == 8)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a176==0)){
       if(!(input==false)){
               if(cf==false){
                       if(!(a135==0)){
                               if(a84==0){
                                                                                      if(a155 == 7){
                                                       if(a15==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a176==0)){
       if(!(input==false)){
               if(cf==false){
                       if(!(a135==0)){
                               if(!(a84==0)){
                                       if(a47 == 8){
                                               if(a155 == 7){
                                                       if(a15==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a176==0)){
       if(!(input==false)){
               if(cf==false){
                       if(!(a135==0)){
                               if(!(a84==0)){
                                       if(a47 == 8){
                                               if(!(a155 == 7)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a176==0)){
       if(!(input==false)){
               if(cf==false){
                       if(!(a135==0)){
                               if(!(a84==0)){
                                       if(a47 == 8){
                                               if(a155 == 7){
                                                       if(!(a15==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a176==0) || (input==false) || (cf==false) && (a135==0) || (a84==0) || (a47 == 8) && (a155 == 7) && (a15==0)){
    	cf = false;
    	a175 = 2;
    	a53 =0;
    	a84 =0;
    	a163 =0;
    	a155 = 6;
    	a176 =0;
    	a47 = 7;
    	a103 =0;
    	a142 = 8;
    	a15 =0;
    	a131 = 5;
    	a122 =0;
    	a118 =0;
    	a171 =0;
    	a57 = 1;
    	a75 =0;
    	a6 =0;
    	a37 = 2;
    	a138 =0;
    	a135 =0;
    	a85 = 10;
    	a184 = 3; 
    	System.out.println("Z");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a103==0){
                      if(input==false){
                                                                                                                                            if(a122==0){
                                                       if(a175 == 3){
                                             }
                                     }
                             }
                     }
if(!(a103==0)){
       if(!(a53==0)){
                                      if(!(cf==false)){
                               if(!(a176==0)){
                                       if(!(a15==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(!(a103==0)){
       if(a53==0){
               if(input==false){
                                                                                                                                            if(a122==0){
                                                       if(a175 == 3){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a103==0)){
       if(a53==0){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(!(a176==0)){
                                       if(!(a15==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a103==0)){
       if(a53==0){
               if(!(input==false)){
                       if(cf==false){
                                                                                                                     if(a122==0){
                                                       if(a175 == 3){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a103==0)){
       if(a53==0){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(a176==0){
                                                                                      if(a122==0){
                                                       if(a175 == 3){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a103==0)){
       if(a53==0){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(!(a176==0)){
                                       if(a15==0){
                                               if(a122==0){
                                                       if(a175 == 3){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a103==0)){
       if(a53==0){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(!(a176==0)){
                                       if(a15==0){
                                               if(!(a122==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a103==0)){
       if(a53==0){
               if(!(input==false)){
                       if(!(cf==false)){
                               if(!(a176==0)){
                                       if(a15==0){
                                               if(a122==0){
                                                       if(!(a175 == 3)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a103==0) || (a53==0) && (input==false) || (cf==false) || (a176==0) || (a15==0) && (a122==0) && (a175 == 3)){
    	cf = false;
    	a155 = 6;
    	a176 =0;
    	a103 =0;
    	a15 =0;
    	a163 =0;
    	a138 =0;
    	a175 = 2;
    	a135 =0;
    	a150 =0;
    	a85 = 10;
    	a142 = 8;
    	a53 =0;
    	a122 =0;
    	a6 =0;
    	a47 = 7; 
    	System.out.println("U");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a184 == 4){
                      if(a131 == 6){
                                                                                             if(!(a175 == 3)){
                                                                                                      if(!(cf==false)){
                                             }
                                     }
                             }
                     }
if(!(a184 == 4)){
       if(!(a103==0)){
                                      if(!(a176==0)){
                               if(!(a175 == 3)){
                                                                                                                                             if(!(cf==false)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a184 == 4)){
       if(a103==0){
               if(a131 == 6){
                                                                                             if(!(a175 == 3)){
                                                                                                      if(!(cf==false)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a184 == 4)){
       if(a103==0){
               if(!(a131 == 6)){
                       if(!(a176==0)){
                               if(!(a175 == 3)){
                                                                                                                                             if(!(cf==false)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a184 == 4)){
       if(a103==0){
               if(!(a131 == 6)){
                       if(a176==0){
                                                                      if(!(a175 == 3)){
                                                                                                      if(!(cf==false)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a184 == 4)){
       if(a103==0){
               if(!(a131 == 6)){
                       if(!(a176==0)){
                               if(a175 == 3){
                                       if(a175 == 3){
                                               if(input==false){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a184 == 4)){
       if(a103==0){
               if(!(a131 == 6)){
                       if(!(a176==0)){
                               if(a175 == 3){
                                       if(a175 == 3){
                                               if(input==false){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a184 == 4)){
       if(a103==0){
               if(!(a131 == 6)){
                       if(!(a176==0)){
                               if(a175 == 3){
                                       if(a175 == 3){
                                               if(!(input==false)){
                                                       if(!(cf==false)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a184 == 4)){
       if(a103==0){
               if(!(a131 == 6)){
                       if(!(a176==0)){
                               if(a175 == 3){
                                       if(a175 == 3){
                                               if(!(input==false)){
                                                       if(cf==false){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a184 == 4) || (a103==0) && (a131 == 6) || (a176==0) || (a175 == 3) && (a175 == 3) && (input==false) || (cf==false)) {
    	cf = false;
    	a161 = 5;
    	a105 = 13;
    	a128 = 4; 
    	System.out.println("Z");
    } 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a37 == 3){
       if(a122==0){
                                      if(cf==false){
                                                                      if(a142 == 9){
                                               if(a75==0){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(!(a37 == 3)){
                      if(!(input==false)){
                                                      if(!(a135==0)){
                                                                                                                                             if(!(a57 == 2)){
                                             }
                                     }
                             }
                     }
if(a37 == 3){
       if(!(a122==0)){
               if(!(input==false)){
                                                      if(!(a135==0)){
                                                                                                                                             if(!(a57 == 2)){
                                                        }
                                              }
                                    }
                          }
                }
if(a37 == 3){
       if(!(a122==0)){
               if(input==false){
                       if(cf==false){
                                                                      if(a142 == 9){
                                               if(a75==0){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(a37 == 3){
       if(!(a122==0)){
               if(input==false){
                       if(!(cf==false)){
                               if(!(a135==0)){
                                                                                                                                             if(!(a57 == 2)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(a37 == 3){
       if(!(a122==0)){
               if(input==false){
                       if(!(cf==false)){
                               if(a135==0){
                                       if(a142 == 9){
                                               if(a75==0){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a37 == 3){
       if(!(a122==0)){
               if(input==false){
                       if(!(cf==false)){
                               if(a135==0){
                                       if(!(a142 == 9)){
                                                                                                      if(!(a57 == 2)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a37 == 3){
       if(!(a122==0)){
               if(input==false){
                       if(!(cf==false)){
                               if(a135==0){
                                       if(a142 == 9){
                                               if(!(a75==0)){
                                                       if(!(a57 == 2)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a37 == 3){
       if(!(a122==0)){
               if(input==false){
                       if(!(cf==false)){
                               if(a135==0){
                                       if(a142 == 9){
                                               if(!(a75==0)){
                                                       if(a57 == 2){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
    if((a37 == 3) && (a122==0) || (input==false) && (cf==false) || (a135==0) && (a142 == 9) && (a75==0) || (a57 == 2)) {
    	cf = false;
    	a105 = 15;
    	a161 = 5;
    	a7 = 8; 
    	System.out.println("U");
    } 
}


private  void calculateOutputm45(boolean input) {
//*********************************************************************
//Transformation for predictes containing only AND operator
if(a122==0){
       if(a53==0){
               if(a142 ==0){
                       if(a75==0){
                               if(a37 ==0){
                                       if(cf==false){
                                               if(input==false){
                                                       if(a131 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a122==0)){
       if(a53==0){
               if(a142 ==0){
                       if(a75==0){
                               if(a37 ==0){
                                       if(cf==false){
                                               if(input==false){
                                                       if(a131 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a122==0){
       if(!(a53==0)){
               if(a142 ==0){
                       if(a75==0){
                               if(a37 ==0){
                                       if(cf==false){
                                               if(input==false){
                                                       if(a131 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a122==0){
       if(a53==0){
               if(!(a142 ==0)){
                       if(a75==0){
                               if(a37 ==0){
                                       if(cf==false){
                                               if(input==false){
                                                       if(a131 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a122==0){
       if(a53==0){
               if(a142 ==0){
                       if(!(a75==0)){
                               if(a37 ==0){
                                       if(cf==false){
                                               if(input==false){
                                                       if(a131 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a122==0){
       if(a53==0){
               if(a142 ==0){
                       if(a75==0){
                               if(!(a37 ==0)){
                                       if(cf==false){
                                               if(input==false){
                                                       if(a131 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a122==0){
       if(a53==0){
               if(a142 ==0){
                       if(a75==0){
                               if(a37 ==0){
                                       if(!(cf==false)){
                                               if(input==false){
                                                       if(a131 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a122==0){
       if(a53==0){
               if(a142 ==0){
                       if(a75==0){
                               if(a37 ==0){
                                       if(cf==false){
                                               if(!(input==false)){
                                                       if(a131 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a122==0){
       if(a53==0){
               if(a142 ==0){
                       if(a75==0){
                               if(a37 ==0){
                                       if(cf==false){
                                               if(input==false){
                                                       if(!(a131 ==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*********************************************************************
    if((a122==0) && (a53==0) && (a142 ==0) && (a75==0) && (a37 ==0) && (cf==false) && (input==false) && (a131 ==0)){
    	cf = false;
    	a122 =0;
    	a184 = 5;
    	a53 =0;
    	a37 = 4;
    	a175 = 4;
    	a131 = 7;
    	a75 =0;
    	a176 =0;
    	a15 =0;
    	a138 =0;
    	a85 = 12;
    	a145 = 3;
    	a57 = 3;
    	a36 = 13; 
    	System.out.println("Z");
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(input==false){
       if(cf==false){
               if(a142 ==0){
                       if(a175 ==0){
                               if(a122==0){
                                       if(a171==0){
                                               if(a171==0){
                                                       if(a53==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(input==false)){
       if(cf==false){
               if(a142 ==0){
                       if(a175 ==0){
                               if(a122==0){
                                       if(a171==0){
                                               if(a171==0){
                                                       if(a53==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(input==false){
       if(!(cf==false)){
               if(a142 ==0){
                       if(a175 ==0){
                               if(a122==0){
                                       if(a171==0){
                                               if(a171==0){
                                                       if(a53==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(input==false){
       if(cf==false){
               if(!(a142 ==0)){
                       if(a175 ==0){
                               if(a122==0){
                                       if(a171==0){
                                               if(a171==0){
                                                       if(a53==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(input==false){
       if(cf==false){
               if(a142 ==0){
                       if(!(a175 ==0)){
                               if(a122==0){
                                       if(a171==0){
                                               if(a171==0){
                                                       if(a53==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(input==false){
       if(cf==false){
               if(a142 ==0){
                       if(a175 ==0){
                               if(!(a122==0)){
                                       if(a171==0){
                                               if(a171==0){
                                                       if(a53==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(input==false){
       if(cf==false){
               if(a142 ==0){
                       if(a175 ==0){
                               if(a122==0){
                                       if(!(a171==0)){
                                               if(a171==0){
                                                       if(a53==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(input==false){
       if(cf==false){
               if(a142 ==0){
                       if(a175 ==0){
                               if(a122==0){
                                       if(a171==0){
                                               if(!(a171==0)){
                                                       if(a53==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(input==false){
       if(cf==false){
               if(a142 ==0){
                       if(a175 ==0){
                               if(a122==0){
                                       if(a171==0){
                                               if(a171==0){
                                                       if(!(a53==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*********************************************************************
    if((input==false) && (cf==false) && (a142 ==0) && (a175 ==0) && (a122==0) && (a171==0) && (a171==0) && (a53==0)){
    	cf = false;
    	a53 =0;
    	a163 =0;
    	a175 = 3;
    	a103 =0;
    	a57 = 2;
    	a161 = 5;
    	a122 =0;
    	a37 = 3;
    	a138 =0;
    	a131 = 6;
    	a142 = 9;
    	a135 =0;
    	a6 =0;
    	a155 = 7;
    	a47 = 8;
    	a17 = 9; 
    	System.out.println("U");
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(a75==0){
       if(cf==false){
               if(input==false){
                       if(a155 ==0){
                               if(a85 ==0){
                                       if(a184 ==0){
                                               if(a15==0){
                                                       if(a57 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a75==0)){
       if(cf==false){
               if(input==false){
                       if(a155 ==0){
                               if(a85 ==0){
                                       if(a184 ==0){
                                               if(a15==0){
                                                       if(a57 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a75==0){
       if(!(cf==false)){
               if(input==false){
                       if(a155 ==0){
                               if(a85 ==0){
                                       if(a184 ==0){
                                               if(a15==0){
                                                       if(a57 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a75==0){
       if(cf==false){
               if(!(input==false)){
                       if(a155 ==0){
                               if(a85 ==0){
                                       if(a184 ==0){
                                               if(a15==0){
                                                       if(a57 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a75==0){
       if(cf==false){
               if(input==false){
                       if(!(a155 ==0)){
                               if(a85 ==0){
                                       if(a184 ==0){
                                               if(a15==0){
                                                       if(a57 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a75==0){
       if(cf==false){
               if(input==false){
                       if(a155 ==0){
                               if(!(a85 ==0)){
                                       if(a184 ==0){
                                               if(a15==0){
                                                       if(a57 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a75==0){
       if(cf==false){
               if(input==false){
                       if(a155 ==0){
                               if(a85 ==0){
                                       if(!(a184 ==0)){
                                               if(a15==0){
                                                       if(a57 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a75==0){
       if(cf==false){
               if(input==false){
                       if(a155 ==0){
                               if(a85 ==0){
                                       if(a184 ==0){
                                               if(!(a15==0)){
                                                       if(a57 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a75==0){
       if(cf==false){
               if(input==false){
                       if(a155 ==0){
                               if(a85 ==0){
                                       if(a184 ==0){
                                               if(a15==0){
                                                       if(!(a57 ==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*********************************************************************
    if((a75==0) && (cf==false) && (input==false) && (a155 ==0) && (a85 ==0) && (a184 ==0) && (a15==0) && (a57 ==0)){
    	cf = false;
    	 
    	System.out.println("Z");
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(a103==0){
       if(a75==0){
               if(a57 ==0){
                       if(a103==0){
                               if(a75==0){
                                       if(cf==false){
                                               if(input==false){
                                                       if(a103==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a103==0)){
       if(a75==0){
               if(a57 ==0){
                       if(a103==0){
                               if(a75==0){
                                       if(cf==false){
                                               if(input==false){
                                                       if(a103==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a103==0){
       if(!(a75==0)){
               if(a57 ==0){
                       if(a103==0){
                               if(a75==0){
                                       if(cf==false){
                                               if(input==false){
                                                       if(a103==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a103==0){
       if(a75==0){
               if(!(a57 ==0)){
                       if(a103==0){
                               if(a75==0){
                                       if(cf==false){
                                               if(input==false){
                                                       if(a103==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a103==0){
       if(a75==0){
               if(a57 ==0){
                       if(!(a103==0)){
                               if(a75==0){
                                       if(cf==false){
                                               if(input==false){
                                                       if(a103==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a103==0){
       if(a75==0){
               if(a57 ==0){
                       if(a103==0){
                               if(!(a75==0)){
                                       if(cf==false){
                                               if(input==false){
                                                       if(a103==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a103==0){
       if(a75==0){
               if(a57 ==0){
                       if(a103==0){
                               if(a75==0){
                                       if(!(cf==false)){
                                               if(input==false){
                                                       if(a103==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a103==0){
       if(a75==0){
               if(a57 ==0){
                       if(a103==0){
                               if(a75==0){
                                       if(cf==false){
                                               if(!(input==false)){
                                                       if(a103==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a103==0){
       if(a75==0){
               if(a57 ==0){
                       if(a103==0){
                               if(a75==0){
                                       if(cf==false){
                                               if(input==false){
                                                       if(!(a103==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*********************************************************************
    if((a103==0) && (a75==0) && (a57 ==0) && (a103==0) && (a75==0) && (cf==false) && (input==false) && (a103==0)){
    	cf = false;
    	a163 =0;
    	a122 =0;
    	a138 =0;
    	a175 = 3;
    	a75 =0;
    	a15 =0;
    	a37 = 3;
    	a131 = 6;
    	a84 =0;
    	a161 = 5;
    	a6 =0;
    	a199 = 11; 
    	System.out.println("U");
    } 
//*********************************************************************
//Transformation for predictes containing only AND operator
if(cf==false){
       if(input==false){
               if(a122==0){
                       if(a15==0){
                               if(a163==0){
                                       if(a131 ==0){
                                               if(a171==0){
                                                       if(a47 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(cf==false)){
       if(input==false){
               if(a122==0){
                       if(a15==0){
                               if(a163==0){
                                       if(a131 ==0){
                                               if(a171==0){
                                                       if(a47 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(cf==false){
       if(!(input==false)){
               if(a122==0){
                       if(a15==0){
                               if(a163==0){
                                       if(a131 ==0){
                                               if(a171==0){
                                                       if(a47 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(cf==false){
       if(input==false){
               if(!(a122==0)){
                       if(a15==0){
                               if(a163==0){
                                       if(a131 ==0){
                                               if(a171==0){
                                                       if(a47 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(cf==false){
       if(input==false){
               if(a122==0){
                       if(!(a15==0)){
                               if(a163==0){
                                       if(a131 ==0){
                                               if(a171==0){
                                                       if(a47 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(cf==false){
       if(input==false){
               if(a122==0){
                       if(a15==0){
                               if(!(a163==0)){
                                       if(a131 ==0){
                                               if(a171==0){
                                                       if(a47 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(cf==false){
       if(input==false){
               if(a122==0){
                       if(a15==0){
                               if(a163==0){
                                       if(!(a131 ==0)){
                                               if(a171==0){
                                                       if(a47 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(cf==false){
       if(input==false){
               if(a122==0){
                       if(a15==0){
                               if(a163==0){
                                       if(a131 ==0){
                                               if(!(a171==0)){
                                                       if(a47 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(cf==false){
       if(input==false){
               if(a122==0){
                       if(a15==0){
                               if(a163==0){
                                       if(a131 ==0){
                                               if(a171==0){
                                                       if(!(a47 ==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*********************************************************************
    if((cf==false) && (input==false) && (a122==0) && (a15==0) && (a163==0) && (a131 ==0) && (a171==0) && (a47 ==0)){
    	cf = false;
    	 
    	System.out.println("Z");
    } 
}

public  void calculateOutput(boolean input) {
 	cf = true;
  
    	 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a57 ==0){
                      if(cf==false){
                                              }
                   }
if(!(a57 ==0)){
       if(!(a161 ==0)){
                                      if(!(a155 ==0)){
                                  }
                            }
                      }
if(!(a57 ==0)){
       if(a161 ==0){
               if(cf==false){
                                                         }
                            }
                      }
if(!(a57 ==0)){
       if(a161 ==0){
               if(!(cf==false)){
                       if(!(a155 ==0)){
                                             }
                                     }
                             }
                     }
if(!(a57 ==0)){
       if(a161 ==0){
               if(!(cf==false)){
                       if(a155 ==0){
                                             }
                                     }
                             }
                     }
//*****************************************************************
    	if((a57 ==0) || (a161 ==0) && (cf==false) ||  (a155 ==0)) {
    		calculateOutputm4(input);
    	} 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a176==0){
                      if(a135==0){
                                                      if(cf==false){
                                       if(a104 ==0){
                                               if(a53==0){
                                                       if(a163==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a176==0)){
       if(!(a84==0)){
                                      if(!(a176==0)){
                                                                                                                                                                                                              }
                            }
                      }
if(!(a176==0)){
       if(a84==0){
               if(a135==0){
                                                      if(cf==false){
                                       if(a104 ==0){
                                               if(a53==0){
                                                       if(a163==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a176==0)){
       if(a84==0){
               if(!(a135==0)){
                       if(!(a176==0)){
                                                                                                                                                                                                                         }
                                     }
                             }
                     }
if(!(a176==0)){
       if(a84==0){
               if(!(a135==0)){
                       if(!(a176==0)){
                                                                                                                                                                                                                         }
                                     }
                             }
                     }
if(!(a176==0)){
       if(a84==0){
               if(!(a135==0)){
                       if(!(a176==0)){
                                                                                                                                                                                                                         }
                                     }
                             }
                     }
if(!(a176==0)){
       if(a84==0){
               if(!(a135==0)){
                       if(!(a176==0)){
                                                                                                                                                                                                                         }
                                     }
                             }
                     }
if(!(a176==0)){
       if(a84==0){
               if(!(a135==0)){
                       if(!(a176==0)){
                                                                                                                                                                                                                         }
                                     }
                             }
                     }
if(!(a176==0)){
       if(a84==0){
               if(!(a135==0)){
                       if(!(a176==0)){
                                                                                                                                                                                                                         }
                                     }
                             }
                     }
//*****************************************************************
		if((a176==0) || (a84==0) && (a135==0) || (a176==0) && (cf==false) && (a104 ==0) && (a53==0) && (a163==0)) {
    	calculateOutputm144(input);
		}
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a75==0){
                      if(cf==false){
                                                      if(a75==0){
                                                                                      if(a171==0){
                                                       if(a142 ==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a75==0)){
       if(!(a85 ==0)){
                                      if(!(a36 ==0)){
                                                                      if(!(a103==0)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(a75==0)){
       if(a85 ==0){
               if(cf==false){
                                                      if(!(a75==0)){
                                       if(!(a103==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(!(a75==0)){
       if(a85 ==0){
               if(!(cf==false)){
                       if(!(a36 ==0)){
                                                                      if(!(a103==0)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(!(a75==0)){
       if(a85 ==0){
               if(!(cf==false)){
                       if(a36 ==0){
                               if(!(a75==0)){
                                       if(!(a103==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a75==0)){
       if(a85 ==0){
               if(!(cf==false)){
                       if(a36 ==0){
                               if(!(a75==0)){
                                       if(!(a103==0)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a75==0)){
       if(a85 ==0){
               if(!(cf==false)){
                       if(a36 ==0){
                               if(!(a75==0)){
                                       if(a103==0){
                                               if(a171==0){
                                                       if(a142 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a75==0)){
       if(a85 ==0){
               if(!(cf==false)){
                       if(a36 ==0){
                               if(!(a75==0)){
                                       if(a103==0){
                                               if(!(a171==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a75==0)){
       if(a85 ==0){
               if(!(cf==false)){
                       if(a36 ==0){
                               if(!(a75==0)){
                                       if(a103==0){
                                               if(a171==0){
                                                       if(!(a142 ==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
		if((a75==0) || (a85 ==0) && (cf==false) || (a36 ==0) && (a75==0) || (a103==0) && (a171==0) && (a142 ==0)) {
    	calculateOutputm130(input);
		}
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a37 ==0){
                      if(a53==0){
                       if(a176==0){
                               if(a75==0){
                                                                                                                                             if(a155 ==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a37 ==0)){
       if(!(a37 ==0)){
                                                                                                            if(!(a3 ==0)){
                                               if(!(cf==false)){
                                                                                                    }
                                     }
                             }
                     }
if(!(a37 ==0)){
       if(!(a37 ==0)){
                                                                                                            if(!(a3 ==0)){
                                               if(!(cf==false)){
                                                                                                    }
                                     }
                             }
                     }
if(!(a37 ==0)){
       if(!(a37 ==0)){
                                                                                                            if(!(a3 ==0)){
                                               if(!(cf==false)){
                                                                                                    }
                                     }
                             }
                     }
if(!(a37 ==0)){
       if(!(a37 ==0)){
                                                                                                            if(!(a3 ==0)){
                                               if(!(cf==false)){
                                                                                                    }
                                     }
                             }
                     }
if(!(a37 ==0)){
       if(!(a37 ==0)){
                                                                                                            if(!(a3 ==0)){
                                               if(!(cf==false)){
                                                                                                    }
                                     }
                             }
                     }
if(!(a37 ==0)){
       if(!(a37 ==0)){
                                                                                                            if(a3 ==0){
                                                                                                      if(a155 ==0){
                                             }
                                     }
                             }
                     }
if(!(a37 ==0)){
       if(!(a37 ==0)){
                                                                                                            if(!(a3 ==0)){
                                               if(cf==false){
                                                       if(a155 ==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a37 ==0)){
       if(!(a37 ==0)){
                                                                                                            if(!(a3 ==0)){
                                               if(cf==false){
                                                       if(!(a155 ==0)){
                                                        }
                                              }
                                    }
                          }
                }
//*****************************************************************
		 if((a37 ==0) || (a37 ==0) && (a53==0) && (a176==0) && (a75==0) || (a3 ==0) || (cf==false) && (a155 ==0)) {
    	calculateOutputm128(input);
		}
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a85 ==0){
       if(a85 ==0){
               if(a75==0){
                                                      if(a103==0){
                                                                                      if(a3 ==0){
                                                       if(a142 ==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a85 ==0)){
                                             if(!(a37 ==0)){
                                                                      if(!(cf==false)){
                                                                                                                                        }
                            }
                      }
if(a85 ==0){
       if(a85 ==0){
               if(a75==0){
                                                      if(a103==0){
                                                                                      if(a3 ==0){
                                                       if(a142 ==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(a85 ==0){
       if(a85 ==0){
               if(!(a75==0)){
                       if(!(a37 ==0)){
                                                                      if(!(cf==false)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(a85 ==0){
       if(a85 ==0){
               if(!(a75==0)){
                       if(a37 ==0){
                               if(a103==0){
                                                                                      if(a3 ==0){
                                                       if(a142 ==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a85 ==0){
       if(a85 ==0){
               if(!(a75==0)){
                       if(a37 ==0){
                               if(!(a103==0)){
                                       if(!(cf==false)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(a85 ==0){
       if(a85 ==0){
               if(!(a75==0)){
                       if(a37 ==0){
                               if(!(a103==0)){
                                       if(cf==false){
                                               if(a3 ==0){
                                                       if(a142 ==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a85 ==0){
       if(a85 ==0){
               if(!(a75==0)){
                       if(a37 ==0){
                               if(!(a103==0)){
                                       if(cf==false){
                                               if(!(a3 ==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a85 ==0){
       if(a85 ==0){
               if(!(a75==0)){
                       if(a37 ==0){
                               if(!(a103==0)){
                                       if(cf==false){
                                               if(a3 ==0){
                                                       if(!(a142 ==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
		if((a85 ==0) && (a85 ==0) && (a75==0) || (a37 ==0) && (a103==0) || (cf==false) && (a3 ==0) && (a142 ==0)) {
    	calculateOutputm121(input);
		}
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a15==0){
       if(a131 ==0){
                                                                     if(a135==0){
                                                                                                                                             if(a53==0){
                                             }
                                     }
                             }
                     }
if(!(a15==0)){
                      if(!(cf==false)){
                       if(!(a145 ==0)){
                                                                      if(a131 ==0){
                                                                                                      if(a53==0){
                                                        }
                                              }
                                    }
                          }
                }
if(a15==0){
       if(!(a131 ==0)){
               if(!(cf==false)){
                       if(!(a145 ==0)){
                                                                      if(!(a131 ==0)){
                                               if(!(a75==1)){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(a15==0){
       if(!(a131 ==0)){
               if(cf==false){
                                                      if(a135==0){
                                                                                                                                             if(a53==0){
                                                        }
                                              }
                                    }
                          }
                }
if(a15==0){
       if(!(a131 ==0)){
               if(!(cf==false)){
                       if(a145 ==0){
                               if(a135==0){
                                                                                                                                             if(a53==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(a15==0){
       if(!(a131 ==0)){
               if(!(cf==false)){
                       if(a145 ==0){
                               if(!(a135==0)){
                                       if(!(a131 ==0)){
                                               if(!(a75==1)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a15==0){
       if(!(a131 ==0)){
               if(!(cf==false)){
                       if(a145 ==0){
                               if(!(a135==0)){
                                       if(!(a131 ==0)){
                                               if(!(a75==1)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(a15==0){
       if(!(a131 ==0)){
               if(!(cf==false)){
                       if(a145 ==0){
                               if(!(a135==0)){
                                       if(!(a131 ==0)){
                                               if(a75==1){
                                                       if(a53==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(a15==0){
       if(!(a131 ==0)){
               if(!(cf==false)){
                       if(a145 ==0){
                               if(!(a135==0)){
                                       if(!(a131 ==0)){
                                               if(a75==1){
                                                       if(!(a53==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
		if((a15==0) && (a131 ==0) || (cf==false)  ||(a145 ==0) && (a135==0) || (a131 ==0) || (a75==1) && (a53==0)) {
    		calculateOutputm122(input);
    	} 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a163==0){
                      if(a85 ==02){
                                                      if(a77==0){
                                                                                      if(a163==0){
                                                       if(a163==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a163==0)){
       if(!(a155 ==0)){
                                      if(!(a84==0)){
                                                                      if(!(cf==false)){
                                                                                                                                                   }
                                     }
                             }
                     }
if(!(a163==0)){
       if(a155 ==0){
               if(a85 ==02){
                                                      if(a77==0){
                                                                                      if(!(a163==0)){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(!(a163==0)){
       if(a155 ==0){
               if(!(a85 ==02)){
                       if(!(a84==0)){
                                                                      if(!(cf==false)){
                                                                                                                                                              }
                                              }
                                    }
                          }
                }
if(!(a163==0)){
       if(a155 ==0){
               if(!(a85 ==02)){
                       if(a84==0){
                               if(a77==0){
                                                                                      if(!(a163==0)){
                                                                                                                          }
                                                       }
                                           }
                               }
                   }
       }
if(!(a163==0)){
       if(a155 ==0){
               if(!(a85 ==02)){
                       if(a84==0){
                               if(!(a77==0)){
                                       if(!(cf==false)){
                                                                                                                                                                         }
                                                       }
                                           }
                               }
                   }
       }
if(!(a163==0)){
       if(a155 ==0){
               if(!(a85 ==02)){
                       if(a84==0){
                               if(!(a77==0)){
                                       if(cf==false){
                                               if(!(a163==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a163==0)){
       if(a155 ==0){
               if(!(a85 ==02)){
                       if(a84==0){
                               if(!(a77==0)){
                                       if(cf==false){
                                               if(!(a163==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a163==0)){
       if(a155 ==0){
               if(!(a85 ==02)){
                       if(a84==0){
                               if(!(a77==0)){
                                       if(cf==false){
                                               if(!(a163==0)){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
//*****************************************************************
		if((a163==0) || (a155 ==0) && (a85 ==02) || (a84==0) && (a77==0) || (cf==false) && (a163==0) && (a163==0)){
			calculateOutputm146(input);
		} 
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a199 == 0){
                      if(a155 == 0){
                                                                                             if(a37 == 0){
                                               if(a175 == 0){
                                                                                                    }
                                     }
                             }
                     }
if(!(a199 == 0)){
       if(!(cf==false)){
                                      if(a155 == 0){
                                                                      if(a37 == 0){
                                               if(a175 == 0){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(!(a199 == 0)){
       if(cf==false){
               if(a155 == 0){
                                                                                             if(a37 == 0){
                                               if(a175 == 0){
                                                                                                               }
                                              }
                                    }
                          }
                }
if(!(a199 == 0)){
       if(cf==false){
               if(!(a155 == 0)){
                       if(!(a155 == 0)){
                               if(!(a57 == 0)){
                                                                                                                                             if(!(a131 == 0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a199 == 0)){
       if(cf==false){
               if(!(a155 == 0)){
                       if(!(a155 == 0)){
                               if(!(a57 == 0)){
                                                                                                                                             if(!(a131 == 0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a199 == 0)){
       if(cf==false){
               if(!(a155 == 0)){
                       if(!(a155 == 0)){
                               if(a57 == 0){
                                       if(a37 == 0){
                                               if(a175 == 0){
                                                                                                                                     }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a199 == 0)){
       if(cf==false){
               if(!(a155 == 0)){
                       if(!(a155 == 0)){
                               if(a57 == 0){
                                       if(!(a37 == 0)){
                                                                                                      if(!(a131 == 0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a199 == 0)){
       if(cf==false){
               if(!(a155 == 0)){
                       if(!(a155 == 0)){
                               if(a57 == 0){
                                       if(a37 == 0){
                                               if(!(a175 == 0)){
                                                       if(!(a131 == 0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a199 == 0)){
       if(cf==false){
               if(!(a155 == 0)){
                       if(!(a155 == 0)){
                               if(a57 == 0){
                                       if(a37 == 0){
                                               if(!(a175 == 0)){
                                                       if(a131 == 0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
		if((a199 == 0) || (cf==false) && (a155 == 0) || (a155 == 0) || (a57 == 0) && (a37 == 0) && (a175 == 0) || (a131 == 0)) {
    	calculateOutputm100(input);
		}
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a142 ==0){
                                             if(cf==false){
                               if(a175 ==0){
                                                                                      if(a142 == 0){
                                                                                                    }
                                     }
                             }
                     }
if(!(a142 ==0)){
       if(!(a47 == 0)){
               if(!(a52==0)){
                                                                                             if(!(a75==0)){
                                                                                                      if(!(a53==0)){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a142 ==0)){
       if(a47 == 0){
                                      if(cf==false){
                               if(a175 ==0){
                                                                                      if(!(a142 == 0)){
                                                       if(!(a53==0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a142 ==0)){
       if(!(a47 == 0)){
               if(a52==0){
                       if(cf==false){
                               if(a175 ==0){
                                                                                      if(!(a142 == 0)){
                                                       if(!(a53==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a142 ==0)){
       if(!(a47 == 0)){
               if(a52==0){
                       if(!(cf==false)){
                                                                      if(!(a75==0)){
                                                                                                      if(!(a53==0)){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a142 ==0)){
       if(!(a47 == 0)){
               if(a52==0){
                       if(cf==false){
                               if(!(a175 ==0)){
                                       if(!(a75==0)){
                                                                                                      if(!(a53==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a142 ==0)){
       if(!(a47 == 0)){
               if(a52==0){
                       if(cf==false){
                               if(!(a175 ==0)){
                                       if(a75==0){
                                               if(!(a142 == 0)){
                                                       if(!(a53==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a142 ==0)){
       if(!(a47 == 0)){
               if(a52==0){
                       if(cf==false){
                               if(!(a175 ==0)){
                                       if(a75==0){
                                               if(!(a142 == 0)){
                                                       if(!(a53==0)){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
if(!(a142 ==0)){
       if(!(a47 == 0)){
               if(a52==0){
                       if(cf==false){
                               if(!(a175 ==0)){
                                       if(a75==0){
                                               if(!(a142 == 0)){
                                                       if(a53==0){
                                                                                         }
                                                                         }
                                                         }
                                         }
                         }
         }
}
}
//*****************************************************************
		if((a142 ==0) || (a47 == 0) || (a52==0) && (cf==false) && (a175 ==0) || (a75==0) && (a142 == 0) || (a53==0)) {
    	calculateOutputm81(input);
		}
//*********************************************************************
//Transformation for predictes containing both AND and OR operator
if(a47 == 0){
                      if(a184 == 0){
                                                      if(cf==false){
                                                                                      if(a163==0){
                                             }
                                     }
                             }
                     }
if(!(a47 == 0)){
       if(!(a37 == 0)){
                                      if(!(a53==0)){
                                                                      if(!(a112 == 0)){
                                                                                            }
                                     }
                             }
                     }
if(!(a47 == 0)){
       if(a37 == 0){
               if(a184 == 0){
                                                      if(cf==false){
                                                                                      if(a163==0){
                                                        }
                                              }
                                    }
                          }
                }
if(!(a47 == 0)){
       if(a37 == 0){
               if(!(a184 == 0)){
                       if(!(a53==0)){
                                                                      if(!(a112 == 0)){
                                                                                                       }
                                              }
                                    }
                          }
                }
if(!(a47 == 0)){
       if(a37 == 0){
               if(!(a184 == 0)){
                       if(a53==0){
                               if(cf==false){
                                                                                      if(a163==0){
                                                                   }
                                                       }
                                           }
                               }
                   }
       }
if(!(a47 == 0)){
       if(a37 == 0){
               if(!(a184 == 0)){
                       if(a53==0){
                               if(!(cf==false)){
                                       if(!(a112 == 0)){
                                                                                                                  }
                                                       }
                                           }
                               }
                   }
       }
if(!(a47 == 0)){
       if(a37 == 0){
               if(!(a184 == 0)){
                       if(a53==0){
                               if(!(cf==false)){
                                       if(a112 == 0){
                                               if(a163==0){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
if(!(a47 == 0)){
       if(a37 == 0){
               if(!(a184 == 0)){
                       if(a53==0){
                               if(!(cf==false)){
                                       if(a112 == 0){
                                               if(!(a163==0)){
                                                                              }
                                                                }
                                                  }
                                    }
                      }
        }
}
//*****************************************************************
		if((a47 == 0) || (a37 == 0) && (a184 == 0) || (a53==0) && (cf==false) || (a112 == 0) && (a163==0)) {
    	calculateOutputm56(input);
		}

	errorCheck();
    if(cf==false)
    	throw new IllegalArgumentException("Current state has no transition for this input!");
		
    }    

public static void main() throws Exception 
	{
	     // init system and input reader
            FinalProblem2016 eca = new FinalProblem2016();
     
		boolean input = Cute.input.Boolean();
			// main i/o-loop
             int x = Cute.input.Integer();
        int y= Cute.input.Integer();
        int y1= Cute.input.Integer();
        int y2= Cute.input.Integer();
        switch(x){
            case -100:
                y=1;
                eca.calculateOutput(input);
                break;
            case 0:
                y = 2;
                eca.calculateOutput(input);
               
                break;
        }       
	}
}


//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=false
