
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class jxnct_bubble_sortjxnct_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public jxnct_bubble_sortjxnct_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-1251865217);
        input[i++] = new Integer(-1204993466);
        input[i++] = new Integer(684942911);
        input[i++] = new Integer(-824462270);
        i=0;
        cute.Cute.input = this;
        jxnct.bubble_sortjxnct.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(-1204993466);
        input[i++] = new Integer(684942911);
        input[i++] = new Integer(-824462270);
        i=0;
        cute.Cute.input = this;
        jxnct.bubble_sortjxnct.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(-1204993466);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jxnct.bubble_sortjxnct.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1204993466);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jxnct.bubble_sortjxnct.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1204993466);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jxnct.bubble_sortjxnct.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(100);
        input[i++] = new Integer(-1204993466);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jxnct.bubble_sortjxnct.main(null);
    }

    public void test24(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(200);
        input[i++] = new Integer(-1204993466);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        jxnct.bubble_sortjxnct.main(null);
    }

    public void test64(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(240);
        input[i++] = new Integer(-1204993466);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        jxnct.bubble_sortjxnct.main(null);
    }

}
