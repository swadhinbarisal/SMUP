package A1;
import cute.Cute;

public class Problem4_RERS2017 {
	
	private String[] inputs = {"B","E","A","G","F","I","J","D","H","C"};
	
	public int a17 =Cute.input.Integer();
	public int a2 =Cute.input.Integer();
	public int a265 =Cute.input.Integer();
	public int a219 =Cute.input.Integer();
	public int a81 =Cute.input.Integer();
	public int a130 =Cute.input.Integer();
	public int a95 =Cute.input.Integer();
	public int a273 =Cute.input.Integer();
	public int a373 =Cute.input.Integer();
	public int a36 =Cute.input.Integer();
	public int a197 =Cute.input.Integer();
	public int a161 =Cute.input.Integer();
	public int a147 =Cute.input.Integer();
	public int a346 =Cute.input.Integer();
	public int a345 =Cute.input.Integer();
	public int a387 =Cute.input.Integer();
	public int a111 =Cute.input.Integer();
	public int a215 =Cute.input.Integer();
	public int a93 =Cute.input.Integer();
	public int a123 =Cute.input.Integer();
	public int a109 =Cute.input.Integer();
	public int a401 =Cute.input.Integer();
	public int a146 =Cute.input.Integer();
	public int a298 =Cute.input.Integer();
	public int a87 =Cute.input.Integer();
	public int a180 =Cute.input.Integer();
	public int a29 =Cute.input.Integer();
	public int a171 =Cute.input.Integer();
	public int a179 =Cute.input.Integer();
	public int a26 =Cute.input.Integer();
	public int a216 =Cute.input.Integer();
	public int a49 =Cute.input.Integer();
	public int a196 =Cute.input.Integer();
	public boolean cf = Cute.input.Boolean();
	public int a181 =Cute.input.Integer();
	public int a143 =Cute.input.Integer();
	public int a260 =Cute.input.Integer();
	public int a355 =Cute.input.Integer();
	public int a400 =Cute.input.Integer();
	public int a157 =Cute.input.Integer();
	public int a192 =Cute.input.Integer();
	public int a119 =Cute.input.Integer();
	public int a136 =Cute.input.Integer();
	public int a55 =Cute.input.Integer();
	public int a325 =Cute.input.Integer();
	public int a106 =Cute.input.Integer();
	public int a21 =Cute.input.Integer();
	public int a227 =Cute.input.Integer();
	public int a74 =Cute.input.Integer();
	public int a10 =Cute.input.Integer();
	public int a156 =Cute.input.Integer();
	public int a41 =Cute.input.Integer();
	public int a23 =Cute.input.Integer();
	public int a127 =Cute.input.Integer();
	public int a101 =Cute.input.Integer();
	public int a53 =Cute.input.Integer();
	public int a103 =Cute.input.Integer();
	public int a151 =Cute.input.Integer();
	public int a150 =Cute.input.Integer();
	public int a61 =Cute.input.Integer();
	public int a139 =Cute.input.Integer();
	public int a86 =Cute.input.Integer();
	public int a220 =Cute.input.Integer();
	public int a50 =Cute.input.Integer();
	public int a338 =Cute.input.Integer();
	public int a18 =Cute.input.Integer();
	public int a183 =Cute.input.Integer();
	public int a141 =Cute.input.Integer();
	public int a71 =Cute.input.Integer();
	public int a132 =Cute.input.Integer();
	public int a44 =Cute.input.Integer();
	public int a91 =Cute.input.Integer();
	public int a126 =Cute.input.Integer();
	public int a96 =Cute.input.Integer();
	public int a174 =Cute.input.Integer();
	public int a32 =Cute.input.Integer();
	public int a170 =Cute.input.Integer();
	public int a90 =Cute.input.Integer();
	public int a25 =Cute.input.Integer();
	public int a62 =Cute.input.Integer();
	public int a4 =Cute.input.Integer();
	public int a152 =Cute.input.Integer();
	public int a188 =Cute.input.Integer();
	public int a311 =Cute.input.Integer();
	public int a158 =Cute.input.Integer();
	public int a45 =Cute.input.Integer();
	public int a140 =Cute.input.Integer();
	public int a76 =Cute.input.Integer();
	public int a388 =Cute.input.Integer();
	public int a125 =Cute.input.Integer();
	public int a97 =Cute.input.Integer();
	public int a148 =Cute.input.Integer();
	public int a82 =Cute.input.Integer();
	public int a164 =Cute.input.Integer();
	public int a191 =Cute.input.Integer();
	public int a385 =Cute.input.Integer();
	public int a162 =Cute.input.Integer();
	public int a262 =Cute.input.Integer();
	public int a129 =Cute.input.Integer();
	public int a113 =Cute.input.Integer();
	public int a94 =Cute.input.Integer();
	public int a149 =Cute.input.Integer();
	public int a20 =Cute.input.Integer();
	public int a14 =Cute.input.Integer();
	public int a117 =Cute.input.Integer();
	public int a255 =Cute.input.Integer();
	public int a232 =Cute.input.Integer();
	public int a75 =Cute.input.Integer();
	public int a58 =Cute.input.Integer();
	public int a84 =Cute.input.Integer();
	public int a98 =Cute.input.Integer();
	public int a115 =Cute.input.Integer();
	public int a182 =Cute.input.Integer();
	public int a73 =Cute.input.Integer();
	public int a6 =Cute.input.Integer();
	public int a163 =Cute.input.Integer();
	public int a160 =Cute.input.Integer();
	public int a63 =Cute.input.Integer();
	public int a116 =Cute.input.Integer();
	public int a176 =Cute.input.Integer();
	public int a57 =Cute.input.Integer();
	public int a383 =Cute.input.Integer();
	public int a186 =Cute.input.Integer();
	public int a107 =Cute.input.Integer();
	public int a379 =Cute.input.Integer();
	public int a13 =Cute.input.Integer();
	public int a114 =Cute.input.Integer();
	public int a155 =Cute.input.Integer();
	public int a47 =Cute.input.Integer();
	public int a51 =Cute.input.Integer();
	public int a133 =Cute.input.Integer();
	public int a85 =Cute.input.Integer();
	public int a254 =Cute.input.Integer();
	public int a92 =Cute.input.Integer();
	public int a72 =Cute.input.Integer();
	public int a79 =Cute.input.Integer();
	public int a321 =Cute.input.Integer();
	public int a46 =Cute.input.Integer();
	public int a381 =Cute.input.Integer();
	public int a159 =Cute.input.Integer();
	public int a69 =Cute.input.Integer();
	public int a1 =Cute.input.Integer();
	public int a7 =Cute.input.Integer();

private  void calculateOutputm32(boolean input) {
    if((a129==0) && (a55 == 8) && (a385==0) || (cf==true)){
    	cf = false;
    	a86 =0;
    	a129 =10;
    	a186 =10;
    	a25 = 6; 
    	System.out.println("Q");
    } 
    if((a136 == 4)  ||(a385==0) && (input==true) && (a55 == 8)){
    	cf = false;
    	a86 =10;
    	a129 =10;
    	a355 =0;
    	a197 = 9; 
    	System.out.println("P");
    } 
    if((input==true)  || (a136 == 4) && (cf==true) || (a55 == 8)){
    	cf = false;
    	a381 =10;
    	a86 =0;
    	a129 =10;
    	a254 = 5; 
    	System.out.println("R");
    } 
    if((a55 == 8) && (cf==true) && (a136 == 4) || (a385==0)){
    	cf = false;
    	a197 = 8;
    	a129 =0;
    	a373 = 5;
    	a96 = 3; 
    	System.out.println("P");
    } 
}
private  void calculateOutputm33(boolean input) {
    if((cf==true) && (a55 == 8) ||(a136 == 4) && (a129==0)){
    	cf = false;
    	a55 = 11;
    	a130 =0;
    	a1 = 6; 
    	System.out.println("R");
    } 
    if((a55 == 8) || (cf==true) && (a385==0) ||  (a136 == 4)){
    	cf = false;
    	a97 =1;
    	a216 =1;
    	a129 =1;
    	a29 = 5; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm34(boolean input) {
    if((a2 == 8)  || (cf==true) && (a55 == 8) || (a129==0)){
    	cf = false;
    	a143 =10;
    	a86 =0;
    	a129 =10;
    	a254 = 4; 
    	System.out.println("V");
    } 
    if((a129==0) || (cf==true) || (a136 == 5) && (a2 == 8)){
    	cf = false;
    	a129 =10;
    	a86 =1;
    	a51 =0;
    	a125 = 11; 
    	System.out.println("W");
    } 
    if((a55 == 8) || (a2 == 8) && (cf==true) ||  (a129==0)){
    	cf = false;
    	a129 =10;
    	a355 =10;
    	a86 =10;
    	a181 = 6; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm35(boolean input) {
    if((cf==true) || (a129==0) && (a136 == 5) && (a55 == 8)){
    	cf = false;
    	a129 =1;
    	a216 =1;
    	a29 = 8;
    	a196 = 14; 
    	System.out.println("R");
    } 
    if((cf==true) && (a136 == 5) || (a55 == 8) && (a129==0)){
    	cf = false;
    	a55 = 11;
    	a130 =0;
    	a1 = 6; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm36(boolean input) {
    if((a129==0) || (a25 == 7) && (cf==true) && (a136 == 6)){
    	cf = false;
    	a216 =10;
    	a129 =1;
    	a311 =1;
    	a156 = 7; 
    	System.out.println("Y");
    } 
    if((a136 == 6) || (cf==true) && (a25 == 7) || (a129==0)){
    	cf = false;
    	a129 =0;
    	a373 = 10;
    	a346 =1;
    	a20 = 10; 
    	System.out.println("P");
    } 
}
private  void calculateOutputm37(boolean input) {
    if((cf==true) || (a129==0) && (a25 == 9) && (a136 == 6)){
    	cf = false;
    	a355 =0;
    	a129 =10;
    	a86 =10;
    	a346 =0; 
    	System.out.println("W");
    } 
    if((cf==true) || (a129==0) && (a136 == 6) && (a25 == 9)){
    	cf = false;
    	a115 = 5;
    	a373 = 6;
    	a129 =0;
    	a72 = 8; 
    	System.out.println("U");
    } 
    if((a136 == 6) && (cf==true) && (a55 == 8) || (a25 == 9)){
    	cf = false;
    	a164 =0;
    	a55 = 13;
    	a181 = 11; 
    	System.out.println("P");
    } 
}
private  void calculateOutputm38(boolean input) {
    if((a55 == 8) && (a25 == 11) && (a136 == 6)){
    	cf = false;
    	a136 = 5;
    	a2 = 11; 
    	System.out.println("R");
    } 
    if((a136 == 6) && (cf==true) || (a25 == 11) ||  (a55 == 8)){
    	cf = false;
    	a130 =0;
    	a55 = 11;
    	a1 = 6; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm39(boolean input) {
    if((a136 == 7) || (cf==true) || (a129==0) && (a71==0)){
    	cf = false;
    	a197 = 5;
    	a373 = 5;
    	a129 =0;
    	a125 = 13; 
    	System.out.println("Q");
    } 
    if((a129==0)  || (cf==true) && (a55 == 8) && (a136 == 7)){
    	cf = false;
    	a55 = 15;
    	a182 =0;
    	a7 = 7; 
    	System.out.println("O");
    } 
    if((a55 == 8) && (a71==0) && (cf==true) || (a136 == 7)){
    	cf = false;
    	a55 = 15;
    	a7 = 4;
    	a176 = 8; 
    	System.out.println("P");
    } 
    if((a55 == 8) || (cf==true) && (a129==0) || (a71==0)){
    	cf = false;
    	a129 =10;
    	a220 =0;
    	a86 =0;
    	a254 = 7; 
    	System.out.println("S");
    } 
}
private  void calculateOutputm40(boolean input) {
    if((cf==true) && (a129==0) || (a71==0) || (a55 == 8) && (a136 == 7)){
    	cf = false;
    	a86 =0;
    	a129 =10;
    	a25 = 12;
    	a36 = 16; 
    	System.out.println("R");
    } 
    if((a129==0) && (a71==0) || (cf==true) || (a136 == 7)){
    	cf = false;
    	a55 = 11;
    	a130 =0;
    	a1 = 6; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm41(boolean input) {
    if((a55 == 8) && (a71==0) && (a136 == 7) ||(cf==true)){
    	cf = false;
    	a55 = 11;
    	a130 =0;
    	a1 = 6; 
    	System.out.println("R");
    } 
    if((a136 == 7) || (a71==0) || (a55 == 8) && (cf==true)){
    	cf = false;
    	a126 =10;
    	a216 =1;
    	a129 =1;
    	a29 = 11; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm42(boolean input) {
    if((a55 == 8) || (cf==true) && (a113 == 8) && (a129==0)){
    	cf = false;
    	 
    	System.out.println("S");
    } 
}
private  void calculateOutputm43(boolean input) {
    if((a55 == 8) || (cf==true) && (a113 == 9) ||  (a136 == 8)){
    	cf = false;
    	a162 = 4;
    	a129 =10;
    	a86 =10;
    	a157 = 16; 
    	System.out.println("R");
    } 
    if((a113 == 9) || (a136 == 8) && (cf==true) || (a55 == 8)){
    	cf = false;
    	a129 =0;
    	a373 = 4;
    	a181 = 10;
    	a141 = 12; 
    	System.out.println("Q");
    } 
    if((a129==0)  && (a55 == 8) || (a113 == 9) && (cf==true)){
    	cf = false;
    	a55 = 10;
    	a346 =0;
    	a72 = 6; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm44(boolean input) {
    if((a129==0) && (a136 == 8) || (a55 == 8) ||  (a113 == 15)){
    	cf = false;
    	a130 =0;
    	a55 = 11;
    	a1 = 6; 
    	System.out.println("R");
    } 
    if((a113 == 15) || (cf==true) && (a55 == 8) || (a129==0)){
    	cf = false;
    	a129 =10;
    	a98 =0;
    	a75 =0;
    	a116 =10; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm45(boolean input) {
    if((a129==0) && (a55 == 8) && (a383==0) || (cf==true)){
    	cf = false;
    	a346 =0;
    	a129 =0;
    	a146 =10;
    	a373 = 10; 
    	System.out.println("Y");
    } 
    if((a136 == 9) && (a55 == 8) && (cf==true) || (a383==0)){
    	cf = false;
    	a129 =10;
    	a75 =1;
    	a61 =0;
    	a49 = 8; 
    	System.out.println("X");
    } 
    if((a55 == 8) || (cf==true) && (a129==0) && (a136 == 9)){
    	cf = false;
    	a81 =0;
    	a55 = 12;
    	a183 = 3; 
    	System.out.println("O");
    } 
}
private  void calculateOutputm46(boolean input) {
    if((cf==true) || (a55 == 8) && (a136 == 9) && (a383==0)){
    	cf = false;
    	a373 = 5;
    	a197 = 10;
    	a129 =0;
    	a109 = 7; 
    	System.out.println("P");
    } 
    if((cf==true)|| (a129==0) && (a55 == 8) && (a383==0)){
    	cf = false;
    	a55 = 11;
    	a130 =0;
    	a1 = 11; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm47(boolean input) {
    if((a129==0) && (a136 == 9) && (a383==0) || (cf==true)){
    	cf = false;
    	a129 =10;
    	a86 =0;
    	a143 =0;
    	a254 = 4; 
    	System.out.println("V");
    } 
    if((a129==0) && (a136 == 9) && (a55 == 8) || (a383==0)){
    	cf = false;
    	a373 = 4;
    	a129 =0;
    	a181 = 6;
    	a53 = 12; 
    	System.out.println("X");
    } 
    if((a129==0) && (a383==0) && (cf==true) || (a55 == 8)){
    	cf = false;
    	a125 = 12;
    	a129 =10;
    	a75 =0;
    	a338 = 17; 
    	System.out.println("Y");
    } 
    if((a129==0) && (a136 == 9) && (cf==true) || (a383==0) ){
    	cf = false;
    	a383 =0; 
    	System.out.println("O");
    } 
}
private  void calculateOutputm48(boolean input) {
    if((cf==true) || (a26 == 4) && (a136 == 10) && (a129==0)){
    	cf = false;
    	a130 =0;
    	a55 = 11;
    	a1 = 6; 
    	System.out.println("R");
    } 
    if((cf==true) && (a129==0) ||(a55 == 8) &&  (a136 == 10)){
    	cf = false;
    	a373 = 5;
    	a129 =0;
    	a197 = 6;
    	a6 = 14; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm49(boolean input) {
    if((a55 == 8) || (a26 == 8) && (cf==true) && (a136 == 10)){
    	cf = false;
    	a55 = 15;
    	a182 =10;
    	a7 = 7; 
    	System.out.println("V");
    } 
    if((a136 == 10) || (cf==true) && (a26 == 8) && (a129==0)){
    	cf = false;
    	a383 =0;
    	a136 = 9; 
    	System.out.println("Q");
    } 
    if((a129==0) || (a136 == 10) && (a55 == 8) || (a26 == 8)){
    	cf = false;
    	a55 = 9;
    	a127 =10;
    	a85 = 14; 
    	System.out.println("O");
    } 
    if((a136 == 10)  || (a129==0) && (cf==true) && (a55 == 8)){
    	cf = false;
    	a273 =10;
    	a55 = 15;
    	a7 = 2; 
    	System.out.println("W");
    } 
}
private  void calculateOutput(boolean input) {
    if((a136 == 4) && (cf==true)){
    	if((a385==0) || (cf==true)){
    		calculateOutputm32(input);
    	} 
    	if((cf==true) && (a385==0)){
    		calculateOutputm33(input);
    	} 
    } 
    if((cf==true) || (a136 == 5)){
    	if((a2 == 8) && (cf==true)){
    		calculateOutputm34(input);
    	} 
    	if((cf==true) || (a2 == 11)){
    		calculateOutputm35(input);
    	} 
    } 
    if((cf==true) ||(a136 == 6)){
    	if((cf==true) && (a25 == 7)){
    		calculateOutputm36(input);
    	} 
    	if((a25 == 9) && (cf==true)){
    		calculateOutputm37(input);
    	} 
    	if((a25 == 11) || (cf==true)){
    		calculateOutputm38(input);
    	} 
    } 
    if((cf==true) || (a136 == 7)){
    	if((cf==true) && (a71==0)){
    		calculateOutputm39(input);
    	} 
    	if((cf==true) || (a71==0)){
    		calculateOutputm40(input);
    	} 
    	if((cf==true) && (a71==0)){
    		calculateOutputm41(input);
    	} 
    } 
    if((cf==true) || (a136 == 8)){
    	if((a113 == 8) && (cf==true)){
    		calculateOutputm42(input);
    	} 
    	if((cf==true) || (a113 == 9)){
    		calculateOutputm43(input);
    	} 
    	if((a113 == 15) && (cf==true)){
    		calculateOutputm44(input);
    	} 
    } 
    if((cf==true) || (a136 == 9)){
    	if((cf==true) && (a383==0)){
    		calculateOutputm45(input);
    	} 
    	if((cf==true) || (a383==0)){
    		calculateOutputm46(input);
    	} 
    	if((cf==true) && (a383==0)){
    		calculateOutputm47(input);
    	} 
    } 
    if((cf==true) || (a136 == 10)){
    	if((cf==true) && (a26 == 4)){
    		calculateOutputm48(input);
    	} 
    	if((a26 == 8) || (cf==true)){
    		calculateOutputm49(input);
    	} 
    } 
	
}	
public static void main() throws Exception {
	// init system and input reader
	Problem4_RERS2017 eca = new Problem4_RERS2017();

	int a=0;
	int x;
        int y;
         
        x = Cute.input.Integer();
        y = Cute.input.Integer();
		boolean input = Cute.input.Boolean();
			// main i/o-loop
            while(a<10) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                	 eca.calculateOutput(input);
					 
				}
				
				if (x>299 || x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutput(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
}
	
}

//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
