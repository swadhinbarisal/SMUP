
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class tests_StringBuffer2_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public tests_StringBuffer2_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[2];
        input[i++] = new Integer(-839913258);
        input[i++] = new Integer(-1270208287);
        i=0;
        cute.Cute.input = this;
        tests.StringBuffer2.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[1];
        input[i++] = new Integer(4);
        i=0;
        cute.Cute.input = this;
        tests.StringBuffer2.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[3];
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1270208287);
        input[i++] = new Integer(27695512);
        i=0;
        cute.Cute.input = this;
        tests.StringBuffer2.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[4];
        input[i++] = new Integer(2);
        input[i++] = new Integer(-1270208287);
        input[i++] = new Integer(190059548);
        input[i++] = new Integer(27695512);
        i=0;
        cute.Cute.input = this;
        tests.StringBuffer2.main(null);
    }

    public void test8(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(2);
        input[i++] = new Integer(0);
        input[i++] = new Character(?);
        input[i++] = new Integer(-1405955496);
        input[i++] = new Integer(1176868366);
        i=0;
        cute.Cute.input = this;
        tests.StringBuffer2.main(null);
    }

    public void test10(){
        i=0;
        input = new Object[6];
        input[i++] = new Integer(3);
        input[i++] = new Integer(0);
        input[i++] = new Character(?);
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1405955496);
        input[i++] = new Integer(-26169334);
        i=0;
        cute.Cute.input = this;
        tests.StringBuffer2.main(null);
    }

    public void test11(){
        i=0;
        input = new Object[8];
        input[i++] = new Integer(3);
        input[i++] = new Integer(0);
        input[i++] = new Character(?);
        input[i++] = new Integer(1);
        input[i++] = new Integer(2);
        input[i++] = new Integer(-26169334);
        input[i++] = new Integer(1112302661);
        input[i++] = new Integer(-1568587665);
        i=0;
        cute.Cute.input = this;
        tests.StringBuffer2.main(null);
    }

    public void test12(){
        i=0;
        input = new Object[9];
        input[i++] = new Integer(3);
        input[i++] = new Integer(0);
        input[i++] = new Character(?);
        input[i++] = new Integer(1);
        input[i++] = new Integer(2);
        input[i++] = new Integer(1);
        input[i++] = new Character(?);
        input[i++] = new Integer(1982313696);
        input[i++] = new Integer(1232703151);
        i=0;
        cute.Cute.input = this;
        tests.StringBuffer2.main(null);
    }

    public void test20(){
        i=0;
        input = new Object[6];
        input[i++] = new Integer(2);
        input[i++] = new Integer(2);
        input[i++] = new Character(?);
        input[i++] = new Integer(-232442627);
        input[i++] = new Integer(-41518192);
        input[i++] = new Integer(-1672665119);
        i=0;
        cute.Cute.input = this;
        tests.StringBuffer2.main(null);
    }

}
