package tests;

import cute.Cute;

/**
 *  .
 * User: ksen
 * Date: Oct 25, 2005
 * Time: 7:38:52 PM
 * To change this template use File | Settings | File Templates.
 */

class MyException extends RuntimeException {

}

public class bubble_sort {


    public static int function1(int x, int z){

        if((x>199) && (z<50)){
            throw new MyException();
        } else {
            return 2*x+1;
        }
    }

    public static int function2(int y){
        int ret = function1(y,11) * 23;
        return ret;
    }
    public static void bubble_srt(int array[]) {
        int n = array.length;
        int k;
       int d = Cute.input.Integer();
        int e = Cute.input.Integer();

        for (int m = n; m >= 0; m--) {
            for (int i = 0; i < n - 1; i++) {
                k = i + 1;
                if((e > d)&&(i>k))
                {
                    System.out.println("Outplateness present");
                }
                if((e >= 0)&&(i>k))
                {
                    System.out.println("Outplateness not present");
                }
                if((e >= 0)&&(i>=0))
                {
                    System.out.println("------");
                }
                if((e > d)||(i>k))
                {
                    System.out.println("------");
                }
                if((e >= 0)&&(i>k))
                {
                    System.out.println("-------");
                }
                if((e >= 0)||(i>=0))
                {
                    System.out.println("--------");
                }
                if (array[i] > array[k]) {
                    swapNumbers(i, k, array);
                }
            }
            for(int i=0; i < array.length; i++){
                        System.out.print(array[i] + " ");
                }

        }
    }

    private static void swapNumbers(int i, int j, int[] array) {

        int temp;
        temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }


    public static void main(String[] args) {
        int x = Cute.input.Integer();
        int y = Cute.input.Integer();

        switch(x){
            case -100:
                y=1;
                int[] input1 = { 4, 2, 9, 6, 23, 12, 34, 0, 1 };
                bubble_srt(input1);

                break;
            case 0:
                y = 2;
                 int[] input2 = { 3, 2, 9, 6, 2, 0, 1 };
                bubble_srt(input2);
                break;
            case 100:
                y = 3;
                int[] input3 = { 4, 1, 9, 6, 23, 1, 3, 0, 1 };
                bubble_srt(input3);
                break;
            default:
                y=4;
                int[] input4 = { 4, 528, 9, 62, 23, 2, 34, 98, 1 };
                bubble_srt(input4);
        }
        try {
            int z = function2(x);
            if(z==69){
                System.out.println("y = " + y);
            }
        } catch(MyException e){
            y = x+10;
            if(y==250)
                System.out.println("OOPS ...");
        }
    }
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
