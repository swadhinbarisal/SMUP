package jpct;

import cute.Cute;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Problem10_RERS2018jpct {
	static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

	private String[] inputs = {"E","A","C","B","D"};

	public int a1591641889 = Cute.input.Integer();
	public int a1933271548 = Cute.input.Integer();
	public int a1580663338 = Cute.input.Integer();
	public int a1384943560 = Cute.input.Integer();
	public int a1491567675 = Cute.input.Integer();
	public int a1554992028 = Cute.input.Integer();
	public int a1431178715 = Cute.input.Integer();
	public int a181636438 = Cute.input.Integer();
	public boolean cf = Cute.input.Boolean();
	public boolean input = Cute.input.Boolean();
	public int a1294378386 = Cute.input.Integer();
	public int a843079661 = Cute.input.Integer();
	public int a1583922005 = Cute.input.Integer();
	public int a2108703896 = Cute.input.Integer();
	public int a1041640432 = Cute.input.Integer();
	public int a510889416 = Cute.input.Integer();
	public int a43901077 = Cute.input.Integer();
	public int a1669722568 = Cute.input.Integer();
	public int a1379546326 = Cute.input.Integer();
	public int a1136264456 = Cute.input.Integer();
	public int a927814483 = Cute.input.Integer();
	public int a1868984816 = Cute.input.Integer();
	public int a1796618233 = Cute.input.Integer();
	public int a469914660 = Cute.input.Integer();
	public int a1450658394 = Cute.input.Integer();
	public int a2077863541 = Cute.input.Integer();
	public int a1649592707 = Cute.input.Integer();
	public int a1944816302 = Cute.input.Integer();
	public int a1551570219 =Cute.input.Integer();
	public int a231305105 = Cute.input.Integer();
	public int a938827910 = Cute.input.Integer();

	private void errorCheck() {
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1554992028==0){
if(a1933271548==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1554992028 ==0) && (a1933271548 ==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("0");
	    }
//******************Transformed code started****************************
if(a1649592707==0){
 }
 else {}
if(a1933271548==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1649592707==0) || (a1933271548 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("1");
	    }
//******************Transformed code started****************************
if(a469914660==0){
 }
 else {}
if(a1868984816==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a469914660 ==0) || (a1868984816 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("2");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1554992028==0){
if(a1041640432==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1554992028 ==0) && (a1041640432 ==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("3");
	    }
//******************Transformed code started****************************
if(a2077863541==0){
 }
 else {}
if(a1868984816==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a2077863541 ==0) || (a1868984816 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("4");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1591641889==0){
if(a1933271548==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1591641889 ==0) && (a1933271548 ==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("5");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1384943560==0){
if(a1669722568==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1384943560==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("6");
	    }
//******************Transformed code started****************************
if(a1554992028==0){
 }
 else {}
if(a1933271548==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1554992028 ==0) || (a1933271548 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("7");
	    }
//******************Transformed code started****************************
if(a1554992028==0){
 }
 else {}
if(a1669722568==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1554992028 ==0) || (a1669722568==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("8");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1944816302==0){
if(a43901077==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1944816302==0) && (a43901077==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("9");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1136264456==0){
if(a1041640432==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1136264456==0) && (a1041640432 ==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("10");
	    }
//******************Transformed code started****************************
if(a1384943560==0){
 }
 else {}
if(a1669722568==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1384943560==0) || (a1669722568==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("11");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1583922005==0){
if(a1669722568==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1583922005 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("12");
	    }
//******************Transformed code started****************************
if(a1583922005==0){
 }
 else {}
if(a1669722568==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1583922005 ==0) || (a1669722568==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("13");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a469914660==0){
if(a1868984816==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a469914660 ==0) && (a1868984816 ==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("14");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1136264456==0){
if(a1041640432==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1136264456==0) && (a1041640432 ==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("15");
	    }
//******************Transformed code started****************************
if(a2077863541==0){
 }
 else {}
if(a1868984816==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a2077863541 ==0) || (a1868984816 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("16");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1583922005==0){
if(a1669722568==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1583922005 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("17");
	    }
//******************Transformed code started****************************
if(a1591641889==0){
 }
 else {}
if(a1868984816==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1591641889 ==0) || (a1868984816 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("18");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1583922005==0){
if(a1669722568==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1583922005 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("19");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1591641889==0){
if(a1933271548==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1591641889 ==0) && (a1933271548 ==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("20");
	    }
//******************Transformed code started****************************
if(a1431178715==0){
 }
 else {}
if(a1041640432==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1431178715==0) || (a1041640432 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("21");
	    }
//******************Transformed code started****************************
if(a1933271548==0){
 }
 else {}
if(a1669722568==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1933271548 ==0) || (a1669722568==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("22");
	    }
//******************Transformed code started****************************
if(a927814483==0){
 }
 else {}
if(a43901077==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a927814483 ==0) || (a43901077==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("23");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1384943560==0){
if(a1669722568==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1384943560==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("24");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1583922005==0){
if(a1669722568==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1583922005 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("25");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1554992028==0){
if(a1669722568==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1554992028 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("26");
	    }
//******************Transformed code started****************************
if(a1136264456==0){
 }
 else {}
if(a1041640432==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1136264456==0) || (a1041640432 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("27");
	    }
//******************Transformed code started****************************
if(a1944816302==0){
 }
 else {}
if(a1041640432==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1944816302==0) || (a1041640432 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("28");
	    }
//******************Transformed code started****************************
if(a1591641889==0){
 }
 else {}
if(a1868984816==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1591641889 ==0) || (a1868984816 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("29");
	    }
//******************Transformed code started****************************
if(a1554992028==0){
 }
 else {}
if(a1933271548==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1554992028 ==0) || (a1933271548 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("30");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1450658394==0){
if(a1669722568==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1450658394 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("31");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1933271548==0){
if(a1669722568==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1933271548 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("32");
	    }
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1933271548==0){
if(a1669722568==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1933271548 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("33");
	    }
//******************Transformed code started****************************
if(a231305105==0){
 }
 else {}
if(a1868984816==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a231305105 ==0) || (a1868984816 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("34");
	    }
//******************Transformed code started****************************
if(a1491567675==0){
 }
 else {}
if(a43901077==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
	    if((a1491567675 ==0) || (a43901077==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("35");
	    }
		
	}

private  void calculateOutputm37(boolean input) {
//******************Transformed code started****************************
if(a1669722568==0){
 }
 else {}
if(cf==false){
if(a1554992028==0){}
 else{}
 }
 else {}
if(input==false){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) && (a1551570219==0) || (cf==false) && (a1554992028 ==0) || (a1669722568==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1868984816 = 10;
    	a2077863541 = 10; 
    	System.out.println("Z");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(cf==false){
if(a1551570219==0){}
 else{}
 }
 else {}
if(a1554992028==0){
if(a1669722568==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) || (a1554992028 ==0) && (a1669722568==0) || (cf==false) && (a1551570219==0)){
    	cf = false;
    	a1669722568 = 0;
    	a1450658394 = 12; 
    	System.out.println("W");
    } 
//******************Transformed code started****************************
if(a1554992028==0){
 }
 else {}
if(cf==false){
 }
 else {}
if(a1551570219==0){
 }
 else {}
if(a1669722568==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1551570219==0) || (cf==false) || (a1669722568==0) && (input==false) || (a1554992028 ==0)){
    	cf = false;
    	a1669722568 = 0;
    	a1583922005 = 10; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm1(boolean input) {
//******************Transformed code started****************************
if(cf==false){
if(a1554992028==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a1554992028 ==0)){
    	calculateOutputm37(input);
    } 
}
private  void calculateOutputm41(boolean input) {
//******************Transformed code started****************************
if(a1669722568==0){
 }
 else {}
if(cf==false){
if(a1583922005==0){}
 else{}
 }
 else {}
if(input==false){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1669722568==0) || (input==false) && (a1551570219==0) || (cf==false) && (a1583922005 ==0)){
    	cf = false;
    	a1669722568 = 0;
    	a1554992028 = 15; 
    	System.out.println("S");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a1583922005==0){
 }
 else {}
if(a1669722568==0){
 }
 else {}
if(cf==false){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1669722568==0) || (cf==false) && (a1551570219==0) || (a1583922005 ==0) || (input==false)){
    	cf = false;
    	 
    	System.out.println("U");
    } 
//******************Transformed code started****************************
if(a1669722568==0){
 }
 else {}
if(input==false){
if(a1551570219==0){}
 else{}
 }
 else {}
if(a1583922005==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1669722568==0) || (a1583922005 ==0) && (cf==false) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a1041640432 = 6;
    	a1551570219 = 0;
    	a1379546326 = 8; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm2(boolean input) {
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1583922005==0){
 }
 else {}
//******************Transformed code end****************************
    if((a1583922005 ==0) || (cf==false)) {
    	calculateOutputm41(input);
    } 
}
private  void calculateOutputm58(boolean input) {
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a1551570219==0){
if(a1669722568==0){}
 else{}
 }
 else {}
if(a1450658394==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) || (a1450658394 ==0) && (cf==false) || (a1551570219==0) && (a1669722568==0)){
    	cf = false;
    	 
    	System.out.println("Y");
    } 
//******************Transformed code started****************************
if(a1450658394==0){
 }
 else {}
if(cf==false){
if(a1551570219==0){}
 else{}
 }
 else {}
if(a1669722568==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1669722568==0) && (input==false) || (a1450658394 ==0) || (cf==false) && (a1551570219==0)){
    	cf = false;
    	a1136264456 = 0;
    	a1551570219 = 0;
    	a1041640432 = 8; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm59(boolean input) {
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1551570219==0){
if(input==false){}
 else{}
 }
 else {}
if(a1669722568==0){
if(a1450658394==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1669722568==0) && (a1450658394 ==0) || (cf==false) || (a1551570219==0) && (input==false)){
    	cf = false;
    	a1551570219 = 0;
    	a43901077 = 0;
    	a1944816302 = 0; 
    	System.out.println("T");
    } 
//******************Transformed code started****************************
if(a1450658394==0){
 }
 else {}
if(a1551570219==0){
 }
 else {}
if(cf==false){
if(input==false){}
 else{}
if(a1669722568==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1551570219==0) || (a1450658394 ==0) || (cf==false) && (input==false) && (a1669722568==0)){
    	cf = false;
    	a510889416 = 0;
    	a1551570219 = 0;
    	a1933271548 = 6; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm5(boolean input) {
//******************Transformed code started****************************
if(a1450658394==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1450658394 ==0) && (cf==false)) {
    	calculateOutputm58(input);
    } 
//******************Transformed code started****************************
if(a1450658394==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a1450658394 ==0)){
    	calculateOutputm59(input);
    } 
}
private  void calculateOutputm65(boolean input) {
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1041640432==0){
 }
 else {}
if(a1136264456==0){
 }
 else {}
if(cf==false){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1136264456==0) || (cf==false) && (input==false) || (a1041640432 ==0) || (a1551570219==0)){
    	cf = false;
    	a1669722568 = 0;
    	a1551570219 = 0;
    	a1450658394 = 12; 
    	System.out.println("W");
    } 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1041640432==0){
if(a1551570219==0){}
 else{}
 }
 else {}
if(input==false){
if(a1136264456==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) && (a1136264456==0) || (cf==false) || (a1041640432 ==0) && (a1551570219==0)){
    	cf = false;
    	a43901077 = 0;
    	a1551570219 = 0;
    	a1944816302 = 0; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm7(boolean input) {
//******************Transformed code started****************************
if(a1136264456==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1136264456==0) && (cf==false)) {
    	calculateOutputm65(input);
    } 
}
private  void calculateOutputm69(boolean input) {
//******************Transformed code started****************************
if(a1041640432==0){
 }
 else {}
if(cf==false){
if(input==false){}
 else{}
 }
 else {}
if(a1379546326==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1041640432 ==0) || (a1379546326 ==0) && (a1551570219==0) || (cf==false) && (input==false)){
    	cf = false;
    	a43901077 = 0;
    	a1551570219 = 0;
    	a927814483 = 9; 
    	System.out.println("T");
    } 
//******************Transformed code started****************************
if(a1379546326==0){
if(a1041640432==0){}
 else{}
 }
 else {}
if(cf==false){
if(input==false){}
 else{}
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1379546326 ==0) && (a1041640432 ==0) || (cf==false) && (input==false) && (a1551570219==0)){
    	cf = false;
    	a1431178715 = 0;
    	a1041640432 = 9; 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(cf==false){
if(a1379546326==0){}
 else{}
 }
 else {}
if(input==false){
if(a1041640432==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1551570219==0) || (input==false) && (a1041640432 ==0) || (cf==false) && (a1379546326 ==0)){
    	cf = false;
    	 
    	System.out.println("W");
    } 
}
private  void calculateOutputm71(boolean input) {
//******************Transformed code started****************************
if(a1379546326==0){
 }
 else {}
if(a1551570219==0){
if(a1041640432==0){}
 else{}
 }
 else {}
if(cf==false){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (input==false) || (a1379546326 ==0) || (a1551570219==0) && (a1041640432 ==0)){
    	cf = false;
    	a1379546326 = 10; 
    	System.out.println("W");
    } 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(input==false){
if(a1551570219==0){}
 else{}
 }
 else {}
if(a1041640432==0){
if(a1379546326==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1041640432 ==0) && (a1379546326 ==0) || (cf==false) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a43901077 = 0;
    	a1551570219 = 0;
    	a1294378386 = 10; 
    	System.out.println("Y");
    } 
//******************Transformed code started****************************
if(a1041640432==0){
 }
 else {}
if(input==false){
if(a1379546326==0){}
 else{}
 }
 else {}
if(cf==false){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1041640432 ==0) || (cf==false) && (a1551570219==0) || (input==false) && (a1379546326 ==0)){
    	cf = false;
    	a1933271548 = 10;
    	a1551570219 = 0;
    	a1554992028 = 8; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm8(boolean input) {
//******************Transformed code started****************************
if(cf==false){
if(a1379546326==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a1379546326 ==0)){
    	calculateOutputm69(input);
    } 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1379546326==0){
 }
 else {}
//******************Transformed code end****************************
    if((a1379546326 ==0) || (cf==false)) {
    	calculateOutputm71(input);
    } 
}
private  void calculateOutputm77(boolean input) {
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a1431178715==0){
if(a1041640432==0){}
 else{}
 }
 else {}
if(a1551570219==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) || (a1551570219==0) && (cf==false) || (a1431178715==0) && (a1041640432 ==0)){
    	cf = false;
    	a2108703896 = 0;
    	a1551570219 = 0;
    	a1933271548 = 4; 
    	System.out.println("T");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a1431178715==0){
if(a1551570219==0){}
 else{}
 }
 else {}
if(cf==false){
if(a1041640432==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a1041640432 ==0) || (input==false) || (a1431178715==0) && (a1551570219==0)){
    	cf = false;
    	a43901077 = 0;
    	a1551570219 = 0;
    	a1294378386 = 11; 
    	System.out.println("S");
    } 
}
private  void calculateOutputm79(boolean input) {
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(input==false){
if(a1041640432==0){}
 else{}
 }
 else {}
if(cf==false){
if(a1431178715==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a1431178715==0) || (a1551570219==0) || (input==false) && (a1041640432 ==0)){
    	cf = false;
    	 
    	System.out.println("U");
    } 
//******************Transformed code started****************************
if(a1431178715==0){
 }
 else {}
if(cf==false){
if(a1041640432==0){}
 else{}
 }
 else {}
if(a1551570219==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1551570219==0) && (input==false) || (a1431178715==0) || (cf==false) && (a1041640432 ==0)){
    	cf = false;
    	 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(a1431178715==0){
 }
 else {}
if(cf==false){
if(a1041640432==0){}
 else{}
 }
 else {}
if(a1551570219==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1431178715==0) || (a1551570219==0) && (input==false) || (cf==false) && (a1041640432 ==0)){
    	cf = false;
    	a1649592707 = 0;
    	a1041640432 = 11; 
    	System.out.println("V");
    } 
//******************Transformed code started****************************
if(a1431178715==0){
 }
 else {}
if(cf==false){
if(a1041640432==0){}
 else{}
 }
 else {}
if(input==false){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) && (a1551570219==0) || (cf==false) && (a1041640432 ==0) || (a1431178715==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1669722568 = 0;
    	a1933271548 = 9; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm11(boolean input) {
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1431178715==0){
 }
 else {}
//******************Transformed code end****************************
    if((a1431178715==0) || (cf==false)) {
    	calculateOutputm77(input);
    } 
//******************Transformed code started****************************
if(a1431178715==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1431178715==0) && (cf==false)) {
    	calculateOutputm79(input);
    } 
}
private  void calculateOutputm81(boolean input) {
//******************Transformed code started****************************
if(a1944816302==0){
 }
 else {}
if(a1041640432==0){
if(a1551570219==0){}
 else{}
 }
 else {}
if(input==false){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) && (cf==false) || (a1944816302==0) || (a1041640432 ==0) && (a1551570219==0)){
    	cf = false;
    	a1868984816 = 8;
    	a1551570219 = 0;
    	a469914660 = 12; 
    	System.out.println("S");
    } 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(input==false){
if(a1041640432==0){}
 else{}
 }
 else {}
if(a1944816302==0){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a1944816302==0) && (a1551570219==0) || (input==false) && (a1041640432 ==0)){
    	cf = false;
    	a1431178715 = 0;
    	a1041640432 = 9; 
    	System.out.println("U");
    } 
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(input==false){
if(a1041640432==0){}
 else{}
 }
 else {}
if(cf==false){
if(a1944816302==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1551570219==0) || (cf==false) && (a1944816302==0) || (input==false) && (a1041640432 ==0)){
    	cf = false;
    	a43901077 = 0;
    	a1551570219 = 0;
    	a1294378386 = 10; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm12(boolean input) {
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1944816302==0){
 }
 else {}
//******************Transformed code end****************************
    if((a1944816302==0) || (cf==false)) {
    	calculateOutputm81(input);
    } 
}
private  void calculateOutputm85(boolean input) {
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(input==false){
if(a1551570219==0){}
 else{}
 }
 else {}
if(a1649592707==0){
if(a1041640432==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1649592707==0) && (a1041640432 ==0) || (cf==false) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1868984816 = 9;
    	a1591641889 = 5; 
    	System.out.println("U");
    } 
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(input==false){
if(cf==false){}
 else{}
 }
 else {}
if(a1041640432==0){
if(a1649592707==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1041640432 ==0) && (a1649592707==0) || (input==false) && (cf==false) || (a1551570219==0)){
    	cf = false;
    	 
    	System.out.println("W");
    } 
//******************Transformed code started****************************
if(a1041640432==0){
 }
 else {}
if(input==false){
if(a1551570219==0){}
 else{}
 }
 else {}
if(a1649592707==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1041640432 ==0) || (a1649592707==0) && (cf==false) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a1431178715 = 0;
    	a1041640432 = 9; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm13(boolean input) {
//******************Transformed code started****************************
if(a1649592707==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a1649592707==0)){
    	calculateOutputm85(input);
    } 
}
private  void calculateOutputm95(boolean input) {
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1649592707==0){
if(input==false){}
 else{}
 }
 else {}
if(a1551570219==0){
if(a1933271548==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a1551570219==0) && (a1933271548 ==0) || (a1649592707==0) && (input==false)){
    	cf = false;
    	a1669722568 = 0;
    	a1551570219 = 0;
    	a1450658394 = 14; 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(a1649592707==0){
 }
 else {}
if(a1933271548==0){
 }
 else {}
if(input==false){
if(a1551570219==0){}
 else{}
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1933271548 ==0) || (a1649592707==0) || (input==false) && (a1551570219==0) && (cf==false)){
    	cf = false;
    	a43901077 = 0;
    	a1551570219 = 0;
    	a1944816302 = 0; 
    	System.out.println("W");
    } 
//******************Transformed code started****************************
if(a1933271548==0){
 }
 else {}
if(cf==false){
if(a1551570219==0){}
 else{}
 }
 else {}
if(a1649592707==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1649592707==0) && (input==false) || (cf==false) && (a1551570219==0) || (a1933271548 ==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1136264456 = 0;
    	a1041640432 = 5; 
    	System.out.println("T");
    } 
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1649592707==0){
 }
 else {}
if(cf==false){
if(input==false){}
 else{}
if(a1933271548==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1649592707==0) || (a1551570219==0) || (cf==false) && (input==false) && (a1933271548 ==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1649592707 = 0;
    	a1041640432 = 11; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm16(boolean input) {
//******************Transformed code started****************************
if(cf==false){
if(a1649592707==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a1649592707==0)){
    	calculateOutputm95(input);
    } 
}
private  void calculateOutputm96(boolean input) {
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(cf==false){
if(a510889416==0){}
 else{}
 }
 else {}
if(a1933271548==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1551570219==0) || (a1933271548 ==0) && (input==false) || (cf==false) && (a510889416==0)){
    	cf = false;
    	 
    	System.out.println("S");
    } 
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(cf==false){
 }
 else {}
if(a510889416==0){
 }
 else {}
if(input==false){
if(a1933271548==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a510889416==0) || (cf==false) || (input==false) && (a1933271548 ==0) || (a1551570219==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1669722568 = 0;
    	a1450658394 = 12; 
    	System.out.println("W");
    } 
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(cf==false){
if(a1933271548==0){}
 else{}
 }
 else {}
if(a510889416==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a510889416==0) && (input==false) || (cf==false) && (a1933271548 ==0) || (a1551570219==0)){
    	cf = false;
    	a1868984816 = 8;
    	a1551570219 = 0;
    	a469914660 = 12; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm97(boolean input) {
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(cf==false){
if(a510889416==0){}
 else{}
 }
 else {}
if(a1933271548==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1551570219==0) || (a1933271548 ==0) && (input==false) || (cf==false) && (a510889416==0)){
    	cf = false;
    	a1551570219 = 0;
    	a43901077 = 0;
    	a1944816302 = 0; 
    	System.out.println("W");
    } 
//******************Transformed code started****************************
if(a1933271548==0){
 }
 else {}
if(a510889416==0){
if(input==false){}
 else{}
 }
 else {}
if(cf==false){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1933271548 ==0) || (cf==false) && (a1551570219==0) || (a510889416==0) && (input==false)){
    	cf = false;
    	a1551570219 = 0;
    	a1669722568 = 0;
    	a1450658394 = 14; 
    	System.out.println("V");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a1933271548==0){
 }
 else {}
if(cf==false){
if(a510889416==0){}
 else{}
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1933271548 ==0) || (input==false) || (cf==false) && (a510889416==0) && (a1551570219==0)){
    	cf = false;
    	a1649592707 = 0;
    	a1933271548 = 5; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm17(boolean input) {
//******************Transformed code started****************************
if(a510889416==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a510889416==0) && (cf==false)) {
    	calculateOutputm96(input);
    } 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a510889416==0){
 }
 else {}
//******************Transformed code end****************************
    if((a510889416==0) || (cf==false)) {
    	calculateOutputm97(input);
    } 
}
private  void calculateOutputm113(boolean input) {
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a43901077==0){
 }
 else {}
if(input==false){
if(a1944816302==0){}
 else{}
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a43901077==0) || (a1551570219==0) || (input==false) && (a1944816302==0) && (cf==false)){
    	cf = false;
    	 
    	System.out.println("W");
    } 
//******************Transformed code started****************************
if(a1944816302==0){
 }
 else {}
if(input==false){
 }
 else {}
if(a1551570219==0){
 }
 else {}
if(cf==false){
if(a43901077==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1551570219==0) || (cf==false) && (a43901077==0) || (input==false) || (a1944816302==0)){
    	cf = false;
    	a1649592707 = 0;
    	a1551570219 = 0;
    	a1933271548 = 5; 
    	System.out.println("V");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a1551570219==0){
 }
 else {}
if(cf==false){
if(a1944816302==0){}
 else{}
if(a43901077==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1551570219==0) || (input==false) || (cf==false) && (a1944816302==0) && (a43901077==0)){
    	cf = false;
    	a1669722568 = 0;
    	a1551570219 = 0;
    	a1933271548 = 5; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm22(boolean input) {
//******************Transformed code started****************************
if(a1944816302==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a1944816302==0)){
    	calculateOutputm113(input);
    } 
}
private  void calculateOutputm119(boolean input) {
//******************Transformed code started****************************
if(a1294378386==0){
 }
 else {}
if(input==false){
if(a43901077==0){}
 else{}
 }
 else {}
if(cf==false){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1294378386 ==0) || (cf==false) && (a1551570219==0) || (input==false) && (a43901077==0)){
    	cf = false;
    	a1041640432 = 6;
    	a1551570219 = 0;
    	a1379546326 = 12; 
    	System.out.println("T");
    } 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(input==false){
if(a1551570219==0){}
 else{}
 }
 else {}
if(a1294378386==0){
if(a43901077==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1294378386 ==0) && (a43901077==0) || (cf==false) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1669722568 = 0;
    	a1384943560 = 0; 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(a1294378386==0){
 }
 else {}
if(input==false){
if(a1551570219==0){}
 else{}
 }
 else {}
if(cf==false){
if(a43901077==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a43901077==0) || (a1294378386 ==0) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1431178715 = 0;
    	a1041640432 = 9; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm120(boolean input) {
//******************Transformed code started****************************
if(a43901077==0){
 }
 else {}
if(cf==false){
 }
 else {}
if(a1294378386==0){
 }
 else {}
if(input==false){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1294378386 ==0) || (cf==false) || (a43901077==0) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a1868984816 = 10;
    	a1551570219 = 0;
    	a2077863541 = 11; 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(a43901077==0){
 }
 else {}
if(cf==false){
if(input==false){}
 else{}
 }
 else {}
if(a1551570219==0){
if(a1294378386==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1551570219==0) && (a1294378386 ==0) || (a43901077==0) || (cf==false) && (input==false)){
    	cf = false;
    	a1669722568 = 0;
    	a1551570219 = 0;
    	a1583922005 = 10; 
    	System.out.println("U");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a1551570219==0){
 }
 else {}
if(a1294378386==0){
 }
 else {}
if(a43901077==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1294378386 ==0) || (a1551570219==0) || (a43901077==0) && (cf==false) || (input==false)){
    	cf = false;
    	a1796618233 = 0;
    	a1551570219 = 0;
    	a1868984816 = 13; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm23(boolean input) {
//******************Transformed code started****************************
if(a1294378386==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a1294378386 ==0)){
    	calculateOutputm119(input);
    } 
//******************Transformed code started****************************
if(cf==false){
if(a1294378386==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a1294378386 ==0)){
    	calculateOutputm120(input);
    } 
}
private  void calculateOutputm129(boolean input) {
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(cf==false){
if(a469914660==0){}
 else{}
 }
 else {}
if(a1868984816==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1868984816 ==0) && (input==false) || (a1551570219==0) || (cf==false) && (a469914660 ==0)){
    	cf = false;
    	a1551570219 = 0;
    	a43901077 = 0;
    	a1944816302 = 0; 
    	System.out.println("T");
    } 
//******************Transformed code started****************************
if(a1868984816==0){
 }
 else {}
if(a1551570219==0){
if(input==false){}
 else{}
 }
 else {}
if(cf==false){
if(a469914660==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1868984816 ==0) || (cf==false) && (a469914660 ==0) || (a1551570219==0) && (input==false)){
    	cf = false;
    	a1868984816 = 9;
    	a1591641889 = 4; 
    	System.out.println("S");
    } 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1868984816==0){
if(a1551570219==0){}
 else{}
 }
 else {}
if(input==false){
if(a469914660==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (input==false) && (a469914660 ==0) || (a1868984816 ==0) && (a1551570219==0)){
    	cf = false;
    	a469914660 = 14; 
    	System.out.println("U");
    } 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(input==false){
if(a1551570219==0){}
 else{}
 }
 else {}
if(a1868984816==0){
if(a469914660==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1868984816 ==0) && (a469914660 ==0) || (cf==false) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1669722568 = 0;
    	a1450658394 = 12; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm27(boolean input) {
//******************Transformed code started****************************
if(a469914660==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a469914660 ==0) && (cf==false)) {
    	calculateOutputm129(input);
    } 
}
private  void calculateOutputm131(boolean input) {
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1591641889==0){
if(input==false){}
 else{}
 }
 else {}
if(cf==false){
if(a1868984816==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1551570219==0) || (cf==false) && (a1868984816 ==0) || (a1591641889 ==0) && (input==false)){
    	cf = false;
    	a1868984816 = 11;
    	a927814483 = 14; 
    	System.out.println("U");
    } 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1868984816==0){
if(a1591641889==0){}
 else{}
 }
 else {}
if(input==false){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (input==false) && (a1551570219==0) || (a1868984816 ==0) && (a1591641889 ==0)){
    	cf = false;
    	a510889416 = 0;
    	a1551570219 = 0;
    	a1933271548 = 6; 
    	System.out.println("S");
    } 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1551570219==0){
if(a1591641889==0){}
 else{}
 }
 else {}
if(input==false){
if(a1868984816==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) && (a1868984816 ==0) || (cf==false) || (a1551570219==0) && (a1591641889 ==0)){
    	cf = false;
    	a1669722568 = 0;
    	a1551570219 = 0;
    	a1450658394 = 9; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm137(boolean input) {
//******************Transformed code started****************************
if(a1868984816==0){
 }
 else {}
if(input==false){
if(a1551570219==0){}
 else{}
 }
 else {}
if(a1591641889==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1868984816 ==0) || (a1591641889 ==0) && (cf==false) || (input==false) && (a1551570219==0)){
    	cf = false;
    	 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(cf==false){
 }
 else {}
if(a1551570219==0){
 }
 else {}
if(a1868984816==0){
if(a1591641889==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1868984816 ==0) && (a1591641889 ==0) || (a1551570219==0) || (cf==false) || (input==false)){
    	cf = false;
    	a1796618233 = 0;
    	a1868984816 = 13; 
    	System.out.println("V");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a1591641889==0){
if(a1551570219==0){}
 else{}
 }
 else {}
if(cf==false){
if(a1868984816==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) || (cf==false) && (a1868984816 ==0) || (a1591641889 ==0) && (a1551570219==0)){
    	cf = false;
    	a1551570219 = 0;
    	a43901077 = 0;
    	a1944816302 = 0; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm28(boolean input) {
//******************Transformed code started****************************
if(a1591641889==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1591641889 ==0) && (cf==false)) {
    	calculateOutputm131(input);
    } 
//******************Transformed code started****************************
if(a1591641889==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a1591641889 ==0)){
    	calculateOutputm137(input);
    } 
}
private  void calculateOutputm139(boolean input) {
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1551570219==0){
if(a1868984816==0){}
 else{}
 }
 else {}
if(input==false){
if(a2077863541==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) && (a2077863541 ==0) || (cf==false) || (a1551570219==0) && (a1868984816 ==0)){
    	cf = false;
    	a1551570219 = 0;
    	a43901077 = 0;
    	a1294378386 = 11; 
    	System.out.println("T");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(cf==false){
 }
 else {}
if(a1868984816==0){
if(a2077863541==0){}
 else{}
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (input==false) || (a1868984816 ==0) && (a2077863541 ==0) && (a1551570219==0)){
    	cf = false;
    	a1669722568 = 0;
    	a1551570219 = 0;
    	a1583922005 = 10; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm29(boolean input) {
//******************Transformed code started****************************
if(a2077863541==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a2077863541 ==0) && (cf==false)) {
    	calculateOutputm139(input);
    } 
}
private  void calculateOutputm145(boolean input) {
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(a1868984816==0){
 }
 else {}
if(input==false){
if(cf==false){}
 else{}
if(a927814483==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1868984816 ==0) || (a1551570219==0) || (input==false) && (cf==false) && (a927814483 ==0)){
    	cf = false;
    	a1868984816 = 9;
    	a1591641889 = 4; 
    	System.out.println("S");
    } 
}
private  void calculateOutputm30(boolean input) {
//******************Transformed code started****************************
if(a927814483==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a927814483 ==0) && (cf==false)) {
    	calculateOutputm145(input);
    } 
}
private  void calculateOutputm152(boolean input) {
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(cf==false){
 }
 else {}
if(a1796618233==0){
 }
 else {}
if(a1868984816==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1868984816 ==0) && (input==false) || (a1796618233==0) || (cf==false) || (a1551570219==0)){
    	cf = false;
    	a43901077 = 0;
    	a1551570219 = 0;
    	a1944816302 = 0; 
    	System.out.println("W");
    } 
//******************Transformed code started****************************
if(input==false){
 }
 else {}
if(a1796618233==0){
if(a1868984816==0){}
 else{}
 }
 else {}
if(a1551570219==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((input==false) || (a1551570219==0) && (cf==false) || (a1796618233==0) && (a1868984816 ==0)){
    	cf = false;
    	a1868984816 = 9;
    	a1591641889 = 11; 
    	System.out.println("X");
    } 
//******************Transformed code started****************************
if(a1868984816==0){
 }
 else {}
if(a1796618233==0){
if(cf==false){}
 else{}
 }
 else {}
if(a1551570219==0){
if(input==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((a1551570219==0) && (input==false) || (a1796618233==0) && (cf==false) || (a1868984816 ==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1933271548 = 9;
    	a927814483 = 9; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm32(boolean input) {
//******************Transformed code started****************************
if(a1796618233==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a1796618233==0)){
    	calculateOutputm152(input);
    } 
}



public  void calculateOutput(boolean input) {
 	cf = true;
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a1551570219==0)){
//******************Transformed code started****************************
if(a1669722568==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a1669722568==0) && (cf==false)) {
    		calculateOutputm1(input);
    	} 
//******************Transformed code started****************************
if(a1669722568==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a1669722568==0) && (cf==false)) {
    		calculateOutputm2(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1669722568==0){
 }
 else {}
//******************Transformed code end****************************
    	if((a1669722568==0) || (cf==false)) {
    		calculateOutputm5(input);
    	} 
    } 
//******************Transformed code started****************************
if(cf==false){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a1551570219==0)){
//******************Transformed code started****************************
if(a1041640432==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a1041640432 ==0) && (cf==false)) {
    		calculateOutputm7(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1041640432==0){
 }
 else {}
//******************Transformed code end****************************
    	if((a1041640432 ==0) || (cf==false)) {
    		calculateOutputm8(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
if(a1041640432==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) && (a1041640432 ==0)){
    		calculateOutputm11(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1041640432==0){
 }
 else {}
//******************Transformed code end****************************
    	if((a1041640432 ==0) || (cf==false)) {
    		calculateOutputm12(input);
    	} 
//******************Transformed code started****************************
if(a1041640432==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a1041640432 ==0) && (cf==false)) {
    		calculateOutputm13(input);
    	} 
    } 
//******************Transformed code started****************************
if(cf==false){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a1551570219==0)){
//******************Transformed code started****************************
if(a1933271548==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) || (a1933271548 ==0)){
    		calculateOutputm16(input);
    	} 
//******************Transformed code started****************************
if(a1933271548==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a1933271548 ==0) && (cf==false)) {
    		calculateOutputm17(input);
    	} 
    } 
//******************Transformed code started****************************
if(cf==false){
if(a1551570219==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) && (a1551570219==0)){
//******************Transformed code started****************************
if(a43901077==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) || (a43901077==0)){
    		calculateOutputm22(input);
    	} 
//******************Transformed code started****************************
if(a43901077==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a43901077==0) && (cf==false)) {
    		calculateOutputm23(input);
    	} 
    } 
//******************Transformed code started****************************
if(a1551570219==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    if((cf==false) || (a1551570219==0)){
//******************Transformed code started****************************
if(a1868984816==0){
if(cf==false){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((a1868984816 ==0) && (cf==false)) {
    		calculateOutputm27(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
if(a1868984816==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) && (a1868984816 ==0)){
    		calculateOutputm28(input);
    	} 
//******************Transformed code started****************************
if(a1868984816==0){
 }
 else {}
if(cf==false){
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) || (a1868984816 ==0)){
    		calculateOutputm29(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
if(a1868984816==0){}
 else{}
 }
 else {}
//******************Transformed code end****************************
    	if((cf==false) && (a1868984816 ==0)){
    		calculateOutputm30(input);
    	} 
//******************Transformed code started****************************
if(cf==false){
 }
 else {}
if(a1868984816==0){
 }
 else {}
//******************Transformed code end****************************
    	if((a1868984816 ==0) || (cf==false)) {
    		calculateOutputm32(input);
    	} 
    } 

    errorCheck();
    if(cf==false)
    	throw new IllegalArgumentException("Current state has no transition for this input!");
}


public static void main() throws Exception 
	{
	     // init system and input reader
            Problem10_RERS2018jpct eca = new Problem10_RERS2018jpct();
        int a=0;
	int x;
        int y;
         
        x = Cute.input.Integer();
        y = Cute.input.Integer();
		boolean input = Cute.input.Boolean();
			// main i/o-loop
            while(a<10) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
//******************Transformed code started****************************
if(x>199){
if(x>y){}
 else{}
 }
 else {}
//******************Transformed code end****************************
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                	 eca.calculateOutput(input);
					 
				}
				
//******************Transformed code started****************************
if(x>299){
if(x<y){}
 else{}
 }
 else {}
//******************Transformed code end****************************
				if (x>299 && x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutput(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
	}
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
