
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class jpct_AssertTest2jpct_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public jpct_AssertTest2jpct_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(-210013786);
        input[i++] = new Integer(-234159169);
        input[i++] = new Integer(1303037481);
        input[i++] = new Integer(1210775540);
        input[i++] = new Integer(-171310728);
        input[i++] = new Integer(289929531);
        input[i++] = new Integer(-2092472750);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(-210013786);
        input[i++] = new Integer(150);
        input[i++] = new Integer(1303037481);
        input[i++] = new Integer(1210775540);
        input[i++] = new Integer(-171310728);
        input[i++] = new Integer(289929531);
        input[i++] = new Integer(-2092472750);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(150);
        input[i++] = new Integer(1303037481);
        input[i++] = new Integer(1210775540);
        input[i++] = new Integer(-171310728);
        input[i++] = new Integer(289929531);
        input[i++] = new Integer(-2092472750);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(150);
        input[i++] = new Integer(1303037481);
        input[i++] = new Integer(1210775540);
        input[i++] = new Integer(-171310728);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(-2092472750);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(150);
        input[i++] = new Integer(1303037481);
        input[i++] = new Integer(9);
        input[i++] = new Integer(-171310728);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(-2092472750);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(150);
        input[i++] = new Integer(1303037481);
        input[i++] = new Integer(9);
        input[i++] = new Integer(-171310728);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(299);
        input[i++] = new Integer(1303037481);
        input[i++] = new Integer(9);
        input[i++] = new Integer(-171310728);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test8(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(299);
        input[i++] = new Integer(1303037481);
        input[i++] = new Integer(9);
        input[i++] = new Integer(101);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test9(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(299);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(101);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test10(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(299);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(101);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test11(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(299);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test12(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(0);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test13(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(0);
        input[i++] = new Integer(90);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test14(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(0);
        input[i++] = new Integer(90);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test15(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(0);
        input[i++] = new Integer(90);
        input[i++] = new Integer(10);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test21(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(90);
        input[i++] = new Integer(10);
        input[i++] = new Integer(0);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test22(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1500);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(90);
        input[i++] = new Integer(900);
        input[i++] = new Integer(0);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test30(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(0);
        input[i++] = new Integer(9);
        input[i++] = new Integer(901);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(900);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test76(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(150);
        input[i++] = new Integer(9);
        input[i++] = new Integer(1501);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test129(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(201);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(9);
        input[i++] = new Integer(10);
        input[i++] = new Integer(-1);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(89);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

    public void test183(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(9);
        input[i++] = new Integer(9);
        input[i++] = new Integer(2000);
        input[i++] = new Integer(2001);
        input[i++] = new Integer(90);
        i=0;
        cute.Cute.input = this;
        jpct.AssertTest2jpct.main(null);
    }

}
