
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class tests_Market_Sales2_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public tests_Market_Sales2_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(1362988734);
        input[i++] = new Integer(1665737238);
        input[i++] = new Integer(310174553);
        input[i++] = new Integer(469778494);
        input[i++] = new Integer(61296244);
        input[i++] = new Integer(2025077002);
        input[i++] = new Integer(1235993918);
        i=0;
        cute.Cute.input = this;
        tests.Market_Sales2.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(310174553);
        input[i++] = new Integer(469778494);
        input[i++] = new Integer(61296244);
        input[i++] = new Integer(2025077002);
        input[i++] = new Integer(1235993918);
        i=0;
        cute.Cute.input = this;
        tests.Market_Sales2.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(101);
        input[i++] = new Integer(0);
        input[i++] = new Integer(310174553);
        input[i++] = new Integer(469778494);
        input[i++] = new Integer(61296244);
        input[i++] = new Integer(2025077002);
        input[i++] = new Integer(1235993918);
        i=0;
        cute.Cute.input = this;
        tests.Market_Sales2.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(101);
        input[i++] = new Integer(0);
        input[i++] = new Integer(310174553);
        input[i++] = new Integer(469778494);
        input[i++] = new Integer(61296244);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1235993918);
        i=0;
        cute.Cute.input = this;
        tests.Market_Sales2.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(310174553);
        input[i++] = new Integer(469778494);
        input[i++] = new Integer(61296244);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1235993918);
        i=0;
        cute.Cute.input = this;
        tests.Market_Sales2.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(400);
        input[i++] = new Integer(310174553);
        input[i++] = new Integer(469778494);
        input[i++] = new Integer(61296244);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1235993918);
        i=0;
        cute.Cute.input = this;
        tests.Market_Sales2.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(400);
        input[i++] = new Integer(310174553);
        input[i++] = new Integer(469778494);
        input[i++] = new Integer(61296244);
        input[i++] = new Integer(1);
        input[i++] = new Integer(1235993918);
        i=0;
        cute.Cute.input = this;
        tests.Market_Sales2.main(null);
    }

    public void test8(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(400);
        input[i++] = new Integer(310174553);
        input[i++] = new Integer(469778494);
        input[i++] = new Integer(61296244);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        tests.Market_Sales2.main(null);
    }

    public void test28(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(310174553);
        input[i++] = new Integer(469778494);
        input[i++] = new Integer(61296244);
        input[i++] = new Integer(1);
        input[i++] = new Integer(2);
        i=0;
        cute.Cute.input = this;
        tests.Market_Sales2.main(null);
    }

    public void test41(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(4001);
        input[i++] = new Integer(4001);
        input[i++] = new Integer(310174553);
        input[i++] = new Integer(469778494);
        input[i++] = new Integer(61296244);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        tests.Market_Sales2.main(null);
    }

    public void test76(){
        i=0;
        input = new Object[7];
        input[i++] = new Integer(101);
        input[i++] = new Integer(0);
        input[i++] = new Integer(310174553);
        input[i++] = new Integer(469778494);
        input[i++] = new Integer(61296244);
        input[i++] = new Integer(102);
        input[i++] = new Integer(103);
        i=0;
        cute.Cute.input = this;
        tests.Market_Sales2.main(null);
    }

}
