package jpct;

import cute.Cute;



public final class StringBuffer2jpct
        implements java.io.Serializable, CharSequence
{

    private char value[];
    private int count;
    private boolean shared;
    static final long serialVersionUID = 3388685877147921107L;
    public StringBuffer2jpct() {
        this(16);
    }
    public StringBuffer2jpct(int length) {
        value = new char[length];
        shared = false;
    }
    public StringBuffer2jpct(String str) {
        this(str.length() + 16);
        append(str);
    }
    public synchronized int length() {
        return count;
    }
    public synchronized int capacity() {
        return value.length;
    }
    private final void copy() {
        char newValue[] = new char[value.length];
        System.arraycopy(value, 0, newValue, 0, count);
        value = newValue;
        shared = false;
    }
    public synchronized void ensureCapacity(int minimumCapacity) {

		if (minimumCapacity > value.length) {
            expandCapacity(minimumCapacity);
        }
    }
    private void expandCapacity(int minimumCapacity) {
        int newCapacity = (value.length + 1) * 2;
        if (newCapacity < 0) {
            newCapacity = Integer.MAX_VALUE;
        } else if (minimumCapacity > newCapacity) {
            newCapacity = minimumCapacity;
        }

        char newValue[] = new char[newCapacity];
        System.arraycopy(value, 0, newValue, 0, count);
        value = newValue;
        shared = false;
    }
    public synchronized void setLength(int newLength) {
        if (newLength < 0) {
            throw new StringIndexOutOfBoundsException(newLength);
        }

        if (newLength > value.length) {
            expandCapacity(newLength);
        }

        if (count < newLength) {
            if (shared) copy();
            for (; count < newLength; count++) {
                value[count] = '\0';
            }
        } else {
            count = newLength;
            if (shared) {
                if (newLength > 0) {
                    copy();
                } else {
                    value = new char[16];
                    shared = false;
                }
            }
        }
    }
    public synchronized char charAt(int index) {
	 if (index<0)
	    {}
		else {}
		if(index >= count)
		  {}
		  else {}

//******************Transformed code started****************************
if(index>=count){
 }
 else {}
if(index<0){
 }
 else {}
//******************Transformed code end****************************
        if ((index < 0) || (index >= count)) {
            throw new StringIndexOutOfBoundsException(index);
        }
        return value[index];
    }


    public synchronized void getChars(int srcBegin, int srcEnd, char dst[], int dstBegin) {
        if (srcBegin < 0) {
            throw new StringIndexOutOfBoundsException(srcBegin);
        }
		if(srcEnd < 0)
		{
		}
		else {}
		if(srcEnd > count)
		{}
		else {}
		if(srcEnd <0)
		{}
		else {}
		if(srcEnd>count)
		{}
		else {}

//******************Transformed code started****************************
if(srcEnd>count){
 }
 else {}
if(srcEnd<0){
 }
 else {}
//******************Transformed code end****************************
        if ((srcEnd < 0) || (srcEnd > count)) {
            throw new StringIndexOutOfBoundsException(srcEnd);
        }
        if (srcBegin > srcEnd) {
            throw new StringIndexOutOfBoundsException("srcBegin > srcEnd");
        }
        System.arraycopy(value, srcBegin, dst, dstBegin, srcEnd - srcBegin);
    }

    public synchronized void setCharAt(int index, char ch) {
        if(index < 0)
		{}
		else {}
		if(index >= count)
		{}
		else {}

		if (index<0)
	    {}
		else {}
		if(index >= count)
		  {}
		  else {}


//******************Transformed code started****************************
if(index>=count){
 }
 else {}
if(index<0){
 }
 else {}
//******************Transformed code end****************************
		if ((index < 0) || (index >= count)) {
            throw new StringIndexOutOfBoundsException(index);
        }
        if (shared) copy();
        value[index] = ch;
    }

      public synchronized StringBuffer2jpct append(Object obj) {
        return append(String.valueOf(obj));
    }
    public synchronized StringBuffer2jpct append(String str) {
        if (str == null) {
            str = String.valueOf(str);
        }

        int len = str.length();
        int newcount = count + len;
        if (newcount > value.length)
            expandCapacity(newcount);
        str.getChars(0, len, value, count);
        count = newcount;
        return this;
    }
    public synchronized StringBuffer2jpct append(StringBuffer2jpct sb) {
        if (sb == null) {
            sb = NULL;
        }

        int len = sb.length();
        int newcount = count + len;
        if (newcount > value.length)
            expandCapacity(newcount);
        sb.getChars(0, len, value, count);
        count = newcount;
        return this;
    }

    private static final StringBuffer2jpct NULL =  new StringBuffer2jpct("null");
    public synchronized StringBuffer2jpct append(char str[]) {
        int len = str.length;
        int newcount = count + len;
        if (newcount > value.length)
            expandCapacity(newcount);
        System.arraycopy(str, 0, value, count, len);
        count = newcount;
        return this;
    }
    public synchronized StringBuffer2jpct append(char str[], int offset, int len) {
        int newcount = count + len;
        if (newcount > value.length)
            expandCapacity(newcount);
        System.arraycopy(str, offset, value, count, len);
        count = newcount;
        return this;
    }
    public synchronized StringBuffer2jpct append(boolean b) {
        if (b) {
            int newcount = count + 4;
            if (newcount > value.length)
                expandCapacity(newcount);
            value[count++] = 't';
            value[count++] = 'r';
            value[count++] = 'u';
            value[count++] = 'e';
        } else {
            int newcount = count + 5;
            if (newcount > value.length)
                expandCapacity(newcount);
            value[count++] = 'f';
            value[count++] = 'a';
            value[count++] = 'l';
            value[count++] = 's';
            value[count++] = 'e';
        }
        return this;
    }
    public synchronized StringBuffer2jpct append(char c) {
        int newcount = count + 1;
        if (newcount > value.length)
            expandCapacity(newcount);
        value[count++] = c;
        return this;
    }


    public synchronized StringBuffer2jpct delete(int start, int end) {
        if (start < 0)
            throw new StringIndexOutOfBoundsException(start);
        if (end > count)
            end = count;
        if (start > end)
            throw new StringIndexOutOfBoundsException();

        int len = end - start;
        if (len > 0) {
            if (shared)
                copy();
            System.arraycopy(value, start+len, value, start, count-end);
            count -= len;
        }
        return this;
    }
    public synchronized StringBuffer2jpct deleteCharAt(int index) {
        if(index < 0)
		{}
		else {}
		if(index >= count)
		{}
		else {}

		if (index<0)
	    {}
		else {}
		if(index >= count)
		  {}
		  else {}

//******************Transformed code started****************************
if(index>=count){
 }
 else {}
if(index<0){
 }
 else {}
//******************Transformed code end****************************
		if ((index < 0) || (index >= count))
            throw new StringIndexOutOfBoundsException();
        if (shared)
            copy();
        System.arraycopy(value, index+1, value, index, count-index-1);
        count--;
        return this;
    }

    public synchronized StringBuffer2jpct replace(int start, int end, String str) {
        if (start < 0)
            throw new StringIndexOutOfBoundsException(start);
        if (end > count)
            end = count;
        if (start > end)
            throw new StringIndexOutOfBoundsException();

        int len = str.length();
        int newCount = count + len - (end - start);
        if (newCount > value.length)
            expandCapacity(newCount);
        else if (shared)
            copy();

        System.arraycopy(value, end, value, start + len, count - end);
        str.getChars(0, len, value, start);
        count = newCount;
        return this;
    }

    public synchronized String substring(int start) {
        return substring(start, count);
    }

    public CharSequence subSequence(int start, int end) {
        return this.substring(start, end);
    }
    public synchronized String substring(int start, int end) {
        if (start < 0)
            throw new StringIndexOutOfBoundsException(start);
        if (end > count)
            throw new StringIndexOutOfBoundsException(end);
        if (start > end)
            throw new StringIndexOutOfBoundsException(end - start);
        return new String(value, start, end - start);
    }
    public synchronized StringBuffer2jpct insert(int index, char str[], int offset,
                                            int len) {

			if(index < 0)
			{}
			else {}
			if(index >count)
			{}
			else {}
			if (index<0)
	    {}
		else {}
		if(index > count)
		  {}
		  else {}
//******************Transformed code started****************************
if(index>count){
 }
 else {}
if(index<0){
 }
 else {}
//******************Transformed code end****************************
        if ((index < 0) || (index > count))
            throw new StringIndexOutOfBoundsException();
			if(offset < 0)
			{}
			else {}
			if(offset + len < 0)
			{}
			else {}
			if(offset + len > str.length)
			{}
			 else {}
			 if(offset <0)
			  {}
			  else {}
			  if(offset+len <0)
			  {}
			  else {}
			  if(offset+ len > str.length)
			  {}
			  else {}



        if (len < 0)
            throw new StringIndexOutOfBoundsException(len);
        int newCount = count + len;
        if (newCount > value.length)
            expandCapacity(newCount);
        else if (shared)
            copy();
        System.arraycopy(value, index, value, index + len, count - index);
        System.arraycopy(str, offset, value, index, len);
        count = newCount;
        return this;
    }
    public synchronized StringBuffer2jpct insert(int offset, Object obj) {
        return insert(offset, String.valueOf(obj));
    }
    public synchronized StringBuffer2jpct insert(int offset, String str) {
        if(offset < 0)
		{}
		else {}
		if(offset > count)
		{}
		else {}

//******************Transformed code started****************************
if(offset>count){
 }
 else {}
if(offset<0){
 }
 else {}
//******************Transformed code end****************************
		if ((offset < 0) || (offset > count)) {
            throw new StringIndexOutOfBoundsException();
        }

        if (str == null) {
            str = String.valueOf(str);
        }
        int len = str.length();
        int newcount = count + len;
        if (newcount > value.length)
            expandCapacity(newcount);
        else if (shared)
            copy();
        System.arraycopy(value, offset, value, offset + len, count - offset);
        str.getChars(0, len, value, offset);
        count = newcount;
        return this;
    }
    public synchronized StringBuffer2jpct insert(int offset, char str[]) {
	 if(offset < 0)
		{}
		else {}
		if(offset > count)
		{}
		else {}
		if(offset < 0)
		{}
		else {}
		if(offset > count)
		{}
		else {}

//******************Transformed code started****************************
if(offset>count){
 }
 else {}
if(offset<0){
 }
 else {}
//******************Transformed code end****************************
        if ((offset < 0) || (offset > count)) {
            throw new StringIndexOutOfBoundsException();
        }
        int len = str.length;
        int newcount = count + len;
        if (newcount > value.length)
            expandCapacity(newcount);
        else if (shared)
            copy();
        System.arraycopy(value, offset, value, offset + len, count - offset);
        System.arraycopy(str, 0, value, offset, len);
        count = newcount;
        return this;
    }
    public StringBuffer2jpct insert(int offset, boolean b) {
        return insert(offset, String.valueOf(b));
    }
    public synchronized StringBuffer2jpct insert(int offset, char c) {
        int newcount = count + 1;
        if (newcount > value.length)
            expandCapacity(newcount);
        else if (shared)
            copy();
        System.arraycopy(value, offset, value, offset + 1, count - offset);
        value[offset] = c;
        count = newcount;
        return this;
    }
    public StringBuffer2jpct insert(int offset, int i) {
        return insert(offset, String.valueOf(i));
    }
    public StringBuffer2jpct insert(int offset, long l) {
        return insert(offset, String.valueOf(l));
    }
    public StringBuffer2jpct insert(int offset, float f) {
        return insert(offset, String.valueOf(f));
    }
    public StringBuffer2jpct insert(int offset, double d) {
        return insert(offset, String.valueOf(d));
    }
    public synchronized StringBuffer2jpct reverse() {
        if (shared) copy();
        int n = count - 1;
        for (int j = (n-1) >> 1; j >= 0; --j) {
            char temp = value[j];
            value[j] = value[n - j];
            value[n - j] = temp;
        }
        return this;
    }
    public String toString() {
	return new String(value);
    }
    final void setShared() { shared = true; }
    final char[] getValue() { return value; }
    private synchronized void readObject(java.io.ObjectInputStream s)
            throws java.io.IOException, ClassNotFoundException {
        s.defaultReadObject();
        value = (char[]) value.clone();
        shared = false;
    }

    public static void main(String[] args) {
        StringBuffer2jpct sb1 = new StringBuffer2jpct();
        StringBuffer2jpct sb2 = new StringBuffer2jpct();
        for(int i=0;i<1;i++){
            (new MyThread1(sb1,sb2)).start();
        }
        int bound = Cute.input.Integer();
        Cute.Assume(bound<=3);
        for(int i=0;i<bound;i++){
            (new MyThread2(sb1)).start();
        }
        bound = Cute.input.Integer();
        Cute.Assume(bound<=3);
        for(int i=0;i<bound;i++){
            (new MyThread2(sb2)).start();
        }
    }


}


class MyThread1 extends Thread{
    StringBuffer2jpct sb1;
    StringBuffer2jpct sb2;

    public MyThread1(StringBuffer2jpct sb1, StringBuffer2jpct sb2) {
        this.sb1 = sb1;
        this.sb2 = sb2;
    }

    public void run() {
            sb1.append(sb2);
    }
}

class MyThread2 extends Thread{
    StringBuffer2jpct sb;

    public MyThread2(StringBuffer2jpct sb) {
        this.sb = sb;
    }

    public void run() {

        int toss = Cute.input.Integer();

        if(toss==0){
            char c = Cute.input.Character();
            sb.append(c);
        } else if(toss==1){
            sb.setLength(0);
        } else if(toss==2){
            char c2 = Cute.input.Character();
            int index = Cute.input.Integer();
            synchronized(sb){
//******************Transformed code started****************************
if(index>=0){
if(index<=sb.length()-1){}
 else{}
 }
 else {}
//******************Transformed code end****************************
                Cute.Assume(index>=0 && index <= sb.length()-1);
                sb.insert(index,c2);
            }
        }
    }
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=false
//@jcute.optionLogTraceAndInput=false
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=100
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
