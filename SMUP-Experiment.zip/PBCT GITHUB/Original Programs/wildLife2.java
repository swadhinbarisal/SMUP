/*
 * Copyright (c) 2016, NIT Rourkela
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package tests;

import cute.Cute;

/**
 *  .
 * User: ADutta
 * Date: Jan 11, 2016
 * Time: 7:38:52 AM
 * To change this template use File | Settings | File Templates.
 */

class MyException extends RuntimeException {

}

public class wildLife2 {


    public static int  carnivorous(int animal_var1, int animal_var3){
          if((animal_var1>199) && (animal_var3<50)||(animal_var1>919) && (animal_var3<1000)){
            System.out.println("carnivorous");
        } else {
            return 2*animal_var1+1;
        }
           if((animal_var1>10) || (animal_var3<5) &&(animal_var1>animal_var3))
           {System.out.println(" hello Java");}
		            //throw new MyException();

        if((animal_var1>10) || (animal_var3<5)){
		            throw new MyException();
		        } else {
		            return 2*animal_var1+1;
        }
    }
     public static int  omnivorous(int animal_var1,int animal_var2, int animal_var3){
          if((animal_var1>919) && (animal_var3<1000)||(animal_var3!=908)){
            System.out.println("omnivorous");
        } else {
            return 2*animal_var1+1;
        }
          if((animal_var1>9) || (animal_var3>1000)&&(animal_var3!=908)){
            System.out.println("omnivorous");
        }
          else
          {
            return 2*animal_var1+1;
        }
          if((animal_var1>91) && (animal_var2<1000)||(animal_var3!=908)){
            System.out.println("omnivorous1");
        }
          else
          {
            return 2*animal_var1+1;
        }
          if((animal_var1>19) && (animal_var3<102)&&(animal_var3!=908)){
            System.out.println("omnivorous3");
        }
          else
          {
            return 2*animal_var1+1;
        }
        if((animal_var1>19) && (animal_var3<102)&&(animal_var3!=908)){
		            System.out.println("omnivorous3");
		        }
		          else
		          {
		            return 2*animal_var3+1;
        }
          if((animal_var1>919) || (animal_var3<10003)||(animal_var3!=908)){
            System.out.println("omnivorous4");
        }
          else
          {
            return 2*animal_var1+1;
        }
          if((animal_var1>900) && (animal_var3<1000)||(animal_var3!=908)){
            System.out.println("omnivorous5");
        }
          else
          {
            return 2*animal_var1+1;
        }
          if((animal_var1>=120) && (animal_var3==1000)||(animal_var3!=908)){
            System.out.println("omnivorous5");
        }
          else
          {
            return 2*animal_var1+1;
        }
          if((animal_var1>120) || (animal_var3<15)||(animal_var1>919) && (animal_var3<1000)){
            System.out.println("omnivorous5");
        }
          else
          {
            return 2*animal_var1+1;
        }
        if((animal_var1>120) || (animal_var3<15)||(animal_var1>919) && (animal_var3<1000)){
		            throw new MyException();
		        } else {
		            return 2*animal_var1+1;
        }
    }

    public static int herbivorous(int animal_var1,int animal_var2){
        int ret = carnivorous(animal_var2,animal_var1) * 46;
        return ret;
    }
    public static int animal_kingdom(int animal_var1,int animal_var2,int animal_var3){
        int ret = omnivorous(animal_var1,animal_var2,animal_var3) * 46;
        return ret;
    }

    public static void main(String[] args) {
        int animal_var1 = Cute.input.Integer();
        int animal_var2 = Cute.input.Integer();
		 int animal_var13 = Cute.input.Integer();
		  int animal_var14 = Cute.input.Integer();
		  
        switch(animal_var1){
            case -1000:
                animal_var2=1;
                break;
            case 0:
             int animal_var3 =  herbivorous(animal_var1,animal_var14);
            if(animal_var3==69)
            {
                System.out.println("animal_var2 = " + animal_var2);

            }
                break;
            case 1000:
                int animal_var4 =  animal_kingdom(animal_var1,animal_var2,animal_var13);
            if(animal_var4==69)
            {
                System.out.println("animal_var2 = " + animal_var2);

            }
                break;
            default:
                animal_var2=4;
        }
       
    }
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
