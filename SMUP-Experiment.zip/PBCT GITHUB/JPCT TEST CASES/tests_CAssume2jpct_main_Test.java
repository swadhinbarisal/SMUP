
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class tests_CAssume2jpct_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public tests_CAssume2jpct_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(2025002287);
        input[i++] = new Integer(-227803757);
        input[i++] = new Integer(270176682);
        input[i++] = new Integer(1770524006);
        input[i++] = new Integer(-317229386);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2jpct.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(-227803757);
        input[i++] = new Integer(270176682);
        input[i++] = new Integer(1770524006);
        input[i++] = new Integer(-317229386);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2jpct.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(-227803757);
        input[i++] = new Integer(270176682);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-317229386);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2jpct.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(-227803757);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(-317229386);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2jpct.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(0);
        input[i++] = new Integer(-227803757);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(-317229386);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2jpct.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(0);
        input[i++] = new Integer(-227803757);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-317229386);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2jpct.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(0);
        input[i++] = new Integer(-227803757);
        input[i++] = new Integer(801);
        input[i++] = new Integer(800);
        input[i++] = new Integer(-317229386);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2jpct.main(null);
    }

    public void test9(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(-227803757);
        input[i++] = new Integer(1001);
        input[i++] = new Integer(1001);
        input[i++] = new Integer(-317229386);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2jpct.main(null);
    }

    public void test10(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(-227803757);
        input[i++] = new Integer(1001);
        input[i++] = new Integer(1001);
        input[i++] = new Integer(1001);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2jpct.main(null);
    }

    public void test12(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(1);
        input[i++] = new Integer(-227803757);
        input[i++] = new Integer(1001);
        input[i++] = new Integer(1001);
        input[i++] = new Integer(1001);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2jpct.main(null);
    }

    public void test13(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(100);
        input[i++] = new Integer(-227803757);
        input[i++] = new Integer(1001);
        input[i++] = new Integer(1001);
        input[i++] = new Integer(1001);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2jpct.main(null);
    }

    public void test16(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(0);
        input[i++] = new Integer(-227803757);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1001);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2jpct.main(null);
    }

    public void test44(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(-227803757);
        input[i++] = new Integer(800);
        input[i++] = new Integer(800);
        input[i++] = new Integer(800);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2jpct.main(null);
    }

}
