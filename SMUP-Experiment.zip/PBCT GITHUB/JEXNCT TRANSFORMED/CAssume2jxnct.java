package jxnct;

import cute.Cute;

/**
 *  .
 * User: ksen
 * Date: Oct 25, 2005
 * Time: 7:38:52 PM
 * To change this template use File | Settings | File Templates.
 */

class MyException extends RuntimeException {

}

public class CAssume2jxnct {


    public static int f(int x, int z){
if(!(z<50))
{
    if(!(x>199)){}
    else if(!!(x>199)){}
}
if(!(x>199))
{
    if(!(z<50)){}
    else if(!!(z<50)){}
}
//************************Modified code Start***********************************
 if(!(z<50)){
if(x>199){}
else if(!(x>199)){}
}
else{}
 if(!(x>199)){
if(z<50){}
else if(!(z<50)){}
}
else{}
//************************Modified code end***********************************
        if((x>199) && (z<50)){
            System.out.println("hello world");
        } else {
            return 2*x+1;
        }
//************************Modified code Start***********************************
 if((z<5)){
if(x>10){}
else if(!(x>10)){}
}
else{}
 if((x>10)){
if(z<5){}
else if(!(z<5)){}
}
else{}
//************************Modified code end***********************************
        if((x>10) || (z<5)){
		            throw new MyException();
		        } else {
		            return 2*x+1;
        }
    }

    public static int g(int y){
        int ret = f(y,11) * 23;
        return ret;
    }

    public static void main(String[] args) {
        int x = Cute.input.Integer();
        int y = Cute.input.Integer();
        int team1 = Cute.input.Integer();
		            int team2 = Cute.input.Integer();
		            int team3 = Cute.input.Integer();

        switch(x){
            case -100:
                y=1;

//************************Modified code Start***********************************
 if((team2<800)){
if(team1>=team2){}
else if(!(team1>=team2)){}
}
else{}
 if((team1>=team2)){
if(team2<800){}
else if(!(team2<800)){}
}
else{}
//************************Modified code end***********************************
				                    if((team1>=team2)||(team2<800))
				                    {
//************************Modified code Start***********************************
 if((team2>1000)){
if(team3!=team2){}
else if(!(team3!=team2)){}
}
else{}
 if((team3!=team2)){
if(team2>1000){}
else if(!(team2>1000)){}
}
else{}
//************************Modified code end***********************************
				                        if((team3!=team2)||(team2>1000))
				                        {
				                            System.out.println("The india is great");
				                        }
				                    }
                    System.out.println("hello world");
                break;
            case 0:
                y = 2;
//************************Modified code Start***********************************
 if((team2<800)&&(90<team3)){
if(team1<=team2){}
else if(!(team1<=team2)){}
}
else{}
 if(!(90<team3)||(team1<=team2)){
if(team2<800){}
else if(!(team2<800)){}
}
else{}
 if(!(team2<800)||(team1<=team2)){
if(90<team3){}
else if(!(90<team3)){}
}
else{}
//************************Modified code end***********************************
                if((team1<=team2)||(team2<800)&&(90<team3))
                    System.out.println("hello india");
                break;
            case 100:
                y = 3;
                break;
            default:
                y=4;
        }
        try {
            int z = g(x);
            if(z==69){
                System.out.println("y = " + y);
            }
        } catch(MyException e){
            y = x+10;
            if(y==250)
                System.out.println("OOPS ...");
        }
    }
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=false
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
