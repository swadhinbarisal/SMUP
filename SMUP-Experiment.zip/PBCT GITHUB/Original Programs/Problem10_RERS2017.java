package A1;

import cute.Cute;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Problem10_RERS2017 {
	static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

	private String[] inputs = {"B","E","C","A","D"};

	public int a41 = Cute.input.Integer();
	public int a13 = Cute.input.Integer();
	public int a175 = Cute.input.Integer();
	public int a161 = Cute.input.Integer();
	public int a196 = Cute.input.Integer();
	public int a11 = Cute.input.Integer();
	public boolean cf = Cute.input.Boolean();
	public boolean input = Cute.input.Boolean();
	public int a137 = Cute.input.Integer();
	public int a69 = Cute.input.Integer();
	public int a165 = Cute.input.Integer();
	public int a141 = Cute.input.Integer();
	public int a187 = Cute.input.Integer();
	public int a179 = Cute.input.Integer();
	public int a168 = Cute.input.Integer();
	public int a19 = Cute.input.Integer();
	public int a55 = Cute.input.Integer();
	public int a149 = Cute.input.Integer();
	public int a49 = Cute.input.Integer();
	public int a62 = Cute.input.Integer();
	public int a26 = Cute.input.Integer();
	public int a114 = Cute.input.Integer();
	public int a3 = Cute.input.Integer();
	public int a73 = Cute.input.Integer();
	public int a188 = Cute.input.Integer();
	public int a16 = Cute.input.Integer();
	public int a50 = Cute.input.Integer();
	public int a97 = Cute.input.Integer();
	public int a68 = Cute.input.Integer();
	public int a65 = Cute.input.Integer();
	public int a148 = Cute.input.Integer();
	public int a126 = Cute.input.Integer();
	public int a170 = Cute.input.Integer();
	public int a173 = Cute.input.Integer();
	public int a152 = Cute.input.Integer();
	public int a169 = Cute.input.Integer();

	private void errorCheck() {
	    if((a169 ==0) && (a41==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("0");
	    }
	    if((a126 ==0) || (a173 ==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("1");
	    }
	    if((a196 ==0) && (a50 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("2");
	    }
	    if((a3 ==0) || (a114==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("3");
	    }
	    if((a137==0) && (a114==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("4");
	    }
	    if((a152==0) && (a173 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("5");
	    }
	    if((a16 ==0) || (a50 ==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("6");
	    }
	    if((a65 ==0) && (a50 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("7");
	    }
	    if((a187 ==0) || (a161 ==00) && (a62==0)){
	    	cf = false;
	    	System.out.println("8");
	    }
	    if((a41==0) && (a173 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("9");
	    }
	    if((a141 ==0) || (a50 ==00) && (a62==0)){
	    	cf = false;
	    	System.out.println("10");
	    }
	    if((a3 ==0) && (a114==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("11");
	    }
	    if((a196 ==0) || (a50 ==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("12");
	    }
	    if((a179==0) || (a161 ==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("13");
	    }
	    if((a16 ==0) && (a50 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("14");
	    }
	    if((a41==0) && (a173 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("15");
	    }
	    if((a26 ==0) && (a161 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("16");
	    }
	    if((a187 ==0) || (a161 ==00) && (a62==0)){
	    	cf = false;
	    	System.out.println("17");
	    }
	    if((a65 ==0) || (a50 ==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("18");
	    }
	    if((a161 ==0) || (a173 ==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("19");
	    }
	    if((a55==0) && (a41==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("20");
	    }
	    if((a175 ==0) && (a50 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("21");
	    }
	    if((a69==0) && (a114==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("22");
	    }
	    if((a165 ==00) || (a41==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("23");
	    }
	    if((a188==0) || (a41==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("24");
	    }
	    if((a168==0) && (a161 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("25");
	    }
	    if((a11 ==0) && (a50 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("26");
	    }
	    if((a3 ==0) || (a114==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("27");
	    }
	    if((a126 ==0) && (a173 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("28");
	    }
	    if((a49 ==0) && (a161 ==0) || (a62==0)){
	    	cf = false;
	    	System.out.println("29");
	    }
	    if((a65 ==0) || (a50 ==0) && (a62==0)){
	    	cf = false;
	    	System.out.println("30");
	    }
	    

	}
	
private  void calculateOutputm35(boolean input) {
    if((a161 ==00) || (input==false) || (cf==false) && (a62==0) && (a173 ==0)){
    	cf = false;
    	a62 =0;
    	a73 =0;
    	a50 = 13; 
    	System.out.println("Y");
    } 
    if((input==false) && (a173 ==0) || (a161 ==00) || (cf==false) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a173 = 7; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm37(boolean input) {
    if((a161 ==0) || (input==false) && (cf==false) || (a173 ==0) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a188 =0; 
    	System.out.println("Z");
    } 
    if((a173 ==0) || (a62==0) && (cf==false) && (input==false) && (a161 ==0)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a152 =0; 
    	System.out.println("Z");
    } 
    if((a173 ==0) || (cf==false) && (a161 ==0) || (a62==0) || (input==false)){
    	cf = false;
    	a50 = 11;
    	a62 =0;
    	a11 = 7; 
    	System.out.println("S");
    } 
}
private  void calculateOutputm1(boolean input) {
    if((a161 ==00) && (cf==false)) {
    	calculateOutputm35(input);
    } 
    if((a161 ==0) || (cf==false)) {
    	calculateOutputm37(input);
    } 
}
private  void calculateOutputm40(boolean input) {
    if((a68==0) && (a62==0) || (cf==false) || (a173 ==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a161 = 9;
    	a49 = 9; 
    	System.out.println("Y");
    } 
    if((input==false) || (a62==0) && (cf==false) || (a173 ==0) && (a68==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a188 =0; 
    	System.out.println("X");
    } 
    if((a68==0) && (a62==0) || (input==false) || (cf==false) && (a173 ==0)){
    	cf = false;
    	a173 = 12;
    	a126 = 7; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm41(boolean input) {
    if((a62==0) && (a68==0) || (input==false) && (cf==false) || (a173 ==0)){
    	cf = false;
    	a161 = 9;
    	a62 =0;
    	a49 = 5; 
    	System.out.println("V");
    } 
    if((a68==0) || (a62==0) && (input==false) && (cf==false) || (a173 ==0)){
    	cf = false;
    	 
    	System.out.println("T");
    } 
}
private  void calculateOutputm2(boolean input) {
    if((cf==false) || (a68==0)){
    	calculateOutputm40(input);
    } 
    if((a68==0) && (cf==false)) {
    	calculateOutputm41(input);
    } 
}
private  void calculateOutputm46(boolean input) {
    if((a173 ==0) || (a41==0) || (cf==false) && (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a73 =0;
    	a50 = 13; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm47(boolean input) {
    if((cf==false) || (a62==0) && (a41==0) && (a173 ==0) || (input==false)){
    	cf = false;
    	a62 =0;
    	a50 = 14;
    	a16 = 7; 
    	System.out.println("T");
    } 
    if((a173 ==0) && (cf==false) || (a41==0) || (a62==0) && (input==false)){
    	cf = false;
    	a50 = 11;
    	a62 =0;
    	a11 = 12; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm3(boolean input) {
    if((a41==0) && (cf==false)) {
    	calculateOutputm46(input);
    } 
    if((cf==false) || (a41==0)){
    	calculateOutputm47(input);
    } 
}
private  void calculateOutputm48(boolean input) {
    if((input==false) || (a62==0) && (cf==false) || (a152==0) && (a173 ==0)){
    	cf = false;
    	a62 =0;
    	a50 = 8;
    	a196 = 6; 
    	System.out.println("Z");
    } 
    if((a173 ==0) && (a62==0) || (input==false) || (cf==false) && (a152==0)){
    	cf = false;
    	a173 = 5;
    	a161 = 12; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm49(boolean input) {
    if((a152==0) && (a173 ==0) || (cf==false) || (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a165 = 16; 
    	System.out.println("V");
    } 
    if((a152==0) && (a173 ==0) || (input==false) || (cf==false) && (a62==0)){
    	cf = false;
    	a173 = 12;
    	a126 = 11; 
    	System.out.println("U");
    } 
    if((input==false) || (cf==false) && (a62==0) || (a173 ==0) && (a152==0)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a69 =0; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm51(boolean input) {
    if((a173 ==0) || (input==false) || (a62==0) && (cf==false) && (a152==0)){
    	cf = false;
    	a62 =0;
    	a161 = 14;
    	a26 = 15; 
    	System.out.println("T");
    } 
    if((a62==0) && (a173 ==0) || (a152==0) || (cf==false) && (input==false)){
    	cf = false;
    	a149 =0;
    	a173 = 11; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm52(boolean input) {
    if((a173 ==0) && (a152==0) || (a62==0) || (cf==false) && (input==false)){
    	cf = false;
    	a50 = 11;
    	a62 =0;
    	a11 = 9; 
    	System.out.println("T");
    } 
    if((input==false) && (a173 ==0) || (cf==false) || (a152==0) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a169 = 5; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm4(boolean input) {
    if((a152==0) && (cf==false)) {
    	calculateOutputm48(input);
    } 
    if((a152==0) || (cf==false)) {
    	calculateOutputm49(input);
    } 
    if((a152==0) && (cf==false)) {
    	calculateOutputm51(input);
    } 
    if((cf==false) || (a152==0)){
    	calculateOutputm52(input);
    } 
}
private  void calculateOutputm54(boolean input) {
    if((a26 ==0) || (a173 ==0) && (cf==false) || (input==false) && (a62==0)){
    	cf = false;
    	a26 = 17; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm55(boolean input) {
    if((cf==false) && (a62==0) || (input==false) || (a173 ==0) && (a26 ==0)){
    	cf = false;
    	a62 =0;
    	a179 =0;
    	a161 = 13; 
    	System.out.println("U");
    } 
    if((a62==0) || (a26 ==0) && (a173 ==0) || (cf==false) || (input==false)){
    	cf = false;
    	a173 = 10;
    	a13 = 14; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm57(boolean input) {
    if((a173 ==0) || (input==false) || (a62==0) && (cf==false) && (a26 ==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a188 =0; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm60(boolean input) {
    if((a26 ==0) && (input==false) || (cf==false) || (a62==0) && (a173 ==0)){
    	cf = false;
    	a62 =0;
    	a50 = 15;
    	a170 = 16; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm5(boolean input) {
    if((cf==false) || (a26 ==0)){
    	calculateOutputm54(input);
    } 
    if((cf==false) && (a26 ==0)){
    	calculateOutputm55(input);
    } 
    if((a26 ==0) || (cf==false)) {
    	calculateOutputm57(input);
    } 
    if((a26 ==0) && (cf==false)) {
    	calculateOutputm60(input);
    } 
}
private  void calculateOutputm61(boolean input) {
    if((a13 ==0) || (a62==0) && (input==false) || (cf==false) && (a173 ==00)){
    	cf = false;
    	a161 = 9;
    	a62 =0;
    	a49 = 9; 
    	System.out.println("Y");
    } 
    if((a13 ==0) && (a173 ==00) || (cf==false) || (input==false) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a188 =0; 
    	System.out.println("X");
    } 
    if((input==false) || (a62==0) && (a173 ==00) && (cf==false) || (a13 ==0)){
    	cf = false;
    	a50 = 15;
    	a62 =0;
    	a170 = 11; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm62(boolean input) {
    if((input==false) || (cf==false) || (a62==0) || (a173 ==00) && (a13 ==0)){
    	cf = false;
    	a50 = 14;
    	a62 =0;
    	a16 = 6; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm64(boolean input) {
    if((input==false) || (cf==false) && (a62==0) || (a173 ==00) && (a13 ==0)){
    	cf = false;
    	a62 =0;
    	a50 = 11;
    	a11 = 8; 
    	System.out.println("Z");
    } 
    if((input==false) && (cf==false) || (a13 ==0) && (a62==0) || (a173 ==00)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a55 =0; 
    	System.out.println("S");
    } 
    if((a13 ==0) || (a62==0) && (a173 ==0) || (cf==false) && (input==false)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a55 =0; 
    	System.out.println("V");
    } 
    if((a62==0) && (a13 ==0) && (cf==false) && (a173 ==0) && (input==false)){
    	cf = false;
    	a68 =0;
    	a62 =0;
    	a161 = 15; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm6(boolean input) {
    if((a13 ==0) && (cf==false)) {
    	calculateOutputm61(input);
    } 
    if((cf==false) || (a13 ==0)){
    	calculateOutputm62(input);
    } 
    if((cf==false) && (a13 ==0)){
    	calculateOutputm64(input);
    } 
}
private  void calculateOutputm65(boolean input) {
    if((a149==0) || (input==false) && (cf==false) || (a62==0) && (a173 ==0)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a69 =0; 
    	System.out.println("U");
    } 
    if((input==false) || (a173 ==0) && (cf==false) || (a62==0) && (a149==0)){
    	cf = false;
    	a173 = 9;
    	a26 = 14; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm68(boolean input) {
    if((a149==0) || (input==false) && (a173 ==0) || (cf==false) && (a62==0)){
    	cf = false;
    	a161 = 9;
    	a62 =0;
    	a49 = 5; 
    	System.out.println("V");
    } 
    if((a173 ==0) || (cf==false) && (a62==0) || (input==false) && (a149==0)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a69 =0; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm7(boolean input) {
    if((a149==0) && (cf==false)) {
    	calculateOutputm65(input);
    } 
    if((cf==false) || (a149==0)){
    	calculateOutputm68(input);
    } 
}
private  void calculateOutputm69(boolean input) {
    if((a62==0) || (a126 ==0) && (a173 ==0) || (cf==false) && (input==false)){
    	cf = false;
    	a126 = 13; 
    	System.out.println("W");
    } 
    if((input==false) || (cf==false) && (a126 ==0) || (a62==0) && (a173 ==0)){
    	cf = false;
    	a179 =0;
    	a62 =0;
    	a161 = 13; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm8(boolean input) {
    if((a126 ==0) && (cf==false)) {
    	calculateOutputm69(input);
    } 
}
private  void calculateOutputm78(boolean input) {
    if((a55==0) || (cf==false) && (a41==0) || (a62==0) && (input==false)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a3 = 14; 
    	System.out.println("V");
    } 
    if((a62==0) && (a55==0) || (cf==false) || (input==false) && (a41==0)){
    	cf = false;
    	a68 =0;
    	a62 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm9(boolean input) {
    if((a55==0) && (cf==false)) {
    	calculateOutputm78(input);
    } 
}
private  void calculateOutputm82(boolean input) {
    if((a62==0) || (cf==false) && (a41==0) || (a169 ==0) && (input==false)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a137 =0; 
    	System.out.println("V");
    } 
    if((input==false) && (a62==0) || (a41==0) || (cf==false) && (a169 ==0)){
    	cf = false;
    	a50 = 15;
    	a62 =0;
    	a170 = 14; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm10(boolean input) {
    if((a169 ==0) && (cf==false)) {
    	calculateOutputm82(input);
    } 
}
private  void calculateOutputm84(boolean input) {
    if((input==false) || (a188==0) && (cf==false) || (a62==0) && (a41==0)){
    	cf = false;
    	a188 =0; 
    	System.out.println("U");
    } 
    if((a41==0) && (a62==0) || (cf==false) || (a188==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a137 =0; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm85(boolean input) {
    if((a188==0) && (a62==0) || (cf==false) || (input==false) && (a41==0)){
    	cf = false;
    	a62 =0;
    	a161 = 12;
    	a148 = 4; 
    	System.out.println("T");
    } 
    if((input==false) || (a62==0) && (cf==false) || (a188==0) && (a41==0)){
    	cf = false;
    	a188 =0; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm86(boolean input) {
    if((a62==0) && (cf==false) || (input==false) || (a188==0) && (a41==0)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a69 =0; 
    	System.out.println("U");
    } 
    if((a62==0) && (a188==0) && (a41==0) && (cf==false) && (input==false)){
    	cf = false;
    	a41 =0;
    	a165 = 16; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm87(boolean input) {
    if((cf==false) || (input==false) && (a188==0) || (a41==0) && (a62==0)){
    	cf = false;
    	a161 = 9;
    	a62 =0;
    	a49 = 9; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm11(boolean input) {
    if((cf==false) && (a188==0)){
    	calculateOutputm84(input);
    } 
    if((cf==false) || (a188==0)){
    	calculateOutputm85(input);
    } 
    if((cf==false) && (a188==0)){
    	calculateOutputm86(input);
    } 
    if((a188==0) || (cf==false)) {
    	calculateOutputm87(input);
    } 
}
private  void calculateOutputm89(boolean input) {
    if((input==false) || (cf==false) || (a62==0) && (a165 ==0) && (a41==0)){
    	cf = false;
    	a168 =0;
    	a62 =0;
    	a161 = 11; 
    	System.out.println("U");
    } 
    if((a165 ==0) && (input==false) || (cf==false) || (a62==0) && (a41==0)){
    	cf = false;
    	a41 =0;
    	a165 = 11; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm90(boolean input) {
    if((cf==false) || (input==false) && (a165 ==00) || (a41==0) && (a62==0)){
    	cf = false;
    	a68 =0;
    	a62 =0;
    	a173 = 6; 
    	System.out.println("W");
    } 
    if((input==false) && (a165 ==00) || (cf==false) || (a62==0) && (a41==0)){
    	cf = false;
    	a50 = 8;
    	a62 =0;
    	a196 = 5; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm93(boolean input) {
    if((a41==0) || (cf==false) && (a62==0) || (input==false) || (a165 ==0)){
    	cf = false;
    	a41 =0;
    	a188 =0; 
    	System.out.println("Z");
    } 
    if((a165 ==0) || (input==false) || (a41==0) && (cf==false) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a188 =0; 
    	System.out.println("Z");
    } 
    if((input==false) && (cf==false) || (a41==0) || (a165 ==0) && (a62==0)){
    	cf = false;
    	a41 =0; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm94(boolean input) {
    if((a62==0) || (input==false) && (cf==false) || (a165 ==0) && (a41==0)){
    	cf = false;
    	a161 = 14;
    	a62 =0;
    	a26 = 10; 
    	System.out.println("T");
    } 
    if((a62==0) && (a41==0) || (a165 ==0) || (cf==false) && (input==false)){
    	cf = false;
    	a19 =0;
    	a62 =0;
    	a161 = 16; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm12(boolean input) {
    if((cf==false) && (a165 ==0)){
    	calculateOutputm89(input);
    } 
    if((a165 ==00) || (cf==false)) {
    	calculateOutputm90(input);
    } 
    if((a165 ==0) && (cf==false)) {
    	calculateOutputm93(input);
    } 
    if((cf==false) || (a165 ==0)){
    	calculateOutputm94(input);
    } 
}
private  void calculateOutputm99(boolean input) {
    if((a165 ==0) || (input==false) && (a62==0) || (cf==false) && (a41==0)){
    	cf = false;
    	a41 =0;
    	a188 =0; 
    	System.out.println("Z");
    } 
    if((input==false) || (cf==false) && (a62==0) || (a165 ==0) && (a41==0)){
    	cf = false;
    	a41 =0;
    	a188 =0; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm101(boolean input) {
    if((a41==0) && (cf==false) || (a165 ==0) || (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a50 = 15;
    	a170 = 16; 
    	System.out.println("Y");
    } 
    if((a62==0) || (a165 ==0) || (input==false) && (cf==false) && (a41==0)){
    	cf = false;
    	a62 =0;
    	a149 =0;
    	a173 = 11; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm102(boolean input) {
    if((cf==false) && (a62==0) || (a165 ==0) || (a41==0) && (input==false)){
    	cf = false;
    	a41 =0;
    	a188 =0; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm13(boolean input) {
    if((a165 ==0) && (cf==false)) {
    	calculateOutputm99(input);
    } 
    if((a165 ==0) || (cf==false)) {
    	calculateOutputm101(input);
    } 
    if((a165 ==0) && (cf==false)) {
    	calculateOutputm102(input);
    } 
}
private  void calculateOutputm104(boolean input) {
    if((a62==0) || (a161 ==0) || (cf==false) && (a49 ==0) || (input==false)){
    	cf = false;
    	a19 =0;
    	a161 = 16; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm105(boolean input) {
    if((a49 ==0) && (a62==0) || (cf==false) || (input==false) && (a161 ==0)){
    	cf = false;
    	a161 = 12;
    	a148 = 4; 
    	System.out.println("T");
    } 
    if((a161 ==0) && (input==false) || (cf==false) || (a49 ==0) && (a62==0)){
    	cf = false;
    	a50 = 14;
    	a62 =0;
    	a16 = 10; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm108(boolean input) {
    if((a161 ==0) && (input==false) || (a49 ==0) || (cf==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a69 =0; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm110(boolean input) {
    if((cf==false) || (a49 ==0) && (a62==0) || (a161 ==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a188 =0; 
    	System.out.println("U");
    } 
    if((a62==0) && (cf==false) || (a161 ==0) || (input==false) && (a49 ==0)){
    	cf = false;
    	a62 =0;
    	a152 =0;
    	a173 = 8; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm14(boolean input) {
    if((a49 ==0) && (cf==false)) {
    	calculateOutputm104(input);
    } 
    if((a49 ==0) || (cf==false)) {
    	calculateOutputm105(input);
    } 
    if((a49 ==0) && (cf==false)) {
    	calculateOutputm108(input);
    } 
    if((a49 ==0) || (cf==false)) {
    	calculateOutputm110(input);
    } 
}
private  void calculateOutputm111(boolean input) {
    if((a62==0) && (cf==false) || (a161 ==00) || (a187 ==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a152 =0;
    	a173 = 8; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm115(boolean input) {
    if((a187 ==0) || (cf==false) && (a161 ==00) || (a62==0) && (input==false)){
    	cf = false;
    	a187 = 10; 
    	System.out.println("Y");
    } 
    if((a161 ==00) || (cf==false) && (a62==0) || (a187 ==0) && (input==false)){
    	cf = false;
    	a68 =0;
    	a62 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
    if((input==false) || (a62==0) || (cf==false) && (a187 ==0) && (a161 ==00)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a137 =0; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm15(boolean input) {
    if((cf==false) && (a187 ==0)){
    	calculateOutputm111(input);
    } 
    if((cf==false) || (a187 ==0)){
    	calculateOutputm115(input);
    } 
}
private  void calculateOutputm121(boolean input) {
    if((cf==false) || (a62==0) && (a161 ==0) || (a168==0) && (input==false)){
    	cf = false;
    	a179 =0;
    	a161 = 13; 
    	System.out.println("U");
    } 
    if((a62==0) || (cf==false) && (a161 ==0) || (input==false) || (a168==0)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a69 =0; 
    	System.out.println("U");
    } 
    if((input==false) && (a161 ==0) || (a62==0) || (a168==0) && (cf==false)){
    	cf = false;
    	a68 =0;
    	a161 = 15; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm122(boolean input) {
    if((a161 ==0) && (a168==0) || (cf==false) || (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a152 =0; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm16(boolean input) {
    if((cf==false) || (a168==0)){
    	calculateOutputm121(input);
    } 
    if((a168==0) && (cf==false)) {
    	calculateOutputm122(input);
    } 
}
private  void calculateOutputm126(boolean input) {
    if((a62==0) && (a161 ==0) || (cf==false) || (a148 ==0) && (input==false)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a165 = 11; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm17(boolean input) {
    if((a148 ==0) && (cf==false)) {
    	calculateOutputm126(input);
    } 
}
private  void calculateOutputm130(boolean input) {
    if((a179==0) || (input==false) || (cf==false) && (a62==0) && (a161 ==0)){
    	cf = false;
    	a161 = 9;
    	a49 = 6; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm131(boolean input) {
    if((a62==0) && (input==false) || (cf==false) || (a161 ==0) && (a179==0)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a173 = 7; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm133(boolean input) {
    if((a62==0) && (cf==false) || (a161 ==0) || (a179==0) && (input==false)){
    	cf = false;
    	a50 = 9;
    	a62 =0;
    	a175 = 9; 
    	System.out.println("V");
    } 
    if((input==false) || (a62==0) && (a161 ==0) || (cf==false) && (a179==0)){
    	cf = false;
    	a168 =0;
    	a161 = 11; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm18(boolean input) {
    if((cf==false) && (a179==0)){
    	calculateOutputm130(input);
    } 
    if((cf==false) || (a179==0)){
    	calculateOutputm131(input);
    } 
    if((a179==0) && (cf==false)) {
    	calculateOutputm133(input);
    } 
}
private  void calculateOutputm134(boolean input) {
    if((a161 ==0) || (a26 ==0) && (cf==false) || (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
    if((a26 ==00) && (a62==0) || (cf==false) || (input==false) && (a161 ==0)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a97 =0; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm136(boolean input) {
    if((a62==0) && (a26 ==0) || (input==false) && (cf==false) || (a161 ==0)){
    	cf = false;
    	a62 =0;
    	a50 = 10;
    	a141 = 8; 
    	System.out.println("X");
    } 
    if((a62==0) || (a161 ==0) && (cf==false) || (input==false) && (a26 ==0)){
    	cf = false;
    	a62 =0;
    	a173 = 9;
    	a26 = 13; 
    	System.out.println("W");
    } 
    if((a161 ==0) || (input==false) || (cf==false) || (a26 ==0) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a114 =0;
    	a3 = 10; 
    	System.out.println("T");
    } 
    if((a26 ==0) && (cf==false) || (a161 ==0) && (input==false) || (a62==0)){
    	cf = false;
    	a161 = 9;
    	a49 = 5; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm137(boolean input) {
    if((a161 ==0) || (a62==0) && (cf==false) || (input==false) && (a26 ==0)){
    	cf = false;
    	a50 = 9;
    	a62 =0;
    	a175 = 7; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm19(boolean input) {
    if((a26 ==00) || (cf==false)) {
    	calculateOutputm134(input);
    } 
    if((cf==false) && (a26 ==0)){
    	calculateOutputm136(input);
    } 
    if((a26 ==0) || (cf==false)) {
    	calculateOutputm137(input);
    } 
}
private  void calculateOutputm139(boolean input) {
    if((a68==0) && (a62==0) || (cf==false) || (input==false) && (a161 ==0)){
    	cf = false;
    	a73 =0;
    	a62 =0;
    	a50 = 13; 
    	System.out.println("V");
    } 
    if((input==false) && (a161 ==0) || (cf==false) || (a62==0) && (a68==0)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
    if((a68==0) || (a161 ==0) || (a62==0) && (cf==false) && (input==false)){
    	cf = false;
    	a161 = 9;
    	a49 = 5; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm140(boolean input) {
    if((input==false) && (cf==false) || (a68==0) && (a161 ==0) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a50 = 15;
    	a170 = 10; 
    	System.out.println("V");
    } 
    if((a161 ==0) && (input==false) || (a68==0) || (cf==false) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a165 = 9; 
    	System.out.println("T");
    } 
    if((a68==0) && (a161 ==0) || (cf==false) || (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a188 =0; 
    	System.out.println("U");
    } 
    if((a68==0) || (a161 ==0) || (cf==false) && (a62==0) && (input==false)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a3 = 13; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm141(boolean input) {
    if((input==false) || (cf==false) && (a161 ==0) || (a68==0) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a188 =0; 
    	System.out.println("X");
    } 
    if((a68==0) && (cf==false) || (a161 ==0) || (a62==0) && (input==false)){
    	cf = false;
    	a50 = 9;
    	a62 =0;
    	a175 = 13; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm142(boolean input) {
    if((cf==false) || (a68==0) && (a161 ==0) || (a62==0) && (input==false)){
    	cf = false;
    	a161 = 12;
    	a148 = 4; 
    	System.out.println("T");
    } 
    if((input==false) || (a161 ==0) && (a62==0) || (cf==false) && (a68==0)){
    	cf = false;
    	a152 =0;
    	a62 =0;
    	a173 = 8; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm20(boolean input) {
    if((cf==false) || (a68==0)){
    	calculateOutputm139(input);
    } 
    if((cf==false) && (a68==0)){
    	calculateOutputm140(input);
    } 
    if((a68==0) || (cf==false)) {
    	calculateOutputm141(input);
    } 
    if((cf==false) && (a68==0)){
    	calculateOutputm142(input);
    } 
}
private  void calculateOutputm143(boolean input) {
    if((a161 ==0) && (a62==0) || (cf==false) || (input==false) && (a19==0)){
    	cf = false;
    	a68 =0;
    	a62 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
    if((a161 ==0) || (cf==false) && (a62==0) || (a19==0) || (input==false)){
    	cf = false;
    	 
    	System.out.println("V");
    } 
}
private  void calculateOutputm145(boolean input) {
    if((a161 ==0) || (cf==false) && (input==false) || (a62==0) && (a19==0)){
    	cf = false;
    	a173 = 9;
    	a62 =0;
    	a26 = 16; 
    	System.out.println("Z");
    } 
    if((input==false) || (a19==0) && (a161 ==0) || (cf==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
    if((a62==0) && (a161 ==0) || (cf==false) && (a19==0) || (input==false)){
    	cf = false;
    	a19 =0; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm21(boolean input) {
    if((cf==false) && (a19==0)){
    	calculateOutputm143(input);
    } 
    if((cf==false) || (a19==0)){
    	calculateOutputm145(input);
    } 
}
private  void calculateOutputm147(boolean input) {
    if((a62==0) && (cf==false) || (a196 ==0) || (input==false) && (a50 ==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a165 = 14; 
    	System.out.println("V");
    } 
    if((a50 ==0) || (input==false) && (cf==false) || (a62==0) && (a196 ==0)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a3 = 8; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm149(boolean input) {
    if((input==false) || (cf==false) && (a196 ==0) || (a50 ==0) || (a62==0)){
    	cf = false;
    	a50 = 12;
    	a65 = 5; 
    	System.out.println("U");
    } 
    if((a196 ==0) && (a50 ==0) && (a62==0) && (cf==false) && (input==false)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a169 = 3; 
    	System.out.println("U");
    } 
    if((a50 ==0) && (a196 ==0) && (cf==false) && (input==false) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a165 = 10; 
    	System.out.println("Y");
    } 
    if((input==false) && (cf==false) && (a50 ==0) && (a196 ==0) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a173 = 6; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm22(boolean input) {
    if((cf==false) && (a196 ==0)){
    	calculateOutputm147(input);
    } 
    if((cf==false) && (a196 ==0)){
    	calculateOutputm149(input);
    } 
}
private  void calculateOutputm153(boolean input) {
    if((a62==0) && (cf==false) && (input==false) && (a50 ==0) && (a175 ==0)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
    if((a62==0) && (input==false) && (a175 ==0) && (cf==false) && (a50 ==0)){
    	cf = false;
    	a62 =0;
    	a19 =0;
    	a161 = 16; 
    	System.out.println("V");
    } 
    if((a62==0) && (cf==false) && (input==false) && (a175 ==0) && (a50 ==0)){
    	cf = false;
    	a62 =0;
    	a161 = 9;
    	a49 = 4; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm154(boolean input) {
    if((a50 ==0) && (a175 ==0) && (cf==false) && (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a188 =0; 
    	System.out.println("Z");
    } 
    if((a50 ==0) && (a175 ==0) && (input==false) && (cf==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a161 = 15; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm156(boolean input) {
    if((input==false) && (cf==false) && (a62==0) && (a50 ==0) && (a175 ==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a173 = 7; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm23(boolean input) {
    if((cf==false) && (a175 ==0)){
    	calculateOutputm153(input);
    } 
    if((a175 ==0) && (cf==false)) {
    	calculateOutputm154(input);
    } 
    if((cf==false) && (a175 ==0)){
    	calculateOutputm156(input);
    } 
}
private  void calculateOutputm169(boolean input) {
    if((a50 ==0) && (a11 ==0) && (cf==false) && (input==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a188 =0; 
    	System.out.println("U");
    } 
    if((a62==0) && (cf==false) && (a50 ==0) && (a11 ==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a161 = 12;
    	a148 = 4; 
    	System.out.println("T");
    } 
    if((a62==0) && (cf==false) && (a50 ==0) && (a11 ==0) && (input==false)){
    	cf = false;
    	a50 = 10;
    	a141 = 10; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm170(boolean input) {
    if((a11 ==0) && (input==false) && (cf==false) && (a50 ==0) && (a62==0)){
    	cf = false;
    	a149 =0;
    	a62 =0;
    	a173 = 11; 
    	System.out.println("T");
    } 
    if((a11 ==0) && (a50 ==0) && (input==false) && (cf==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a161 = 9;
    	a49 = 5; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm171(boolean input) {
    if((a62==0) && (cf==false) && (a11 ==00) && (a50 ==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a173 = 9;
    	a26 = 12; 
    	System.out.println("Z");
    } 
    if((a50 ==0) && (a62==0) && (cf==false) && (input==false) && (a11 ==00)){
    	cf = false;
    	a62 =0;
    	a161 = 10;
    	a187 = 3; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm173(boolean input) {
    if((a11 ==0) && (a62==0) && (input==false) && (cf==false) && (a50 ==0)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a69 =0; 
    	System.out.println("U");
    } 
    if((input==false) && (a50 ==0) && (a11 ==0) && (cf==false) && (a62==0)){
    	cf = false;
    	a179 =0;
    	a62 =0;
    	a161 = 13; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm174(boolean input) {
    if((cf==false) && (a62==0) && (input==false) && (a50 ==0) && (a11 ==0)){
    	cf = false;
    	a50 = 8;
    	a196 = 9; 
    	System.out.println("W");
    } 
    if((a62==0) && (input==false) && (cf==false) && (a11 ==0) && (a50 ==0)){
    	cf = false;
    	a50 = 15;
    	a170 = 12; 
    	System.out.println("V");
    } 
    if((a62==0) && (a11 ==0) && (a50 ==0) && (input==false) && (cf==false)){
    	cf = false;
    	a68 =0;
    	a62 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm25(boolean input) {
    if((cf==false) && (a11 ==0)){
    	calculateOutputm169(input);
    } 
    if((cf==false) && (a11 ==0)){
    	calculateOutputm170(input);
    } 
    if((a11 ==00) && (cf==false)) {
    	calculateOutputm171(input);
    } 
    if((a11 ==0) && (cf==false)) {
    	calculateOutputm173(input);
    } 
    if((a11 ==0) && (cf==false)) {
    	calculateOutputm174(input);
    } 
}
private  void calculateOutputm176(boolean input) {
    if((a50 ==0) && (cf==false) && (a65 ==0) && (input==false) && (a62==0)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a55 =0; 
    	System.out.println("T");
    } 
    if((input==false) && (a50 ==0) && (a65 ==0) && (cf==false) && (a62==0)){
    	cf = false;
    	a161 = 9;
    	a62 =0;
    	a49 = 5; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm26(boolean input) {
    if((cf==false) && (a65 ==0)){
    	calculateOutputm176(input);
    } 
}
private  void calculateOutputm181(boolean input) {
    if((input==false) && (a50 ==0) && (cf==false) && (a62==0) && (a73==0)){
    	cf = false;
    	a173 = 10;
    	a62 =0;
    	a13 = 12; 
    	System.out.println("W");
    } 
    if((input==false) && (a73==0) && (a62==0) && (cf==false) && (a50 ==0)){
    	cf = false;
    	a62 =0;
    	a173 = 9;
    	a26 = 11; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm183(boolean input) {
    if((input==false) && (a73==0) && (cf==false) && (a62==0) && (a50 ==0)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a97 =0; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm27(boolean input) {
    if((cf==false) && (a73==0)){
    	calculateOutputm181(input);
    } 
    if((cf==false) && (a73==0)){
    	calculateOutputm183(input);
    } 
}
private  void calculateOutputm187(boolean input) {
    if((input==false) && (a50 ==0) && (a16 ==0) && (cf==false) && (a62==0)){
    	cf = false;
    	a152 =0;
    	a62 =0;
    	a173 = 8; 
    	System.out.println("Z");
    } 
    if((a50 ==0) && (cf==false) && (input==false) && (a16 ==0) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a161 = 9;
    	a49 = 11; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm188(boolean input) {
    if((input==false) && (a50 ==0) && (cf==false) && (a16 ==0) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a173 = 10;
    	a13 = 16; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm191(boolean input) {
    if((a50 ==0) && (cf==false) && (input==false) && (a62==0) && (a16 ==00)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a165 = 16; 
    	System.out.println("V");
    } 
    if((a16 ==00) && (cf==false) && (a50 ==0) && (a62==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a161 = 9;
    	a49 = 10; 
    	System.out.println("V");
    } 
    if((a62==0) && (a16 ==00) && (a50 ==0) && (cf==false) && (input==false)){
    	cf = false;
    	a114 =0;
    	a62 =0;
    	a69 =0; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm28(boolean input) {
    if((cf==false) && (a16 ==0)){
    	calculateOutputm187(input);
    } 
    if((a16 ==0) && (cf==false)) {
    	calculateOutputm188(input);
    } 
    if((a16 ==00) && (cf==false)) {
    	calculateOutputm191(input);
    } 
}
private  void calculateOutputm193(boolean input) {
    if((a50 ==0) && (cf==false) && (a170 ==0) && (a62==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a179 =0;
    	a161 = 13; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm194(boolean input) {
    if((a170 ==0) && (a50 ==0) && (cf==false) && (input==false) && (a62==0)){
    	cf = false;
    	a50 = 9;
    	a175 = 6; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm196(boolean input) {
    if((a62==0) && (cf==false) && (a50 ==0) && (a170 ==0) && (input==false)){
    	cf = false;
    	a50 = 11;
    	a11 = 13; 
    	System.out.println("T");
    } 
    if((a62==0) && (a50 ==0) && (cf==false) && (input==false) && (a170 ==0)){
    	cf = false;
    	a73 =0;
    	a50 = 13; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm198(boolean input) {
    if((a62==0) && (input==false) && (cf==false) && (a170 ==0) && (a50 ==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a173 = 7; 
    	System.out.println("S");
    } 
    if((a50 ==0) && (input==false) && (cf==false) && (a170 ==0) && (a62==0)){
    	cf = false;
    	a73 =0;
    	a50 = 13; 
    	System.out.println("W");
    } 
    if((a170 ==0) && (a50 ==0) && (cf==false) && (input==false) && (a62==0)){
    	cf = false;
    	a173 = 5;
    	a62 =0;
    	a161 = 10; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm29(boolean input) {
    if((cf==false) && (a170 ==0)){
    	calculateOutputm193(input);
    } 
    if((a170 ==0) && (cf==false)) {
    	calculateOutputm194(input);
    } 
    if((cf==false) && (a170 ==0)){
    	calculateOutputm196(input);
    } 
    if((a170 ==0) && (cf==false)) {
    	calculateOutputm198(input);
    } 
}
private  void calculateOutputm200(boolean input) {
    if((input==false) && (cf==false) && (a62==0) && (a97==0) && (a114==0)){
    	cf = false;
    	a62 =0;
    	a152 =0;
    	a173 = 8; 
    	System.out.println("U");
    } 
    if((a97==0) && (cf==false) && (a62==0) && (a114==0) && (input==false)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a161 = 15; 
    	System.out.println("T");
    } 
    if((cf==false) && (input==false) && (a62==0) && (a114==0) && (a97==0)){
    	cf = false;
    	a62 =0;
    	a19 =0;
    	a161 = 16; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm201(boolean input) {
    if((a62==0) && (input==false) && (a114==0) && (cf==false) && (a97==0)){
    	cf = false;
    	a161 = 10;
    	a62 =0;
    	a187 = 7; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm30(boolean input) {
    if((a97==0) && (cf==false)) {
    	calculateOutputm200(input);
    } 
    if((cf==false) && (a97==0)){
    	calculateOutputm201(input);
    } 
}
private  void calculateOutputm203(boolean input) {
    if((a62==0) && (a114==0) && (cf==false) && (a69==0) && (input==false)){
    	cf = false;
    	a179 =0;
    	a62 =0;
    	a161 = 13; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm205(boolean input) {
    if((input==false) && (cf==false) && (a62==0) && (a69==0) && (a114==0)){
    	cf = false;
    	a69 =0; 
    	System.out.println("T");
    } 
    if((a69==0) && (a62==0) && (a114==0) && (input==false) && (cf==false)){
    	cf = false;
    	a50 = 12;
    	a62 =0;
    	a65 = 4; 
    	System.out.println("T");
    } 
    if((a114==0) && (a69==0) && (input==false) && (cf==false) && (a62==0)){
    	cf = false;
    	a161 = 9;
    	a62 =0;
    	a49 = 5; 
    	System.out.println("V");
    } 
    if((a62==0) && (input==false) && (cf==false) && (a69==0) && (a114==0)){
    	cf = false;
    	a50 = 8;
    	a62 =0;
    	a196 = 4; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm206(boolean input) {
    if((a69==0) && (input==false) && (a114==0) && (cf==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a165 = 11; 
    	System.out.println("Z");
    } 
    if((input==false) && (a69==0) && (a62==0) && (cf==false) && (a114==0)){
    	cf = false;
    	a50 = 12;
    	a62 =0;
    	a65 = 11; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm31(boolean input) {
    if((cf==false) && (a69==0)){
    	calculateOutputm203(input);
    } 
    if((a69==0) && (cf==false)) {
    	calculateOutputm205(input);
    } 
    if((cf==false) && (a69==0)){
    	calculateOutputm206(input);
    } 
}
private  void calculateOutputm207(boolean input) {
    if((a114==0) && (a152==0) && (a62==0) && (cf==false) && (input==false)){
    	cf = false;
    	a62 =0;
    	a168 =0;
    	a161 = 11; 
    	System.out.println("U");
    } 
    if((a114==0) && (cf==false) && (a62==0) && (a152==0) && (input==false)){
    	cf = false;
    	a114 =0;
    	a69 =0; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm209(boolean input) {
    if((a114==0) && (cf==false) && (a152==0) && (input==false)&& (a62==0)){
    	cf = false;
    	a50 = 8;
    	a62 =0;
    	a196 = 7; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm32(boolean input) {
    if((a152==0) && (cf==false)) {
    	calculateOutputm207(input);
    } 
    if((a152==0) && (cf==false)) {
    	calculateOutputm209(input);
    } 
}
private  void calculateOutputm211(boolean input) {
    if((input==false) && (a62==0) && (cf==false) && (a137==0) && (a114==0)){
    	cf = false;
    	a62 =0;
    	a161 = 14;
    	a26 = 14; 
    	System.out.println("T");
    } 
    if((a114==0) && (a137==0) && (input==false) && (cf==false) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a41 =0;
    	a165 = 14; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm212(boolean input) {
    if((a62==0) && (cf==false) && (input==false) && (a137==0) && (a114==0)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
    if((input==false) && (a114==0) && (cf==false) && (a137==0) && (a62==0)){
    	cf = false;
    	a62 =0;
    	a161 = 12;
    	a148 = 2; 
    	System.out.println("Y");
    } 
    if((input==false) && (a137==0) && (a114==0) && (cf==false) && (a62==0)){
    	cf = false;
    	a19 =0;
    	a62 =0;
    	a161 = 16; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm214(boolean input) {
    if((a137==0) && (cf==false) && (a62==0) && (a114==0) && (input==false)){
    	cf = false;
    	a41 =0;
    	a62 =0;
    	a165 = 13; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm33(boolean input) {
    if((cf==false) && (a137==0)){
    	calculateOutputm211(input);
    } 
    if((cf==false) && (a137==0)){
    	calculateOutputm212(input);
    } 
    if((a137==0) && (cf==false)) {
    	calculateOutputm214(input);
    } 
}
private  void calculateOutputm216(boolean input) {
    if((input==false) && (cf==false) && (a62==0) && (a114==0) && (a3 ==00)){
    	cf = false;
    	a62 =0;
    	a68 =0;
    	a173 = 6; 
    	System.out.println("T");
    } 
    if((input==false) && (a3 ==00) && (a114==0) && (cf==false) && (a62==0)){
    	cf = false;
    	a173 = 12;
    	a62 =0;
    	a126 = 10; 
    	System.out.println("T");
    } 
    if((a114==0) && (a62==0) && (cf==false) && (a3 ==00) && (input==false)){
    	cf = false;
    	a161 = 9;
    	a62 =0;
    	a49 = 5; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm220(boolean input) {
    if((a114==0) && (cf==false) && (input==false) && (a62==0) && (a3 ==0)){
    	cf = false;
    	a62 =0;
    	a19 =0;
    	a161 = 16; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm34(boolean input) {
    if((cf==false) && (a3 ==00)){
    	calculateOutputm216(input);
    } 
    if((cf==false) && (a3 ==0)){
    	calculateOutputm220(input);
    } 
}



public  void calculateOutput(boolean input) {
 	cf = true;
    	if((cf==false) && (a173 ==0)){
    		calculateOutputm1(input);
    	} 
    	if((a173 ==0) && (cf==false)) {
    		calculateOutputm2(input);
    	} 
    	if((a173 ==0) && (cf==false)) {
    		calculateOutputm3(input);
    	} 
    	if((cf==false) && (a173 ==0)){
    		calculateOutputm4(input);
    	} 
    	if((a173 ==0) && (cf==false)) {
    		calculateOutputm5(input);
    	} 
    	if((a173 ==00) && (cf==false)) {
    		calculateOutputm6(input);
    	} 
    	if((cf==false) && (a173 ==0)){
    		calculateOutputm7(input);
    	} 
    	if((a173 ==0) && (cf==false)) {
    		calculateOutputm8(input);
    	} 
    	if((cf==false) && (a41==0)){
    		calculateOutputm9(input);
    	} 
    	if((cf==false) && (a41==0)){
    		calculateOutputm10(input);
    	} 
    	if((a41==0) && (cf==false)) {
    		calculateOutputm11(input);
    	} 
    	if((cf==false) && (a41==0)){
    		calculateOutputm12(input);
    	} 
    	if((a41==0) && (cf==false)) {
    		calculateOutputm13(input);
    	} 
    	if((cf==false) && (a161 ==0)){
    		calculateOutputm14(input);
    	} 
    	if((cf==false) && (a161 ==00)){
    		calculateOutputm15(input);
    	} 
    	if((cf==false) && (a161 ==0)){
    		calculateOutputm16(input);
    	} 
    	if((a161 ==0) && (cf==false)) {
    		calculateOutputm17(input);
    	} 
    	if((cf==false) && (a161 ==0)){
    		calculateOutputm18(input);
    	} 
    	if((cf==false) && (a161 ==0)){
    		calculateOutputm19(input);
    	} 
    	if((a161 ==0) && (cf==false)) {
    		calculateOutputm20(input);
    	} 
    	if((a161 ==0) && (cf==false)) {
    		calculateOutputm21(input);
    	} 
    	if((a50 ==0) && (cf==false)) {
    		calculateOutputm22(input);
    	} 
    	if((a50 ==0) && (cf==false)) {
    		calculateOutputm23(input);
    	} 
    	if((cf==false) && (a50 ==0)){
    		calculateOutputm25(input);
    	} 
    	if((cf==false) && (a50 ==0)){
    		calculateOutputm26(input);
    	} 
    	if((cf==false) && (a50 ==0)){
    		calculateOutputm27(input);
    	} 
    	if((a50 ==0) && (cf==false)) {
    		calculateOutputm28(input);
    	} 
    	if((cf==false) && (a50 ==0)){
    		calculateOutputm29(input);
    	} 
    	if((a114==0) && (cf==false)) {
    		calculateOutputm30(input);
    	} 
    	if((a114==0) && (cf==false)) {
    		calculateOutputm31(input);
    	} 
    	if((cf==false) && (a114==0)){
    		calculateOutputm32(input);
    	} 
    	if((a114==0) && (cf==false)) {
    		calculateOutputm33(input);
    	} 
    	if((cf==false) && (a114==0)){
    		calculateOutputm34(input);
    	} 
    

    errorCheck();
    if(cf==false)
    	throw new IllegalArgumentException("Current state has no transition for this input!");
}


public static void main() throws Exception 
	{
	     // init system and input reader
            Problem10_RERS2017 eca = new Problem10_RERS2017();
        int a=0;
	int x;
        int y;
         
        x = Cute.input.Integer();
        y = Cute.input.Integer();
		boolean input = Cute.input.Boolean();
			// main i/o-loop
            while(a<10) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                	 eca.calculateOutput(input);
					 
				}
				
				if (x>299 && x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutput(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
	}
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
