
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class tests_CAssume2_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public tests_CAssume2_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-121899002);
        input[i++] = new Integer(2021626405);
        input[i++] = new Integer(-1290473211);
        input[i++] = new Integer(1914219985);
        input[i++] = new Integer(981326891);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(2021626405);
        input[i++] = new Integer(-1290473211);
        input[i++] = new Integer(1914219985);
        input[i++] = new Integer(981326891);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(2021626405);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(981326891);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2.main(null);
    }

    public void test4(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(2021626405);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(2021626405);
        input[i++] = new Integer(1001);
        input[i++] = new Integer(1001);
        input[i++] = new Integer(1001);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(-100);
        input[i++] = new Integer(2021626405);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(1001);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2.main(null);
    }

    public void test8(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(0);
        input[i++] = new Integer(2021626405);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2.main(null);
    }

    public void test9(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(0);
        input[i++] = new Integer(2021626405);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2.main(null);
    }

    public void test10(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(0);
        input[i++] = new Integer(2021626405);
        input[i++] = new Integer(801);
        input[i++] = new Integer(800);
        input[i++] = new Integer(1);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2.main(null);
    }

    public void test21(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(0);
        input[i++] = new Integer(2021626405);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        input[i++] = new Integer(91);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2.main(null);
    }

    public void test22(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(1);
        input[i++] = new Integer(2021626405);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        input[i++] = new Integer(91);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2.main(null);
    }

    public void test23(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(100);
        input[i++] = new Integer(2021626405);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        input[i++] = new Integer(91);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2.main(null);
    }

    public void test25(){
        i=0;
        input = new Object[5];
        input[i++] = new Integer(200);
        input[i++] = new Integer(2021626405);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        input[i++] = new Integer(91);
        i=0;
        cute.Cute.input = this;
        tests.CAssume2.main(null);
    }

}
